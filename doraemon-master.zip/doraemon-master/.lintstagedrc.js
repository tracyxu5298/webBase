module.exports = {
  '*.{js,ts,tsx,vue}': ['prettier --write', 'eslint --fix'],
  '*.{vue,css,scss}': ['prettier --write'],
};
