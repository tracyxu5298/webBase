# 使用说明

## VSCode 必备插件

- VSCode 左测导航点击`Extensions` --> 展开`RECOMMENDED` --> 点击`Install`
- 推荐扩展详细配置 `.vscode/extensions.json`

## Git 全局设置

```shell
git config --global user.name "linbin"
git config --global user.email "linbin@leedarson.com"
# git config --list
# git config --get user.name
```

## 分支管理

1. 功能分支统一从master分支拉取；
2. hotfix分支统一从当前线上最新的tag拉取（一般情况下等同于master分支）；
3. hotfix上线后对应分支会合并到master分支；
4. 测试时根据pjm或测试的安排将功能分支合并到test1或test2（若无安排，默认月中版本合并到test1，月末版本合并到test2）；
5. 迭代进入pre阶段时，代码会从test分支合并到master分支；
6. develop分支只做开发阶段测试用，可合并任意分支，但是不可合并到其他分支；

## 命名规范

- 大驼峰法, 即第一个字母大写, 后面单词首字母大写

  1.  组件目录名, 比如 `views/SystemSettings/`
  2.  组件文件名, 比如 `views/SystemSettings/ThemeSettingsView.vue`
  3.  路由路径, 比如
      ```js
      const routes = {
        path: '/SystemSettings', // 路由路径
        name: 'SystemSettings',
        component: () => import('../views/SystemSettings/SystemSettingsView.vue'),
        children: [
          {
            path: 'ThemeSettings', // 路由路径
            name: 'ThemeSettings',
            component: () => import('../views/ThemeSettingsView.vue'),
          },
        ],
      };
      ```

- 小驼峰法, 即第一个字母小写, 后面单词首字母大写

  1. stores 数据状态管理, 比如 `stores/userInfo.ts`
  2. hooks 业务复用钩子, 比如 `hooks/useHttp.ts`
  3. helper 帮助工具函数, 比如 `helper/getDateTime.ts`

## 安装依赖

```shell
yarn install

# yarn config get registry
# yarn config set registry <url-to-your-registry>
# yarn config delete registry
# yarn config list
```

## 开发本地调试

```shell
yarn dev
```

## 生产构建发布

```shell
yarn build:xxx
```

## 添加依赖

```shell
# 添加 dependencies 依赖包
yarn workspace xxx add vue
# 添加 devDependencies 依赖包
yarn workspace xxx add vue-tsc -D
```

## 删除依赖

```shell
yarn workspace xxx remove vue
```

## TODO

1. "stylelint-config-standard-scss": "11.0.0",
