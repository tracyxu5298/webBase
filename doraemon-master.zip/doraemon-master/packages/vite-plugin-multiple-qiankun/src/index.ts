import { resolve, join } from 'path';
import type { Plugin, ResolvedConfig } from 'vite';
import type { OutputChunk } from 'rollup';
import fse from 'fs-extra';
import type { CheerioAPI, Element } from 'cheerio';
import cheerio from 'cheerio';

interface PagesOptions {
  qiankunName: string;
  basename: string;
  entry: string;
  output: string;
  htmlTemplate: string;
}

interface Options {
  baseEntry: string;
  pages: PagesOptions[];
  useDevMode?: boolean;
}

const DEFAULT_TEMPLATE = 'index.html';

const createQiankunHelper = (qiankunName: string) => `
  const createDeffer = (hookName) => {
    const d = new Promise((resolve, reject) => {
      window.proxy && (window.proxy[\`vite\${hookName}\`] = resolve)
    })
    return props => d.then(fn => fn(props));
  }
  const bootstrap = createDeffer('bootstrap');
  const mount = createDeffer('mount');
  const unmount = createDeffer('unmount');
  const update = createDeffer('update');

  ;(global => {
    global.qiankunName = '${qiankunName}';
    global['${qiankunName}'] = {
      bootstrap,
      mount,
      unmount,
      update
    };
  })(window);
`;

const createImportFinallyResolve = (qiankunName: string) => {
  return `
    const qiankunLifeCycle = window.moudleQiankunAppLifeCycles && window.moudleQiankunAppLifeCycles['${qiankunName}'];
    if (qiankunLifeCycle) {
      window.proxy.vitemount((props) => qiankunLifeCycle.mount(props));
      window.proxy.viteunmount((props) => qiankunLifeCycle.unmount(props));
      window.proxy.vitebootstrap(() => qiankunLifeCycle.bootstrap());
      window.proxy.viteupdate((props) => qiankunLifeCycle.update(props));
    }
  `;
};

export default function plugin(options: Options): Plugin {
  let isProduction: boolean;
  let viteConfig: ResolvedConfig;
  const inputKeys: Record<string, PagesOptions> = {};
  const assets: Record<string, OutputChunk> = {};

  const module2DynamicImport = (
    $: CheerioAPI,
    scriptTag: Element,
    qiankunName: string,
    basename: string,
  ) => {
    if (!scriptTag) {
      return;
    }
    const script$ = $(scriptTag);
    const moduleSrc = script$.attr('src');
    let appendBase = '';
    if (options.useDevMode && !isProduction) {
      appendBase =
        "(window.proxy ? (window.proxy.__INJECTED_PUBLIC_PATH_BY_QIANKUN__ + '../..') : '') + ";
    }
    script$.removeAttr('src');
    script$.removeAttr('type');

    const asset = assets[qiankunName];
    const assetUrl = asset?.fileName ? join(viteConfig.base, asset.fileName) : moduleSrc;
    script$.html(
      `if(window.proxy){window.proxy.__QIANKUN_BASENAME__='${basename}';}
      import(${appendBase}'${assetUrl}')`,
    );

    const modulePreloads = $('head link[rel="modulepreload"]');
    modulePreloads.remove();
    // modulePreloads.each((i, modulePreload) => {
    //   $(modulePreload).attr('href', assetUrl);
    // });

    return script$;
  };

  return {
    name: 'vite-plugin-multiple-qiankun',
    enforce: 'pre',
    configResolved(resolvedConfig: ResolvedConfig) {
      viteConfig = resolvedConfig;
      isProduction = resolvedConfig.command === 'build' || resolvedConfig.isProduction;
    },
    config(config) {
      const input: Record<string, string> = {};
      if (options.pages?.length) {
        options.pages.forEach((option) => {
          input[option.qiankunName] = resolve(config.root || '', option.entry);
          inputKeys[option.qiankunName] = option;
        });
      }

      input['index'] = resolve(config.root || '', DEFAULT_TEMPLATE);

      return {
        build: {
          rollupOptions: {
            input,
          },
        },
      };
    },
    transformIndexHtml(html, ctx) {
      if (!isProduction) {
        const key = ctx.originalUrl?.replace(/^\/?/i, '').replace(/\/?$/i, '').replace(/\//, '__');
        if (key && inputKeys[key]) {
          const { qiankunName, basename } = inputKeys[key];

          const $ = cheerio.load(html);
          const moduleTags = $('body script[type=module], head script[crossorigin=""]');
          if (!moduleTags || !moduleTags.length) {
            return;
          }
          const len = moduleTags.length;
          moduleTags.each((i, moduleTag) => {
            const script$ = module2DynamicImport($, moduleTag, qiankunName, basename);
            if (len - 1 === i) {
              script$?.html(`${script$.html()}.finally(() => {
                ${createImportFinallyResolve(qiankunName)}
              })`);
            }
          });

          $('body').append(`<script>${createQiankunHelper(qiankunName)}</script>`);
          const output = $.html();
          return output;
        }
      }
      return html;
    },
    generateBundle: (o, bundle) => {
      Object.values(bundle).forEach((asset) => {
        if (asset.type == 'chunk' && inputKeys[asset.name]) {
          assets[asset.name] = asset;
        }
      });
    },
    async closeBundle() {
      if (isProduction) {
        const distDir = resolve(viteConfig.root, viteConfig.build.outDir);

        if (options.pages?.length) {
          const baseHtmlPath = resolve(distDir, 'index.html');
          const baseHtml = await fse.readFile(baseHtmlPath, 'utf-8');
          const task: Promise<void>[] = [];
          options.pages.forEach((page) => {
            const html = baseHtml.slice();
            const $ = cheerio.load(html);
            const moduleTags = $('body script[type=module], head script[crossorigin=""]');
            if (!moduleTags || !moduleTags.length) {
              return;
            }
            const len = moduleTags.length;
            moduleTags.each((i, moduleTag) => {
              const script$ = module2DynamicImport($, moduleTag, page.qiankunName, page.basename);
              if (len - 1 === i) {
                script$?.html(`${script$.html()}.finally(() => {
                  ${createImportFinallyResolve(page.qiankunName)}
                })`);
              }
            });

            $('body').append(`<script>${createQiankunHelper(page.qiankunName)}</script>`);
            const output = $.html();

            if (page.output) {
              const outpath = join(distDir, page.output);
              task.push(fse.outputFile(outpath, output));
            }
          });

          await Promise.all(task);
        }

        if (options.baseEntry && assets[options.baseEntry]) {
          const baseAsset = assets[options.baseEntry];
          const baseAssetPath = resolve(distDir, baseAsset.fileName);
          const baseAssetContent = await fse.readFile(baseAssetPath, 'utf-8');
          const task: Promise<void>[] = [];

          Object.entries(assets).forEach(([key, asset]) => {
            if (key !== options.baseEntry) {
              const assetPath = resolve(distDir, asset.fileName);
              task.push(fse.outputFile(assetPath, baseAssetContent));
            }
          });

          await Promise.all(task);
        }
      }
    },
  };
}
