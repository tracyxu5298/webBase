import typescript from '@rollup/plugin-typescript';

export default {
	input: [
    'src/index.ts',
    'src/helper.ts',
  ],
  output: {
    dir: 'dist',
    format: 'cjs',
  },
  external: ['path', 'fs-extra', 'cheerio'],
	plugins: [
		typescript({
      compilerOptions: {
        declaration: true,
        declarationDir: 'dist',
      },
    }),
	]
};
