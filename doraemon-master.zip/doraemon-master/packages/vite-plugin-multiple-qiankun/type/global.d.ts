declare interface Window {
  proxy: Window;
  moudleQiankunAppLifeCycles: any;
  __GLOBAL_CONCURENT_QIANKUN__?: any;
}
