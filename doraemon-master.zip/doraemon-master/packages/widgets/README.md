# 工作台小组件开发文档

---

## 在业务线仓库，开发小组件

#### 小组件目录（包名：@lexikos/xxx-widgets）

```shell
  ├── packages
  |     ├── widgets
  |     |     ├── lib
  |     |     |     ├── WidgetName             \* 小组件名称目录（大驼峰）
  |     |     |     |     ├── index.vue        \* 小组件文件
  |     |     |     ├── main.ts                \* 导出所有小组件
  |     |     ├── package.json                 \* 包管理配置文件
  |     |     ├── README.md                    \* 开发文档
  |     |     ├── tsconfig.json                \* TypeScript 配置文件
  |     |     ├── vite.config.ts               \* Vite 配置文件
```

#### 开发小组件

- 大驼峰命名法, 即第一个字母大写, 后面单词首字母大写
- 组件目录和组件文件名称，建议使用大驼峰命名法

1. 在 `lib` 目录下，添加小组件目录 `WidgetName`
2. 在 `WidgetName` 目录下，添加小组件 `index.vue` 和其它文件

   ```html
   <!-- 可以使用中台提供的组件 `WidgetCard` 包裹 -->
   <script setup lang="ts">
     import { WidgetCard } from '@lexikos/doraemon-business';
   </script>
   <template>
     <WidgetCard>
       <template #title>小组件名称</template>
       <template #button>
         <a-button type="link" @click="handleClick">更多</a-button>
       </template>
       <template #body>小组件内容</template>
     </WidgetCard>
   </template>
   ```

3. 在 `main.ts` 文件中，导出 `WidgetName` 小组件

   ```ts
   export { default as WidgetName } from './WidgetName/index.vue';
   ```

---

## 在BOSS网站，配置小组件

> 新基座开发的小组件使用 `package` 的方式引入，对应的配置如下

```json
{
  "w": 1, // 宽度即列数: 1|2|3 (最多占3列)
  "h": 150, // 高度（单位：px）
  "mode": "package", // 导入方式："package" | "iframe"
  "repository": "@lexikos/xxx-widgets", // 小组件包
  "component": "WidgetName" // 小组件名
}
```

> 旧基座开发的小组件使用 `iframe` 的方式引入，对应的配置如下

```json
{
  "w": 1, // 宽度即列数: 1|2|3 (最多占3列)
  "h": 150, // 高度（单位：px）
  "mode": "iframe", // 导入方式："package" | "iframe"
  "url": "https://imp.leedarson.com/xxx/yyy"
}
```

---

## 在中台仓库，集成小组件

1. 添加业务线小组件包依赖 `projects\imp-platform\package.json`

   ```json
   "dependencies": {
      "@lexikos/xxx-widgets": "0.1.0",
   }
   ```

2. 修改工作台小组件渲染器 `projects\imp-platform\src\views\Workbench\components\RenderWidget.vue`

   ```typescript
   import * as xxxWidgets from '@lexikos/xxx-widgets';

   const widgetComponentMap: Record<string, Component> = {
     ...xxxWidgets,
   };
   ```

---

## `doraemon`调试`产品线`最新代码

1. 在`产品线`工程, 依次执行如下命令

   ```shell
    cd packages/widgets && yarn link
   ```

2. 在`doraemon`工程, 执行如下命令

   ```shell
    yarn lk2;
   ```

3. Git 拉取`产品线`最新代码
