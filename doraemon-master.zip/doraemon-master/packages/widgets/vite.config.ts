import { resolve } from 'path';
import { fileURLToPath, URL } from 'node:url';
import { defineConfig } from 'vite';
import dts from 'vite-plugin-dts';
import vue from '@vitejs/plugin-vue';
import vueJsx from '@vitejs/plugin-vue-jsx';
import packageJson from './package.json';
import svgLoader from 'vite-svg-loader';

function alias(relativeLibPath: string) {
  return fileURLToPath(new URL(relativeLibPath, import.meta.url));
}

export default defineConfig({
  resolve: {
    alias: {
      // '@': fileURLToPath(new URL('../../packages/business/lib', import.meta.url)),
      '@lexikos/doraemon-business': alias('../../packages/business/lib/main.ts'),
      '@lexikos/doraemon-network': alias('../../packages/network/lib/main.ts'),
    },
  },
  plugins: [
    vue(),
    vueJsx(),
    dts({
      rollupTypes: true,
    }),
    svgLoader({
      defaultImport: 'component',
      svgoConfig: {
        multipass: true,
      },
    }),
  ],
  build: {
    lib: {
      entry: resolve(__dirname, 'lib/main.ts'),
      name: 'doraemonWidgets',
      formats: ['es', 'umd'],
      fileName: (format) => `index.${format}.js`,
    },
    sourcemap: true,
    rollupOptions: {
      external: [...Object.keys(packageJson.dependencies)],
    },
  },
});
