<script lang="ts" setup>
import { WidgetCard } from '../../../business/lib/components';
import { useRouter } from 'vue-router';
import {
  useNoticeCenterService,
  type NoticeItem,
  ReadStatus,
  useNoticeDetail,
} from '@lexikos/doraemon-business';
import { ref } from 'vue';
import dayjs from 'dayjs';
import { theme } from 'ant-design-vue';
import { Empty } from 'ant-design-vue';
const simpleImage = Empty.PRESENTED_IMAGE_SIMPLE;

const { token } = theme.useToken();
const router = useRouter();

const { getNoticePage } = useNoticeCenterService();
const { handleNoticeDetail } = useNoticeDetail();

const noticeList = ref<NoticeItem[]>([]);
const noticeListLoading = ref(false);

const init = async () => {
  noticeListLoading.value = true;
  const res = await getNoticePage({ pageNum: 1, pageSize: 4 }).finally(() => {
    noticeListLoading.value = false;
  });
  noticeList.value = res.result;
};

const handleMore = () => {
  router.push('/NoticeCenter');
};

init();
</script>
<template>
  <WidgetCard>
    <template #button><a class="link" @click="handleMore">更多</a></template>
    <template #body>
      <div class="wrap">
        <a-spin :spinning="noticeListLoading">
          <div class="list">
            <div v-if="!noticeList.length" class="empty-wrap">
              <a-empty :image="simpleImage"></a-empty>
            </div>
            <div
              v-for="item in noticeList"
              :class="[
                'item',
                {
                  'is-unread': item.readStatus === ReadStatus.Unread,
                },
              ]"
              :key="item.id"
              @click="handleNoticeDetail(item)"
            >
              <div class="title-wrap">
                <span :title="item.title" class="title-text">
                  {{ item.title }}
                </span>
                <span class="title-time">{{
                  dayjs(item.notifyTime).format('YYYY-MM-DD HH:mm')
                }}</span>
              </div>
              <div class="desc-wrap">
                <span :title="item.content" class="desc-text">
                  {{ item.content }}
                </span>
                <a class="desc-btn link"> 详情 </a>
              </div>
            </div>
          </div>
        </a-spin>
      </div>
    </template>
  </WidgetCard>
</template>
<style lang="scss" scoped>
.link {
  color: v-bind('token.colorPrimaryText');
  &:hover {
    color: v-bind('token.colorPrimaryTextHover');
  }
}

.wrap {
  padding: 0 20px;
}
.list {
  color: v-bind('token.colorText');
  margin-top: 8px;
  height: 224px;
  .empty-wrap {
    height: 100%;
    display: flex;
    align-items: center;
    justify-content: center;
  }
  .item {
    margin-bottom: 16px;
    cursor: pointer;
    &.is-unread {
      .title-wrap {
        &::before {
          position: absolute;
          content: ' ';
          display: block;
          width: 6px;
          height: 6px;
          border-radius: 50%;
          background-color: v-bind('token.colorError');
          left: -12px;
        }
      }
    }
  }
  .title {
    &-wrap {
      display: flex;
      line-height: 20px;
      align-items: center;
      position: relative;
    }
    &-text {
      flex: auto;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
      color: v-bind('token.colorText');
      font-weight: bold;
    }
    &-time {
      flex: none;
      margin-left: 16px;
      color: v-bind('token.colorTextDisabled');
      font-size: 12px;
    }
  }
  .desc {
    &-wrap {
      margin-top: 4px;
      line-height: 20px;
      display: flex;
      align-items: center;
    }
    &-text {
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
      color: v-bind('token.colorTextDisabled');
      flex: auto;
    }
    &-btn {
      flex: none;
    }
  }
}
</style>
