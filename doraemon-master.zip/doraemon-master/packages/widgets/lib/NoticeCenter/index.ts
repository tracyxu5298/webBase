import LatestNotice from './LatestNotice.vue';

LatestNotice.defaultTitle = '最新通知';

export default LatestNotice;
