import ApprovalCenter from './index.vue';

ApprovalCenter.demoData = {
  todoCount: 100,
  todoList: [
    {
      id: '1',
      fullName: '模拟数据1',
      userName: '刘冬梅',
      timeStr: '03-25 10:00',
      expireTime: 1711771200000,
    },
    {
      id: '2',
      fullName: '模拟数据2',
      userName: '刘冬梅',
      timeStr: '03-25 10:00',
      expireTime: 1711771200000,
    },
    {
      id: '3',
      fullName: '模拟数据3',
      userName: '刘冬梅',
      timeStr: '03-25 10:00',
      expireTime: 1711771200000,
    },
  ],
};

ApprovalCenter.demoDataTips = `
  #待办中心模拟数据
  todoCount: 待办数量
  todoList: 待办列表数据
  - id
  - fullName: 待办标题
  - userName: 发起人
  - timeStr: 发起时间（字符串）
  - expireTime: 截止时间（时间戳）
`;

ApprovalCenter.defaultTitle = '待办中心';

export default ApprovalCenter;
