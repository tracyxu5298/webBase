<script setup lang="ts">
import { ref, onMounted, computed } from 'vue';
import { theme, Empty, message } from 'ant-design-vue';
import { PlusOutlined } from '@ant-design/icons-vue';
import dayjs from 'dayjs';
import {
  WidgetCard,
  useHttp,
  useWidgetConfig,
  useUserId,
  MqttObserver,
  useIsBureau,
  useAccessToken,
  useRefreshToken,
  WebNoticeTarget,
} from '@lexikos/doraemon-business';
import {} from '@lexikos/doraemon-business';
import copy from './assets/copy.svg';
import done from './assets/done.svg';
import todo from './assets/todo.svg';
import sent from './assets/sent.svg';
import { IconType, ReadStatus } from './types';
import type { TodoItem } from './types';
import UrgencyTag from './components/UrgencyTag.vue';

const simpleImage = Empty.PRESENTED_IMAGE_SIMPLE;
const userId = useUserId();
const authToken = useAccessToken();
const refreshToken = useRefreshToken();

const { demoData, demoSwitch } = useWidgetConfig<{
  todoCount: number;
  todoList: TodoItem[];
}>();

const http = useHttp();
const { token } = theme.useToken();
const appList = ref([
  {
    id: 1,
    icon: 'todo',
    name: '待处理',
    url: '/LowcodeApps/TodoCenter/LowcodePage/TodoCenter/Todo',
  },
  {
    id: 2,
    icon: 'done',
    name: '已处理',
    url: '/LowcodeApps/TodoCenter/LowcodePage/TodoCenter/Done',
  },
  {
    id: 3,
    icon: 'sent',
    name: '我发起',
    url: '/LowcodeApps/TodoCenter/LowcodePage/TodoCenter/Mine',
  },
  {
    id: 4,
    icon: 'copy',
    name: '抄送我',
    url: '/LowcodeApps/TodoCenter/LowcodePage/TodoCenter/CarbonCopy',
  },
]);

const isTodo = (item: { id: number }) => item.id === 1;

const navigateTo = (url: string) => {
  history.pushState({}, '', url);
};

const handleClick = () => {
  const url = '/LowcodeApps/TodoCenter/LowcodePage/TodoCenter/FlowQuickLaunch';
  navigateTo(url);
};
const handleItemClick = ({ url }: { url: string }) => {
  navigateTo(url);
};

// TODO: 待办数量实时更新更新，待后端提供 mqtt
// jira 任务跟踪：https://jira.leedarson.com/browse/SMD-72747
const todoCount = ref(0);

const getTodoCount = async () => {
  if (demoSwitch) {
    todoCount.value = demoData?.todoCount || 0;
    return;
  }
  const res: number = await http.get('/api/lowcode/workflow/Engine/FlowTask/todoNums');
  console.log('...... 更新待办数量：', res);
  todoCount.value = res;
};

const todoList = ref<TodoItem[]>([]);
const todoListLoading = ref(false);
const isEmpty = computed(() => !todoListLoading.value && !todoList.value.length);

const getTodoList = async () => {
  if (demoSwitch) {
    todoList.value = demoData?.todoList || [];
    return;
  }
  todoListLoading.value = true;
  const res = await http
    .get(`/api/lowcode/workflow/Engine/FlowBefore/List/1`, {
      pageSize: 3,
      currentPage: 1,
      sortRule: 1,
      category: 1,
    })
    .finally(() => {
      todoListLoading.value = false;
    });
  todoList.value = res.list;
};

const pageJump = (item: TodoItem) => {
  const pathObj = JSON.parse(item.webPagePath!);
  const isBureau = useIsBureau();
  let path = isBureau.value ? pathObj.todoEdu || pathObj.todo : pathObj.todo;
  if (!path) {
    message.warn('未配置跳转路径。');
    return;
  }
  // 替换 AUTH_TOKEN 和 REFRESH_TOKEN
  path = path.replace('${AUTH_TOKEN}', authToken.value);
  path = path.replace('${REFRESH_TOKEN}', refreshToken.value);

  switch (pathObj.target as WebNoticeTarget) {
    case WebNoticeTarget.NewWindow:
      window.open(path);
      break;
    case WebNoticeTarget.Modal:
      message.warn('暂不支持弹窗');
      break;
    default:
      navigateTo(path);
      break;
  }

  navigateTo(path);
};

const readTodo = async (item: TodoItem) => {
  return http.put(`/api/workflow/Engine/FlowTask/actions/readTodo/1/${item.id}`);
};

const handleTodoItemClick = (item: TodoItem) => {
  if (demoSwitch) {
    message.info('演示数据不支持跳转');
    return;
  }
  readTodo(item);
  if (item.webPagePath) {
    pageJump(item);
    return;
  }
  navigateTo(`/LowcodeApps/TodoCenter/LowcodePage/TodoCenter/Todo/Detail?id=${item.processId}`);
};

const onMessage = (message: any) => {
  console.log('...... 收到待办数量变更 mqtt 消息', message);
  getTodoCount();
};

const onMqttInit = ({ notifySubOrUnSubToEndApi }: any) => {
  notifySubOrUnSubToEndApi(true, {
    topic: 'todoCenter/todoNums',
    bid: userId.value,
  });
};

onMounted(() => {
  getTodoList();
  getTodoCount();
});
</script>

<template>
  <WidgetCard class="todo-center-widget">
    <template #button>
      <a class="link" type="primary" @click="handleClick"
        ><a-space><PlusOutlined></PlusOutlined>发起事项</a-space></a
      >
    </template>
    <template #body>
      <div class="body-content">
        <div class="app-list">
          <div v-for="item in appList" :key="item.id" class="item" @click="handleItemClick(item)">
            <a-badge :count="isTodo(item) ? todoCount : 0" :offset="[4, 0]" class="icon-badge">
              <copy v-if="item.icon === 'copy'" class="icon-svg" />
              <done v-if="item.icon === 'done'" class="icon-svg" />
              <todo v-if="item.icon === 'todo'" class="icon-svg" />
              <sent v-if="item.icon === 'sent'" class="icon-svg" />
            </a-badge>
            <div class="title">{{ item.name }}</div>
          </div>
        </div>
        <div class="todo-list">
          <div class="loading-wrap" v-if="todoListLoading"><a-spin></a-spin></div>
          <div class="empty-wrap" v-else-if="isEmpty"><a-empty :image="simpleImage" /></div>
          <div
            v-else
            v-for="todoItem in todoList"
            :key="todoItem.id"
            class="item"
            @click="handleTodoItemClick(todoItem)"
            :title="todoItem.fullName"
          >
            <div class="icon-wrap flex-none">
              <img v-if="todoItem.iconType === IconType.Image" :src="todoItem.icon" alt="" />
              <div
                v-else
                class="icon-box"
                :style="{ background: todoItem.iconBackground || token.colorPrimary }"
              >
                <i :class="todoItem.icon || 'icon-ym icon-ym-portal-image'"></i>
              </div>
            </div>
            <div class="info-wrap">
              <div class="title-wrap">
                <UrgencyTag class="tag" :level="todoItem.flowUrgent"></UrgencyTag>
                <span
                  :class="[
                    'title',
                    {
                      strong: todoItem.readState === ReadStatus.Unread,
                    },
                  ]"
                  >{{ todoItem.fullName }}</span
                >
              </div>
              <div class="desc-wrap">
                <span class="desc desc-user">
                  <span>{{ todoItem.userName }}</span>
                  <span>发起于</span>
                  <span>{{ todoItem.timeStr }}</span>
                </span>
                <span class="desc desc-time">
                  <span
                    >截止时间：{{
                      todoItem.expireTime ? dayjs(todoItem.expireTime).format('MM-DD HH:mm') : '/'
                    }}</span
                  >
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </template>
  </WidgetCard>
  <MqttObserver
    @init="onMqttInit"
    :topics="['todoCenter/todoNums']"
    @message="onMessage"
  ></MqttObserver>
</template>

<style scoped lang="scss">
.link {
  color: v-bind('token.colorPrimaryText');
  &:hover {
    color: v-bind('token.colorPrimaryTextHover');
  }
}
.icon-badge {
  :deep(sup) {
    min-width: 16px;
    height: 16px;
    line-height: 16px;
    font-family: helvetica;
  }
  :deep(.#{$ant-prefix}-badge-multiple-words) {
    padding: 0 6px;
  }
}
.todo-center-widget :deep {
  &.workbench-card .body {
    overflow: visible;
  }
}
.body-content {
  display: flex;
  flex-direction: column;
  padding: 0 14px;
  height: 100%;
}
.app-list {
  display: flex;
  justify-content: space-between;
  box-sizing: border-box;
  flex: none;

  .item {
    display: flex;
    align-items: center;
    width: 56px;
    height: 60px;
    flex-direction: column;
    border-radius: 6px;
    cursor: pointer;
    padding: 8px 0 4px;
    justify-content: space-between;
    &:hover {
      background-color: #f7f7fa;
    }
    .title {
      color: v-bind('token.colorTextSecondary');
      font-size: v-bind('token.fontSizeSM') px;
    }
  }
  .icon-svg {
    display: block;
    color: v-bind('token.colorPrimary');
  }
}
.todo-list {
  flex: auto;
  overflow: hidden;
  margin-top: 6px;
  height: 1px;
  .loading-wrap,
  .empty-wrap {
    height: 100%;
    display: flex;
    align-items: center;
    justify-content: center;
  }
  .item {
    display: flex;
    padding: 6px;
    cursor: pointer;
    border-radius: 6px 10px;
    height: 60px;
    &:hover {
      background-color: #f7f7fa;
    }
  }
  .icon-wrap {
    margin-right: 8px;
    img,
    .icon-box {
      width: 24px;
      height: 24px;
      border-radius: 8px;
      border: 0;
      display: block;
    }

    .icon-box {
      display: flex;
      align-items: center;
      justify-content: center;
      color: v-bind('token.colorWhite');

      i {
        font-size: 16px;
        line-height: 1em;
      }
    }
  }
  .info-wrap {
    flex: auto;
    width: 1px;
    display: flex;
    flex-direction: column;
    justify-content: space-between;
    padding-top: 2px;
  }
  .title-wrap {
    display: flex;
    align-items: center;
    height: 20px;
    .title {
      flex: auto;
      line-height: 20px;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
      width: 0;
      color: v-bind('token.colorText');
      font-weight: v-bind('token.fontWeightStrong');
    }
    .tag {
      margin-right: 4px;
    }
  }
  .desc-wrap {
    display: flex;
    justify-content: space-between;
    gap: 8px;
  }
  .desc {
    color: v-bind('token.colorTextTertiary');
    white-space: nowrap;
    line-height: 20px;
    font-size: 12px;
    > span:not(:last-child) {
      margin-right: 4px;
    }
    &-user {
      flex: none;
    }
    &-time {
      flex: auto;
      width: 1px;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
      text-align: right;
    }
  }
}
</style>
