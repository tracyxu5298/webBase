<script setup lang="ts">
import { defineProps, type PropType } from 'vue';
import { Urgent } from '../types';

defineProps({
  level: {
    type: Number as PropType<Urgent>,
  },
});
</script>
<template>
  <a-tag v-if="level === Urgent.Normal" color="default" bordered>一般</a-tag>
  <a-tag v-else-if="level === Urgent.Medium" color="blue" bordered>平急</a-tag>
  <a-tag v-else-if="level === Urgent.Urgent" color="orange" bordered>加急</a-tag>
  <a-tag v-else-if="level === Urgent.Critical" color="red" bordered>特急</a-tag>
</template>
