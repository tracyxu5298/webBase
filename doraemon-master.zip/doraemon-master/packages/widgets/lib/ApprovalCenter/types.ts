export enum Category {
  /** 我发起的 */
  Mine = -1,
  /** 待办 */
  Todo = 1,
  /** 已办 */
  Done,
  /** 抄送 */
  CarbonCopy,
}

export enum Urgent {
  /** 一般 */
  Normal = 1,
  /** 平急 */
  Medium,
  /** 加急 */
  Urgent,
  /** 特急 */
  Critical,
}

export enum FormType {
  Flow,
  /** 系统表单 */
  System,
  /** 动态表单 */
  Dynamic,
}

export enum Status {
  Processing = 1,
  Done,
}

export enum ReadStatus {
  Unread,
  HaveRead,
}

export enum IconType {
  Icon = 1,
  Image,
}

export interface TodoItem {
  approversProperties: string;
  creatorTime: number;
  creatorUserId: string;
  delegateUser: string;
  enCode: string;
  expireTime: number;
  flowCategory: string;
  flowCode: string;
  flowId: string;
  flowName: string;
  flowUrgent: Urgent;
  flowVersion: string;
  formType: FormType;
  fullName: string;
  circulateId?: string;
  id: string;
  nodeName: string;
  processId: string;
  processNo: string;
  startTime: string;
  // status: number;
  todoCenterStatus: Status;
  thisStep: string;
  thisStepId: string;
  timeStr: string;
  userName: string;
  userImage: string;
  value: string;
  readState: ReadStatus;
  icon: string;
  iconBackground: string;
  iconType: IconType;
  parentId?: string;
  webPagePath?: string;
  visionFormDatas: {
    label: string;
    value: string;
  }[];
}
