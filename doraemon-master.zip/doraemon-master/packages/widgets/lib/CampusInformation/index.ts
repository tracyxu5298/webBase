import CampusInformation from './index.vue';

CampusInformation.defaultTitle = '校园资讯';

export default CampusInformation;
