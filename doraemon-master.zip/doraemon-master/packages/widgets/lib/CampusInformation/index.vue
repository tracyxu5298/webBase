<script setup lang="ts">
import { ref, computed, onBeforeMount } from 'vue';
import { theme, Carousel, message, Modal, Spin } from 'ant-design-vue';
import dayjs from 'dayjs';
import { Http } from '@lexikos/doraemon-network';
import { EMPTY_OBJ, WidgetCard } from '@lexikos/doraemon-business';

interface Item {
  id: string;
  url: string;
  title: string;
  publishTime: number;
  content: string;
}

const { token } = theme.useToken();

const list = ref<Item[]>();
const loading = ref(true);
const isEmpty = computed(() => loading.value === false && !!list.value && list.value.length === 0);

const open = ref(false);
const currentItem = ref<Item>(EMPTY_OBJ as Item);
const currentLoading = ref(true);

const getCampusInformationList = async () => {
  try {
    loading.value = true;
    const response = await Http.getInstance().get(
      '/api/campus/schoolPublishInfos/campusInformations',
    );
    list.value = response;
  } catch (e: any) {
    message.error(e.desc || '获取校园资讯列表失败！');
  } finally {
    loading.value = false;
  }
};

const getCampusInformationItem = async (id: string) => {
  try {
    currentLoading.value = true;
    const response = await Http.getInstance().get(
      `/api/campus/schoolPublishInfos/campusInformations/${id}`,
    );
    currentItem.value.content = response.content;
    currentLoading.value = false;
  } catch (e: any) {
    currentItem.value.content = '<p style="color:red">获取校园资讯详情失败！</p>';
  }
};

onBeforeMount(async () => {
  getCampusInformationList();
});

const handleDetail = (item: Item) => {
  open.value = true;
  currentItem.value = item;
  getCampusInformationItem(item.id);
};

const afterClose = () => {
  currentItem.value = EMPTY_OBJ as Item;
  currentLoading.value = true;
};

const handleMore = () => {
  history.pushState({}, '', '/information-delivery/campus-information');
};
</script>

<template>
  <WidgetCard :loading="loading" :isEmpty="isEmpty">
    <template #button>
      <a @click="handleMore" :style="{ color: token.colorPrimary }">更多</a>
    </template>
    <template #body>
      <div class="container">
        <Carousel class="carousel" autoplay :autoplaySpeed="5000">
          <div
            class="carousel-item"
            v-for="item in list"
            :key="item.id"
            @click="handleDetail(item)"
          >
            <img :src="item.url" />
            <div class="carousel-title">{{ item.title }}</div>
          </div>
        </Carousel>
        <ul class="list">
          <li class="list-item" v-for="item in list" :key="item.id" @click="handleDetail(item)">
            <div class="list-title">{{ item.title }}</div>
            <div class="list-time">{{ dayjs(item.publishTime).format('YYYY-MM-DD') }}</div>
          </li>
        </ul>
      </div>
    </template>
  </WidgetCard>
  <Modal
    v-model:open="open"
    title="校园资讯详情"
    width="800px"
    centered
    :footer="null"
    :destroyOnClose="true"
    :afterClose="afterClose"
    wrap-class-name="campus-information-modal"
  >
    <h2 class="modal-title">{{ currentItem.title }}</h2>
    <div class="modal-time">{{ dayjs(currentItem.publishTime).format('YYYY-MM-DD HH:mm') }}</div>
    <Spin class="center" v-if="currentLoading" />
    <div v-else v-html="currentItem.content"></div>
  </Modal>
</template>

<style scoped lang="scss">
.container {
  display: flex;
  height: 100%;
  padding: 0 20px 20px 20px;
  .carousel {
    height: 240px;
    width: 480px;
    cursor: pointer;
    &-item {
      position: relative;
      border-radius: 6px;
      overflow: hidden;
    }
    img {
      width: 480px;
      height: 240px;
      object-fit: cover;
      border-radius: 6px;
    }
    &-title {
      position: absolute;
      bottom: 0;
      left: 0;
      width: 100%;
      padding: 12px 12px 24px 12px;
      background: linear-gradient(180deg, #00000000 0%, #0000003d 65.9%);
      color: #fff;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
    }
  }
  .list {
    flex: 1;
    margin-left: 20px;
    overflow: hidden;
    &-item {
      display: flex;
      margin-bottom: 16px;
      line-height: 20px;
      cursor: pointer;
    }
    &-title {
      flex: 1;
      color: #111111;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
    }
    &-time {
      font-size: 12px;
      color: #00000066;
      text-align: right;
      text-wrap: nowrap;
      margin-left: 8px;
    }
  }
  :deep(.slick-dots-bottom) {
    left: 12px;
    justify-content: left;
  }
}
.modal-title {
  font-size: 24px;
}
.modal-time {
  color: #00000066;
  font-size: 12px;
  padding: 4px 0 8px;
}
</style>

<style lang="scss">
.campus-information-modal {
  img {
    max-width: 100%;
  }
  .antv-modal-body {
    height: 70vh;
    overflow: auto;
    margin-right: -24px;
    padding-right: 24px;
    position: relative;
  }
  .center {
    position: absolute;
    left: 50%;
    top: 50%;
    transform: translate(-50%, -50%);
  }
}
</style>
