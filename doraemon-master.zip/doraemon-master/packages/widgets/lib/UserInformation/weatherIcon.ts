import cloudyNight from './assets/cloudy-night.svg';
import dust from './assets/dust.svg';
import extraordinaryStorm from './assets/extraordinary-storm.svg';
import fog from './assets/fog.svg';
import freezingRain from './assets/freezing-rain.svg';
import heavyRain from './assets/heavy-rain.svg';
import heavySnow from './assets/heavy-snow.svg';
import heavySnowfall from './assets/heavy-snowfall.svg';
import heavyWind from './assets/heavy-wind.svg';
import lightRain from './assets/light-rain.svg';
import lightSnow from './assets/light-snow.svg';
import moderateRain from './assets/moderate-rain.svg';
import moderateSnow from './assets/moderate-snow.svg';
import mostlyCloud from './assets/mostly-cloudy.svg';
import noData from './assets/no-data.svg';
import partialCloudy from './assets/partial-cloudy.svg';
import rainSnow from './assets/rain-snow.svg';
import rainstorm from './assets/rainstorm.svg';
import rainyday from './assets/rainyday.svg';
import snowday from './assets/snowday.svg';
import sun from './assets/sun.svg';
import thunderstorm from './assets/thunderstorm.svg';
import thunderstormHail from './assets/thunderstorm-hail.svg';
import tornado from './assets/tornado.svg';

export const getWeatherIcon = (weather: string) => {
  console.log(weather);
  // 根据不同的天气返回不同的图标名称
  switch (weather) {
    case '晴':
      return sun;
    case '少云':
      return cloudyNight;
    case '晴间多云':
      return partialCloudy;
    case '多云':
      return partialCloudy;
    case '阴':
      return mostlyCloud;
    case '有风':
      return heavyWind;
    case '平静':
      return partialCloudy;
    case '微风':
      return heavyWind;
    case '和风':
      return heavyWind;
    case '清风':
      return heavyWind;
    case '强风/劲风':
      return tornado;
    case '疾风':
      return tornado;
    case '大风':
      return tornado;
    case '烈风':
      return tornado;
    case '风暴':
      return tornado;
    case '狂爆风':
      return tornado;
    case '飓风':
      return tornado;
    case '热带风暴':
      return tornado;
    case '霾':
      return dust;
    case '中度霾':
      return dust;
    case '重度霾':
      return dust;
    case '严重霾':
      return dust;
    case '阵雨':
      return rainyday;
    case '雷阵雨':
      return thunderstorm;
    case '雷阵雨并伴有冰雹':
      return thunderstormHail;
    case '小雨':
      return lightRain;
    case '中雨':
      return moderateRain;
    case '大雨':
      return heavyRain;
    case '暴雨':
      return rainstorm;
    case '大暴雨':
      return extraordinaryStorm;
    case '特大暴雨':
      return extraordinaryStorm;
    case '强阵雨':
      return extraordinaryStorm;
    case '强雷阵雨':
      return thunderstorm;
    case '极端降雨':
      return extraordinaryStorm;
    case '毛毛雨/细雨':
      return lightRain;
    case '雨':
      return moderateRain;
    case '小雨-中雨':
      return moderateRain;
    case '中雨-大雨':
      return heavyRain;
    case '大雨-暴雨':
      return rainstorm;
    case '暴雨-大暴雨':
      return extraordinaryStorm;
    case '大暴雨-特大暴雨':
      return extraordinaryStorm;
    case '雨雪天气':
      return rainSnow;
    case '雨夹雪':
      return rainSnow;
    case '阵雨夹雪':
      return rainSnow;
    case '冻雨':
      return freezingRain;
    case '雪':
      return moderateSnow;
    case '阵雪':
      return snowday;
    case '小雪':
      return lightSnow;
    case '中雪':
      return moderateSnow;
    case '大雪':
      return heavySnow;
    case '暴雪':
      return heavySnowfall;
    case '小雪-中雪':
      return moderateSnow;
    case '中雪-大雪':
      return heavySnow;
    case '大雪-暴雪':
      return heavySnowfall;
    case '浮尘':
      return dust;
    case '扬沙':
      return dust;
    case '沙尘暴':
      return dust;
    case '强沙尘暴':
      return dust;
    case '龙卷风':
      return tornado;
    case '雾':
      return fog;
    case '浓雾':
      return fog;
    case '强浓雾':
      return fog;
    case '轻雾':
      return fog;
    case '大雾':
      return fog;
    case '特强浓雾 ':
      return fog;
    case '热':
      return sun;
    case '冷':
      return moderateSnow;
    case '未知':
      return noData;
    // 其他天气情况可以继续追加
    default:
      return noData;
  }
};
