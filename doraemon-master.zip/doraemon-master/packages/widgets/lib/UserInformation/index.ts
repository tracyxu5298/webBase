import UserInformation from './index.vue';

export default UserInformation;
