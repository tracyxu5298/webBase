<script setup lang="ts">
import { ref, onBeforeMount } from 'vue';
import { theme, message } from 'ant-design-vue';
import { useHttp, useUserAvatar, useUserName } from '@lexikos/doraemon-business';
import { getWeatherIcon } from './weatherIcon';
import defaultAvatar from './assets/avatar.png';
interface WeatherData {
  weather: string;
  winddirection: string;
  windpower: string;
}
const http = useHttp();
const { token } = theme.useToken();
const userAvatar = useUserAvatar();
const userName = useUserName();
const greeting = ref('');
const currentDate = ref('');
const dutyStatus = ref<number>(0);
const position = ref<string>('');
const weatherData = ref<WeatherData>({
  weather: '',
  winddirection: '',
  windpower: '',
});
const weatherIcon = ref();
const dutyStatusOptions = [
  { label: '在岗', value: 0 },
  { label: '开会', value: 1 },
  { label: '下校', value: 2 },
  { label: '公事外出', value: 3 },
  { label: '请假', value: 4 },
];
const getChineseDayOfWeek = (day: number) => {
  const chineseDays = ['日', '一', '二', '三', '四', '五', '六'];
  return chineseDays[day];
};

const getGreeting = () => {
  const now = new Date();
  const hour = now.getHours();
  const year = now.getFullYear();
  const month = now.getMonth() + 1;
  const day = now.getDate();
  const dayOfWeek = getChineseDayOfWeek(now.getDay());

  if (hour >= 6 && hour < 11) {
    greeting.value = '上午好';
  } else if (hour >= 11 && hour < 13) {
    greeting.value = '中午好';
  } else if (hour >= 13 && hour < 18) {
    greeting.value = '下午好';
  } else if (hour >= 18 && hour < 24) {
    greeting.value = '晚上好';
  } else {
    greeting.value = '深夜了，注意休息';
  }
  currentDate.value = `${year}年${month}月${day}日 星期${dayOfWeek}`;
};

const getUserOnDutyStatus = async () => {
  try {
    const res = await http.get(`/api/auth/v1/userManagement/getUserOnDutyStatusPosition`);
    dutyStatus.value = res.onDutyStatus;
    position.value = res.position;
  } catch (e: any) {
    message.error(e?.desc || '获取在岗状态失败！');
  }
};
const setUserOnDutyStatus = async (val: number) => {
  try {
    await http.put(`/api/auth/v1/userManagement/setUserOnDutyStatus/${val}`);
    getUserOnDutyStatus();
  } catch (e: any) {
    message.error(e?.desc || '在岗状态修改失败');
  }
};
const getWeather = async () => {
  try {
    const res = await http.get(`/api/auth/amap/weather/liveInfo`);
    weatherData.value = res?.lives[0];
    weatherIcon.value = getWeatherIcon(weatherData.value.weather);
  } catch (e: any) {
    message.error(e?.desc || '获取天气信息失败！');
  }
};
onBeforeMount(() => {
  getUserOnDutyStatus();
  getWeather();
  getGreeting();
});
</script>

<template>
  <div class="wrap">
    <div class="logo">
      <img :src="userAvatar || defaultAvatar" alt="" />
    </div>
    <div class="content">
      <div class="title-box">
        <div class="title">
          {{ `${greeting}，${userName}${position ? position : ''}` }}
        </div>
        <a-select
          class="select-box"
          size="small"
          v-model:value="dutyStatus"
          :options="dutyStatusOptions"
          @change="setUserOnDutyStatus"
          :dropdownStyle="{ width: '90px' }"
          :dropdownMatchSelectWidth="false"
        >
        </a-select>
      </div>
      <div class="data-weather">
        <div class="date">{{ currentDate }}</div>
        <a-tooltip placement="top" v-if="weatherData.weather">
          <template #title>
            <span>{{
              `${weatherData.weather}， ${weatherData.winddirection}风${weatherData.windpower}级`
            }}</span>
          </template>
          <component :is="weatherIcon" class="con-svg"></component>
        </a-tooltip>
      </div>
    </div>
  </div>
</template>

<style scoped lang="scss">
.wrap {
  display: flex;
  gap: 0 20px;
  .logo {
    width: 64px;
    height: 64px;
    display: flex;
    justify-content: center;
    align-items: center;
    overflow: hidden;
    border-radius: 50%;
    img {
      width: 100%;
    }
  }
  .content {
    display: flex;
    flex-direction: column;
    gap: 12px 0;
    flex: 1;
    .date {
      line-height: 20px;
      font-size: 14px;
      color: rgba(0, 0, 0, 0.6);
    }
  }
}
.title-box {
  display: flex;
  align-items: center;
  gap: 0 8px;
  :deep(.#{$ant-prefix}-select-selector) {
    border-color: v-bind('token.colorPrimaryBorder');
    color: v-bind('token.colorPrimary');
    background-color: v-bind('token.colorPrimaryBg');
  }
  :deep(.#{$ant-prefix}-select-arrow) {
    color: v-bind('token.colorPrimary');
  }

  .title {
    font-weight: 500;
    color: #111111;
    font-size: 24px;
    line-height: 32px;
  }
}
.data-weather {
  height: 20px;
  display: flex;
  align-items: center;
}

.con-svg {
  width: 32px;
  height: 32px;
  line-height: 32px;
}
</style>
