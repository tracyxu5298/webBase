import DepartmentLeader2x1 from './index.vue';

DepartmentLeader2x1.defaultTitle = '部门负责人';

export default DepartmentLeader2x1;
