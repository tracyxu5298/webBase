<script setup lang="ts">
import { ref, onMounted, computed } from 'vue';
import { theme, Empty, message } from 'ant-design-vue';
import { WidgetCard, useHttp } from '@lexikos/doraemon-business';
import { getDutyStatus, getColor } from './utils';
import Deboy from './assets/boy.svg';
import degirl from './assets/girl.svg';
import dep from './assets/dep.svg';
import tel from './assets/tel.svg';

const simpleImage = Empty.PRESENTED_IMAGE_SIMPLE;
const http = useHttp();
const { token } = theme.useToken();

const navigateTo = (url: string) => {
  history.pushState({}, '', url);
};

const handleClick = () => {
  const url = '/OrganizationCenter';
  navigateTo(url);
};

const headList = ref<any[]>([]);
const loading = ref(false);
const isEmpty = computed(() => !loading.value && !headList.value.length);

// 一维数组转二维数组  num 为取几个
const convertToTwoDimensionalArray = (arr: any[], num: number) => {
  const result: any[] = [];
  for (let i = 0; i < arr.length; i += num) {
    result.push(arr.slice(i, i + num));
  }
  return result;
};
const getDepartmentHeadList = async () => {
  loading.value = true;
  try {
    const res = await http.get(`/api/auth/v1/userManagement/getDepartmentPrincipalTab`);
    headList.value = convertToTwoDimensionalArray(res, 6);
  } catch (e: any) {
    message.error(e.desc || '获取部门负责人失败！');
  } finally {
    loading.value = false;
  }
};

onMounted(() => {
  getDepartmentHeadList();
});
</script>

<template>
  <WidgetCard>
    <template #button>
      <a class="link" type="primary" @click="handleClick">全部</a>
    </template>
    <template #body>
      <div class="body-content">
        <div class="loading-wrap" v-if="loading"><a-spin></a-spin></div>
        <div class="empty-wrap" v-else-if="isEmpty"><a-empty :image="simpleImage" /></div>
        <a-carousel v-else autoplay :autoplaySpeed="15000">
          <div v-for="(item, itemIndex) in headList" :key="itemIndex">
            <a-row :gutter="[20, 16]">
              <a-col v-for="head in item" :key="head.userId" :span="12">
                <div class="head-item">
                  <img class="head-icon" v-if="head.headIcon" :src="head.headIcon" alt="" />
                  <div v-else style="width: 40px; height: 40px">
                    <Deboy
                      v-if="head.gender === 1"
                      :height="40"
                      :width="40"
                      viewBox="0 0 100 100"
                    />
                    <degirl v-else :height="40" :width="40" viewBox="0 0 100 100" />
                  </div>
                  <div class="head-right">
                    <div class="con-box">
                      <div class="name" :title="head.name">{{ head.name }}</div>
                      <a-tag style="margin-left: 8px" :color="getColor(head.onDutyStatus)">{{
                        getDutyStatus(head.onDutyStatus)
                      }}</a-tag>
                    </div>
                    <div class="con-box">
                      <div class="icon-box">
                        <dep :width="9" :height="10" />
                      </div>
                      <div class="dep" :title="head.departmentName">{{ head.departmentName }}</div>
                    </div>
                    <div class="con-box">
                      <div class="icon-box">
                        <tel :width="9" :height="10" />
                      </div>
                      <div>{{ head.tel ? head.tel : '/' }}</div>
                    </div>
                  </div>
                </div>
              </a-col>
            </a-row>
          </div>
        </a-carousel>
      </div>
    </template>
  </WidgetCard>
</template>

<style scoped lang="scss">
.swiper-head {
  height: 100%;
  display: flex;
  flex-wrap: wrap;
  gap: 16px 20px;
}
.head-item {
  width: 100%;
  height: 64px;
  display: flex;
  overflow: hidden;
}

.head-right {
  margin-left: 12px;
  flex: 1;
  overflow: hidden;
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  .con-box {
    display: flex;
    align-items: center;
    color: v-bind('token.colorTextTertiary');
  }
}

.name,
.dep {
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.name {
  font-weight: bold;
  color: v-bind('token.colorText');
}
.head-icon {
  display: block;
  width: 40px;
  height: 40px;
  border-radius: 100%;
}
.icon-box {
  display: flex;
  align-items: center;
  margin-right: 4px;
  width: 9px;
  height: 20px;
  font-size: 12px;
}

.loading-wrap,
.empty-wrap {
  height: 100%;
  display: flex;
  align-items: center;
  justify-content: center;
}
:deep(.slick-dots li.slick-active button) {
  background: v-bind('token.colorPrimary');
}
:deep(.slick-dots li button) {
  background: v-bind('token.colorTextTertiary');
}
:deep(.slick-dots) {
  bottom: -25px;
}
.link {
  color: v-bind('token.colorPrimaryText');
  &:hover {
    color: v-bind('token.colorPrimaryTextHover');
  }
}
.body-content {
  display: flex;
  flex-direction: column;
  padding: 5px 20px 20px;
  height: 100%;
}
</style>
