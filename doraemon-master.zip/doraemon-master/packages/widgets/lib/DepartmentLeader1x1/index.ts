import DepartmentLeader1x1 from './index.vue';

DepartmentLeader1x1.defaultTitle = '部门负责人';

export default DepartmentLeader1x1;
