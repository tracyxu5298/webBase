export const getDutyStatus = (num: number) => {
  switch (num) {
    case 0:
      return '在岗';
    case 1:
      return '开会';
    case 2:
      return '下校';
    case 3:
      return '公事外出';
    case 4:
      return '请假';
  }
};
export const getColor = (num: number) => {
  switch (num) {
    case 0:
      return 'green';
    case 1:
      return 'cyan';
    case 2:
      return 'orange';
    case 3:
      return 'blue';
    case 4:
      return 'red';
  }
};
