<script setup lang="ts">
import { ref, onMounted, computed } from 'vue';
import { theme } from 'ant-design-vue';
import { cloneDeep, split } from 'lodash-es';
import { ApplicationType, type Application } from '@lexikos/doraemon-business';
import {
  useHttp,
  openNewWindow,
  ApplicationTarget,
  useThirdApplication,
  WidgetCard,
  ApplicationIcon,
  getFullPathByAppPath,
  setLocalAppFullPath,
  useDeployConfigStore,
} from '@lexikos/doraemon-business';

const { token } = theme.useToken();
const { getThirdAppInfo } = useThirdApplication();
const http = useHttp();

const deployConfigStore = useDeployConfigStore();

const loading = ref(false);
const appList = ref<Application[]>([]);
const showAppList = computed(() => {
  return appList.value.slice(0, 10);
});

const getFinalMicroAppPath = (_app: Application) => {
  const appPath = _app.path;
  if (appPath && _app.type === ApplicationType.old && appPath.startsWith('/')) {
    let _path = appPath;
    let _search = '';

    // 带参数的 url 需要拆开处理
    const _searchStartIndex = appPath.indexOf('?');
    if (_searchStartIndex >= 0) {
      _search = appPath.substring(_searchStartIndex) || '';
      _path = appPath.substring(0, _searchStartIndex);
    }

    const paths = split(_path, '/');
    const path = paths[paths.length - 1];
    const application = { ..._app, path: `/${path}${_search}` };
    return application;
  }
  return _app;
};

const fetchData = async () => {
  try {
    loading.value = true;
    const res = await http.get('/api/auth/v1/userRecentApp?limit=10');
    appList.value = res || [];
  } catch (error) {
    console.log(error);
  }
  loading.value = false;
};
const handleMoreClick = () => {
  history.pushState({}, '', '/Applications');
};

const handleItemClick = async (item: Application) => {
  // 旧应用的地址需要处理地址
  let app = getFinalMicroAppPath(item);

  // 智慧录播: 录播管理
  if (deployConfigStore.isMediaApp(app.code)) {
    const _path = await deployConfigStore.getMediaAppPath(app.path);
    if (_path) {
      openNewWindow(_path);
      return;
    }
  }

  // 第三方应用，获取云端的地址
  if (app.type === ApplicationType.third) {
    app = await getThirdAppInfo(app);
  }

  const { path, code } = app;

  if (item.target === ApplicationTarget.blank) {
    let _path = path;

    // 打开新页签需要存储是否全屏标识
    const _fullPath = getFullPathByAppPath(_path);
    if (_fullPath) {
      setLocalAppFullPath(_fullPath);
    }

    /**
     * 打开新页签，需要判断是否携带 token
     */
    if (_path.includes('${AUTH_TOKEN}')) {
      _path = _path.replace('${AUTH_TOKEN}', localStorage.getItem('token') || '');
    }
    if (_path.includes('${REFRESH_TOKEN}')) {
      _path = _path.replace('${REFRESH_TOKEN}', localStorage.getItem('refreshToken') || '');
    }
    openNewWindow(_path);
    return;
  }

  // 如果已经打开了某个子应用，则用缓存的
  const cacheAppRoute = JSON.parse(sessionStorage.getItem('recentAppLastPath') || '{}')[code];
  const finalPath = cacheAppRoute?.path || path;

  if (finalPath) {
    history.pushState(cacheAppRoute?.state ? cloneDeep(cacheAppRoute.state) : {}, '', finalPath);
    // proxy.$parentRouter.push({ path: finalPath });
  }
};

onMounted(() => {
  fetchData();
});
</script>
<template>
  <WidgetCard :isEmpty="!showAppList.length" :loading="loading">
    <template #button>
      <a-button class="button" type="link" @click="handleMoreClick"> 全部应用 </a-button>
    </template>
    <template #body>
      <div class="body-content">
        <div v-for="item in showAppList" :key="item.id" class="item" @click="handleItemClick(item)">
          <ApplicationIcon :icon="item.icon" />
          <p class="title" :title="item.name?.length > 6 ? item.name : ''">
            {{ item.name }}
          </p>
        </div>
      </div>
    </template>
  </WidgetCard>
</template>

<style scoped lang="scss">
.button {
  padding-right: 0;
  color: v-bind('token.colorPrimary');
  &:hover,
  &:active {
    color: v-bind('token.colorPrimary');
  }
}
.body-content {
  display: grid;
  justify-content: space-between;
  overflow: hidden;
  height: 180px;
  margin: 24px 16px;
  box-sizing: border-box;
  grid-template-columns: repeat(auto-fill, 84px);
  grid-template-rows: 80px 80px;
  grid-row-gap: 20px;
  .item {
    display: flex;
    align-items: center;
    width: 84px;
    height: 80px;
    flex-direction: column;
    cursor: pointer;
    .title {
      margin: 8px 0 0 0;
      width: 100%;
      text-align: center;
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
    }
  }
}
.imag-wrapper {
  width: 40px;
  height: 40px;
  background-position: center;
  background-repeat: no-repeat;
  background-size: contain;
}
</style>
