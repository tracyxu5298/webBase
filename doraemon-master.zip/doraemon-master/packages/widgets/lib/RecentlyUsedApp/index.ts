import RecentlyUsedApp from './index.vue';

RecentlyUsedApp.defaultTitle = '最近使用';

export default RecentlyUsedApp;
