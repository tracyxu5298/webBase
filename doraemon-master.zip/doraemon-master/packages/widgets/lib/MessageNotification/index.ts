import MessageNotification from './index.vue';

MessageNotification.defaultTitle = '最新通知';

export default MessageNotification;
