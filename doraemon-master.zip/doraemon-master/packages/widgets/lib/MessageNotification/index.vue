<script setup lang="ts">
import { ref, onMounted } from 'vue';
import { theme } from 'ant-design-vue';
import { useHttp, useUserId, WidgetCard } from '@lexikos/doraemon-business';

interface ISystemMessage {
  id: string;
  readStatus: number;
  title: string;
  content: string;
  createTime: string;
  impPage: string;
  bizDataJson: string;
  bizCode: string;
  webPath: string;
}
const { token } = theme.useToken();
const http = useHttp();
const loading = ref(false);
const dataList = ref<ISystemMessage[]>([]);
const userId = useUserId();

const fetchData = async () => {
  try {
    loading.value = true;

    const res = await http.post('/api/building/v1/systemMessages/page', {
      clientType: 'WEB',
      pageNum: 1,
      pageSize: 3,
      userId: userId.value,
      userType: 1,
    });
    dataList.value = res?.result || [];
  } catch (error) {
    console.log(error);
  }
  loading.value = false;
};
const handleMoreClick = () => {
  history.pushState({}, '', '/notice-center');
};

const toTodoCenterDetail = (bizDataJson: { flowId: string; type: number; processId: string }) => {
  const typeStr: any = {
    1: 'Mine',
    2: 'Todo',
    3: 'CarbonCopy',
  };

  history.pushState(
    {},
    '',
    `/LowcodeApps/TodoCenter/LowcodePage/TodoCenter/${typeStr[bizDataJson.type]}/Detail?id=${
      bizDataJson.processId
    }`,
  );
};

const read = async (item: ISystemMessage) => {
  if (item.readStatus) {
    return;
  }
  await http.get(`/api/building//v1/systemMessages/${item.id}/actions/read`);
  fetchData();
};

const toDetail = (item: ISystemMessage) => {
  read(item);
  const bizDataJson = JSON.parse(item.bizDataJson);
  switch (item.bizCode) {
    case 'Todo:Center': {
      toTodoCenterDetail(bizDataJson);
      break;
    }
    case 'zntb': {
      const pathname = `/LowcodeApps/zntb/LowcodePage/fillReport/home?activeKey=1&forcePath=1&reportId=${
        bizDataJson?.reportId || ''
      }&recordId=${bizDataJson?.flowBeforeId || ''}`;
      window.history.pushState({}, '', pathname);
      break;
    }
    case 'zntbOffice': {
      const pathname = `/LowcodeApps/zntbOffice/LowcodePage/fillReport/home?activeKey=1&forcePath=1&reportId=${
        bizDataJson?.reportId || ''
      }&recordId=${bizDataJson?.flowBeforeId || ''}`;
      window.history.pushState({}, '', pathname);
      break;
    }
    case 'documentv3': {
      if (item?.webPath) {
        window.history.pushState({}, '', item.webPath);
      }
      break;
    }
    default:
      break;
  }
};

onMounted(() => {
  fetchData();
});
</script>

<template>
  <WidgetCard :isEmpty="!dataList.length" :loading="loading">
    <template #button>
      <a-button class="button" type="link" @click="handleMoreClick"> 更多 </a-button>
    </template>
    <template #body>
      <div class="body-content">
        <div class="item" v-for="item in dataList" :key="item.id">
          <div class="left">
            <div class="title">
              <span class="dot" :class="{ red: item.readStatus !== 1 }"></span>
              <span class="title-content nowrap">{{ item.title }}</span>
            </div>
            <div class="desc">
              <span class="dot"></span>
              <span class="desc-content nowrap">{{ item.content }}</span>
            </div>
          </div>
          <div class="right">
            <div class="time">{{ item.createTime }}</div>
            <div class="detail">
              <a-button class="button" type="link" @click="toDetail(item)"> 详情 </a-button>
            </div>
          </div>
        </div>
      </div>
    </template>
  </WidgetCard>
</template>

<style scoped lang="scss">
.button {
  padding-right: 0;
  color: v-bind('token.colorPrimary');
  &:hover,
  &:active {
    color: v-bind('token.colorPrimary');
  }
}
.nowrap {
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.body-content {
  height: 100%;
  padding: 20px 24px;
  box-sizing: border-box;
  .item {
    display: flex;
    overflow: hidden;
    margin-bottom: 24px;
    .left {
      overflow: hidden;
      flex: 1;
      .dot {
        display: block;
        flex: none;
        width: 6px;
        height: 6px;
        margin: 0 8px 0 0;
        border-radius: 50%;
        &.red {
          background-color: #f53f3f;
        }
      }
      .title {
        display: flex;
        align-items: center;
      }
      .title-content {
        word-break: break-word;
        font-weight: 600;
        font-size: 14px;
      }
      .desc {
        display: flex;
        margin-top: 4px;
      }
      .desc-content {
        font-size: 14px;
      }
    }
    .right {
      flex: none;
      overflow: hidden;
      margin-left: 40px;
      .detail {
        display: flex;
        justify-content: flex-end;
      }
      .time {
        font-size: 12px;
        color: rgb(0 0 0 / 45%);
      }
    }
  }
}
</style>
