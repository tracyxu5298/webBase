<script setup lang="ts">
import { computed, onMounted, ref } from 'vue';
import { message } from 'ant-design-vue';
import { MenuOutlined, CloseCircleOutlined } from '@ant-design/icons-vue';
import draggable from 'vuedraggable';
import { useHttp } from '@lexikos/doraemon-business';
import type { IAppItem } from './type.ts';

const emit = defineEmits(['refreshList']);

const http = useHttp();

const searchKey = ref('');
const open = ref(false);
const okLoading = ref(false);
const appList = ref<IAppItem[]>([]);
const selectedIds = ref<string[]>([]);

const filterAppList = computed(() => {
  let res = appList.value;
  if (searchKey.value) {
    res = appList.value.filter((item) => item.permissionName.includes(searchKey.value));
  }
  return res.map((i) => ({
    ...i,
    label: i.permissionName,
    value: i.permissionId,
  }));
});

const handleOk = async () => {
  const data = selectedIds.value.map((one) => ({ permissionId: one })) || [];
  try {
    okLoading.value = true;
    await http.post('/api/auth/shortcuts/actions/setting', data);
    message.success('保存成功');
    open.value = false;
    searchKey.value = '';
    emit('refreshList');
  } catch (error) {
    message.error('保存失败');
  } finally {
    okLoading.value = false;
  }
};

const openModal = (selected: IAppItem[]) => {
  open.value = true;
  selectedIds.value = selected.map((one) => one.permissionId);
};

const fetchData = async () => {
  try {
    const res = await http.get('/api/auth/shortcuts/actions/recommendList');
    appList.value = res || [];
  } catch (error) {
    console.log(error);
  }
};

const onSelect = (selected: string[]) => {
  const otherSelected = selectedIds.value.filter(
    (i) => !filterAppList.value.some((f) => f.permissionId === i),
  );
  const mix = [...(otherSelected || []), ...selected];
  const res = Array.from(new Set(mix));

  if (res.length > 10) {
    message.warning('最多设置10个快捷功能');
  } else {
    selectedIds.value = res;
  }
};

const removeSelected = (permissionId: IAppItem['permissionId']) => {
  selectedIds.value = selectedIds.value.filter((i) => i !== permissionId);
};

onMounted(() => {
  fetchData();
});

defineExpose({
  openModal,
});
</script>

<template>
  <a-modal
    v-model:open="open"
    title="设置快捷功能"
    @ok="handleOk"
    centered
    :width="600"
    class="workbench-shortcut-app-setting"
    okText="确定"
    cancelText="取消"
    :confirmLoading="okLoading"
    @cancel="searchKey = ''"
  >
    <div class="content">
      <div class="left">
        <a-input-search
          v-model:value="searchKey"
          placeholder="搜索"
          style="width: 100%"
          allowClear
        />
        <div class="app-list-wrap">
          <a-checkbox-group
            :value="selectedIds"
            :options="filterAppList"
            @change="onSelect"
            style="width: 100%"
          >
            <template #label="item">
              <span class="app-list-item">
                <a-typography-text
                  class="app-list-item-name ellipsis"
                  :content="item.permissionName"
                />
                <a-typography-text class="app-list-item-label ellipsis" :content="item.appName" />
              </span>
            </template>
          </a-checkbox-group>
        </div>
      </div>
      <div class="right">
        <p class="right-title">已选({{ selectedIds?.length }})</p>
        <div class="selected-list">
          <draggable
            v-model="selectedIds"
            item-key="permissionId"
            class="selected-list-group"
            ghost-class="ghost"
          >
            <template #item="{ element }: { element: IAppItem['permissionId'] }">
              <div class="selected-list-item">
                <MenuOutlined />
                <a-typography-text
                  class="item-body ellipsis"
                  :content="appList.find((i) => i.permissionId === element)?.permissionName || ''"
                />
                <CloseCircleOutlined @click="removeSelected(element)" />
              </div>
            </template>
          </draggable>
        </div>
      </div>
    </div>
  </a-modal>
</template>

<style scoped lang="scss">
.ellipsis {
  text-overflow: ellipsis;
  overflow: hidden;
  white-space: nowrap;
}
.workbench-shortcut-app-setting {
  .content {
    display: flex;
    overflow: hidden;
    height: 396px;
  }

  :deep(.ant-modal-header) {
    border-bottom: 1px solid rgb(0 0 0 / 60%);
  }

  .left {
    display: flex;
    overflow: hidden;
    flex-direction: column;
    flex: 1;
    padding-top: 24px;
    padding-right: 24px;
    box-sizing: border-box;
    border-right: 1px solid rgb(0 0 0 / 6%);
  }
  .right {
    display: flex;
    width: 224px;
    padding-top: 24px;
    padding-left: 24px;
    flex-direction: column;
    .right-title {
      font-weight: 600;
      margin-bottom: 8px;
    }
  }
  .app-list-wrap {
    overflow: auto;
    padding-left: 8px;
    margin-top: 8px;
    flex: 1;
    &::-webkit-scrollbar {
      display: none;
    }
    .app-list-item {
      display: flex;
      justify-content: space-between;
      align-items: center;
      width: 269px;
      height: 40px;
    }
    .app-list-item-name {
      flex: 1;
      display: block;
      overflow: hidden;
      margin: 0 8px 0 0;
    }
    .app-list-item-label {
      max-width: 94px;
      color: rgb(0 0 0 / 45%);
    }
  }

  .selected-list {
    overflow: auto;
    flex: 1;
    &::-webkit-scrollbar {
      display: none;
    }
    .selected-list-item {
      display: flex;
      align-items: center;
      height: 40px;
      cursor: pointer;
      .item-body {
        overflow: hidden;
        margin: 0 8px;
        flex: 1;
      }
    }
  }
}
</style>
