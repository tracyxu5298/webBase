<script setup lang="ts">
import { computed, onMounted, ref } from 'vue';
import { theme } from 'ant-design-vue';
import { startsWith } from 'lodash-es';
import { useHttp, WidgetCard } from '@lexikos/doraemon-business';
import type { IAppItem } from './type.ts';
import Setting from './Setting.vue';

const { token } = theme.useToken();
const http = useHttp();
const settingRef = ref<null | { openModal: (val: IAppItem[]) => void }>(null);
const appList = ref<IAppItem[]>([]);
const loading = ref(false);
const showAppList = computed(() => {
  return appList.value.slice(0, 10);
});

const handleMoreClick = () => {
  settingRef?.value?.openModal(appList.value);
};
const handleItemClick = (item: IAppItem) => {
  const { query, openPath, appPath, developType } = item;
  if (openPath) {
    // 低代码菜单需要拼接 query
    let pathWithQuery = openPath + (query || '');
    if (!startsWith(pathWithQuery, '/')) {
      pathWithQuery = '/' + pathWithQuery;
    }
    // 去除应用地址与菜单地址重叠部分
    const prefixPaths: string[] = [];
    if (appPath) {
      const appPaths = appPath.split('/').filter((i) => !!i);
      let hasFoundPrefix = false;
      appPaths.forEach((i) => {
        if (i && !hasFoundPrefix && !startsWith(pathWithQuery, `/${i}/`)) {
          prefixPaths.push(`/${i}`);
        } else {
          hasFoundPrefix = true;
        }
      });
    }

    // 去除旧基座应用的应用地址前面的大类地址
    if (developType === 1) {
      prefixPaths.splice(0, 1);
    }
    const pathWidthPrefix = prefixPaths.join('') + pathWithQuery;
    history.pushState({}, '', pathWidthPrefix);
  }
};
const fetchData = async () => {
  try {
    loading.value = true;
    const res = await http.get('/api/auth/shortcuts/actions/list');
    appList.value = res || [];
  } catch (error) {
    console.log(error);
  }
  loading.value = false;
};

onMounted(() => {
  fetchData();
});
</script>

<template>
  <WidgetCard :isEmpty="!showAppList.length" :loading="loading">
    <template #button>
      <a class="button" @click="handleMoreClick">设置</a>
    </template>
    <template #body>
      <div class="body-content">
        <div
          v-for="item in showAppList"
          :key="item.permissionId"
          class="item"
          @click="handleItemClick(item)"
        >
          <a-typography-text
            class="title"
            :ellipsis="{ tooltip: item.permissionName }"
            :content="item.permissionName"
          />
        </div>
      </div>
    </template>
  </WidgetCard>
  <Setting ref="settingRef" @refreshList="fetchData" />
</template>

<style scoped lang="scss">
.button {
  padding-right: 0;
  color: v-bind('token.colorPrimary');
  &:hover,
  &:active {
    color: v-bind('token.colorPrimary');
  }
}
.body-content {
  display: grid;
  grid-template-rows: repeat(5, 35px);
  grid-template-columns: 1fr 1fr;
  gap: 12px;
  height: 100%;
  padding: 0 24px;
  box-sizing: border-box;
  .item {
    display: flex;
    justify-content: center;
    align-items: center;
    overflow: hidden;
    height: 35px;
    padding: 0 8px;
    background-color: v-bind('token.colorPrimaryBg');
    border-radius: 6px;
    cursor: pointer;
  }
  .title {
    overflow: hidden;
    width: 100%;
    text-align: center;
    color: v-bind('token.colorPrimary');
  }
}
</style>
