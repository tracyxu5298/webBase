import ShortcutApp from './index.vue';

ShortcutApp.defaultTitle = '快捷功能';

export default ShortcutApp;
