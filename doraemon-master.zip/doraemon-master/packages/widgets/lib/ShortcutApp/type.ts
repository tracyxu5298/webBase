import type { ApplicationType } from '@lexikos/doraemon-business';

export interface IAppItem {
  permissionId: string;
  permissionCode: string;
  permissionName: string;
  sort?: number;
  openPath?: string;
  developType?: number;
  appName?: string;
  query?: string;
  appPath?: string;
  appCode: string;
  type: ApplicationType;
}
