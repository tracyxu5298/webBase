export declare type HttpBody = BodyInit | Record<string, any>;
export declare type HttpHeaders = (HeadersInit | Record<string, any>) & { 'Content-Type': string };

export declare interface HttpOptions {
  // baseUrl: string;
  headers: HttpHeaders;
  onLogout: VoidFunction;
  onRefreshToken?: () => Promise<{
    token: string;
    tokenKey: string;
  }>;
  showErrorMessage: (msg: string, duration?: number) => any; // 返回值需要是 Promise<void>, 显示完消息后退出到登录页
  timeout?: number;
}
export declare interface HttpActionConfig {
  headers?: Record<string, any>;
  timeout?: number;
  keepalive?: boolean;
}
