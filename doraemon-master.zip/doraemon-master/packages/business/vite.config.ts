import { resolve } from 'path';
import { fileURLToPath, URL } from 'node:url';
import { defineConfig } from 'vite';
import dts from 'vite-plugin-dts';
import vue from '@vitejs/plugin-vue';
import vueJsx from '@vitejs/plugin-vue-jsx';
import packageJson from './package.json';
import Components from 'unplugin-vue-components/vite';
import { AntDesignVueResolver } from 'unplugin-vue-components/resolvers';
import { visualizer } from 'rollup-plugin-visualizer';

function alias(relativeLibPath: string) {
  return fileURLToPath(new URL(relativeLibPath, import.meta.url));
}

export default defineConfig((config) => {
  const { command } = config;
  const isBuild = command === 'build';
  return {
    plugins: [
      vue(),
      vueJsx(),
      dts({
        rollupTypes: true,
      }),
      Components({
        // https://github.com/unplugin/unplugin-vue-components/issues/654
        resolvers: [
          AntDesignVueResolver({
            importStyle: false, // css in js
          }),
        ],
      }),
      isBuild &&
        visualizer({
          gzipSize: true,
          brotliSize: true,
          emitFile: false,
          open: true, //如果存在本地服务端口，将在打包后自动展示
        }),
    ],
    resolve: {
      alias: {
        '@lexikos/doraemon-network': alias('../../packages/network/lib/main.ts'),
      },
    },
    build: {
      lib: {
        entry: resolve(__dirname, 'lib/main.ts'),
        name: 'doraemonBusiness',
        formats: ['es', 'umd'],
        fileName: (format) => `index.${format}.js`,
      },
      sourcemap: false,
      rollupOptions: {
        external: [...Object.keys(packageJson.dependencies)],
      },
    },
  };
});
