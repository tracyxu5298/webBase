import type { AliasToken } from 'ant-design-vue/es/theme/interface/alias';

const themes: Record<string, Partial<AliasToken>> = {
  blue: {
    colorPrimary: '#1677FF',
    colorBgLayout: '#EBECF5',
    colorBorderSecondary: '#e5e6eb',
    colorFillQuaternary: '#f2f3f5',
  },
  cyan: {
    colorPrimary: '#13C2C2',
    colorBgLayout: '#EBECF5',
    colorBorderSecondary: '#e5e6eb',
    colorFillQuaternary: '#f2f3f5',
  },
  gold: {
    colorPrimary: '#FAAD14',
    colorBgLayout: '#EBECF5',
    colorBorderSecondary: '#e5e6eb',
    colorFillQuaternary: '#f2f3f5',
  },
  green: {
    colorPrimary: '#52C41A',
    colorBgLayout: '#EBECF5',
    colorBorderSecondary: '#e5e6eb',
    colorFillQuaternary: '#f2f3f5',
  },
  pink: {
    colorPrimary: '#f25460',
    colorBgLayout: '#EBECF5',
    colorBorderSecondary: '#e5e6eb',
    colorFillQuaternary: '#f2f3f5',
  },
  purple: {
    colorPrimary: '#722ED1',
    colorBgLayout: '#EBECF5',
    colorBorderSecondary: '#e5e6eb',
    colorFillQuaternary: '#f2f3f5',
  },
  red: {
    colorPrimary: '#F5222D',
    colorBgLayout: '#EBECF5',
    colorBorderSecondary: '#e5e6eb',
    colorFillQuaternary: '#f2f3f5',
  },
  volcano: {
    colorPrimary: '#FA541C',
    colorBgLayout: '#EBECF5',
    colorBorderSecondary: '#e5e6eb',
    colorFillQuaternary: '#f2f3f5',
  },
};

export { themes };
