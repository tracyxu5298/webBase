import { type App } from 'vue';
import Report from '../utils/Report';

export default {
  install(app: App) {
    const report = new Report();
    app.provide('report', report);
    app.config.globalProperties.$report = report;
    return app;
  },
};
