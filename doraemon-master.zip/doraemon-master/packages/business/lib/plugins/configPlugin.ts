// import type { App } from 'vue';

// export default {
//   async getData() {
//     try {
//       // 注意: 各域(低码、低码)请求此路径, 需要在Nginx重定向到新基座域
//       const response = await fetch('/config.json');
//       const config = await response.json();
//       return config;
//     } catch (error) {
//       return Promise.reject(error);
//     }
//   },
//   async install(app: App) {
//     try {
//       const config = await this.getData();
//       app.provide('config', config);
//     } catch (error) {
//       console.warn(error);
//       setTimeout(() => this.getData(), 3000);
//     }
//     return app;
//   },
// };
