import { type App, unref } from 'vue';
import { message } from 'ant-design-vue';
import { Http, httpKey } from '@lexikos/doraemon-network';
import onLogout from '../utils/onLogout';
import onRefreshToken from '../utils/onRefreshToken';
import useAuthStore from '../stores/useAuthStore';

export interface HttpPluginOptions {
  version?: string;
}

export default {
  install(app: App, options?: HttpPluginOptions) {
    const store = useAuthStore();
    const token = unref(store.token);
    // const tokenKey = unref(store.tokenKey);
    const http = new Http({
      onLogout,
      onRefreshToken,
      showErrorMessage: message.error,
      headers: {
        'Content-Type': 'application/json',
        terminal: 'WebPC',
        // token: '',
        cuser_token: '',
        token,
        // [tokenKey]: token,
        version: (options && options.version) || '',
      },
    });
    app.provide(httpKey, http);
    app.config.globalProperties.$http = http;
    return app;
  },
};
