export enum UserTypes {
  Teacher = 1,
  ParentOrStudent,
}

/** 消息阅读状态 */
export enum ReadStatus {
  /** 未读 */
  Unread,
  /** 已读 */
  Read,
}

export enum WebNoticeTarget {
  /** 路由跳转 (默认)，path 为跳转路径 */
  Route = 1,
  /** 新窗口打开页面，path 为页面路径 */
  NewWindow = 2,
  /** 弹窗，path 为弹窗组件路径 */
  Modal = 3,
}
