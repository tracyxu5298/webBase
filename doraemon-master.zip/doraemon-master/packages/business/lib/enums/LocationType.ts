/**
 * 组织类型
 * 当 locationIndustry = "Edu" 教育行业
 * 当 locationLevel = 0 时, 类型有: 教育局 "Edu", 集团校 "Group:School"
 * 当 locationLevel = 1 时, 类型有: 十二年义务教育 "K12", 中高职 "Secondary:Vocational", 高校 "College", 前学教育 "Pre:School"
 * 当 locationIndustry = "Manu" 制造行业
 * 当 locationLevel = 0 时, 类型有: 企业总总 "Enterprise:Headquarters"
 * 当 locationLevel = 1 时, 类型有: 园区 "Park", 子公司 "Subsidiary"
 */
export enum LocationType {
  /** 教育局 */
  EducationBureau = 'Edu',
  /** 集团校 */
  GroupSchool = 'Group:School',
  /** 十二年义务教育 */
  K12 = 'K12',
  /** 中高职 */
  VocationalEducation = 'Secondary:Vocational',
  /** 高校 */
  College = 'College',
  /** 学前教育 */
  PreprimaryEducation = 'Pre:School',
  /** 企业总部 */
  EnterpriseHeadquarter = 'Enterprise:Headquarters',
  /** 园区 */
  Park = 'Park',
  /** 子公司 */
  Subsidiary = 'Subsidiary',
}
