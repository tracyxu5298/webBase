/**
 * 组织行业
 */
export enum LocationIndustry {
  /** 教育行业 */
  Edu = 'Edu',
  /** 制造行业 */
  Manu = 'Manu',
}
