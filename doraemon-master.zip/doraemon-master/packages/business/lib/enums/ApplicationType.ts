/**
 * @value 1 旧基座
 * @value 2 新基座
 * @value 3 第三方
 */
export enum ApplicationType {
  old = 1,
  new,
  third,
}
