/**
 * 用户身份
 * */
export enum UserIdentity {
  /** 0: 教职工，或教育局人员 */
  Teacher,
  /** 1: 学生 */
  Student,
  /** 2: 家长 */
  Parent,
  /** 3: 其他 */
  Other,
  /** 4. 外部人员 */
  Outsider,
}
