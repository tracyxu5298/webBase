/**
 * 按钮权限编码
 */
export enum PermissionCode {
  btn_add = 'btn_add', // 新增
  btn_edit = 'btn_edit', // 编辑
  btn_detail = 'btn_detail', // 详情
  btn_delete = 'btn_delete', // 删除
  btn_batchDelete = 'btn_batchDelete', // 批量删除
  btn_batchPrint = 'btn_batchPrint', // 批量打印
  btn_copy = 'btn_copy', // 复制
  btn_import = 'btn_import', // 导入
  btn_export = 'btn_export', // 导出
}
