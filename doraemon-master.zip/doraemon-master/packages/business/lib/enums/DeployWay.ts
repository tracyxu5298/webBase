/**
 * 部署方式
 * */
export enum DeployWay {
  /** 0: 私有化 */
  Private,
  /** 1: 公有云 */
  Public,
  /** 2: 混合云 */
  Mixed,
}
