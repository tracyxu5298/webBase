/**
 * 组织级别
 */
export enum LocationLevel {
  /** 0: 管理单位，局端 */
  Bureau,
  /** 1: 执行单位，校端 */
  School,
}
