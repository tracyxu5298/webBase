/**
 * @value 0 应用中心列表
 * @value 1 收藏应用
 * @value 2 主导航栏
 */
export enum ApplicationPosition {
  default = 0,
  favorite = 1,
  navigation = 2,
}
