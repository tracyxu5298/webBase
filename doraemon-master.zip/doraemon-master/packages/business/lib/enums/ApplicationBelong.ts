/**
 * @value 1 业务应用
 * @value 2 系统应用
 */
export enum ApplicationBelong {
  product = 1,
  system = 2,
}
