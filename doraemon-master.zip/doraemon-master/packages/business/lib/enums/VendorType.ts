/**
 * 厂商类型(第三方应用标识)
 * */
export enum VendorType {
  /** 内部应用(原生应用)  */
  Internal,
  /** 外部应用(第三方应用) */
  Third,
}
