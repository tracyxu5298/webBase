/** 任务变更类型 */
export enum ChangeType {
  /** 任务已完成 */
  Complete = 1,
  /** 任务超时 */
  Timeout = 2,
}
