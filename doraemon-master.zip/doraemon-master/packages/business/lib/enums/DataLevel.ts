/**
 * 数据等级
 *
 * - 0: 年级
 * - 1: 班级
 * - 2: 学校
 * - 3: 区/县（教育局）
 * - 4: 超管
 */
export enum DataLevel {
  SchoolGrade = 0,
  SchoolClass = 1,
  School = 2,
  EducationAuthority = 3,
  Administrator = 4,
}
