/**
 * 应用大类编码（旧基座React版）
 */
export enum AppTypeCode {
  All = 'All',
  Configuration_center = 'Configuration:Center',
  Comprehensive = 'Comprehensive',
  Safe = 'Safe',
  Green = 'Green',
  Health = 'Health',
  Civilization = 'Civilization',
  Vision = 'Vision:Screening:Bureau',
  Device = 'Intelligent:Inspection',
  VisionTraining = 'Vision:Training',
}
