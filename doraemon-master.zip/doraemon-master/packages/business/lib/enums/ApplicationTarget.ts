/**
 * @value 1 系统内打开
 * @value 2 新标签打开
 */
export enum ApplicationTarget {
  self = 1,
  blank = 2,
}
