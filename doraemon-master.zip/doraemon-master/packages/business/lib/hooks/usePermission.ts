import { unref, computed, type ComputedRef } from 'vue';
import { useRoute } from 'vue-router';
import useApplicationMenuStore from '../stores/useApplicationMenuStore';
import type { IMenu } from '../types/ApplicationMenu';

/**
 * 根据浏览器URL路径查找菜单, 包括父亲和祖先菜单
 * @param {AppMenu[]} menus - 来自服务端返回的应用菜单数据.
 * @param {string} pathname - 浏览器URL路径`location.pathname`.
 * @return {AppMenu[]} 返回菜单对象数组.
 */
function getMenusByPathname(menus: IMenu[], pathname: string): IMenu[] {
  const result: IMenu[] = [];
  for (let i = 0, len = menus.length; i < len; i++) {
    const menu = menus[i];
    const { path, query } = menu;
    if (path && pathname.includes(`${path}${query || ''}`)) {
      return [menu]; // 叶子菜单
    }
    if (Array.isArray(menu.children) && menu.children.length > 0) {
      result.push(menu); // 添加父菜单 (叶子菜单不一定匹配)
      const m = getMenusByPathname(menu.children, pathname); // AppMenu[]
      if (m.length > 0) {
        return result.concat(m); // 已找到, 添加子菜单
      } else {
        result.pop(); // 未找到, 删除父菜单
      }
    }
  }
  return result; // [根级菜单，父级菜单，叶子菜单]
}

function usePermission(_appCode: string, permissionCode: string): ComputedRef<boolean> {
  const route = useRoute();
  const store = useApplicationMenuStore();
  return computed(() => {
    const result = getMenusByPathname(unref(store.data), route.path);
    const permissions = result.pop()?.permissions;
    const found = !!permissions?.find((p) => p.code === permissionCode);
    return found;
  });

  // const route = useRoute();
  // const store = useApplicationMenuStore();
  // // TODO: currentAppCode 持久化
  // // state: ComputedRef<Record<string, IMenuState>>
  // const state = computed(() => unref(store.state));
  // return computed(() => {
  //   const s = state.value[appCode];
  //   if (s && s.menus) {
  //     const result = getMenusByPathname(s.menus, route.path);
  //     const permissions = result.pop()?.permissions;
  //     const found = !!permissions?.find((p) => p.code === permissionCode);
  //     return found;
  //   }
  //   return false;
  // });
}

export default usePermission;
