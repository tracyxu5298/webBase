export default function useOnline() {
  return navigator.onLine;
}
