// import { inject } from 'vue';
// import { httpKey, type Http } from '@lexikos/doraemon-network';
import { Http } from '@lexikos/doraemon-network';

// 返回`Http`实例, 相当于在模板中使用`$http`
// const useHttp = (): Http => {
//   return inject(httpKey)!;
// };

const useHttp = (): Http => {
  return Http.getInstance();
};

export default useHttp;
