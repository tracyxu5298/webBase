import { inject } from 'vue';

type WidgetConfig<T = any> = {
  title: string;
  demoSwitch: boolean;
  demoData: T | undefined | null;
};

export const useWidgetConfig = <T = any>() => {
  const { title, demoSwitch, demoData } = inject('WIDGET_CONFIG', {} as any);
  return {
    /** 小组件标题 */
    title,
    /** 是否开启演示数据 */
    demoSwitch: !!demoSwitch,
    /** 演示数据内容 */
    demoData: (() => {
      if (!demoData) {
        return null;
      }
      try {
        return JSON.parse(demoData);
      } catch (e) {
        console.error('DemoData 解析错误:', e);
        return null;
      }
    })(),
  } as WidgetConfig<T>;
};
