import { unref, h } from 'vue';
import { useRouter } from 'vue-router';
import { Modal, message } from 'ant-design-vue';
import { cloneDeep } from 'lodash-es';
import { LiveNotifyJumpType, useLiveNotifyJump } from './NoticeCenter/useLiveNotifyJump';
import useAssetMaterialPipe from './NoticeCenter/useAssetMaterialPipe';
import useInstrumentPipe from './NoticeCenter/useInstrumentPipe';
import { useIframeNoticeModal } from '../stores';
import { useAccessToken, useIsBureau, useNoticeCenterService } from '.';
import type { NoticeItem } from '../types';
import { ReadStatus, WebNoticeTarget } from '../enums';
import useRefreshToken from './useRefreshToken';
// import FeedbackDetail from '../components/Feedback/Detail.vue';

export const useNoticeDetail = () => {
  const _router = useRouter();

  const router = _router || {
    push: (options: any) => {
      if (typeof options === 'string') {
        window.history.pushState({}, '', options);
      } else {
        window.history.pushState(options.state || {}, '', options.path);
      }
    },
  };

  const {
    checkLiveNotifyJumpType,
    jumpToClassroomDetail,
    teachingResearchOnlineJumpType,
    eduOrSchoolPath,
    jumpToTeachingActionDetail,
  } = useLiveNotifyJump();

  /** 资产和耗材消息分发 */
  const assetMaterialPipe = useAssetMaterialPipe();
  /** 大型仪器管理消息分发 */
  const instrumentPipe = useInstrumentPipe();

  const iframeNoticeModalStore = useIframeNoticeModal();
  const { readNotice } = useNoticeCenterService();

  const accessToken = useAccessToken();
  const refreshToken = useRefreshToken();

  const handleOpenIframeModal = (payload: any) => {
    const iframe: HTMLIFrameElement | undefined = unref(iframeNoticeModalStore.iframeRef);
    if (!iframe || !unref(iframeNoticeModalStore.ready)) {
      console.warn('Iframe not Ready.');
      return;
    }
    iframeNoticeModalStore.setVisible(true);
    iframe?.contentWindow?.postMessage(
      {
        type: 'openNoticeModal',
        payload: cloneDeep(payload),
      },
      '*',
    );
  };

  const withTimestamp = (path: string) =>
    `${path}${path.includes('?') ? '&' : '?'}t=${+new Date()}`;

  const replaceToken = (path: string) => {
    let result = path.replace('${AUTH_TOKEN}', accessToken.value);
    result = result.replace('${REFRESH_TOKEN}', refreshToken.value || '');
    return result;
  };

  const transformPath = (path: string) => replaceToken(withTimestamp(path));

  /** 点击消息通知详情操作 */
  const handleNoticeDetail = (record: NoticeItem, callback?: () => void) => {
    if (!record) {
      return;
    }
    const { bizDataJson, id, readStatus, bizCode, path, target, ...rest } = record ?? {};
    const newBizDataJson = JSON.parse(bizDataJson || '{}');
    const { alarmRecordId, reportId, reportBizCode } = newBizDataJson;

    if (readStatus === ReadStatus.Unread) {
      readNotice(id).then(() => {
        callback?.();
      });
    }

    const createPayloadData = () => ({
      visible: true,
      detailId: alarmRecordId,
      bizDataJson: newBizDataJson,
      id,
      readStatus,
      detailIdList: [],
    });

    // 新的消息处理方式，有传 path 的情况，统一按此处理
    if (path) {
      switch (target) {
        // case WebNoticeTarget.Modal:
        //   // TODO: 弹窗处理
        //   break;
        case WebNoticeTarget.NewWindow:
          window.open(transformPath(path));
          break;
        case WebNoticeTarget.Route:
        default:
          router.push(transformPath(path));
      }
      return;
    }

    // 以下为兼容旧消息跳转及弹窗处理逻辑
    // 后续增加的应用消息，应使用统一的 target + path 方式
    switch (bizCode) {
      case 'alarm':
      case 'Electronic:Fence:Alarm':
      case 'Device:Exception:Alarm':
      case 'SOS:Call:Alarm':
      case 'One:Click:Alarm':
      case 'Student:Archive:Miss:Alarm':
      case 'Student:Archive:Danger:Alarm': {
        const payload = {
          modalType: 'AlarmDetailDialog',
          data: createPayloadData(),
        };
        handleOpenIframeModal(payload);
        break;
      }
      case 'Medication:Notice': {
        router.push(`/medication-regist/home`);
        break;
      }
      case 'Resource:Collection:Notice':
      case 'Resource:Likes:Notice':
      case 'Resource:Generated:Notice': {
        window.open(
          `/resource-management/resource-list/detail?lessonId=${newBizDataJson?.resourceId || ''}`,
        );
        break;
      }
      case 'vision:screen': {
        router.push(`/vision-screening/screen/work`);
        break;
      }
      case 'Disease:Management': {
        router.push(`/disease-management/information`);
        break;
      }
      case 'Material:Notice':
      case 'AssetManage:Notice': {
        assetMaterialPipe(record);
        break;
      }
      case 'Outsider:Register:Notice':
      case 'Instrument:Notice': {
        instrumentPipe(record);
        break;
      }
      case 'Training:Room:Reservation': {
        const payload = {
          modalType: 'TrainMessageModel',
          data: createPayloadData(),
        };
        handleOpenIframeModal(payload);
        break;
      }
      case 'Report:Subscribe': {
        if (reportBizCode === 'Report:AiSceneDaily') {
          router.push({
            path: `/ai-monitor/security-scene-config/report-detail/new`,
            state: {
              reportId,
            },
          });
          return;
        }
        const payload = {
          modalType: 'CommonNotice',
          data: { visible: true, id, readStatus, detail: { bizCode, bizDataJson, ...rest } },
        };
        handleOpenIframeModal(payload);
        break;
      }
      case 'Information:Delivery': {
        // 信息发布审核列表
        router.push('/information-delivery/information-review');
        break;
      }
      case 'Training:Room:Apply':
      case 'Training:Room:Late':
      case 'Training:Room:Absenteeism':
      case 'Training:Room:Cancel':
      case 'Training:Room:Reject':
      case 'Training:Room:Success':
      case 'Training:Room:End':
      case 'Training:Room:End:Advance':
      case 'Course:Room:Apply':
      case 'Course:Room:Late':
      case 'Course:Room:Cancel':
      case 'Course:Room:Reject':
      case 'Course:Room:Absenteeism':
      case 'Course:Room:Success':
      case 'Course:Room:End':
      case 'Course:Room:End:Advance': {
        router.push(`/training-management/reservation/record/detail/${newBizDataJson.id}`);
        break;
      }
      case 'Live:Lesson:Advance:Time:Start:Notice': {
        router.push(
          `/classroom-on-cloud/management/opening-classroom?id=${newBizDataJson.lessonId}`,
        );
        break;
      }
      case 'zntb': {
        const pathname = `/LowcodeApps/zntb/LowcodePage/fillReport/home?activeKey=1&forcePath=1&reportId=${
          newBizDataJson?.reportId || ''
        }&recordId=${newBizDataJson?.flowBeforeId || ''}&t=${Date.now()}`;
        router.push(pathname);
        break;
      }
      case 'zntbOffice': {
        const pathname = `/LowcodeApps/zntb/LowcodePage/fillReport/home?activeKey=1&forcePath=1&reportId=${
          newBizDataJson?.reportId || ''
        }&recordId=${newBizDataJson?.flowBeforeId || ''}&t=${Date.now()}`;
        router.push(pathname);
        break;
      }
      // 待办中心
      case 'Todo:Center': {
        const isBureau = useIsBureau().value;
        if (newBizDataJson.webPagePath) {
          const jsonKey: string = (
            {
              1: 'launch',
              2: 'todo',
              3: 'copy',
              4: 'completed',
            } as any
          )[newBizDataJson.type];
          let path = '';
          if (isBureau) {
            path = newBizDataJson.webPagePath[jsonKey + 'Edu'];
          }
          if (!path) {
            path = newBizDataJson.webPagePath[jsonKey];
          }
          if (!path) {
            message.warn('未配置跳转路径。');
            return;
          }
          router.push(path);
          return;
        }
        const typeStr: any = {
          1: 'Mine',
          2: 'Todo',
          3: 'CarbonCopy',
          4: 'Done',
        };
        router.push(
          `/LowcodeApps/TodoCenter/LowcodePage/TodoCenter/${
            typeStr[newBizDataJson.type]
          }/Detail?id=${newBizDataJson.processId}`,
        );
        break;
      }
      // 增加校务-协同通知消息提示
      case 'CollaborateNotice':
      case 'CollaborateNoticeEdu':
      case 'documentv3': {
        if (record?.webPath) {
          router.push(record?.webPath);
        }
        break;
      }
      // 会议管理
      case 'meetingManage:reserve': {
        router.push(path);
        break;
      }
      case 'Feedback': {
        import('../components/Feedback/Detail.vue').then((FeedbackDetail) => {
          Modal.info({
            title: '通知详情',
            content: h(FeedbackDetail.default, newBizDataJson),
            centered: true,
            closable: true,
            maskClosable: true,
            width: 800,
            okText: '好的',
            icon: null,
          });
        });
        break;
      }
      default:
        if (checkLiveNotifyJumpType(bizCode) === LiveNotifyJumpType.Detail) {
          router.push(jumpToClassroomDetail(newBizDataJson));
        } else if (checkLiveNotifyJumpType(bizCode) === LiveNotifyJumpType.List) {
          router.push(`/classroom-on-cloud/management/joining-classroom`);
        } else if (teachingResearchOnlineJumpType(bizCode) === LiveNotifyJumpType.List) {
          router.push(`/${eduOrSchoolPath()}/teaching-activity/teaching-join`);
        } else if (teachingResearchOnlineJumpType(bizCode) === LiveNotifyJumpType.Detail) {
          router.push(jumpToTeachingActionDetail(newBizDataJson));
        } else if (teachingResearchOnlineJumpType(bizCode) === LiveNotifyJumpType.teachingDetail) {
          router.push(
            `/${eduOrSchoolPath()}/teaching-activity/teaching-launch?detailId=${
              newBizDataJson.lessonId
            }`,
          );
        } else {
          Modal.info({
            title: '通知详情',
            content: record.content,
            centered: true,
            okText: '确定',
            icon: null,
          });
        }
        break;
    }
  };

  return {
    handleNoticeDetail,
  };
};
