import { unref, computed, type ComputedRef } from 'vue';
import useUserInfoStore from '../stores/useUserInfoStore';

/**
 * 当前用户名称
 */
function useUseName(): ComputedRef<string | null> {
  const store = useUserInfoStore();
  return computed(() => {
    const data = unref(store.data);
    if (data) {
      return data.userName;
    }
    return null;
  });
}

export default useUseName;
