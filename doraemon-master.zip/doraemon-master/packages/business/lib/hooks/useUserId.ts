import { unref, computed, type ComputedRef } from 'vue';
import useUserInfoStore from '../stores/useUserInfoStore';

/**
 * 当前用户标识
 */
function useUserId(): ComputedRef<string | null> {
  const store = useUserInfoStore();
  return computed(() => {
    const data = unref(store.data);
    if (data) {
      return data.id;
    }
    return null;
  });
}

export default useUserId;
