import { computed, type ComputedRef } from 'vue';
import useLocationLevel from './useLocationLevel';
import { LocationLevel } from '../enums/LocationLevel';

/**
 * 当前组织是否为校端
 */
function useIsSchool(): ComputedRef<boolean> {
  const level = useLocationLevel();
  return computed(() => {
    return level.value === LocationLevel.School;
  });
}

export default useIsSchool;
