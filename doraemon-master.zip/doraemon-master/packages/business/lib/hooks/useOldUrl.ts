import { computed, type ComputedRef } from 'vue';
import type { ImportMetaEnvExtra } from '../types/ImportMetaEnvExtra';
import useIsBureau from './useIsBureau';
import useIsParentOrStudent from './useIsParentOrStudent';

/**
 * 获取旧基座域名前缀
 * useOldUrl<K extends ImportMetaEnvExtra>(importMetaEnv: K)
 * importMetaEnv: Parameters<typeof useOldUrl>[0]
 */
function useOldUrl(importMetaEnv: ImportMetaEnvExtra): ComputedRef<string> {
  const isBureau = useIsBureau();
  const isParentOrStudent = useIsParentOrStudent();
  return computed(() => {
    if (isBureau.value === true) {
      return importMetaEnv.VITE_IMP2_EDU_PREFIX; // 局端, 如 "/imp2-edu"
    }
    if (isParentOrStudent.value === true) {
      return importMetaEnv.VITE_IMP2_STU_PREFIX; // 家长学生端, 如 "/imp2-stu"
    }
    return importMetaEnv.VITE_IMP2_PREFIX; // 校端, 如 "/imp2"
  });
}

export default useOldUrl;
