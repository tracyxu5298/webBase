import { computed, type ComputedRef } from 'vue';
import useUserIdentity from './useUserIdentity';
import { UserIdentity } from '../enums/UserIdentity';

/**
 * 当前用户身份是否为家长
 */
function useIsParent(): ComputedRef<boolean> {
  const userIdentity = useUserIdentity();
  return computed(() => {
    // 隐含前提: locationLevel.value === LocationLevel.School
    return userIdentity.value === UserIdentity.Parent;
  });
}

export default useIsParent;
