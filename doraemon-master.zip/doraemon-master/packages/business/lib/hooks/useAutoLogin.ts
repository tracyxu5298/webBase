import { unref } from 'vue';
import { type RouteLocationNormalized } from 'vue-router';
import { Http } from '@lexikos/doraemon-network';
import { clearStorage } from '../utils';
import { useAuthStore } from '../stores';

const useAutoLogin = ({ to }: { to: RouteLocationNormalized }) => {
  const { _t_, _tk_, ...rest } = to.query || {};
  if (_t_) {
    const store = useAuthStore();
    clearStorage();
    store.set({
      token: _t_ as string,
      tokenKey: _tk_ as string,
    });
    Http.getInstance().setHeader({
      token: '',
      cuser_token: '',
      [(_tk_ as string) || unref(store.tokenKey)]: _t_ as string,
    });
    return { ...to, query: rest };
  }
};

export default useAutoLogin;
