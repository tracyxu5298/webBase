import { debounce, map } from 'lodash-es';
import { useRouter } from 'vue-router';

interface BizData {
  code: string;
  id: string;
}

export const ASSET_BIZ_CODE = 'AssetManage:Notice';

export const MATERIAL_BIZ_CODE = 'Material:Notice';

export const obj2Query = (obj: any) => map(obj, (v, k) => `${k}=${v}`).join('&');

/**
 * @hack
 * 应用间切换存在相同 params 时，会触发副作用
 * useMemo 包完后，消息通知停留在当前页不会重新请求
 * 消息通知添加制定时间戳，依赖更新
 * 添加调整记得业务那边处理下依赖
 */

const MATERIAL_PATH: Record<string, string> = {
  // 耗材采购申请
  materialPurchase: '/purchase/apply/edit',
};

const ASSET_PATH: Record<string, string> = {
  // 资产报废
  assetUseless: '/useless/edit',
  // 报修管理
  assetRepair: '/repair/apply/edit',
  // 资产借用
  assetBorrow: '/borrow/apply/edit',
  // 资产变更
  assetChange: '/change/edit',
  // 验收入库
  assetPut: '/put/edit',
  // 采购申请
  assetPurchase: '/purchase/apply/edit',
};

/** 资产和耗材消息分发 */
const useAssetMaterialPipe = () => {
  const router = useRouter();

  const push = (path: string, params?: Record<string, string | number>) => {
    router.push(`${path}${params ? `?${obj2Query(params)}` : ''}`);
  };

  const _pipe = (detail: any) => {
    if (!detail?.bizDataJson) {
      return;
    }

    const { bizCode, bizDataJson } = detail;
    let bizData: BizData = {} as BizData;
    try {
      bizData = JSON.parse(bizDataJson);
    } catch (error) {
      bizData = {} as BizData;
    }

    if (!bizData.code) {
      return;
    }

    const { code, id } = bizData;

    let path = '';

    if (bizCode === ASSET_BIZ_CODE && ASSET_PATH[code]) {
      path = `/asset-management${ASSET_PATH[code]}`;
    }
    if (bizCode === MATERIAL_BIZ_CODE && MATERIAL_PATH[code]) {
      path = `/consumable-management${MATERIAL_PATH[code]}`;
    }

    if (path) {
      push(path, { id, view: 1, [code]: Date.now() });
    }
  };

  const pipe = debounce(_pipe, 500);

  return pipe;
};

export default useAssetMaterialPipe;
