import { useRouter } from 'vue-router';
import { obj2Query } from './useAssetMaterialPipe';
import { debounce } from 'lodash-es';

interface BizData {
  pageType: string;
  id: string;
}

export const INSTRUMENT_BIZ_CODE = 'Instrument:Notice';
export const OUTSIDER_BIZ_CODE = 'Outsider:Register:Notice';

/**
 * @hack
 * 应用间切换存在相同 params 时，会触发副作用
 * useMemo 包完后，消息通知停留在当前页不会重新请求
 * 消息通知添加制定时间戳，依赖更新
 * 添加调整记得业务那边处理下依赖
 */
const INSTRUMENT_PATH: Record<string, string> = {
  // 我的申请
  myApply: '/task/apply',
  // 待我审核
  myApprove: '/task/approve',
  // 检测任务
  myInspection: '/task/inspection',
};

/** 大仪管理消息分发 */
const useInstrumentPipe = () => {
  const router = useRouter();

  const push = (
    path: string,
    params?: Record<string, string | number>,
    state?: Record<string, string>,
  ) => {
    router.push({
      path: `${path}${params ? `?${obj2Query(params)}` : ''}`,
      state,
    });
  };

  const _pipe = (detail: any) => {
    if (detail?.bizCode === OUTSIDER_BIZ_CODE) {
      sessionStorage.setItem('outsideUsersTab', 'audit');
      push('/OrganizationCenter/OutsideUsers', undefined, {});
      return;
    }

    if (!detail?.bizDataJson) {
      return;
    }

    const { bizCode, bizDataJson } = detail;
    let bizData: BizData = {} as BizData;
    try {
      bizData = JSON.parse(bizDataJson);
    } catch (error) {
      bizData = {} as BizData;
    }

    if (!bizData.pageType) {
      return;
    }

    const { pageType, id } = bizData;

    let path = '';

    if (bizCode === INSTRUMENT_BIZ_CODE && INSTRUMENT_PATH[pageType]) {
      path = `/instrument-management${INSTRUMENT_PATH[pageType]}`;
    }

    if (path) {
      push(path, { id, view: 1, [pageType]: Date.now() });
    }
  };

  const pipe = debounce(_pipe, 500);

  return pipe;
};

export default useInstrumentPipe;
