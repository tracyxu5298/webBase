/**
 * @see imp-web: projects\platform\src\pages\notice-center\utils\index.ts
 */

import useIsBureau from '../useIsBureau';
import useIsParentOrStudent from '../useIsParentOrStudent';
import useUserId from '../useUserId';

/**
 * 录播消息跳转类型
 * None: 非录播消息
 */
export enum LiveNotifyJumpType {
  None,
  List,
  Detail,
  teachingDetail,
}

export const useLiveNotifyJump = () => {
  const isBureau = useIsBureau();
  const isParentOrStudent = useIsParentOrStudent();
  const userId = useUserId();

  /**
   * 判断录播消息跳转类型
   * (非录播消息会返回 LiveNotifyJumpType.None)
   * @param bizCode 消息业务code
   * @returns
   */
  const checkLiveNotifyJumpType = (bizCode: string) => {
    if (isParentOrStudent.value) {
      /** 跳转到课堂列表页的code */
      const list = ['Live:Lesson:Invite:Notice', 'Live:Lesson:Cancel:Notice'];
      if (list.includes(bizCode)) return LiveNotifyJumpType.List;
      /** 跳转到云上课堂直播详情页的code */
      const detailList = [
        'Live:Lesson:Is:About:To:Start:Notice',
        'Live:Lesson:Registration:Review:Notice',
        'Live:Lesson:Edit:Publish:StartTime:Notice',
      ];
      if (detailList.includes(bizCode)) return LiveNotifyJumpType.Detail;
    } else {
      /** 跳转到课堂列表页的code */
      const list = ['Live:Lesson:Cancel:Notice'];
      if (list.includes(bizCode)) return LiveNotifyJumpType.List;
      /** 跳转到云上课堂直播详情页的code */
      const detailList = [
        'Live:Lesson:Invite:Notice',
        'Live:Lesson:Is:About:To:Start:Notice',
        'Live:Lesson:Registration:Review:Notice',
        'Live:Lesson:Edit:Publish:StartTime:Notice',
      ];
      if (detailList.includes(bizCode)) return LiveNotifyJumpType.Detail;
    }

    return LiveNotifyJumpType.None;
  };

  /**
   * 判断在线教研消息跳转类型
   * (非录播消息会返回 LiveNotifyJumpType.None)
   * @param bizCode 消息业务code
   * @returns
   */
  const teachingResearchOnlineJumpType = (bizCode: string) => {
    /**
     * 跳转到加入课堂列表页的code
     * 听课端: 取消提醒，打开加入课堂的列表页面
     */
    const list = ['Teaching:Activities:Cancel:Notice']; //线上教研取消提醒
    if (list.includes(bizCode)) return LiveNotifyJumpType.List;
    /**
     * 跳转到在线教研详情页、加入课堂页的code
     * 听课端: 开始提醒，打开本次在线教研的详情页（即直播页面）
     * 听课端: 邀请通知，打开本次在线教研的直播详情页面。
     * 授课端: 开始提醒，打开本次在线教研的进入课堂页（即直播页面）
     */
    const detailList = [
      'Teaching:Activities:Is:About:To:Start:Notice', //线上教研即将开始提醒
      'Teaching:Activities:Invite:Notice', //线上教研邀请通知
    ];
    if (detailList.includes(bizCode)) return LiveNotifyJumpType.Detail;
    /**
     * 跳转到授课端在线教研详情页的code
     * 授课端: 局级发起教研安排提醒，打开本次在线教研的详情页（即课堂详情信息页）
     */
    const teachingDetailList = [
      'Teaching:Activities:Publish:Notice', //教研安排提醒
    ];
    if (teachingDetailList.includes(bizCode)) return LiveNotifyJumpType.teachingDetail;
    return LiveNotifyJumpType.None;
  };

  const jumpToClassroomDetail = (newBizDataJson: any) => {
    if (isParentOrStudent.value) {
      const pathName = `/classroom-on-cloud/management/joining-classroom?detailId=${newBizDataJson.lessonId}&studentId=${newBizDataJson.studentId}&studentName=${newBizDataJson.personName}`;
      return pathName;
    } else {
      const pathName =
        newBizDataJson.teacherId === userId.value
          ? `/classroom-on-cloud/management/opening-classroom?detailId=${newBizDataJson.lessonId}`
          : `/classroom-on-cloud/management/joining-classroom?detailId=${newBizDataJson.lessonId}`;
      return pathName;
    }
  };

  const eduOrSchoolPath = () => {
    return isBureau.value ? 'teaching-research-online-bureau' : 'teaching-research-online';
  };

  const jumpToTeachingActionDetail = (newBizDataJson: any) => {
    return newBizDataJson.teacherId === userId.value
      ? `/${eduOrSchoolPath()}/teaching-activity/teaching-launch?detailId=${
          newBizDataJson.lessonId
        }&isEnter=true`
      : `/${eduOrSchoolPath()}/teaching-activity/teaching-join?detailId=${newBizDataJson.lessonId}`;
  };

  return {
    checkLiveNotifyJumpType,
    jumpToClassroomDetail,
    teachingResearchOnlineJumpType,
    eduOrSchoolPath,
    jumpToTeachingActionDetail,
  };
};
