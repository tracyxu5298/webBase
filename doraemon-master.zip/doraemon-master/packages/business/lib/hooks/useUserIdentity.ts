import { unref, computed, type ComputedRef } from 'vue';
import useUserInfoStore from '../stores/useUserInfoStore';
import type { UserIdentity } from '../enums';

/**
 * 当前用户身份
 */
function useUserIdentity(): ComputedRef<UserIdentity | null> {
  const store = useUserInfoStore();
  return computed(() => {
    const data = unref(store.data);
    if (data) {
      return data.userIdentity;
    }
    return null;
  });
}

export default useUserIdentity;
