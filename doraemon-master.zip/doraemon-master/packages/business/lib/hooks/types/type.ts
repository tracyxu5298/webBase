export interface LocationItem {
  id: string;
  name: string;
  searchedName?: string;
  locationLevel: number;
  locationLevelName: string;
  parentId: string;
  parentName: string;
  isRecentlyLogin: boolean;
  relationship: string;
  childName: string;
  childId: string;
  logoFileUrl: string;
  children: LocationItem[];
}

export interface LocationByUserType {
  userType: number;
  locations: LocationItem[];
}
