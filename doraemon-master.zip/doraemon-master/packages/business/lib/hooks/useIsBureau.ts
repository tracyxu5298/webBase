import { computed, type ComputedRef } from 'vue';
import useLocationLevel from './useLocationLevel';
import { LocationLevel } from '../enums/LocationLevel';

/**
 * 当前组织是否为局端
 */
function useIsBureau(): ComputedRef<boolean> {
  const level = useLocationLevel();
  return computed(() => {
    return level.value === LocationLevel.Bureau;
  });
}

export default useIsBureau;
