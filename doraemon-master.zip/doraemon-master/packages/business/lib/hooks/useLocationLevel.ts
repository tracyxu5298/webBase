import { unref, computed, type ComputedRef } from 'vue';
import useUserInfoStore from '../stores/useUserInfoStore';
import type { LocationLevel } from '../enums';

/**
 * 当前组织级别
 */
function useLocationLevel(): ComputedRef<LocationLevel | null> {
  const store = useUserInfoStore();
  return computed(() => {
    const data = unref(store.data);
    if (data) {
      return data.locationLevel;
    }
    return null;
  });
}

export default useLocationLevel;
