import { ref } from 'vue';
import useHttp from '../useHttp';
import type { Application } from '../../types';

const useApplicationsFavorite = () => {
  const loading = ref(false);
  const data = ref<Application[]>([]);

  function saveApplicationsFavorite(newData: Application[]) {
    data.value = newData;
  }

  async function getApplicationsFavorite(): Promise<Application[]> {
    try {
      loading.value = true;
      const http = useHttp();
      const response = await http.get('/api/auth/favoriteApplications?clientType=1');
      data.value = response;
      return response;
    } catch (error: any) {
      return Promise.reject(error);
    } finally {
      loading.value = false;
    }
  }

  return { loading, data, getApplicationsFavorite, saveApplicationsFavorite };
};

export default useApplicationsFavorite;
