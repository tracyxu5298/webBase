import { onUnmounted } from 'vue';
import { message } from 'ant-design-vue';
import type { Application } from '../../types';
import useHttp from '../useHttp';

// 第三方应用跳转
const useThirdApplication = () => {
  const http = useHttp();

  let loadingTimer: any = null;
  let hide: any = null;

  const _hideLoading = () => {
    loadingTimer && clearTimeout(loadingTimer);
    hide?.();
  };

  /**
   * 第三方应用需要去云端获取新的地址
   * 地址上会存在需要替换的参数，该参数具有时效性，所以只能点击时获取
   * @param app
   * @returns
   */
  const getThirdAppInfo = async (app: Application) => {
    // 100ms 内不需要 loading
    loadingTimer = setTimeout(() => {
      hide = message.loading('正在获取链接，请稍等...', 0);
    }, 100);

    try {
      const response = await http.get(
        `/api/auth/applicationPaths/get/final/path?applicationId=${app.id}&clientType=1`,
      );

      _hideLoading();
      // 组装新的应用信息
      return {
        ...app,
        path: response.finalPath || app.path,
        target: response.openType ? response.openType : app.target,
      } as Application;
    } catch (error: any) {
      _hideLoading();
      return app;
    }
  };

  onUnmounted(() => {
    _hideLoading();
  });

  return { getThirdAppInfo };
};

export default useThirdApplication;
