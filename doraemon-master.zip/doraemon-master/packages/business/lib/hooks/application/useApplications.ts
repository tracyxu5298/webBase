import { ref } from 'vue';
import { filter } from 'lodash-es';
import useHttp from '../useHttp';
import type { Application } from '../../types';

const LOCAL_STORAGE_APPLICATION = 'applications';

/**
 * 过滤掉以下应用，为兼容旧应用菜单嵌套在新系统权限问题
 *
 * 校端应用
 * 家校管理：Home:School:Management
 * 用户管理：User:Management
 * 系统管理：System:Management
 * 办学基础：Basic:School:Management
 *
 * 局端应用
 * 用户管理：User:Management:Bureau
 * 资产管理：Asset:Management:Bureau
 * 系统管理：System:Management:Bureau
 */
const excludeApps = [
  'home:school:management',
  'user:management',
  'system:management',
  'user:management:bureau',
  'asset:management:bureau',
  'system:management:bureau',
];

const useApplications = () => {
  const loading = ref(false);
  const loaded = ref(false);
  const data = ref<Application[]>(getApplicationsByLocal() || []);

  function saveApplications(newData: Application[]) {
    data.value = newData;
    localStorage.setItem(LOCAL_STORAGE_APPLICATION, JSON.stringify(newData));
  }

  function resetApplications() {
    loading.value = false;
    loaded.value = false;
    data.value = [];
    localStorage.removeItem(LOCAL_STORAGE_APPLICATION);
  }

  function getApplicationsByLocal(): Application[] | null {
    const localData = localStorage.getItem(LOCAL_STORAGE_APPLICATION);
    if (localData) {
      return JSON.parse(localData);
    }
    return null;
  }

  async function getApplicationsByRemote() {
    try {
      loading.value = true;
      const http = useHttp();
      const response = await http.get<Application[]>('/api/auth/v1/applications');
      const apps = filter(response, (i) => !excludeApps.includes(i.code.toLowerCase()));
      saveApplications(apps); // 同步并保存最新数据
      return apps;
    } catch (error) {
      return Promise.reject(error);
    } finally {
      loading.value = false;
      loaded.value = true;
    }
  }

  // 本地优先
  async function getApplications(): Promise<Application[]> {
    const localData = getApplicationsByLocal();
    if (localData) {
      loaded.value = true;
      getApplicationsByRemote().catch((error) => console.warn('getApplications', error));
      return localData;
    }
    return getApplicationsByRemote();
  }

  return { loading, loaded, data, getApplications, resetApplications };
};

export default useApplications;
