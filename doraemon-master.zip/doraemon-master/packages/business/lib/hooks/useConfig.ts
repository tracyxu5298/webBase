// import { inject } from 'vue';
// import type { IConfig } from '../types';

// function useConfig() {
//   return inject('config') as IConfig;
// }

// export default useConfig;
