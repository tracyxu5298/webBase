import { unref, computed, type ComputedRef } from 'vue';
import useUserInfoStore from '../stores/useUserInfoStore';

/**
 * 当前用户手机号
 */
function useUsePhone(): ComputedRef<string | null> {
  const store = useUserInfoStore();
  return computed(() => {
    const data = unref(store.data);
    if (data) {
      return data.tel;
    }
    return null;
  });
}

export default useUsePhone;
