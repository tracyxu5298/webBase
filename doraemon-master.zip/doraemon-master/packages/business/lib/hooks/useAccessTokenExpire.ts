import { computed, unref, type ComputedRef } from 'vue';
import useAuthStore from '../stores/useAuthStore';

/**
 * 当前访问令牌 value
 * 用户身分为教职工, HTTP 请求头 key 是 "token"
 * 用户身份为家长或学生时, HTTP 请求头 key 是 "cuser_token"
 */
function useAccessTokenExpire(): ComputedRef<number> {
  const store = useAuthStore();
  return computed(() => {
    return unref(store.tokenExpire);
  });
}

export default useAccessTokenExpire;
