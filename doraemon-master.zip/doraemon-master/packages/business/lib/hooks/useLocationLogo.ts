import { unref, computed, type ComputedRef } from 'vue';
import useUserInfoStore from '../stores/useUserInfoStore';

/**
 * 当前组织徽标
 */
function useLocationLogo(): ComputedRef<string | null> {
  const store = useUserInfoStore();
  return computed(() => {
    const data = unref(store.data);
    if (data) {
      return data.logoFileUrl;
    }
    return null;
  });
}

export default useLocationLogo;
