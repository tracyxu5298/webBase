import { unref, computed, type ComputedRef } from 'vue';
import useUserInfoStore from '../stores/useUserInfoStore';
import type { LocationType } from '../enums';

/**
 * 当前组织类型
 */
function useLocationType(): ComputedRef<LocationType | null> {
  const store = useUserInfoStore();
  return computed(() => {
    const data = unref(store.data);
    if (data) {
      return data.locationType;
    }
    return null;
  });
}

export default useLocationType;
