import { unref, computed, type ComputedRef } from 'vue';
import useUserInfoStore from '../stores/useUserInfoStore';

/**
 * 当前用户头像
 */
function useUserAvatar(): ComputedRef<string | null> {
  const store = useUserInfoStore();
  return computed(() => {
    const data = unref(store.data);
    if (data) {
      return data.headImgUrl;
    }
    return null;
  });
}

export default useUserAvatar;
