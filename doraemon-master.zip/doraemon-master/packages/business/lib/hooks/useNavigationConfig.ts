import { ref } from 'vue';
import useHttp from './useHttp';
import type { Application } from '../types';

const LOCAL_STORAGE_NAVIGATION_CONFIG = 'navigationConfig';

const useNavigationConfig = () => {
  const loading = ref(false);
  const data = ref<Application[]>(getNavigationConfigByLocal() || []);

  function saveNavigationConfig(newData: Application[]) {
    data.value = newData;
    localStorage.setItem(LOCAL_STORAGE_NAVIGATION_CONFIG, JSON.stringify(newData));
  }

  function resetNavigationConfig() {
    data.value = [];
    localStorage.removeItem(LOCAL_STORAGE_NAVIGATION_CONFIG);
  }

  function getNavigationConfigByLocal(): Application[] | null {
    const localData = localStorage.getItem(LOCAL_STORAGE_NAVIGATION_CONFIG);
    if (localData) {
      return JSON.parse(localData);
    }
    return null;
  }

  async function getNavigationConfigByRemote() {
    try {
      loading.value = true;
      const http = useHttp();
      const response = await http.get('/api/auth/navigationConfig');
      const _data = response || [];
      saveNavigationConfig(_data); // 同步并保存最新数据
      return _data;
    } catch (error: any) {
      return Promise.reject(error);
    } finally {
      loading.value = false;
    }
  }

  // 本地优先
  async function getNavigationConfig(): Promise<Application[]> {
    const localData = getNavigationConfigByLocal();
    if (localData) {
      getNavigationConfigByRemote().catch((error) => console.warn('getNavigationConfig', error));
      return localData;
    }
    return getNavigationConfigByRemote();
  }

  return { loading, data, getNavigationConfig, resetNavigationConfig };
};

export default useNavigationConfig;
