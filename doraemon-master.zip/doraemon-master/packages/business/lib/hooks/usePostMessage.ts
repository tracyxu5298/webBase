import { h, render, onBeforeUnmount, ref, onMounted, type VNode } from 'vue';
import { message, notification, Spin, Modal } from 'ant-design-vue';
import { includes, endsWith, startsWith } from 'lodash-es';
import onLogout from '../utils/onLogout';
import { openNewWindow } from '../utils/openNewWindow';
import type {
  PostMessageEventData,
  IframeParams,
  JumpParams,
  MessageParams,
  NotificationParams,
  ModalFuncParams,
} from '../types';
import { useLocationLevel } from '.';

const usePostMessage = () => {
  const vNode = ref<VNode | null>(null);
  const el = ref<Element | null>(null);

  const withToken = (url: string) => {
    let res = url;
    let token = localStorage.getItem('token') || '';
    if (!token) {
      return res;
    }
    token = `token=${token}`;
    if (!includes(url, '?')) {
      res += `?${token}`;
      return res;
    }
    if (!endsWith(url, '&')) {
      res += `&${token}`;
    } else {
      res += token;
    }
    return res;
  };
  const widthOldBaseUrl = (url: string) => {
    const locationLevel = useLocationLevel();
    if (!/^https?:\/\//.test(url)) {
      let baseUrl = '';
      if (locationLevel.value === 0) {
        baseUrl = import.meta.env.VITE_IMP2_EDU_PREFIX;
      } else if (locationLevel.value === 1) {
        baseUrl = import.meta.env.VITE_IMP2_PREFIX;
      }
      return baseUrl + (startsWith(url, '/') ? url : '/' + url);
    }
    return url;
  };
  const createIframe = (props: IframeParams) => {
    // 创建实例
    el.value = document.createElement('div');
    document.body.appendChild(el.value);
    document.body.style.overflow = 'hidden';
    let src = withToken(props.url);
    if (props.old) {
      src = widthOldBaseUrl(src);
    }
    const instance = h('div', {}, [
      h(
        'div',
        {
          style: {
            position: 'fixed',
            inset: 0,
            zIndex: 1000,
            background: 'rgb(0 0 0 / 45%)',
            pointerEvents: 'auto',
            display: 'flex',
            justifyContent: 'center',
            alignItems: 'center',
            ...(props.bgStyles || {}),
          },
        },
        props.withLoading ? [h(Spin, { id: 'iframeLoading' })] : [],
      ),
      h('iframe', {
        style: {
          position: 'fixed',
          zIndex: 1000,
          height: props.height || '100vh',
          width: props.width || '100vw',
          border: 'none',
          outline: 'none',
          top: '50%',
          left: '50%',
          transform: 'translate(-50%, -50%)',
        },
        src,
      }),
    ]);
    // 将instance挂载到body上面
    render(instance, el.value);
    vNode.value = instance;
  };

  const handlePostMessageEvent = (event: MessageEvent) => {
    const eventData = event.data as PostMessageEventData;
    if (!eventData || !eventData.type) {
      return;
    }

    console.log('window.postMessage receive event data', eventData);

    switch (eventData.type) {
      case 'jump': {
        const jumpParams = eventData.params as JumpParams;
        if (jumpParams && jumpParams.url) {
          try {
            if (jumpParams._blank === true) {
              if (jumpParams.old) {
                openNewWindow(widthOldBaseUrl(jumpParams.url));
              } else {
                openNewWindow(jumpParams.url);
              }
            } else {
              history.pushState(jumpParams.state || {}, '', jumpParams.url);
            }
          } catch (error: any) {
            console.error(error);
          }
        } else {
          console.error('no jump url');
        }
        break;
      }
      case 'message': {
        const messageParams = eventData.params as MessageParams;
        if (messageParams && messageParams.content) {
          try {
            message.open(messageParams);
          } catch (error: any) {
            console.error(error);
          }
        } else {
          console.error('antv message 消息需要`content`属性');
        }
        break;
      }
      case 'notification': {
        const notificationParams = eventData.params as NotificationParams;
        if (notificationParams && notificationParams.message) {
          try {
            notification.open(notificationParams);
          } catch (error: any) {
            console.error(error);
          }
        } else {
          console.error('antv notification 消息需要`message`属性');
        }
        break;
      }
      case 'modal': {
        const modalParams = eventData.params as ModalFuncParams;
        if (modalParams && modalParams.content) {
          try {
            Modal.info({
              icon: [],
              centered: true,
              okText: '确定',
              ...modalParams,
            });
          } catch (error: any) {
            console.error(error);
          }
        } else {
          console.error('antv modal 消息需要`content`属性');
        }
        break;
      }
      case 'openIframe': {
        const iframeParams = eventData.params as IframeParams;
        if (iframeParams && iframeParams.url) {
          try {
            createIframe(iframeParams);
          } catch (error: any) {
            console.error(error);
          }
        } else {
          console.error('no iframe url');
        }
        break;
      }
      case 'openTaskCenter': {
        const taskCenterBtnEl = document.getElementById('taskCenterBtn');
        if (taskCenterBtnEl) {
          taskCenterBtnEl.click();
        }
        break;
      }
      case 'closeIframe': {
        if (vNode.value) {
          if (el.value) {
            render(null, el.value);
          }
          vNode.value = null;
        }
        if (el.value) {
          document.body.removeChild(el.value);
          document.body.style.overflow = '';
          el.value = null;
        }
        break;
      }
      case 'closeLoading': {
        document.getElementById('iframeLoading')?.remove();
        break;
      }
      case 'back': {
        history.back();
        break;
      }
      case 'logout': {
        onLogout();
        break;
      }
      case 'noticeModalReady':
      case 'closeNoticeModal':
        // 消息中心内部处理弹窗，此处不做处理
        break;
      default: {
        console.error('usePostMessage type 溢出', eventData);
      }
    }
  };

  onMounted(() => {
    window.addEventListener('message', handlePostMessageEvent, false);
    // setTimeout(() => {
    //   window.postMessage(
    //     {
    //       traceId: Date.now(),
    //       // jump
    //       // type: 'jump',
    //       // params: {
    //       //   // url: '/SystemSettings/WorkbenchSettings',
    //       //   url: 'https://www.leedarson.com',
    //       //   _blank: true,
    //       // },
    //       // message
    //       // type: 'message',
    //       // params: {
    //       //   type: 'info',
    //       //   content: '提示内容',
    //       //   duration: 2000,
    //       // },
    //       // notification
    //       // type: 'notification',
    //       // params: {
    //       //   type: 'info',
    //       //   message: '提示内容',
    //       //   placement: 'topRight',
    //       //   description: '描述。。。。。',
    //       //   duration: 2000,
    //       // },
    //       // openIframe
    //       type: 'openIframe',
    //       params: {
    //         // url: 'https://www.leedarson.com',
    //         url: '/widgets?type=WB_CloudCourseReservationLectures',
    //         old: true,
    //         width: '200px',
    //         height: '100px',
    //         withLoading: true,
    //       },
    //       // closeIframe
    //       // type: 'closeIframe',
    //     },
    //     '*',
    //   );
    // }, 2000);

    // setTimeout(() => {
    //   window.postMessage(
    //     {
    //       traceId: Date.now(),
    //       // type: 'closeIframe',
    //       type: 'closeLoading',
    //     },
    //     '*',
    //   );
    // }, 15000);
  });

  onBeforeUnmount(() => {
    window.removeEventListener('message', handlePostMessageEvent, false);
  });
};

export default usePostMessage;

// window.postMessage({
//   type: 'message',
//   params: {
//     type: 'info',
//     content: '提示内容',
//     duration: 2000,
//   },
// });
