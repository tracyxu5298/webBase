import { computed, unref, type ComputedRef } from 'vue';
import useAuthStore from '../stores/useAuthStore'; // TODO: 本地存储需要加密

/**
 * 当前访问令牌 key
 * 用户身分为教职工, HTTP 请求头 key 是 "token"
 * 用户身份为家长或学生时, HTTP 请求头 key 是 "cuser_token"
 */
function useAccessTokenKey(): ComputedRef<string> {
  const store = useAuthStore();
  return computed(() => {
    return unref(store.tokenKey);
  });
}

export default useAccessTokenKey;
