import { unref, computed, type ComputedRef } from 'vue';
import useUserInfoStore from '../stores/useUserInfoStore';

/**
 * personId 说明
 * 当 userIdentity = 0 时, 即教职工身份, id == userId == personId
 * 当 userIdentity = 1 或 2 时，即学生或家长身份, id == cuserId, 但不等于 personId
 */
function useLocationId(): ComputedRef<string | null> {
  const store = useUserInfoStore();
  return computed(() => {
    const data = unref(store.data);
    if (data) {
      return data.personId;
    }
    return null;
  });
}

export default useLocationId;
