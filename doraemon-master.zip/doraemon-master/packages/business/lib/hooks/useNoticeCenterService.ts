import { computed } from 'vue';
import { useHttp, useIsParentOrStudent, useUserId } from '.';
import { UserTypes } from '../enums';
import type { NoticeGroup } from '../types';

const useNoticeCenterService = () => {
  const http = useHttp();
  const isParentOrStudent = useIsParentOrStudent();
  const userId = useUserId();
  const userType = computed(() =>
    isParentOrStudent.value ? UserTypes.ParentOrStudent : UserTypes.Teacher,
  );
  const clientType = 'WEB';

  const getNoticeGroups = () => {
    const params = {
      clientType,
      userType: userType.value,
      userId: userId.value,
    };
    return http.get<NoticeGroup[]>('/api/message/v1/systemMessages/groupByBizGroupCode', params);
  };

  const getNoticePage = (params: any) => {
    const searchParams = {
      clientType,
      userType: userType.value,
      userId: userId.value,
      pageNum: 1,
      pageSize: 15,
      ...params,
    };
    return http.post('/api/building/v1/systemMessages/pageByLocation', searchParams);
  };

  const readNotice = (id: string) => {
    return http.get(`/api/building/v1/systemMessages/${id}/actions/read`);
  };

  const batchReadNotice = (ids: string[]) => {
    return http.post(`/api/building/v1/systemMessages/actions/batchRead`, ids);
  };

  return {
    getNoticeGroups,
    getNoticePage,
    readNotice,
    batchReadNotice,
  };
};

export default useNoticeCenterService;
