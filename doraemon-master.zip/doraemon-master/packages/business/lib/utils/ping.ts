/** 通过`image.src`的方式探测 */
const pingByImage = async (url: string, timeout = 3000) => {
  const img = new Image();
  const time = Date.now();
  // fix: https://jira.leedarson.com/browse/SMD-12541
  // chrome 升 v111.0.5563.65 之后, http 探测已不适用, 只能用 https 才能正常探测
  img.src = `${url.replace('http://', 'https://')}${
    url.endsWith('/') ? '' : '/'
  }favicon.ico?t=${time}`;
  return new Promise<boolean>((resolve) => {
    const handler = setTimeout(() => {
      console.log('探测超时');
      img.onload = () => {
        return void 0;
      };
      img.onerror = () => {
        return void 0;
      };
      resolve(false);
    }, timeout);
    img.onload = () => {
      clearTimeout(handler);
      console.log('探测 onload');
      resolve(true);
    };
    img.onerror = () => {
      clearTimeout(handler);
      console.log('探测 onerror');
      resolve(true);
    };
  });
};

export const ping = async (url: string, timeout = 3000) => {
  console.time('探测耗时');
  const response = await pingByImage(url, timeout);
  console.timeEnd('探测耗时');
  return response;
};
