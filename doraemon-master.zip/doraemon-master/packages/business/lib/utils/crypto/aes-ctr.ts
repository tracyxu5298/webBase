/*
 * @Author: linbin@leedarson.com
 * @Date: 2019-08-26 10:30:41
 * Copyright © Leedarson. All rights reserved.
 */

// CTR（Counter Mode，计数器模式）

let key;
let counter;
let cipherText;

const generateKey = async () => {
  key = await window.crypto.subtle.generateKey(
    {
      name: 'AES-CTR',
      length: 256,
    },
    true,
    ['encrypt', 'decrypt'],
  );
  // console.log('key:', key);
  return key;
  // { publicKey, privateKey }
};

const encryptMessage = async (message) => {
  const encoder = new TextEncoder();
  const encoded = encoder.encode(message);
  counter = window.crypto.getRandomValues(new Uint8Array(16));
  cipherText = await window.crypto.subtle.encrypt(
    {
      name: 'AES-CTR',
      counter,
      length: 64,
    },
    key,
    encoded,
  );
  // console.log('cipherText:', cipherText);
  return cipherText;
};

const decryptMessage = async () => {
  const decrypted = await window.crypto.subtle.decrypt(
    {
      name: 'AES-CTR',
      counter,
      length: 64,
    },
    key,
    cipherText,
  );
  const decoder = new TextDecoder();
  const message = decoder.decode(decrypted);
  // console.log('message:', message);
  return message;
};

const encrypt = async (message) => {
  await generateKey();
  encryptMessage(message);
};

const decrypt = async () => {
  decryptMessage();
};

// example
// encrypt('123');
// setTimeout(decrypt, 3000);

export { encrypt, decrypt };
