/*
 * @Author: linbin@leedarson.com
 * @Date: 2019-08-26 10:30:51
 * Copyright © Leedarson. All rights reserved.
 */

let keyPair;
let cipherText;

const generateKey = async () => {
  keyPair = await window.crypto.subtle.generateKey(
    {
      name: 'RSA-OAEP',
      // Consider using a 4096-bit key for systems that require long-term security
      modulusLength: 2048,
      publicExponent: new Uint8Array([1, 0, 1]),
      hash: 'SHA-256',
    },
    true,
    ['encrypt', 'decrypt'],
  );
  // console.log('keyPair:', keyPair);
  return keyPair;
  // { publicKey, privateKey }
};

const encryptMessage = async (message, publicKey) => {
  const encoder = new TextEncoder();
  const encoded = encoder.encode(message);
  cipherText = await window.crypto.subtle.encrypt(
    {
      name: 'RSA-OAEP',
    },
    publicKey,
    encoded,
  );
  // console.log('cipherText:', cipherText);
  return cipherText;
};

const decryptMessage = async (privateKey) => {
  const decrypted = await window.crypto.subtle.decrypt(
    {
      name: 'RSA-OAEP',
    },
    privateKey,
    cipherText,
  );
  const decoder = new TextDecoder();
  const message = decoder.decode(decrypted);
  // console.log('message:', message);
  return message;
};

const encrypt = async (message) => {
  await generateKey();
  encryptMessage(message, keyPair.publicKey);
};

const decrypt = async () => {
  decryptMessage(keyPair.privateKey);
};

// example
// encrypt('123');
// setTimeout(decrypt, 3000);

export { encrypt, decrypt };
