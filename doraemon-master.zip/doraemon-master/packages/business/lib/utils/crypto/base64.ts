/* eslint-disable no-plusplus */
/*
 * @Author: huangjiacan@leedarson.com
 * @Date: 2021-05-07 10:30:37
 * Copyright © Leedarson. All rights reserved.
 */

// import Base64 from 'crypto-js/enc-base64';
// import Utf8 from 'crypto-js/enc-utf8';

// const Base64Encode = message => {
//   return Base64.stringify(Utf8.parse(message));
// };

// const Base64Decode = message => {
//   return Base64.parse(message).toString(Utf8);
// };

// export { Base64Encode, Base64Decode };

const Base64Code = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/'.split(''); // 索引表

/**
 * arr [2,4,5,56,66] 字节数组 - 每一个值占一个字节
 */

const Base64EncodeForRaw = (arr) => {
  const bitString = arr.reduce((result, cur) => {
    let charCode = cur.toString(2);
    charCode = new Array(9 - charCode.length).join('0') + charCode;
    return result + charCode;
  }, '');
  let result = '';
  const tail = bitString.length % 6;
  const bitStringTemp1 = bitString.substr(0, bitString.length - tail);
  let bitStringTemp2 = bitString.substr(bitString.length - tail, tail);
  for (let i = 0; i < bitStringTemp1.length; i += 6) {
    const index = parseInt(bitStringTemp1.substr(i, 6), 2);
    result += Base64Code[index];
  }
  bitStringTemp2 += new Array(7 - tail).join('0');
  if (tail) {
    const encode = Base64Code[parseInt(bitStringTemp2, 2)];
    const newEncode = new Array((6 - tail) / 2 + 1).join('=');
    result += encode + newEncode;
  }
  return result;
};

const Base64DecodeForRaw = (str) => {
  let bitString = '';
  let tail = 0;
  for (let i = 0; i < str.length; i++) {
    if (str[i] !== '=') {
      const decode = Base64Code.indexOf(str[i]).toString(2);
      const newDecode = new Array(7 - decode.length).join('0') + decode;
      bitString += newDecode;
    } else {
      tail++;
    }
  }
  // const tail = bitString.length % 8;
  // const bitStringTemp1 = bitString.substr(0, bitString.length - tail);
  const bitStringTemp1 = bitString.substr(0, bitString.length - tail * 2);
  const arr = [];
  for (let i = 0; i < bitStringTemp1.length; i += 8) {
    const value = parseInt(bitStringTemp1.substr(i, 8), 2);
    arr.push(value);
  }
  return arr;
};

export { Base64EncodeForRaw, Base64DecodeForRaw };
