/*
 * @Author: linbin@leedarson.com
 * @Date: 2019-08-26 10:30:44
 * Copyright © Leedarson. All rights reserved.
 */

// GCM (Galois/Counter Mode，伽罗瓦/计数器模式)

let key;
let iv;
let cipherText;

const generateKey = async () => {
  key = await window.crypto.subtle.generateKey(
    {
      name: 'AES-GCM',
      length: 256,
    },
    true,
    ['encrypt', 'decrypt'],
  );
  // console.log('key:', key);
  return key;
  // { publicKey, privateKey }
};

const encryptMessage = async (message) => {
  const encoder = new TextEncoder();
  const encoded = encoder.encode(message);
  iv = window.crypto.getRandomValues(new Uint8Array(12));
  cipherText = await window.crypto.subtle.encrypt(
    {
      name: 'AES-GCM',
      iv,
    },
    key,
    encoded,
  );
  // console.log('cipherText:', cipherText);
  return cipherText;
};

const decryptMessage = async () => {
  const decrypted = await window.crypto.subtle.decrypt(
    {
      name: 'AES-GCM',
      iv,
    },
    key,
    cipherText,
  );
  const decoder = new TextDecoder();
  const message = decoder.decode(decrypted);
  // console.log('message:', message);
  return message;
};

const encrypt = async (message) => {
  await generateKey();
  encryptMessage(message);
};

const decrypt = async () => {
  decryptMessage();
};

// example
// encrypt('123');
// setTimeout(decrypt, 3000);

export { encrypt, decrypt };
