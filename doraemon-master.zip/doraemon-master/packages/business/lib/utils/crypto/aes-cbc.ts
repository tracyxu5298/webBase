/*
 * @Author: linbin@leedarson.com
 * @Date: 2019-08-26 10:30:37
 * Copyright © Leedarson. All rights reserved.
 */

// CBC (Cipher Block Chaining，密码块链接)

import AES from 'crypto-js/aes';
import Pkcs7 from 'crypto-js/pad-pkcs7';
import CryptoJSCore from 'crypto-js/core';

const key = CryptoJSCore.enc.Utf8.parse('1MA0D9C3V3040A9D'); //十六位十六进制数作为密钥
const iv = CryptoJSCore.enc.Utf8.parse('1346A5Z7CN8H9GF0'); //十六位十六进制数作为密钥偏移量

// 加密方法
const encryptByAesCbc = (message: string) => {
  try {
    const encrypted = AES.encrypt(message, key, {
      iv,
      mode: CryptoJSCore.mode.CBC,
      padding: Pkcs7,
    });
    return encrypted.toString();
  } catch (err) {
    return '';
  }
};

// 解密方法
const decryptByAesCbc = (message: string) => {
  try {
    const decrypted = AES.decrypt(message, key, {
      iv,
      mode: CryptoJSCore.mode.CBC,
      padding: Pkcs7,
    });
    return decrypted.toString(CryptoJSCore.enc.Utf8);
  } catch (err) {
    return '';
  }
};

export { encryptByAesCbc, decryptByAesCbc };

// example:
// const cipherText = encrypt('1234567');
// const plaintext = decrypt(cipherText);

/** ***************** WebCrypto ******************* */
/*
let key;
let iv;
let cipherText;

const generateKey = async () => {
  key = await window.crypto.subtle.generateKey(
    {
      name: 'AES-CBC',
      length: 256,
    },
    true,
    ['encrypt', 'decrypt'],
  );
  // console.log('key:', key);
  return key; // { publicKey, privateKey }
};

const encryptMessage = async message => {
  const encoder = new TextEncoder();
  const encoded = encoder.encode(message);
  iv = window.crypto.getRandomValues(new Uint8Array(16));
  cipherText = await window.crypto.subtle.encrypt(
    {
      name: 'AES-CBC',
      iv,
    },
    key,
    encoded,
  );
  // console.log('cipherText:', cipherText);
  return cipherText;
};

const decryptMessage = async () => {
  const decrypted = await window.crypto.subtle.decrypt(
    {
      name: 'AES-CBC',
      iv,
    },
    key,
    cipherText,
  );
  const decoder = new TextDecoder();
  const message = decoder.decode(decrypted);
  // console.log('message:', message);
  return message;
};

const encrypt = async message => {
  await generateKey();
  encryptMessage(message);
};

const decrypt = async () => {
  decryptMessage();
};

// example
// encrypt('123');
// setTimeout(decrypt, 3000);

export { encrypt, decrypt };
*/
