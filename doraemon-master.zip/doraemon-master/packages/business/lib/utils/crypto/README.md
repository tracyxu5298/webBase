# GitHub

https://github.com/mdn/dom-examples/blob/master/web-crypto/encrypt-decrypt/rsa-oaep.js

# Mozilla

https://developer.mozilla.org/en-US/docs/Web/API/SubtleCrypto/encrypt

# Example

https://mdn.github.io/dom-examples/web-crypto/encrypt-decrypt/index.html

# Article

- [前端 crypto-js aes 加解密](https://blog.csdn.net/yusirxiaer/article/details/79931619)

- [理解AES加密解密的使用方法](https://blog.csdn.net/vieri_32/article/details/48345023)

# Notes

- AES分为几种模式，比如ECB，CBC，CFB等等，这些模式除了ECB由于没有使用IV而不太安全，其他模式差别并没有太明显，大部分的区别在IV和KEY来计算密文的方法略有区别。

- 强烈建议使用认证加密（authenticated encryption），它可以检测密文是否已被攻击者篡改。使用认证也可以避免选择密文攻击（chosen-ciphertext attack），即攻击者可以请求系统解密任意的消息，然后使用解密结果来倒推出关于密钥的一些信息。虽然 CTR 和 CBC 模式可以添加认证，但是它们默认不提供该操作，并且在手动实现它们的时候，很容易犯一些微小但严重的错误。`GCM` 提供了内置的认证，因此常常推荐使用这种模式。
