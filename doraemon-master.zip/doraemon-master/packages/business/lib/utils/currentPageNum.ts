/** 删除后的分页方法：currentPageNum
 * pagination 分页数据
 * delL 删除的数量 默认1
 * 页码最小值：1
 * 当前页小于等于删除后的总页  取当前页
 * 当前页大于删除后的总页数取 取总页
 */
export const currentPageNum = (pagination: any, delL = 1) => {
  const { total, pageSize, current } = pagination;
  // 删除后的总页数
  const totalPages = Math.ceil((total - delL) / pageSize);
  if (totalPages >= current) {
    return current;
  } else {
    return totalPages;
  }
};
