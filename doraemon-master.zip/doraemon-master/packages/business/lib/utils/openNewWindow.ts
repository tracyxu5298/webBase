export const openNewWindow = (path: string) => {
  // noopener 不携带 sessionStorage
  window.open(path, '_blank', 'noopener');
};
