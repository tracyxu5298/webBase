// 使用 URL 构造器来验证 URL 的有效性
function isValidHttpUrl(str: string) {
  try {
    const newUrl = new URL(str);
    return newUrl.protocol === 'http:' || newUrl.protocol === 'https:';
  } catch (err) {
    return false;
  }
}

// 使用正则来验证 URL，/^https?:\/\//.test(str)
// function isValidHttpUrl(str: string) {
//   const pattern = new RegExp(
//     '^(https?:\\/\\/)?' + // protocol
//       '((([a-z\\d]([a-z\\d-]*[a-z\\d])*)\\.)+[a-z]{2,}|' + // domain name
//       '((\\d{1,3}\\.){3}\\d{1,3}))' + // OR ip (v4) address
//       '(\\:\\d+)?(\\/[-a-z\\d%_.~+]*)*' + // port and path
//       '(\\?[;&a-z\\d%_.~+=-]*)?' + // query string
//       '(\\#[-a-z\\d_]*)?$', // fragment locator
//     'i'
//   );
//   return pattern.test(str);
// }
// console.log(isValidHttpUrl('https://www.freecodecamp.org/')); // true
// console.log(isValidHttpUrl('mailto://mail@freecodecamp.org')); // false
// console.log(isValidHttpUrl('freecodecamp')); // false

// function isValidUrl(str: string) {
//   try {
//     new URL(str);
//     return true;
//   } catch (err) {
//     return false;
//   }
// }
// function isValidUrl(str: string) {
//   const pattern = new RegExp(
//     '^([a-zA-Z]+:\\/\\/)?' + // protocol
//       '((([a-z\\d]([a-z\\d-]*[a-z\\d])*)\\.)+[a-z]{2,}|' + // domain name
//       '((\\d{1,3}\\.){3}\\d{1,3}))' + // OR IP (v4) address
//       '(\\:\\d+)?(\\/[-a-z\\d%_.~+]*)*' + // port and path
//       '(\\?[;&a-z\\d%_.~+=-]*)?' + // query string
//       '(\\#[-a-z\\d_]*)?$', // fragment locator
//     'i',
//   );
//   return pattern.test(str);
// }
// console.log(isValidUrl('https://www.freecodecamp.org/')); // true
// console.log(isValidUrl('mailto://mail@freecodecamp.org')); // true
// console.log(isValidUrl('freecodecamp')); // false

export default isValidHttpUrl;
