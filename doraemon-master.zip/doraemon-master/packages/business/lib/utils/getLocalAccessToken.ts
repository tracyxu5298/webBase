import { LOCAL_STORAGE_TOKEN } from '../stores/useAuthStore';

const getLocalAccessToken = () => {
  return localStorage.getItem(LOCAL_STORAGE_TOKEN);
};

export default getLocalAccessToken;
