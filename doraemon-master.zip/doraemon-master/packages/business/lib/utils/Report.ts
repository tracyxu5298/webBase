import { UserIdentity } from '../enums';
import type { UserInfo } from '../types';

export interface IReportUser {
  aid?: string; // 家长或学生`id`, 其它身份`accountId`
  uid?: string; // 家长或学生`personId`, 其它身份`id`
  uIdentity?: number; // 用户身份, `userIdentity`
}
export interface IReportEvent {
  code: string; // 事件编码, 比如`pageview`
  url: string; // 页面路径
  ts: number; // 时间戳
  lid: string; // 组织编码, locationId
  st?: number; // 事件结束时间戳
  ai?: string; // 应用编码, appId
  md?: string; // `login`事件编码, 登录方式, sms: 短信, account: 帐号
}
export interface IReportEnv {
  pt: string /** 客户端平台类型 web, app, wxa */;
  version: string /** 应用程序迭代版本号 */;
  build: string /** 应用程序迭代构建号 */;
  em?: string /** 设备终端型号, Web端不用传, 解析UA */;
  os?: string /** 操作系统类型, Web端不用传, 解析UA */;
  ov?: string /** 操作系统版本, Web端不用传, 解析UA */;
}

const uuid = function () {
  const s: any[] = [];
  const hexDigits = '0123456789abcdef';
  for (let i = 0; i < 32; i++) {
    const idx = Math.floor(Math.random() * 0x10);
    s[i] = hexDigits.substring(idx, idx + 1);
  }
  s[14] = '4'; // bits 12-15 of the time_hi_and_version field to 0010
  const idx19 = (s[19] & 0x3) | 0x8;
  s[19] = hexDigits.substring(idx19, idx19 + 1); // bits 6-7 of the clock_seq_hi_and_reserved to 01
  const uuid = s.join('').replace('-', '');
  return uuid;
};

class Report {
  static instance: Report;
  private env: IReportEnv;
  private user: IReportUser;
  private locationId: string;

  constructor() {
    this.env = {
      pt: 'web',
      version: import.meta.env.ROOT_VERSION,
      build: import.meta.env.BUILDER_NUMBER,
    };
    this.user = {};
    this.locationId = '';
    Report.instance = this;
  }

  static getInstance() {
    const instance: Report = Report.instance;
    if (instance) {
      return instance;
    }
    throw new Error('[Report] 未实例化');
  }

  setUserInfo(userInfo: UserInfo | undefined) {
    if (!userInfo) {
      this.locationId = '';
      this.user = {};
      return;
    }
    this.locationId = userInfo.locationId;
    const userIdentity = userInfo.userIdentity;
    const isParentOrStudent =
      userIdentity === UserIdentity.Parent || userIdentity === UserIdentity.Student;
    // aid?: string; // 家长或学生`id`, 其它身份`accountId`
    // uid?: string; // 家长或学生`personId`, 其它身份`id`
    // uIdentity?: number; // 用户身份, `userIdentity`
    this.user.aid = isParentOrStudent ? userInfo.id : userInfo.accountId;
    this.user.uid = isParentOrStudent ? userInfo.personId : userInfo.id;
    this.user.uIdentity = userIdentity;
  }

  buildEvent(event: Partial<IReportEvent>): IReportEvent {
    return {
      lid: this.locationId,
      ts: Date.now(),
      ...event,
    } as IReportEvent;
  }

  private buildData(event: IReportEvent | IReportEvent[]) {
    return {
      cid: 1, // 1: Web端, 2: 小程序, 5: App, 6: Boss, 7: 小管家
      env: this.env,
      events: Array.isArray(event) ? event : [event],
      seq: uuid(),
      user: this.user,
    };
  }

  async send(event: IReportEvent | IReportEvent[]) {
    try {
      const data = this.buildData(event);
      const response = await fetch('/api/ops/anon/event/v1/report', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(data),
      });
      return response.json();
    } catch (error) {
      console.warn('Report', event, error);
    }
  }
}

export default Report;
