export const EMPTY_FUNC = () => {};
export const EMPTY_OBJ = Object.freeze({});
export const EMPTY_ARR = Object.freeze([]);
