export const clearStorage = (exclude?: string | string[]) => {
  sessionStorage.clear();

  /**
   * 记住密码不需要清空
   * dedicatedWebsite 是当前自定义登录页面的标识 跳转登录页时需要
   */
  const remainKeys = [
    'username',
    'password',
    'dedicatedWebsite',
    'current_location', // 门户
    'weeklyRoutines', // 新手引导
  ];

  if (exclude) {
    if (typeof exclude === 'string') {
      remainKeys.push(exclude);
    } else {
      remainKeys.push(...exclude);
    }
  }

  Object.keys(localStorage).forEach((key) => {
    if (!remainKeys.includes(key)) {
      localStorage.removeItem(key);
    }
  });
};

const onLogout = () => {
  clearStorage();

  // token 去掉，触发 router.beforeEach
  window.location.replace(
    `${window.location.href}${window.location.href.includes('?') ? '&' : '?'}logout=1`,
  );
  // const dedicatedWebsite = localStorage.getItem('dedicatedWebsite');
  // window.location.href = `/Login${dedicatedWebsite ? `?n=${dedicatedWebsite}` : ''}`;
};

export default onLogout;
