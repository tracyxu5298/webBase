/** 中国大陆手机号 */
export const regExpPhoneNumber = /^[1]([3-9])[0-9]{9}$/;
/** 密码安全等级校验 */
export const regExpPassword = /^(?=.*[A-Za-z])(?=.*\d)(?=.*[^a-zA-z0-9]).{8,20}$/;
/** 用户姓名30个字符 中英文数字组合 */
export const regExpUserName = /[\u4e00-\u9fa5a-zA-Z0-9]+/;
/** 账号仅支持4-15位以字母开头与数字、-_的组合*/
export const regExpAccountName = /^[a-zA-Z][a-zA-Z0-9_-]{3,14}$/;
/** 正整数（不包括0） */
export const regExpPositiveInteger = /^[1-9]\d*$/;
/** 非负整数 （包括0） */
export const regExpNonNegativeInteger = /^\d+$/;
// 两位浮点数
export const regExpTwoDecimal = /^[1-9]?\d{1}(\.\d{1,2})?$/;
// 支持https或http协议，支持携带端口号
export const regExpHttpUrl =
  /^(https?:\/\/([a-zA-Z0-9-_]+\.)+([a-zA-Z0-9-_]+))(:\d+)?(\/.*)?(\?.*)?(#.*)?$/;
