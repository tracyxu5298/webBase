export const LOCAL_FULL_PATH = 'appFullPaths';

/**
 * @params path 应用地址
 * @return 地址上的 fullPath 值
 */
export const getFullPathByAppPath = (path: string) => {
  // 打开新页签需要存储是否全屏标识
  if (path?.includes('fullPath=')) {
    const reg = new RegExp(`(^|&)fullPath=([^&]*)(&|$)`, 'i');
    const val = path.substring(path.indexOf('?')).substring(1).match(reg)?.[2];
    return val ? decodeURIComponent(val) : '';
  }

  return '';
};

export const getLocalAppFullPaths = (): string[] => {
  return JSON.parse(localStorage.getItem(LOCAL_FULL_PATH) || '[]');
};

export const setLocalAppFullPath = (fullPath: string) => {
  const _data = getLocalAppFullPaths();
  if (!_data.includes(fullPath)) {
    localStorage.setItem(LOCAL_FULL_PATH, JSON.stringify(_data.concat(fullPath)));
  }
};
