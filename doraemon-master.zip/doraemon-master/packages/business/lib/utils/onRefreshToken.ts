import { unref } from 'vue';
import useHttp from '../hooks/useHttp';
import useAuthStore from '../stores/useAuthStore';

interface RefreshResponse {
  accessToken: string;
  expireTime: number;
  refreshToken: string;
  refreshExpireTime: number;
}

function onRefreshToken() {
  const http = useHttp();
  const store = useAuthStore();
  const accessToken = unref(store.token);
  const refreshToken = unref(store.refreshToken);

  if (!accessToken || !refreshToken) {
    const msg = `[onRefreshToken] accessToken 或 refreshToken 不存在 ${!!accessToken} ${!!refreshToken}`;
    return Promise.reject(msg);
  }

  return http
    .post<RefreshResponse>('/api/building/anon/refreshToken', {
      accessToken,
      refreshToken,
    })
    .then((data) => {
      if (data.accessToken) {
        store.set({
          token: data.accessToken,
          tokenExpire: data.expireTime,
          refreshToken: data.refreshToken,
          refreshExpire: data.refreshExpireTime,
        });
        return Promise.resolve({
          token: unref(store.token) as string, // TS强制类型必需, 因为可能为null
          tokenKey: unref(store.tokenKey),
        });
      } else {
        const msg = '[onRefreshToken] accessToken 不存在';
        return Promise.reject(msg);
      }
    });
}

export default onRefreshToken;
