import { JSEncrypt } from 'jsencrypt';

const RSA_PUBLIC = `-----BEGIN PUBLIC KEY-----
MIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIICCgKCAgEAvbRh4qwpq54ZBff8FrMm
nKfOGsLZHScnX18vxALKv0jdV41GNsI60itXLTSbWWzxbthBZ0MrhjOI/jxd7VyP
lf+WWaA5uywDHKIbEGYjZPvEknQfPHq5r7tQ87MctgrEvLkygBKu2jUMsw/QlNvg
adzWjdWQV7ZQwXQ0zQx4iUfq08ZNeqm/Etf/m9qXvy842jBa4wGOw/aGvmWg459E
HibIVW/QpLuYd0BgM/tl6yhMRj42OrSbfyzkdpep0DY6z3twlHNcGA0vA4y1kJB7
/Alfha3Za3XC+Ty5+wtC3lc3BNZvR8+/Br9nYq2mt33YRA1t/L0b1hucik2IajF7
hm4HrnWvj+aM9vexZXbWneUwvUEDcHg9Lr3ucM7tDjz7SjIVN/XYFD8BGmL+XTQe
PJHp4j9Pyq/3EquNFt+mHtv/6s5eWyX/J4WE2HXasj33P0ISzE6NB3NcPcK/4kEx
1Ic15KwR3b1ClrNLc9YvHj9LG5P7UdBqkHzbdxhSAuRbONvd5orVWbrHZcSwC9D7
+nwvgQJDHiZXlUpnNko6ZWBxvZACA32eq1JqIyfBmFl+PEY27yb1Z/yAaHkuOcl/
KeSL1i/+grr1XTbowzg678mBmPaHLLWeBF9NiC1OFQxvBzpWID5BW4PktdlNZz9F
vKeAtirnOjonH94C8B1iSY8CAwEAAQ==
-----END PUBLIC KEY-----`;

/** RSA加密 */
export const RSAEncrypt = (str: string | null) => {
  if (!str) {
    return '';
  }

  const encrypt = new JSEncrypt();
  encrypt.setPublicKey(RSA_PUBLIC);

  return encrypt.encrypt(str) as string;
};
