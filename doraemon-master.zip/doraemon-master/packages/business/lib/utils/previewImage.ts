/**
 * 参考内容：https://github.com/vueComponent/ant-design-vue/blob/main/components/upload/utils.tsx
 */

interface PreviewOptions {
  measureWidth?: number;
  measureHeight?: number;
  mode?: 'contain' | 'cover';
}

interface DrawPreviewOptions extends PreviewOptions {
  width: number;
  height: number;
}

const MEASURE_SIZE = 200;

export function previewImage(source: CanvasImageSource, options: DrawPreviewOptions) {
  const { width, height, measureWidth, measureHeight } = options;
  const MW = measureWidth || MEASURE_SIZE;
  const MH = measureHeight || MEASURE_SIZE;

  const canvas = document.createElement('canvas');
  canvas.width = MW;
  canvas.height = MH;
  const ctx = canvas.getContext('2d');

  let drawWidth = MW;
  let drawHeight = MH;
  let offsetX = 0;
  let offsetY = 0;

  if (
    (options.mode !== 'cover' && width > height) ||
    (options.mode === 'cover' && width < height)
  ) {
    drawHeight = height * (MW / width);
    offsetY = -(drawHeight - drawWidth) / 2;
  } else {
    drawWidth = width * (MH / height);
    offsetX = -(drawWidth - drawHeight) / 2;
  }

  ctx!.drawImage(source, offsetX, offsetY, drawWidth, drawHeight);
  const dataURL = canvas.toDataURL();

  return dataURL;
}

export function loadVideoElement(file: File | Blob | string): Promise<HTMLVideoElement> {
  return new Promise((resolve) => {
    const video = document.createElement('video');
    video.onseeked = () => {
      resolve(video);
    };
    video.onloadedmetadata = () => {
      video.currentTime = 0.0;
    };
    video.crossOrigin = 'anonymous';
    video.src = typeof file === 'string' ? file : window.URL.createObjectURL(file);
  });
}

export function loadImageElement(file: File | Blob | string): Promise<HTMLImageElement> {
  return new Promise((resolve) => {
    const img = new Image();
    img.onload = () => {
      resolve(img);
    };
    img.crossOrigin = 'anonymous';
    if (typeof file === 'string') {
      img.src = file;
    } else if (file.type.startsWith('image/svg+xml')) {
      const reader = new FileReader();
      reader.addEventListener('load', () => {
        if (reader.result) img.src = reader.result as string;
      });
      reader.readAsDataURL(file);
    } else {
      img.src = window.URL.createObjectURL(file);
    }
  });
}

export function getVideoPreviewImage(
  file: File | Blob | string,
  options?: PreviewOptions,
): Promise<string> {
  return loadVideoElement(file).then((video) =>
    previewImage(video, {
      ...options,
      width: video.videoWidth,
      height: video.videoHeight,
    }),
  );
}

export function getImagePreviewImage(
  file: File | Blob | string,
  options?: PreviewOptions,
): Promise<string> {
  return loadImageElement(file).then((img) =>
    previewImage(img, {
      ...options,
      width: img.width,
      height: img.height,
    }),
  );
}
