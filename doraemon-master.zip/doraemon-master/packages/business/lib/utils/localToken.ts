/** @deprecated 方法已废弃，请该用 useAuthStore 替代 */
export const LOCAL_STORAGE_TOKEN_KEY = 'tokenKey';

/** @deprecated 方法已废弃，请该用 useAuthStore 替代 */
export const LOCAL_STORAGE_TOKEN = 'token';

/** @deprecated 方法已废弃，请该用 useAuthStore 替代 */
export const LOCAL_STORAGE_EXPIRE = 'tokenExpire';

/** @deprecated 方法已废弃，请该用 useAuthStore 替代 */
export const LOCAL_STORAGE_REFRESH_TOKEN = 'refreshToken';

/** @deprecated 方法已废弃，请该用 useAuthStore 替代 */
export const LOCAL_STORAGE_REFRESH_EXPIRE = 'refreshExpire';

/** @deprecated 方法已废弃，请该用 useAuthStore 替代 */
export const setLocalToken = (value: string, key?: string) => {
  // 存储 token key
  if (key) {
    localStorage.setItem(LOCAL_STORAGE_TOKEN_KEY, key);
  } else {
    localStorage.removeItem(LOCAL_STORAGE_TOKEN_KEY);
  }

  // 存储 token
  localStorage.setItem(LOCAL_STORAGE_TOKEN, value);
};

/** @deprecated 方法已废弃，请该用 useAuthStore 替代 */
export const setLocalTokenExpire = (expire: number) => {
  localStorage.setItem(LOCAL_STORAGE_EXPIRE, String(Date.now() + expire));
};

/** @deprecated 方法已废弃，请该用 useAuthStore 替代 */
export const getLocalToken = () => {
  return localStorage.getItem(LOCAL_STORAGE_TOKEN) || '';
};

/** @deprecated 方法已废弃，请该用 useAuthStore 替代 */
export const isLocalTokenExpire = () => {
  return Date.now() > Number(localStorage.getItem(LOCAL_STORAGE_EXPIRE));
};

/** @deprecated 方法已废弃，请该用 useAuthStore 替代 */
export const getLocalTokenKey = () => {
  return localStorage.getItem(LOCAL_STORAGE_TOKEN_KEY) || LOCAL_STORAGE_TOKEN;
};

/** @deprecated 方法已废弃，请该用 useAuthStore 替代 */
export const getLocalRefreshToken = () => {
  return localStorage.getItem(LOCAL_STORAGE_REFRESH_TOKEN) || '';
};

/** @deprecated 方法已废弃，请该用 useAuthStore 替代 */
export const setLocalRefreshToken = (token: string, expire: number) => {
  localStorage.setItem(LOCAL_STORAGE_REFRESH_TOKEN, token);
  localStorage.setItem(LOCAL_STORAGE_REFRESH_EXPIRE, String(Date.now() + expire));
};

/** @deprecated 方法已废弃，请该用 useAuthStore 替代 */
export const isLocalRefreshTokenExpire = () => {
  return Date.now() > Number(localStorage.getItem(LOCAL_STORAGE_REFRESH_EXPIRE));
};
