import { Http } from '@lexikos/doraemon-network';
import { message } from 'ant-design-vue';

export const downloadByALinkElement = async (href: string, fileName?: string) => {
  if (!href) {
    message.error('文件不存在');
    return;
  }

  try {
    const fileRes = await Http.getInstance().get(
      href,
      {},
      {
        headers: {
          'Content-Type': '',
          'cache-control': 'no-cache',
        },
      },
    );
    const blob = fileRes instanceof Blob ? fileRes : await fileRes.blob();
    const url = window.URL.createObjectURL(blob);
    const aLink = document.createElement('a');
    aLink.style.display = 'none';
    aLink.href = url;
    aLink.target = '_blank';
    const name =
      fileName ||
      decodeURIComponent(fileRes.headers.get('Content-Disposition'))?.split('=')[1] ||
      '';
    aLink.setAttribute('download', name);
    document.body.appendChild(aLink);
    aLink.click();
    window.URL.revokeObjectURL(url);
    document.body.removeChild(aLink);
  } catch (error) {
    console.log('下载失败', error);
    message.error('下载失败');
  }
};
