import { Md5 } from 'ts-md5';

/** MD5加密*/
export const MD5Encrypt = (str: string) => {
  if (!str) {
    return '';
  }

  return Md5.hashStr(str);
};
