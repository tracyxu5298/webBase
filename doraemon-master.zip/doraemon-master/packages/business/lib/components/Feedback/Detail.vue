<script setup lang="ts">
import { ref, onBeforeMount } from 'vue';
import { theme, Modal } from 'ant-design-vue';
import { getVideoPreviewImage } from '../../utils/previewImage';
import { Http } from '@lexikos/doraemon-network';
import { PlayCircleOutlined } from '@ant-design/icons-vue';

const props = defineProps<{
  id?: string;
}>();

const { token } = theme.useToken();

const loading = ref<boolean>();
const data = ref<any>({});
const feedPreviewImage = ref<string>();
const replyPreviewImage = ref<string>();
const previewImageUrl = ref<string>();
const previewVideoUrl = ref<string>();
const previewVisible = ref<boolean>();

const fetch = (id: string) => {
  loading.value = true;
  Http.getInstance()
    .get(`/api/data/feedback/${id}`)
    .then((detail) => {
      data.value = detail;
      if (detail.videoPath) {
        getVideoPreviewImage(detail.videoPath, { mode: 'cover' }).then((dataURL) => {
          feedPreviewImage.value = dataURL;
        });
      }
      if (detail.replyVideoPath) {
        getVideoPreviewImage(detail.replyVideoPath, { mode: 'cover' }).then((dataURL) => {
          replyPreviewImage.value = dataURL;
        });
      }
    })
    .finally(() => {
      loading.value = false;
    });
};

const handlePreviewImage = (url: string) => {
  previewImageUrl.value = url;
  previewVideoUrl.value = '';
  previewVisible.value = true;
};

const handlePreviewVideo = (url: string) => {
  previewImageUrl.value = '';
  previewVideoUrl.value = url;
  previewVisible.value = true;
};

const handleCancel = () => {
  previewVisible.value = false;
};

onBeforeMount(() => {
  if (props.id) {
    fetch(props.id);
  }
});
</script>

<template>
  <div v-if="loading" class="container-loading">
    <a-spin tip="加载中" />
  </div>
  <div v-else>
    <div class="feed">
      <div class="avatar">问</div>
      <p class="content">{{ data.content }}</p>
      <template v-if="(data.imagePaths && data.imagePaths.length) || data.videoPath">
        <div class="image-list">
          <div
            v-for="(url, idx) in data.imagePaths"
            :key="idx"
            class="image-wrap"
            :style="{ backgroundImage: `url(${url})` }"
            @click="handlePreviewImage(url)"
          ></div>
          <div
            v-if="data.videoPath"
            class="video-wrap"
            :style="{ backgroundImage: `url(${feedPreviewImage})` }"
            @click="handlePreviewVideo(data.videoPath)"
          >
            <PlayCircleOutlined class="icon" :style="{ color: token.colorPrimary }" />
          </div>
        </div>
      </template>
    </div>
    <div class="reply">
      <div class="avatar">答</div>
      <p class="content">{{ data.replyContent }}</p>
      <template v-if="(data.replyImagePaths && data.replyImagePaths.length) || data.replyVideoPath">
        <div class="image-list">
          <div
            v-for="(url, idx) in data.replyImagePaths"
            :key="idx"
            class="image-wrap"
            :style="{ backgroundImage: `url(${url})` }"
            @click="handlePreviewImage(url)"
          ></div>
          <div
            v-if="data.replyVideoPath"
            class="video-wrap"
            :style="{ backgroundImage: `url(${replyPreviewImage})` }"
            @click="handlePreviewVideo(data.replyVideoPath)"
          >
            <PlayCircleOutlined class="icon" :style="{ color: token.colorPrimary }" />
          </div>
        </div>
      </template>
    </div>
  </div>
  <Modal
    destroy-on-close
    centered
    :open="previewVisible"
    :title="previewVideoUrl ? '视频内容' : '图片内容'"
    :footer="null"
    class="preview"
    @cancel="handleCancel"
  >
    <video
      v-if="previewVideoUrl"
      style="width: 100%"
      :src="previewVideoUrl"
      autoplay
      controls
      controlsList="nodownload noplaybackrate"
      oncontextmenu="return false;"
      disablePictureInPicture
    />
    <img v-else style="width: 100%" :src="previewImageUrl" />
  </Modal>
</template>

<style scoped lang="scss">
.container-loading {
  display: flex;
  align-items: center;
  justify-content: center;
  height: 200px;
}

.preview {
  img,
  video {
    width: 100%;
    height: 100%;
  }
}
.feed,
.reply {
  position: relative;
  width: 480px;
  margin: 40px 0;
  padding: 20px;

  .avatar {
    position: absolute;
    top: -20px;
    display: flex;
    align-items: center;
    justify-content: center;
    width: 40px;
    height: 40px;
    border-radius: 20px;
    color: #fff;
  }
}

.feed {
  margin-left: 52px;
  margin-right: auto;
  background-color: #f2f9ff;
  border: 1px solid #bae0ff;
  border-radius: 0 20px 20px 20px;
  .avatar {
    left: -52px;
    background-color: #4096ff;
  }
}

.reply {
  margin-left: auto;
  margin-right: 52px;
  background-color: #f8fff1;
  border: 1px solid #e0f4cd;
  border-radius: 20px 0 20px 20px;
  .avatar {
    right: -52px;
    background-color: #52c41a;
  }
}

.content {
  margin-bottom: 0;
}

.image-list {
  display: flex;
  flex-wrap: wrap;
}
.image-wrap,
.video-wrap {
  display: block;
  overflow: hidden;
  width: 100px;
  height: 100px;
  margin-top: 12px;
  margin-left: 12px;
  background-color: #fff;
  background-position: center;
  background-repeat: no-repeat;
  background-size: cover;
  border-radius: 6px;
  cursor: pointer;

  &:nth-child(4n + 1) {
    margin-left: 0;
  }
}
.video-wrap {
  position: relative;
  cursor: pointer;

  &::before,
  .icon {
    position: absolute;
    transition: all ease-in-out 300ms;
  }

  &::before {
    content: '';
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background-color: rgba(255, 255, 255, 0.3);
    opacity: 0;
  }

  .icon {
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    opacity: 0;
    font-size: 32px;
  }

  &:hover {
    &::before,
    .icon {
      opacity: 1;
    }
  }
}
</style>
