<script lang="ts" setup>
import { Drawer } from 'ant-design-vue';
import { computed, unref } from 'vue';
import { endsWith, includes } from 'lodash-es';
import type { ImportMetaEnvExtra } from '../../types';
import { useOldUrl } from '../../hooks';
import { useAuthStore } from '../../stores';

const props = defineProps<{
  open: boolean; // 弹窗开关
  importMetaEnv: ImportMetaEnvExtra /** 项目运行环境env */;
}>();

const emit = defineEmits<{
  (event: 'close'): void;
}>();

const partUrl = useOldUrl(props.importMetaEnv);

const taskVisible = computed(() => {
  return unref(props.open);
});
const withToken = (url: string) => {
  const store = useAuthStore();
  let res = url;
  let token = store.token || '';
  const refreshToken = store.refreshToken || '';
  if (!token) {
    return res;
  }
  token = `token=${token}&t=${+new Date()}`;
  if (refreshToken) {
    token += `&refreshToken=${refreshToken}`;
  }
  if (!includes(url, '?')) {
    res += `?${token}`;
    return res;
  }
  if (!endsWith(url, '&')) {
    res += `&${token}`;
  } else {
    res += token;
  }
  return res;
};
</script>

<template>
  <Drawer
    v-model:open="taskVisible"
    class="task-center"
    title="任务中心"
    width="500"
    @close="emit('close')"
  >
    <iframe :src="withToken(`${partUrl}/platform/task-center`)" />
  </Drawer>
</template>

<style lang="scss" scoped>
iframe {
  display: block;
  width: 100%;
  height: 100%;
  border: none;
}
</style>
