<script lang="ts" setup>
import { ref, reactive, watch, nextTick, onMounted, onBeforeUnmount } from 'vue';
import { theme } from 'ant-design-vue';
import { debounce } from 'lodash-es';

const props = defineProps({
  lineClamp: {
    type: Number,
    default: 3,
  },
  content: {
    type: String,
    default: '',
  },
});
const { token } = theme.useToken();
const state = reactive({
  showMore: false,
  expand: false,
  maxHeight: props.lineClamp * 22,
});

const contentRef = ref();

const updateShowMore = () => {
  nextTick().then(() => {
    if (contentRef.value?.clientHeight) {
      state.showMore = contentRef.value.clientHeight > state.maxHeight;
    }
  });
};

watch(
  () => props.content,
  (newVal) => {
    if (!newVal) {
      state.showMore = false;
    } else {
      updateShowMore();
    }
  },
  { immediate: true },
);

const debouncedUpdate = debounce(updateShowMore, 300);

onMounted(() => {
  window.addEventListener('resize', debouncedUpdate);
});

onBeforeUnmount(() => {
  window.removeEventListener('resize', debouncedUpdate);
});
</script>

<template>
  <div
    class="paragraph-ellipsis"
    :style="{ maxHeight: state.expand ? 'unset' : `${state.maxHeight}px` }"
  >
    <div ref="contentRef" class="paragraph-ellipsis-text">
      {{ content }}
      <span
        v-if="state.expand"
        class="paragraph-ellipsis-expanded"
        @click="state.expand = !state.expand"
      >
        收起
      </span>
    </div>
    <span
      v-if="state.showMore && !state.expand"
      class="paragraph-ellipsis-more"
      @click="state.expand = !state.expand"
    >
      展开
    </span>
  </div>
</template>

<style lang="scss">
.paragraph-ellipsis {
  position: relative;
  overflow: hidden;
  background: #fff;
  word-break: break-word;
  line-height: 22px;
  flex: none;
  &-expanded,
  &-more {
    line-height: 22px;
    cursor: pointer;
    color: v-bind('token.colorPrimary');
  }
  &-more {
    position: absolute;
    right: 0;
    bottom: 0;
    padding: 0 0 0 34px;
    background: linear-gradient(90deg, rgba(255, 255, 255, 0.2) 0%, rgb(255, 255, 255) 52%);
  }
  &-expanded {
    padding: 0 0 0 8px;
  }
}
</style>
