## Upload 上传组件

### API

| 参数           | 说明                      | 是否必传 | 类型                                                                                   | 默认值 |
| -------------- | ------------------------- | -------- | -------------------------------------------------------------------------------------- | ------ |
| multiple       | 多文件上传模式            | 否       | boolean                                                                                | false  |
| accept         | 允许上传的文件扩展名      | 否       | string,详见https://developer.mozilla.org/en-US/docs/Web/HTML/Element/input/file#accept | -      |
| fileList       | 已经上传的文件列表        | 否       | object[]                                                                               | -      |
| minSize        | 限制最小文件体积          | 否       | number                                                                                 | -      |
| maxSize        | 限制最大文件体积          | 否       | number                                                                                 | -      |
| maxCount       | 限制上传数量              | 否       | number                                                                                 | 1      |
| listType       | 预览类型                  | 否       | 'text'、'picture'、'picture-card'                                                      | text   |
| showUploadBtn  | 是否展示默认按钮          | 否       | boolean                                                                                | trur   |
| isPublic       | 上传 type (公有桶/私有桶) | 否       | boolean                                                                                | false  |
| beforeUpload   | 文件上传前钩子            | 否       | (file) => Promise                                                                      | -      |
| onCustomRemove | 自定义文件删除行为        | 否       | (file) => boolean                                                                      | -      |

### 事件

| 参数          | 说明           | 是否必传 | 类型               | 默认值 |
| ------------- | -------------- | -------- | ------------------ | ------ |
| onChange      | 文件变更回调   | 否       | (fileList) => void | -      |
| onAfterUpload | 文件上传后钩子 | 否       | (data)=>void       | -      |

#### 图片卡片预览列表

```javascript
import { Upload } from '@lexikos/doraemon-business';

<Upload
  listType="picture-card"
  accept=".jpg, .jpeg, .png"
  :maxSize="1024"
  beforeUpload={() =>
    new Promise(resolve => {
      resolve('');
    })
  }
  @onAfterUpload={({ md5, fileId, downloadUrl }) => console.log(downloadUrl)}
  @onChange={(fileList: TFileObject[]) => console.log(fileList)}
/>;
```

#### 文件预览列表

```javascript
<Upload listType="text" accept=".doc, .docx" />
```

### 自定义上传按钮

```javascript
<Upload listType="text" accept=".txt" :showUploadBtn="false">
  <template #uploadBtn>
    <Button>文件上传</Button>
  </template>
</Upload>
```
