import { type UploadFile } from 'ant-design-vue';
/** 上传文件类型 */
export type TFileObject = UploadFile & {
  // uid: string;
  // url: string;
  // status: string;
  fileId?: string;
  // name: string;
  // type: string;
  size: number;
};

/** 上传参数 */
export interface IUploadProps {
  onLineFilePreview?: boolean;
  /** 是否禁用 */
  disabled?: boolean;
  /** 展示上传按钮 */
  showUploadBtn?: boolean;
  /** 是否多文件上传 */
  multiple?: boolean;
  /** 限制上传数量 */
  maxCount?: number;
  /** 上传列表的内建样式 */
  listType?: string;
  /** 限制最小文件体积 */
  minSize?: number;
  /** 限制最大文件体积 */
  maxSize?: number;
  /** 允许上传的文件扩展名列表 */
  accept?: string;
  /** 上传 type (公有桶/私有桶) */
  isPublic?: boolean;
  /**已经上传的文件列表 */
  fileList?: string[];
  /** 预览图片回调 */
  previewFile?: (file: string) => Promise<string>;
  /** 文件变更回调 */
  onChange?: (fileList: TFileObject[]) => void;
  /** 文件上传前钩子 */
  beforeUpload?: (file: TFileObject) => void;
  /**文件上传后钩子 */
  onAfterUpload?: (data: Record<string, any>) => void;
  /** 自定义文件删除行为 */
  onCustomRemove?: (file: TFileObject) => boolean;
  [x: string]: any;
}

/** 返回参数 */
export interface IAfterUpload {
  /** 文件id */
  fileId?: string;
  /** 文件下载地址 */
  downloadUrl?: string;
  /** 文件名 */
  fileName?: string;
  /** 提示参数 */
  msg?: string;
}
