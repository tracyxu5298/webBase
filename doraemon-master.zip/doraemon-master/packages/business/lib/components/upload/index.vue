<script lang="ts" setup>
import { PlusOutlined, UploadOutlined } from '@ant-design/icons-vue';
import { ref, computed, watch, unref } from 'vue';
import { cloneDeep, findIndex, lowerCase, map } from 'lodash-es';
import {
  type UploadChangeParam,
  type UploadFile,
  Upload,
  message,
  Button,
  Modal,
  theme,
} from 'ant-design-vue';
import type { TFileObject, IUploadProps } from './type';
import useUploadServer from './useUploadServer';
import useUpload from './useUpload';
import Preview from '../Preview/Preview.vue';
import { isImageUrl, isVideoFileType, getPreviewFile } from './utils';
const props = withDefaults(defineProps<IUploadProps>(), {
  multiple: false,
  showUploadBtn: true,
});

const emit = defineEmits<{
  (event: 'onChange', data: TFileObject[]): void;
  (event: 'onBeforeUpload', data: TFileObject): void;
  (event: 'onAfterUpload', data: UploadFile): void;
  (event: 'update:value', data: TFileObject[]): void;
}>();

const { token } = theme.useToken();

/** 上传按钮文案 */
const uploadTxt = ref<string>('上传');
const previewVisible = ref(false);
const previewImage = ref<string>('');
const previewVideo = ref<string>('');
const previewTitle = ref<string>('');
const fileList = ref<TFileObject[]>([]);
const loading = ref<boolean>(false);
const uploadPreviewFileRef = ref();
// 图片文件最大长度
const maxLength = computed(() => (!props?.multiple ? 1 : props?.maxCount));

const { uploadFile2Server } = useUploadServer();
const { getBase64, handleDefaultFile } = useUpload();

watch(
  () => props.fileList,
  (val) => {
    fileList.value = handleDefaultFile(cloneDeep(val));
  },
  {
    deep: true,
    immediate: true,
  },
);

/** 文件上传前 */
const handleBeforeUpload = (file: TFileObject) => {
  const { minSize, maxSize, accept } = props;

  const isTopLimit = maxLength.value ? fileList.value.length > maxLength.value : false;
  if (isTopLimit) {
    message.error(`当前限制最多可以上传${maxLength.value}张图片`);
    return Upload.LIST_IGNORE;
  }
  // 校验
  if (accept) {
    const types: string[] = accept?.split(',');
    const acceptTypes: string[] = map(types, (v) => {
      const t = v.includes('.') ? v?.split('.') : v?.split('/');
      return t[t.length - 1];
    });
    const extension = file.name.slice(file.name.lastIndexOf('.') + 1);
    if (findIndex(acceptTypes, (t) => lowerCase(t) === lowerCase(extension)) === -1) {
      message.error(`暂不支持${extension}格式`);
      return Upload.LIST_IGNORE;
    }
  }
  // 大小控制
  if (minSize || maxSize) {
    if (file.size / 1024 < +minSize) {
      message.error('文件大小超出限制');
      return Upload.LIST_IGNORE;
    }
    if (file.size / 1024 > +maxSize) {
      message.error('文件大小超出限制');
      return Upload.LIST_IGNORE;
    }
  }
  emit('onBeforeUpload', file);
};

const emitChange = () => {
  const _list = unref(fileList.value).map((i: any) => ({
    ...i,
    ...i.response,
  }));
  emit('onChange', _list);
  emit('update:value', _list);
};

const handleChange = ({ file }: UploadChangeParam) => {
  if (file.status === 'uploading') return (loading.value = true);
  if (file.status === 'error') {
    loading.value = false;
    fileList.value = fileList.value.filter((o) => o.uid != file.uid);
    message.error('上传失败');
    return;
  }
  if (file.status === 'done') {
    loading.value = false;
    emitChange();
    emit('onAfterUpload', { ...file, ...file.response, fileName: file.name });
  }
};

// 删除文件回调
const handleRemove = (file: UploadFile<any>) => {
  const { uid } = file;
  if (props?.onCustomRemove && !props.onCustomRemove(file)) {
    return;
  }
  fileList.value = fileList.value.filter((item) => item.uid !== uid);
  emitChange();
};

const customUpload = async (e: any) => {
  try {
    const res = await uploadFile2Server({
      file: e.file as unknown as File,
      isPublic: props?.isPublic,
    });
    e.onSuccess(res);
  } catch (error) {
    e.onError(error);
  }
};

/** 取消预览 */
const handleCancel = () => {
  previewVisible.value = false;
  previewTitle.value = '';
};
/** 预览 */
const handlePreview = async (file: {
  url: string;
  fileId?: string;
  preview: string;
  originFileObj: File;
  name: string;
  type: string;
  response: any;
}) => {
  if (props?.listType === 'text') {
    /** 在线 iframe 预览 */
    if (props?.onLineFilePreview) {
      const _response = file?.response || {};
      const _fileId = file.fileId || _response.fileId;
      if (_fileId) {
        const _fileName = file.name || _response.fileName;
        // 文件预览
        uploadPreviewFileRef.value?.init({
          fileId: _fileId,
          fileName: _fileName,
          fullUrl: file.url || _response.downloadUrl,
          fileType: _fileName ? _fileName.split('.').pop() : '',
        });
      }
    }
    return;
  }
  if (!file.url && !file.preview) {
    file.preview = (await getBase64(file.originFileObj)) as string;
  }

  const fileUrl = file.url || file.preview;
  const url = props.previewFile ? await props.previewFile(fileUrl) : fileUrl;
  if (isVideoFileType(file.type)) {
    previewImage.value = '';
    previewVideo.value = url;
  } else {
    previewVideo.value = '';
    previewImage.value = url;
  }
  previewTitle.value = file.name || file.url.substring(file.url.lastIndexOf('/') + 1);
  previewVisible.value = true;
};

defineExpose({
  handleRemove,
});
</script>
<template>
  <div class="upload-wrap">
    <Upload
      v-model:file-list="fileList"
      :listType="listType"
      :multiple="multiple"
      :maxCount="maxCount"
      :before-upload="handleBeforeUpload"
      :customRequest="customUpload"
      :accept="accept"
      :show-upload-list="{
        showRemoveIcon: !disabled,
      }"
      :is-image-url="isImageUrl"
      :preview-file="getPreviewFile"
      @change="handleChange"
      @remove="handleRemove"
      @preview="handlePreview as any"
    >
      <slot name="uploadBtn" />

      <template
        v-if="$slots.itemRender"
        v-slot:itemRender="{ actions, file, fileList, originNode }"
      >
        <slot
          name="itemRender"
          :actions="actions"
          :file="file"
          :fileList="fileList"
          :originNode="originNode"
        />
      </template>
      <div
        class="upload-content"
        v-if="!disabled && showUploadBtn && fileList?.length < (maxLength || Infinity)"
      >
        <div v-if="props?.listType === 'text'">
          <Button>
            <UploadOutlined></UploadOutlined>
            {{ uploadTxt }}
          </Button>
        </div>
        <div v-else class="upload-content-img">
          <PlusOutlined />
          <text class="upload-content-txt">{{ uploadTxt }}</text>
        </div>
      </div>
    </Upload>
    <Modal
      destroy-on-close
      centered
      :open="previewVisible"
      :title="previewTitle"
      :footer="null"
      @cancel="handleCancel"
    >
      <video
        v-if="previewVideo"
        style="width: 100%"
        :src="previewVideo"
        autoplay
        controls
        controlsList="nodownload noplaybackrate"
        oncontextmenu="return false;"
        disablePictureInPicture
      />
      <img v-else style="width: 100%" :src="previewImage" />
    </Modal>
    <Preview v-if="onLineFilePreview" ref="uploadPreviewFileRef" />
  </div>
</template>

<style lang="scss" scoped>
.upload-wrap {
  .upload-content {
    display: flex;
    justify-content: center;
  }
  .upload-content-img {
    display: flex;
    flex-direction: column;
    align-items: center;
  }
  .upload-content-txt {
    margin-top: 8px;
    color: #666;
  }
}
:deep(.antv-sa-upload-list-item-name) {
  color: v-bind('token.colorLink');
  cursor: pointer;
}
</style>
