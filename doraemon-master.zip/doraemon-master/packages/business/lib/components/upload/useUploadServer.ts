import { Http } from '@lexikos/doraemon-network';
import { message } from 'ant-design-vue';
import SparkMD5 from 'spark-md5';

const useUploadServer = () => {
  /** 文件MD5处理 */
  const getFileMd5 = (file: File) =>
    new Promise((resolve, reject) => {
      const blobSlice = File.prototype.slice;
      const chunkSize = 2097152; // 只取2M chunk
      const chunks = Math.ceil(file.size / chunkSize); // 遍历取块的md5
      let currentChunk = 0;
      const spark = new SparkMD5.ArrayBuffer();
      const fileReader = new FileReader();

      fileReader.addEventListener('load', (e: ProgressEvent<FileReader>) => {
        spark.append(e.target!.result as ArrayBuffer);
        currentChunk++;

        if (currentChunk < chunks) {
          readNext();
        } else {
          resolve(spark.end());
        }
      });
      fileReader.addEventListener('error', () => reject('文件读取失败'));

      function readNext() {
        const start = currentChunk * chunkSize;
        const end = start + chunkSize >= file.size ? file.size : start + chunkSize;

        fileReader.readAsArrayBuffer(blobSlice.call(file, start, end));
      }

      readNext();
    });

  /** 文件上传接口 */
  const uploadFile2Server = ({
    file,
    timeout = 1000 * 50,
    isPublic = false,
  }: {
    file: File;
    timeout?: number; // 上传超时时间
    isPublic?: boolean;
  }) => {
    let isTimeout = false;
    return new Promise((resolve, reject) => {
      const params = new URLSearchParams();
      const fileReader = new FileReader();
      fileReader.readAsArrayBuffer(file);
      fileReader.addEventListener('loadend', async (e: ProgressEvent<FileReader>) => {
        const blob = new Blob([e?.target?.result as ArrayBuffer], { type: file.type });
        const fileType = file.name.split('.').pop()?.toLowerCase();
        const timer = setTimeout(() => {
          isTimeout = true;
          message.error('上传超时，请重试');
        }, timeout);
        try {
          // 1、获取预上传文件、图片地址
          const res: any = await Http.getInstance().get('/api/resource/files/getUploadUrl', {
            locationId: '999', // 暂时传999,后续后端接口修改后删除该参数
            bucketType: isPublic ? 'public' : 'private',
            fileType: fileType ?? '',
          });
          const { fileId, header, uploadUrl } = res || {};
          if (isTimeout) {
            reject('超时取消上传');
            return;
          }

          // 2、上传文件、图片至预上传服务器
          const headerParams = {
            ...(header ?? {}),
            'Content-Disposition': `attachment;filename=${encodeURIComponent(
              file.name,
            )};filename*=UTF-8''${encodeURIComponent(file.name)}`,
          };

          const uploadRes = await Http.getInstance().put(uploadUrl, blob, {
            headers: headerParams,
            timeout,
            keepalive: false,
          });
          if (!uploadRes || isTimeout) {
            reject('取消上传');
            return;
          }

          const md5 = await getFileMd5(file);
          if (isTimeout) {
            reject('超时取消上传');
            return;
          }

          params.append('fileId', fileId);
          params.append('fileName', file.name);
          params.append('status', '1');
          // 3、更新上传结果至IMP服务下的接口
          const resultRes = await Http.getInstance().post(
            '/api/resource/files/updateResult',
            params,
            {
              headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
              },
            },
          );
          if (!resultRes || isTimeout) {
            reject('取消上传');
            return;
          }

          // 4、获取图片、文件地址供预览
          const data: any = await Http.getInstance().get('/api/resource/files/getFileInfo', {
            fileId,
          });
          if (!data || isTimeout) {
            reject('取消上传');
            return;
          }
          clearTimeout(timer);
          const downloadUrl = (data || {}).fullUrl;
          return resolve({ md5, fileId, downloadUrl, fileName: file.name });
        } catch (err) {
          reject('取消上传');
        }
      });
    });
  };
  return { uploadFile2Server };
};
export default useUploadServer;
