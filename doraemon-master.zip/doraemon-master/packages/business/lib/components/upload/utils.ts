import { type UploadFile } from 'ant-design-vue';
import { previewImage, loadImageElement, loadVideoElement } from '../../utils/previewImage';

export const isImageFileType = (type: string): boolean => type.indexOf('image/') === 0;

export const isVideoFileType = (type: string): boolean => type.indexOf('video/') === 0;

export function getPreviewFile(file: File | Blob): Promise<string> {
  return new Promise((resolve) => {
    if (!file.type || !(isImageFileType(file.type) || isVideoFileType(file.type))) {
      resolve('');
      return;
    }

    if (isImageFileType(file.type)) {
      loadImageElement(file).then((img) => {
        const dataURL = previewImage(img, {
          width: img.width,
          height: img.height,
        });
        resolve(dataURL);
      });
    } else if (isVideoFileType(file.type)) {
      loadVideoElement(file).then((video) => {
        const dataURL = previewImage(video, {
          width: video.videoWidth,
          height: video.videoHeight,
        });
        resolve(dataURL);
      });
    }
  });
}

const extname = (url = '') => {
  const temp = url.split('/');
  const filename = temp[temp.length - 1];
  const filenameWithoutSuffix = filename.split(/#|\?/)[0];
  return (/\.[^./\\]*$/.exec(filenameWithoutSuffix) || [''])[0];
};

export const isImageUrl = (file: UploadFile<any>) => {
  if (file && file.type) {
    return isImageFileType(file.type) || isVideoFileType(file.type);
  }

  if (file.type && !file.thumbUrl) {
    return isImageFileType(file.type);
  }
  const url: string = (file.thumbUrl || file.url || '') as string;
  const extension = extname(url);
  if (
    /^data:image\//.test(url) ||
    /(webp|svg|png|gif|jpg|jpeg|jfif|bmp|dpg|ico)$/i.test(extension)
  ) {
    return true;
  }
  if (/^data:/.test(url)) {
    return false;
  }
  if (extension) {
    return false;
  }
  return true;
};
