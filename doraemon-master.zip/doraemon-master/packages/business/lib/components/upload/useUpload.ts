import { message } from 'ant-design-vue';
import { findIndex, lowerCase, map, uniqWith } from 'lodash-es';
import type { IUploadProps, TFileObject } from './type';

const useUpload = () => {
  /** 上传文件校验 */
  const handleCheckBeforeUpload = ({
    file,
    fileListData,
    propsParams,
    files,
    uploadingList = [],
  }: {
    file: TFileObject;
    fileListData: TFileObject[];
    propsParams: IUploadProps;
    files: TFileObject[];
    uploadingList: TFileObject[];
  }) => {
    const { minSize, maxSize, accept, multiple, maxCount } = propsParams;
    const copyFileList = fileListData.map((fileItem: TFileObject) => {
      fileItem.status = 'uploading';
      return fileItem;
    });
    const uploadData = [...uploadingList];
    if (minSize || maxSize) {
      let minSizeResult;
      let maxSizeResult;
      if (minSize)
        minSizeResult = copyFileList.find(
          (fileItem: TFileObject) => fileItem.size / 1024 < +minSize,
        );
      if (maxSize)
        maxSizeResult = copyFileList.find(
          (fileItem: TFileObject) => fileItem.size / 1024 > +maxSize,
        );
      if (minSizeResult || maxSizeResult) {
        message.error('文件大小超出限制');
        return false;
      }
    }
    // 校验
    if (accept) {
      const types: string[] = accept?.split(',');
      const acceptTypes: string[] = map(types, (v) => {
        const t = v.includes('.') ? v?.split('.') : v?.split('/');
        return t[t.length - 1];
      });
      const extension = file.name.slice(file.name.lastIndexOf('.') + 1);
      if (findIndex(acceptTypes, (t) => lowerCase(t) === lowerCase(extension)) === -1) {
        message.error(`暂不支持${extension}格式`);
        return false;
      }
    }
    if (multiple) {
      // 多选模式
      const newFileList = [...(files || []), ...copyFileList];
      if (maxCount) {
        if (newFileList.length > maxCount) {
          message.error('文件上传个数超出限制');
          return false;
        }
      }
      for (let i = 0; i < fileListData?.length; i++) {
        const uploadingExist = uploadData.find(
          (fileItem: TFileObject) => fileItem.uid === fileListData?.[i].uid,
        );
        if (!uploadingExist) uploadData.push(fileListData?.[i]);
      }

      const newUploadData: TFileObject[] = [];
      if (accept) {
        const types: string[] = accept?.split(',');
        const acceptTypes: string[] = map(types, (v) => {
          const t = v.includes('.') ? v?.split('.') : v?.split('/');
          return t[t.length - 1];
        });
        uploadData.forEach((item) => {
          const extension = item.name.slice(item.name.lastIndexOf('.') + 1);
          if (findIndex(acceptTypes, (t) => lowerCase(t) === lowerCase(extension)) !== -1) {
            newUploadData.push(item);
          }
        });
        if (newUploadData.length === 0) {
          return false;
        }
      }
      return { filesData: newUploadData, uploadData: newUploadData };
    } else {
      // 单选模式
      const newFile = file;
      const singleFile = [newFile];
      newFile.status = 'uploading';
      return { filesData: singleFile, uploadData: singleFile };
    }
  };

  const getBase64 = (file: File) => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = () => resolve(reader.result);
      reader.onerror = (error) => reject(error);
    });
  };

  // 删除发现
  const handleDeleteFind = (fileList: TFileObject[], deletedList: TFileObject[]) => {
    for (let i = 0; i < fileList.length; i++) {
      const deleted = deletedList.find((file: TFileObject) => {
        if (file.uid === fileList[i].uid) {
          i--;
          return true;
        }
        return false;
      });
      if (deleted) fileList.splice(i + 1, 1);
    }
    if (fileList.length === 0) {
      return fileList;
    }
    const uniqueArray = Array.from(
      fileList.reduce((map, obj) => map.set(obj.fileId, obj), new Map()).values(),
    );
    return uniqueArray;
  };

  /** 默认显示文件 */
  const handleDefaultFile = (defaultFiles: string[]) => {
    const files: TFileObject[] = [];
    (defaultFiles || []).forEach((item) => {
      const urlObj = typeof item === 'string' ? { url: item } : item;
      const url = urlObj.url;
      if (!url) return;
      const uid = `img-${Date.now() + Math.round(Math.random() * 1000)}`;
      const name = '查看大图';
      files.push({ uid, name, status: 'done', type: '', size: 0, ...urlObj });
    });
    return files;
  };

  const handleFiles = (fileList: TFileObject[], defaultFiles: TFileObject[]) => {
    const files = uniqWith(fileList?.concat(defaultFiles), (arrVal, othVal) => {
      if (arrVal?.fileId || othVal?.fileId) {
        return arrVal?.fileId === othVal?.fileId;
      } else {
        return arrVal.uid === othVal.uid;
      }
    });
    const allFiles = files.map((file: TFileObject) => {
      if (!file.url) file.url = URL.createObjectURL(file as unknown as File);
      return file;
    });
    return allFiles;
  };
  return { handleCheckBeforeUpload, getBase64, handleDeleteFind, handleDefaultFile, handleFiles };
};

export default useUpload;
