import { ref } from 'vue';
import { message, Modal } from 'ant-design-vue';
import { clearStorage } from '../../utils';
import { useAuthStore } from '../../stores';
import {
  LOCAL_STORAGE_EXPIRE,
  LOCAL_STORAGE_REFRESH_EXPIRE,
  LOCAL_STORAGE_REFRESH_TOKEN,
} from '../../stores/useAuthStore';
import type { LocationByUserType, LocationItem } from '../../hooks';
import useHttp from '../../hooks/useHttp';

interface Props {
  currentId?: string;
  currentUserType?: number;
  currentChildId?: string;
  /**
   *
   * @param loading 切换组织接口的 loading 状态
   * @returns
   */
  onSelecting?: (loading: boolean) => void;
}

const useLocations = ({ currentId, currentUserType, currentChildId, onSelecting }: Props = {}) => {
  const http = useHttp();
  const locations = ref<LocationByUserType[]>([]);
  const loadingLocations = ref(false);

  const getLocations = async () => {
    loadingLocations.value = true;
    try {
      const res = await http.get('/api/building/locations');
      const _data = res || [];
      locations.value = _data;
      if (_data.length > 1 || _data[0]?.locations?.length > 1) {
        localStorage.setItem('multipleLocation', '1');
      } else {
        localStorage.removeItem('multipleLocation');
      }
    } catch (error) {
      // do sth
    } finally {
      loadingLocations.value = false;
    }
  };

  const onSelected = async (
    location: LocationItem,
    userType: number,
    /**
     *
     * @param value 切换组织成功后的组织信息
     * @returns
     */
    callback: (value?: LocationItem, homePageAddress?: string) => void,
  ) => {
    // 同个组织同个身份
    if (
      location.id === currentId &&
      currentUserType === userType &&
      currentChildId &&
      currentChildId === location.childId
    ) {
      return;
    }

    // 社会公众角色暂不开放
    if (userType === 4) {
      Modal.info({
        centered: true,
        content: '即将开放，敬请期待',
        okText: '确定',
      });
      callback();
      return;
    }

    onSelecting?.(true);

    try {
      const res = await http.post('/api/building/changeLocation', {
        locationId: location.id,
        childId: location.childId,
        userType,
      });

      if (res.accessToken) {
        // 设置站点 title
        const _title = location.name || '立达信数字教育云平台';
        document.title = _title;

        // 切换组织清楚本地缓存，相当于重新登录
        clearStorage([
          LOCAL_STORAGE_EXPIRE,
          LOCAL_STORAGE_REFRESH_TOKEN,
          LOCAL_STORAGE_REFRESH_EXPIRE,
        ]);

        localStorage.setItem('documentTitle', _title);
        useAuthStore().set({
          token: res.accessToken,
          tokenKey: res.tokenHeaderName,
        });

        // 如果是已经登录的状态，不要立即更新http，否则可能出现拿新的token，取旧业务的情况，导致退出登录
        // 依赖后续的刷新更新 http 的 token 就行
        if (!currentId) {
          http.setHeader({
            token: '',
            cuser_token: '',
            [res.tokenHeaderName || 'token']: res.accessToken,
          });
        }

        callback(location, res.homePageAddress);
      } else {
        callback();
        message.error('切换失败');
      }
    } catch (error: any) {
      callback();
      message.error(error?.desc || '切换失败');
    } finally {
      onSelecting?.(false);
    }
  };

  return { loadingLocations, locations, getLocations, onSelected };
};

export default useLocations;
