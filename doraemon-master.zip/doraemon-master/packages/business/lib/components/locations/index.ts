export { default as LocationSelector } from './LocationSelector.vue';
