<script lang="ts" setup>
import { computed, onBeforeMount, ref, watchEffect } from 'vue';
import { Empty, theme, InputSearch, Spin, TypographyParagraph } from 'ant-design-vue';
import type { LocationByUserType, LocationItem } from '../../hooks';
import LocationSelectorList from './LocationSelectorList.vue';
import useLocations from './useLocations';

const props = defineProps<{
  currentId?: string;
  currentUserType?: number;
  locations?: LocationByUserType[] | null;
  currentChildId?: string;
  /** 是否将上次登录抽到顶部 */
  showLastLogin?: boolean;
}>();

const emit = defineEmits<{
  (event: 'beforeChanged'): void;
  (event: 'afterChanged', value: LocationItem, homePageAddress?: string): void;
  (event: 'loading', loading: boolean): void;
  (event: 'multiple', multiple: boolean): void;
}>();

const { token } = theme.useToken();

const searchValue = ref();

const simpleImage = Empty.PRESENTED_IMAGE_SIMPLE;

const userTypeMap = ['教育工作者', '学生', '家长', '其他', '社会公众'];

// 选择完组织调用接口 loading 的回调
const onSelecting = (value: boolean) => {
  emit('loading', value);
};

const { locations, loadingLocations, getLocations, onSelected } = useLocations({
  currentId: props.currentId,
  currentUserType: props.currentUserType,
  currentChildId: props.currentChildId,
  onSelecting,
});

const finallyLocations = computed(() => props.locations || locations.value || []);

watchEffect(() => {
  if (finallyLocations.value.length > 1 || finallyLocations.value[0]?.locations?.length > 1) {
    localStorage.setItem('multipleLocation', '1');
    emit('multiple', true);
  }
});

// 选择完组织的回调
const _onAfterSelected = (value?: LocationItem, homePageAddress?: string) => {
  emit('loading', false);
  if (value) {
    localStorage.setItem('multipleLocation', '1');
    if (value.logoFileUrl) {
      sessionStorage.setItem('locationLogo', value.logoFileUrl);
    } else {
      sessionStorage.removeItem('locationLogo');
    }
    emit('afterChanged', value, homePageAddress);
  }
};

const handleSelected = (value: LocationItem, userType: number) => {
  emit('beforeChanged');
  onSelected(value, userType, _onAfterSelected);
};

type LastLoginItem = LocationItem & { userType: number };

const findLastLoginNode = (items: LocationItem[], userType: number) => {
  let _item: LastLoginItem | null = null;

  const stack: LocationItem[] = [];
  for (const item of items) {
    if (item) {
      stack.push(item);
      while (stack.length) {
        const temp = stack.pop();

        if (temp?.isRecentlyLogin) {
          _item = { ...temp, userType };
          break;
        }

        const children = temp?.children || [];
        for (let i = children.length - 1; i >= 0; i--) {
          stack.push(children[i]);
        }
      }
    }
  }

  return _item;
};

const lastLoginItem = computed(() => {
  if (!props.showLastLogin || !finallyLocations.value.length) {
    return null;
  }

  let _value = null;
  const _stack = [];

  for (const item of finallyLocations.value) {
    if (item) {
      _stack.push(item);
      while (_stack.length) {
        const temp = _stack.pop();
        const _last = findLastLoginNode(temp?.locations || [], item.userType);
        if (_last) {
          _value = _last;
          break;
        }
      }
    }
  }

  return _value;
});

const lastLoginItemContent = computed(() => {
  if (lastLoginItem.value) {
    return `${lastLoginItem.value.name}
  ${lastLoginItem.value.childName ? ` - ${lastLoginItem.value.childName}` : ''}（${`${userTypeMap[lastLoginItem.value.userType] || '其他'}`}）`;
  }
  return '';
});

const filterLocations = (value: string, list: LocationItem[]) => {
  let newList: LocationItem[] = [];
  list.forEach((item) => {
    if (item.name && item.name.toLocaleLowerCase().indexOf(value.toLocaleLowerCase()) > -1) {
      let children: LocationItem[] = [];
      if (item.children && item.children.length > 0) {
        children = filterLocations(value, item.children);
      }

      // 忽略大小写 正则查询搜索内容
      const reg = RegExp(value, 'ig');
      const searchedName = item.name.replace(
        reg,
        (match) => `<span style="color: ${token.value.colorPrimary}">${match}</span>`,
      );

      newList.push({
        ...item,
        searchedName,
        children,
      });
    } else if (item.children?.length) {
      let _children = filterLocations(value, item.children);
      if (_children && _children.length > 0) {
        let obj = {
          ...item,
          children: _children,
        };
        newList.push(obj);
      }
    }
  });
  return newList;
};

const searchLocations = computed(() => {
  if (!searchValue.value) {
    return finallyLocations.value;
  }

  return finallyLocations.value
    .map((item) => {
      return {
        ...item,
        locations: filterLocations(searchValue.value, item.locations),
      };
    })
    .filter((i) => i.locations.length);
});

onBeforeMount(() => {
  if (!props.locations) {
    getLocations();
  }
});
</script>

<template>
  <div class="location-selector-warp">
    <InputSearch
      v-if="finallyLocations.length"
      v-model:value="searchValue"
      allowClear
      placeholder="搜索"
      style="width: 100%; margin-bottom: 8px"
    />
    <div class="location-selector">
      <div class="location-selector-spin" v-if="currentId && loadingLocations">
        <Spin />
      </div>
      <div
        v-if="lastLoginItem"
        class="last-login-item"
        @click="handleSelected(lastLoginItem, lastLoginItem.userType)"
      >
        <span class="last-login-item-label">上次登录：</span>
        <TypographyParagraph
          style="max-width: 330px; margin-bottom: 0"
          :ellipsis="{ tooltip: lastLoginItemContent }"
          :content="lastLoginItemContent"
        />
      </div>
      <template v-if="searchLocations.length">
        <template v-for="item in searchLocations" :key="item.userType">
          <TypographyParagraph
            ellipsis
            class="user-type"
            :content="`${userTypeMap[item.userType] || '其他'}:`"
          />
          <LocationSelectorList
            :currentId="currentId"
            :currentUserType="currentUserType"
            :currentChildId="currentChildId"
            :data="item.locations"
            :userType="item.userType"
            :selected="handleSelected"
          />
        </template>
      </template>
      <div v-else-if="!loadingLocations" class="location-empty">
        <Empty :image="simpleImage" description="暂无数据" />
      </div>
    </div>
  </div>
</template>

<style lang="scss" scoped>
.tree {
  margin-left: 20px;
  border-left: 2px #01847f dashed;
}

.location-selector-spin {
  padding: 24px 0;
  text-align: center;
}

.location-selector-warp {
  display: flex;
  flex-direction: column;
  flex: 1;
  overflow: hidden;
}

.location-selector {
  flex: 1;
  height: 100%;
  overflow: hidden auto;
}

.location-empty {
  margin-top: 88px;
}

.user-type {
  padding: 8px 16px 8px 2px;
  margin-bottom: 4px;
  color: rgb(0 0 0 / 88%);
  font-weight: 600;
  line-height: 22px;
  border-bottom: 1px solid rgb(0 0 0 / 6%);
}

.last-login-item {
  display: flex;
  margin: 10px 0;
  align-items: center;
  cursor: pointer;
  &-label {
    color: v-bind('token.colorSuccess');
  }
}
</style>
