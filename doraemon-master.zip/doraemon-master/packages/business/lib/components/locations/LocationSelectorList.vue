<script lang="ts" setup>
import type { LocationItem } from '../../hooks';
import LocationSelectorItem from './LocationSelectorItem.vue';

const props = defineProps<{
  data: LocationItem[];
  currentId?: string;
  currentUserType?: number;
  currentChildId?: string;
  userType: number;
  selected: (value: LocationItem, userType: number) => void;
}>();
</script>

<template>
  <template v-for="item in data || []" :key="`${item.id}${item.childId}${item.locationLevel}`">
    <div v-if="item.children?.length" class="location-group">
      <LocationSelectorItem
        :item="item"
        :active="
          currentId === item.id &&
          userType === currentUserType &&
          (!item.childId || item.childId === currentChildId)
        "
        class="location-item-inner"
        @click.stop="selected(item, props.userType)"
      />
      <LocationSelectorList
        :currentId="currentId"
        :currentUserType="currentUserType"
        :currentChildId="currentChildId"
        :data="item.children"
        :userType="userType"
        :selected="selected"
      />
    </div>
    <LocationSelectorItem
      v-else
      :item="item"
      :active="
        currentId === item.id &&
        userType === currentUserType &&
        (!item.childId || item.childId === currentChildId)
      "
      class="location-item"
      @click.stop="selected(item, props.userType)"
    />
  </template>
</template>

<style lang="scss" scoped>
.location-group {
  padding-left: 16px;
}
</style>
