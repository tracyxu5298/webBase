<script lang="ts" setup>
import { theme } from 'ant-design-vue';
import type { LocationItem } from '../../hooks';

defineProps<{
  item: LocationItem;
  active?: boolean;
}>();
const { token } = theme.useToken();
</script>

<template>
  <div :style="{ color: active ? token.colorPrimary : token.colorTextBase }">
    <span v-html="item.searchedName || item.name || ''"></span
    >{{ item.childName ? ` - ${item.childName}` : '' }}
    <!-- <Tag v-if="!active && item.isRecentlyLogin" class="location-tag" color="green"
      >上次登录</Tag
    > -->
  </div>
</template>

<style lang="scss" scoped>
.location-item-inner,
.location-item {
  padding: 8px 16px;
  margin-bottom: 4px;
  cursor: pointer;
}

.location-item-inner {
  padding-left: 0;
}

.location-tag {
  margin-left: 8px;
}
</style>
