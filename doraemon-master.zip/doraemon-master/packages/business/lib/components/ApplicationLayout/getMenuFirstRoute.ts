import type { IMenu } from '../../types';

function getMenuFirstRoute(menus: IMenu[]): IMenu | null {
  for (let i = 0, len = menus.length; i < len; i++) {
    const menu = menus[i];
    if (menu.path) {
      return menu;
    }
    if (Array.isArray(menu.children) && menu.children.length > 0) {
      const found = getMenuFirstRoute(menu.children);
      if (found) {
        return found;
      }
    }
  }
  return null;
}

export default getMenuFirstRoute;
