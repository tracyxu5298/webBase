import type { IMenu } from '../../types';

function getMenuDefaultRoute(menus: IMenu[]): IMenu | null {
  for (let i = 0, len = menus.length; i < len; i++) {
    const menu = menus[i];
    if (menu.checked) {
      return menu;
    }
    if (Array.isArray(menu.children) && menu.children.length > 0) {
      const found = getMenuDefaultRoute(menu.children);
      if (found) {
        return found;
      }
    }
  }
  return null;
}

export default getMenuDefaultRoute;
