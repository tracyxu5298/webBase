import { ref, h } from 'vue';
import { RouterLink } from 'vue-router';
import type { MenuProps } from 'ant-design-vue';
import {
  PieChartOutlined,
  MailOutlined,
  DesktopOutlined,
  SettingOutlined,
} from '@ant-design/icons-vue';

const items = ref<MenuProps['items']>([
  {
    key: '1',
    icon: () => h(PieChartOutlined),
    label: h(RouterLink, { to: '/SystemSettings/NavigationSettings' }, '导航栏设置'),
    title: '导航栏设置',
  },
  {
    key: '2',
    icon: () => h(DesktopOutlined),
    label: h(RouterLink, { to: '/SystemSettings/WorkbenchSettings' }, '工作台设置'),
    title: '工作台设置',
  },
  {
    key: '3',
    icon: () => h(DesktopOutlined),
    label: h(RouterLink, { to: '/SystemSettings/ThemeSettings' }, '主题设置'),
    title: '主题设置',
  },
  {
    key: '33',
    icon: () => h(DesktopOutlined),
    label: h(RouterLink, { to: '/SystemSettings/Lowcode/494576110567176645' }, '低代码页面'),
    title: '低代码页面',
  },
  {
    key: '4',
    icon: () => h(MailOutlined),
    label: '系统管理',
    title: '系统管理',
    children: [
      {
        key: '5',
        label: '系统参数',
        title: '系统参数',
      },
      {
        key: '6',
        label: '日志中心',
        title: '日志中心',
      },
      {
        key: '7',
        label: '报表订阅',
        title: '报表订阅',
      },
      {
        key: '8',
        label: '应用管理',
        title: '应用管理',
      },
    ],
  },
  {
    type: 'group',
    label: '分组一',
    children: [
      {
        label: 'Option 1',
        icon: () => h(DesktopOutlined),
        key: 'setting:1',
      },
      {
        label: 'Option 2',
        icon: () => h(DesktopOutlined),
        key: 'setting:2',
      },
    ],
  },
  {
    type: 'group',
    label: '分组二',
    children: [
      {
        label: 'Option 3',
        key: 'setting:3',
      },
      {
        label: 'Option 4',
        key: 'setting:4',
      },
    ],
  },

  {
    key: 'sub2',
    icon: () => h(SettingOutlined),
    label: '折叠分组',
    title: 'Navigation Three - Submenu',
    children: [
      {
        type: 'group',
        label: '分组一',
        children: [
          {
            label: 'Option 1',
            key: 'setting:1',
          },
          {
            label: 'Option 2',
            key: 'setting:2',
          },
        ],
      },
      {
        type: 'group',
        label: '分组二',
        children: [
          {
            label: 'Option 3',
            key: 'setting:3',
          },
          {
            label: 'Option 4',
            key: 'setting:4',
          },
        ],
      },
    ],
  },
  {
    key: 'sub3',
    icon: () => h(SettingOutlined),
    label: '三级菜单',
    title: 'Navigation Two',
    children: [
      {
        key: '9',
        label: '第二层菜单1',
        title: 'Option 9',
      },
      {
        key: '10',
        label: '第二层菜单2',
        title: 'Option 10',
      },
      {
        key: 'sub4',
        label: '第二层菜单3',
        title: 'Submenu',
        children: [
          {
            key: '11',
            label: '第三层菜单1',
            title: 'Option 11',
          },
          {
            key: '12',
            label: '第三层菜单2',
            title: 'Option 12',
          },
        ],
      },
    ],
  },
]);

export default items;
