import { h, type VNode } from 'vue';
import { RouterLink } from 'vue-router';
import type { ItemType } from 'ant-design-vue';
import type { IMenu } from '../../types';

function _getMenuItem(
  label: VNode | string,
  title: string,
  key: string,
  icon?: any,
  children?: ItemType[],
  type?: string,
): ItemType {
  return { label, title, key, icon, children, type } as ItemType;
}

/**
 * 数据转换
 * @param {IMenu[]} menus - 来自服务端返回的应用菜单数据.
 * @return {ItemType[]} 返回 Ant Design Vue Menu.ItemType[]
 */
function getMenuItems(menus: IMenu[]): ItemType[] {
  return menus.map((menu) => {
    const { id: key, name, type, path, query } = menu;
    const title = name;
    let icon;
    if (menu.icon) {
      icon = h('i', { class: menu.icon });
    }
    let label: VNode | string = name;
    let group;
    switch (type) {
      case 11: // 目录 - 支持折叠
        break;
      case 12: // 目录 - 不支持折叠
        group = 'group';
        break;
      case 21: // 手工页面
        // [Vue warn]: Non-function value encountered for default slot. Prefer function slots for better performance.
        label = h(RouterLink, { to: path || '' }, { default: () => name });
        break;
      case 31: // 低代码功能
        label = h(RouterLink, { to: `${path}${query || ''}` }, { default: () => name });
        break;
      case 32: // 低代码报表
        break;
      case 33: // 低代码大屏
        break;
      case 34: // 低代码门户
        break;
      case 41: // 外链
        label = h(RouterLink, { to: path || '' }, { default: () => name });
        break;
      default:
        console.error(`[getMenuItems.ts] type=${type} 超出范围`);
    }
    const children =
      Array.isArray(menu.children) && menu.children.length > 0
        ? getMenuItems(menu.children)
        : undefined;
    return _getMenuItem(label, title, key, icon, children, group);
  });
}

export default getMenuItems;
