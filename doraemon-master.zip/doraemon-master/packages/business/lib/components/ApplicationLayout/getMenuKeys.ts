import type { IMenu } from '../../types';

/**
 * 根据浏览器URL路径查找菜单, 包括父亲和祖先菜单
 * @param {IMenu[]} menus - 来自服务端返回的应用菜单数据.
 * @param {string} pathname - 浏览器URL路径`location.pathname`.
 * @return {IMenu[]} 返回菜单对象数组.
 */
function getMenusByPathname(menus: IMenu[], pathname: string): IMenu[] {
  const result: IMenu[] = [];
  for (let i = 0, len = menus.length; i < len; i++) {
    const menu = menus[i];
    const { path, query } = menu;
    if (path && pathname.includes(`${path}${query || ''}`)) {
      return [menu]; // 叶子菜单
    }
    if (Array.isArray(menu.children) && menu.children.length > 0) {
      result.push(menu); // 添加父菜单 (叶子菜单不一定匹配)
      const m = getMenusByPathname(menu.children, pathname); // IMenu[]
      if (m.length > 0) {
        return result.concat(m); // 已找到, 添加子菜单
      } else {
        result.pop(); // 未找到, 删除父菜单
      }
    }
  }
  return result; // [根级菜单，父级菜单，叶子菜单]
}

/**
 * 根据浏览器URL路径查找叶子节点的菜单
 * @param {IMenu[]} menus - 来自服务端返回的应用菜单数据.
 * @param {string} pathname - 浏览器URL路径`location.pathname`.
 * @return {string[]} 返回叶子菜单id数组.
 */
const cacheMenuSelectedKeys: Record<string, string[]> = {};
function getMenuSelectedKeys(menus: IMenu[], pathname: string): string[] | undefined {
  if (!cacheMenuSelectedKeys[pathname]) {
    const menu = getMenusByPathname(menus, pathname).pop(); // 只需要叶子菜单
    if (menu) {
      cacheMenuSelectedKeys[pathname] = [menu.id];
    }
  }
  return cacheMenuSelectedKeys[pathname];
}

/**
 * 根据浏览器URL路径查找叶子节点的菜单
 * @param {IMenu[]} menus - 来自服务端返回的应用菜单数据.
 * @param {string} pathname - 浏览器URL路径`location.pathname`.
 * @return {string[]} 返回叶子菜单id数组.
 */
const cacheMenuOpenKeys: Record<string, string[]> = {};
function getMenuOpenKeys(menus: IMenu[], pathname: string): string[] | undefined {
  if (!cacheMenuOpenKeys[pathname]) {
    const _menus = getMenusByPathname(menus, pathname);
    _menus.pop(); // 去掉叶子菜单
    if (_menus.length > 0) {
      cacheMenuOpenKeys[pathname] = _menus.map((m) => m.id);
    }
  }
  return cacheMenuOpenKeys[pathname];
}

export { getMenuSelectedKeys, getMenuOpenKeys };
