<!-- <script lang="ts" setup>
import { ref, unref, watch, watchEffect, onBeforeMount, computed, h } from 'vue';
import { useRoute, useRouter } from 'vue-router';
import { theme } from 'ant-design-vue';
import { MenuFoldOutlined, MenuUnfoldOutlined } from '@ant-design/icons-vue';
import useApplicationMenuStore from '../../stores/useApplicationMenuStore';
import getMenuItems from './getMenuItems';
import { getMenuSelectedKeys, getMenuOpenKeys } from './getMenuKeys';
import getMenuDefaultRoute from './getMenuDefaultRoute';
import getMenuFirstRoute from './getMenuFirstRoute';

const props = defineProps<{ appCode: string; hideMenu?: boolean }>();

const { token } = theme.useToken();
const route = useRoute();
const router = useRouter();
const selectedKeys = ref<string[] | undefined>();
const openKeys = ref<string[] | undefined>();
const collapsed = ref<boolean>(false);

const store = useApplicationMenuStore();
// state: ComputedRef<Record<string, IMenuState>>
const state = computed(() => unref(store.state));
// loading: ComputedRef<boolean | undefined>
const loading = computed(() => {
  const s = state.value[props.appCode];
  return s && s.loading;
});
// menus: ComputedRef<IMenus[] | undefined>
const menus = computed(() => {
  const s = state.value[props.appCode];
  return s && s.menus;
});
// items: ComputedRef<ItemType[] | undefined>
const items = computed(() => menus.value && getMenuItems(menus.value));
// showMenu: ComputedRef<boolean>
const showMenu = computed(() => {
  if (Array.isArray(menus.value)) {
    if (menus.value.length === 0) {
      return false;
    }
    if (menus.value.length === 1) {
      const children = menus.value[0].children;
      if (Array.isArray(children) && children.length > 0) {
        return true;
      }
      return false;
    }
  }
  return true;
});

onBeforeMount(() => {
  store.getApplicationMenus(props.appCode);
});

// console.log('ApplicationLayoutView', route.fullPath, menus.value);

watch(
  menus,
  () => {
    if (Array.isArray(menus.value) && menus.value.length > 0) {
      if (selectedKeys.value === undefined || selectedKeys.value.length === 0) {
        /* 待办中心跳转外部应用，不需要默认选中项 */
        if (route.query.forcePath === '1') {
          return;
        }
        // 默认路由
        const defaultMenu = getMenuDefaultRoute(menus.value);
        if (defaultMenu && defaultMenu.path) {
          router.replace(defaultMenu.path + (defaultMenu.query || ''));
          return;
        }
        // 第一个路由
        const firstMenu = getMenuFirstRoute(menus.value);
        if (firstMenu && firstMenu.path) {
          router.replace(firstMenu.path + (firstMenu.query || ''));
        }
      }
    }
  },
  { immediate: true },
);

watchEffect(() => {
  if (Array.isArray(menus.value)) {
    selectedKeys.value = getMenuSelectedKeys(menus.value, route.fullPath);
    openKeys.value = getMenuOpenKeys(menus.value, route.fullPath);
  }
});

const onClick = (e: any) => {
  selectedKeys.value = [e.key];
};

const onOpenChange = (keys: string[]) => {
  openKeys.value = keys;
};
</script>

<template>
  <Layout class="application-layout">
    <Layout.Sider
      theme="light"
      class="application-layout-sider"
      :collapsible="!loading"
      v-model:collapsed="collapsed"
      :collapsedWidth="80"
      :width="220"
      :trigger="
        h((collapsed ? MenuUnfoldOutlined : MenuFoldOutlined) as any, {
          style: { fontSize: '16px' },
        })
      "
      v-show="!hideMenu && (loading || showMenu)"
    >
      <div v-if="loading" class="application-layout-sider-loading">
        <Spin></Spin>
      </div>
      <Menu
        v-model:openKeys="openKeys"
        v-model:selectedKeys="selectedKeys"
        @click="onClick"
        @openChange="onOpenChange"
        theme="light"
        mode="inline"
        prefix-cls="application-layout-menu"
        :items="items"
        :class="['menu', collapsed ? 'menu-collapsed' : '']"
      ></Menu>
    </Layout.Sider>
    <Layout.Content class="application-layout-content">
      <slot><RouterView></RouterView></slot>
    </Layout.Content>
  </Layout>
</template>

<style lang="scss" scoped>
.application-layout {
  width: 100%;
  height: 100%;
}

.application-layout-sider {
  &-loading {
    width: 100%;
    height: 100%;
    padding-top: 80px;
    text-align: center;
    border-inline-end: 1px solid rgba(19, 28, 73, 0.11);
  }
  :deep(div[class$='-layout-sider-trigger']) {
    position: relative;
    padding: 0 32px;
    text-align: left;
    border-inline-end: 1px solid rgba(19, 28, 73, 0.11);
  }
  :deep(.application-layout-menu .application-layout-menu-submenu-arrow::before),
  :deep(.application-layout-menu .application-layout-menu-submenu-arrow::after) {
    background-color: v-bind('token.colorTextDescription');
  }
  :deep(
      .application-layout-menu-light.application-layout-menu-inline
        .application-layout-menu-sub.application-layout-menu-inline
    ) {
    background-color: transparent;
  }
}

.menu {
  overflow-x: hidden;
  overflow-y: auto;
  height: 100%;
  padding: 16px;
  li a {
    color: inherit;
  }
}

.menu-collapsed {
  :deep(.application-layout-menu-item-group-title) {
    display: none;
  }
}

.application-layout-content {
  display: flex;
  overflow-y: auto;
  height: 100%;
  background: #fff;
  flex: 1;
  flex-direction: column;
}
</style> -->

<script lang="ts" setup>
import { ref, unref, watchEffect, onBeforeMount, computed, h, watch } from 'vue';
import { useRoute, useRouter } from 'vue-router';
import { theme, Layout, Menu, Spin } from 'ant-design-vue';
import { MenuFoldOutlined, MenuUnfoldOutlined } from '@ant-design/icons-vue';
import useApplicationMenuStore from '../../stores/useApplicationMenuStore';
import getMenuItems from './getMenuItems';
import { getMenuSelectedKeys, getMenuOpenKeys } from './getMenuKeys';
import getMenuDefaultRoute from './getMenuDefaultRoute';
import getMenuFirstRoute from './getMenuFirstRoute';

const props = defineProps<{ appCode: string; hideMenu?: boolean }>();

const { token } = theme.useToken();
const route = useRoute();
const router = useRouter();
const selectedKeys = ref<string[] | undefined>();
const openKeys = ref<string[] | undefined>();
const collapsed = ref<boolean>(false);

const store = useApplicationMenuStore();
const menus = computed(() => unref(store.data));
const items = computed(() => getMenuItems(menus.value));
const showMenu = computed(() => {
  if (menus.value.length === 0) {
    return false;
  }
  if (menus.value.length === 1) {
    const children = menus.value[0].children;
    if (Array.isArray(children) && children.length > 0) {
      return true;
    }
    return false;
  }
  return true;
});

onBeforeMount(() => {
  store.getApplicationMenus(props.appCode);
});

watch(menus, (newMenus) => {
  if (Array.isArray(newMenus) && newMenus.length > 0) {
    if (selectedKeys.value === undefined || selectedKeys.value.length === 0) {
      const defaultRoute = getMenuDefaultRoute(newMenus);

      /* 待办中心跳转外部应用，不需要默认选中项 */
      if (route.query.forcePath === '1') return;

      if (defaultRoute && defaultRoute.path) {
        router.replace(defaultRoute.path + (defaultRoute.query || ''));
        return;
      }

      const firstMenu = getMenuFirstRoute(newMenus);
      if (firstMenu && firstMenu.path) {
        router.replace(firstMenu.path + (firstMenu.query || ''));
      }
    }
  }
});

watchEffect(() => {
  if (Array.isArray(menus.value) && menus.value.length > 0) {
    selectedKeys.value = getMenuSelectedKeys(menus.value, route.fullPath);
    openKeys.value = getMenuOpenKeys(menus.value, route.fullPath);
  }
});

const onClick = (e: any) => {
  selectedKeys.value = [e.key];
};

const onOpenChange = (keys: string[]) => {
  openKeys.value = keys;
};
</script>

<template>
  <Layout class="layout">
    <Layout.Sider
      theme="light"
      class="layout-sider"
      :collapsible="!store.loading"
      v-model:collapsed="collapsed"
      :collapsedWidth="80"
      :width="220"
      :trigger="
        h((collapsed ? MenuUnfoldOutlined : MenuFoldOutlined) as any, {
          style: { fontSize: '16px' },
        })
      "
      v-show="!hideMenu && (store.loading || showMenu)"
    >
      <div v-if="store.loading" class="layout-sider-loading">
        <Spin></Spin>
      </div>
      <Menu
        v-model:openKeys="openKeys"
        v-model:selectedKeys="selectedKeys"
        @click="onClick"
        @openChange="onOpenChange as any"
        theme="light"
        mode="inline"
        prefix-cls="application-layout-menu"
        :items="items"
        :class="['menu', collapsed ? 'menu-collapsed' : '']"
      ></Menu>
    </Layout.Sider>
    <Layout.Content class="layout-content">
      <slot>
        <RouterView></RouterView>
      </slot>
    </Layout.Content>
  </Layout>
</template>

<style lang="scss" scoped>
.layout {
  width: 100%;
  height: 100%;
}

.layout-sider {
  &-loading {
    width: 100%;
    height: 100%;
    padding-top: 80px;
    text-align: center;
    border-inline-end: 1px solid rgba(19, 28, 73, 0.11);
  }
  :deep(div[class$='-layout-sider-trigger']) {
    position: relative;
    padding: 0 32px;
    text-align: left;
    border-inline-end: 1px solid rgba(19, 28, 73, 0.11);
  }
  :deep(.application-layout-menu .application-layout-menu-submenu-arrow::before),
  :deep(.application-layout-menu .application-layout-menu-submenu-arrow::after) {
    background-color: v-bind('token.colorTextDescription');
  }
  :deep(
      .application-layout-menu-light.application-layout-menu-inline
        .application-layout-menu-sub.application-layout-menu-inline
    ) {
    background-color: transparent;
  }
}

.menu {
  overflow-x: hidden;
  overflow-y: auto;
  height: 100%;
  padding: 16px;
  li a {
    color: inherit;
  }
}

.menu-collapsed {
  :deep(.application-layout-menu-item-group-title) {
    display: none;
  }
}

.layout-content {
  display: flex;
  overflow-y: auto;
  height: 100%;
  background: #fff;
  flex: 1;
  flex-direction: column;
}
</style>
