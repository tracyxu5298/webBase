<script setup lang="ts">
import { computed, unref } from 'vue';
import { ConfigProvider, type ConfigProviderProps } from 'ant-design-vue';
import zhCN from 'ant-design-vue/es/locale/zh_CN';
import dayjs from 'dayjs';
import 'dayjs/locale/zh-cn';
import { usePreferenceSettingsStore, defaultPreferenceSettings } from '../../stores';
import { themes } from '../../themes';

const props = defineProps<ConfigProviderProps>();

dayjs.locale('zh-cn');

// https://ant-design.antgroup.com/components/config-provider-cn#configproviderconfig
// 设置 Modal、Message、Notification 静态方法配置，只会对非 hooks 的静态方法调用生效。
ConfigProvider.config({
  prefixCls: props.prefixCls || 'antv',
});

const preferenceSettingsStore = usePreferenceSettingsStore();
const theme = computed(() => {
  const preference = unref(preferenceSettingsStore.data);
  // console.log('ThemeConfigProvider', preference?.theme);
  return preference?.theme || defaultPreferenceSettings.theme;
});
</script>

<template>
  <ConfigProvider
    v-bind="props"
    :locale="zhCN"
    :theme="{
      token: themes[theme],
      components: {
        Table: {
          borderRadiusLG: 0,
        },
      },
    }"
  >
    <slot></slot>
  </ConfigProvider>
</template>
