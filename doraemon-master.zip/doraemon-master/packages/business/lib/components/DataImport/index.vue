<script lang="ts" setup>
import { computed, onBeforeUnmount, onMounted, reactive, ref, watch } from 'vue';
import {
  theme,
  message,
  Modal,
  Tabs,
  Spin,
  Popover,
  Button,
  UploadDragger,
  Form,
} from 'ant-design-vue';
import { InfoCircleOutlined, ExclamationCircleOutlined } from '@ant-design/icons-vue';
import { useUploadServer } from '../upload';
import TaskCenterDrawer from '../TaskCenterDrawer/index.vue';
import ResultDialog from './ResultDialog.vue';
import type { ResultType } from './ResultDialog.vue';
import useHttp from '../../hooks/useHttp';
import Verify from './Verify.vue';
import { type SelectorScopeValue } from '../Selector';
import exampleImg from './example.png';
import type { ImportMetaEnvExtra } from '../../types';
import { ChangeType } from '../../enums/TaskCenter';
import { downloadByALinkElement } from '../../utils/download';
import { getTreeItems } from '../Selector/utils';
import { first, split, map } from 'lodash-es';

// mqtt的内容加了两个参数：
// changeType：1 - 任务完成，2 - 任务超时
// seqNo：任务seq
type MessageType = {
  unReadQty: number;
  seqNo?: string;
  changeType?: ChangeType;
};

export interface DataImportProps {
  open: boolean; // 弹窗开关
  importMode?: number; // 导入模式：1、新增导入 2、更新导入
  /* 任务编码，例：
   * stu_info_import  学生信息导入
   * stu_face_import  学生人脸导入
   * person_ic_card_code_import  人员IC卡导入
   * user_info_import 人员导入
   * clazz_import 批量设置班级
   */
  taskCode: string;
  /** 项目运行环境env */
  importMetaEnv: ImportMetaEnvExtra;
  locationId: string | number;
  opUserId: string | number;
  title?: string;
  // 更新导入模式下需要更新的记录id列表
  ids?: string[];
  // 更新导入模式下业务列表接口的请求参数
  params?: Record<string, any>;
  // 更新导入模式下下载数据是否非空
  nonempty?: boolean;
  phoneNumber?: string | null;
  promptInformation?: string | null;
  envMode: string;
  // 导入扩展参数 用于导入时业务数据关联
  extParams?: Record<string, any>;
}
interface TFile extends File {
  fileId: string;
}
interface HttpConfig {
  [key: string]: any;
}

const props = defineProps<DataImportProps>();
const emit = defineEmits<{
  (event: 'close'): void;
}>();

const idLevelMap: Record<string, number> = {};

/** tab数据源 */
const tabItems = [
  { key: 1, label: '新增导入' },
  { key: 2, label: '更新导入' },
];

const faceTabs = [
  { key: 1, label: '导入' },
  { key: 2, label: '更新' },
  { key: 3, label: '删除' },
];

/** 文件类型 */
const fileTypeMap: Record<number, { type: string; accept: string[] }> = {
  1: { type: 'excel', accept: ['xls', 'xlsx'] },
  2: { type: 'zip', accept: ['zip'] },
  3: { type: 'word', accept: ['doc', 'docx'] },
};

const configLoading = ref<boolean>(false);
const configInfo = ref();
const tip = ref('导入');
const activeKey = ref<number>(1);
const fileObj = ref({} as TFile);
const fileList = ref<any[]>([]);
const loading = ref<boolean>(false);
const resultModal = ref<ResultType>();
/** 导入的任务 SeqNo, 用于判断 mqtt 消息 */
const resultTaskSeqNo = ref<string>();
const lastTaskCenterMessage = ref<MessageType>();
/** 身份校验 */
const verifyVisible = ref<boolean>(false);
// 更新导入身份认证消息记录id
const msgId = ref<string>('');
const downloadMethod = ref<string>('GET');
const taskVisible = ref<boolean>(false);
const treeData = ref<any[]>([]);
const modelForm = reactive<{ paramJson: SelectorScopeValue[] }>({
  paramJson: [],
});

const { token } = theme.useToken();
const useForm = Form.useForm;
const http = useHttp();
const { uploadFile2Server } = useUploadServer();
const { resetFields, validate, validateInfos } = useForm(modelForm, {
  paramJson: [
    {
      required: true,
      async validator(_rule: any, value: (typeof modelForm)['paramJson']) {
        if (!value || value.length === 0) {
          return Promise.reject('选择删除人脸范围');
        }
        return Promise.resolve();
      },
    },
  ],
});

const modalOpen = computed(() => props.open);

const tips = computed(() => {
  const isFace = props.taskCode === 'user_face_info_import';
  let msg = isFace ? '，录入后批量更新数据' : '，编辑完成后上传';
  if (activeKey.value > 2) {
    msg = '';
  }

  return activeKey.value === 1 ? '，录入后批量新增数据' : msg;
});

const isDeleteFace = computed(
  () => 'user_face_info_import' === props.taskCode && activeKey.value > 2,
);

/** 模版文件下载 */
const handleDownload = async (method: string, mId?: string) => {
  const locationId = props.locationId;
  const taskCode = props.taskCode;
  const {
    insertFileUrl = '',
    updateFileUrl,
    taskName,
    fileFormat,
    insertModeDoubleCheck,
  } = configInfo.value;
  const isPost = method == 'POST';
  const baseUrl = isPost && !insertModeDoubleCheck ? updateFileUrl : insertFileUrl;
  let url = baseUrl
    .replace(/^api/i, '/api')
    .replace('${locationId}', String(locationId))
    .replace('${taskCode}', taskCode);
  const options: HttpConfig = { method, headers: { token: localStorage.getItem('token') } };
  if (isPost) {
    const orgParams: Record<string, string> = { taskCode, msgId: mId || '' };
    Object.keys(orgParams).forEach((key) => {
      url = url.replace('${' + key + '}', orgParams[key]);
    });
    (options.headers as Record<string, string>)['Content-Type'] = 'application/json';
    options.body = JSON.stringify({ ids: props.ids, otherParamMap: props.params });
  }

  const fileData: Blob = isPost
    ? await http
        .post(url, { ids: props.ids, otherParamMap: props.params })
        .then((res) => res.blob())
    : await http.get(url).then((res) => res.blob());
  try {
    const downloadUrl = window.URL.createObjectURL(fileData);
    const downloadName = `${taskName}.${fileTypeMap[fileFormat]?.accept[0]}`;

    const aLink = document.createElement('a');
    aLink.href = downloadUrl;
    aLink.target = '_blank';
    aLink.download = downloadName;
    document.body.appendChild(aLink);
    aLink.click();
    document.body.removeChild(aLink);
    // }
  } catch (e) {
    message.error('文件请求失败');
  }
};

// 更新导出下载校验结果
const handleVerify = (mId: string) => {
  msgId.value = mId;
  handleDownload(downloadMethod.value, mId);
};

// 判断更新导入是否需要信息校验才能下载文件
const triggerVerify = () => {
  const { doubleCheck } = configInfo.value;
  let isPass = true;
  if (doubleCheck === 1) {
    if (props.nonempty) {
      verifyVisible.value = true;
      downloadMethod.value = 'POST';
    } else isPass = false;
  } else {
    if (props.nonempty) handleDownload('POST');
    else isPass = false;
  }
  !isPass && message.warning('没有可下载的数据');
};

// 判断新增导入是否需要信息校验才能下载文件
const triggerInsertVerify = () => {
  const { insertModeDoubleCheck } = configInfo.value;
  if (insertModeDoubleCheck === 1) {
    verifyVisible.value = true;
    downloadMethod.value = 'POST';
  } else handleDownload('GET');
};

const reUpload = () => {
  fileObj.value = { fileId: '' } as TFile;
};
const onClose = () => {
  resetFields();
  fileObj.value = { fileId: '' } as TFile;
  handleCloseResultModal();
  emit('close');
};

const handleImport = async () => {
  const { fileId, name } = fileObj.value;
  tip.value = '导入';

  if (fileId) {
    const fileExtend = name.slice(name.lastIndexOf('.') + 1);
    let { taskName } = configInfo.value;
    const taskCode = props.taskCode;

    if (taskCode === 'user_face_info_import' && activeKey.value === 2) {
      taskName = '人脸信息更新导入';
    }

    const reqBody = {
      fileExtend,
      fileId,
      fileName: name,
      importMode: activeKey.value,
      locationId: props.locationId,
      ...(msgId.value ? { msgId: msgId.value } : {}),
      opUserId: props.opUserId,
      taskCode,
      taskFullName: `${taskName}-${name}`,
      ...(props.extParams ? { otherParamMap: props.extParams } : {}),
    };
    try {
      loading.value = true;
      const data = await http.post('/api/building/task/center/v1/import', reqBody, {
        headers: {
          Accept: 'application/json',
        },
      });
      if (data) {
        msgId.value = '';
        resultModal.value = { type: 'loading' };
        resultTaskSeqNo.value = data;
        // 有可能 mqtt 消息先返回，这里做个判断
        if (data && lastTaskCenterMessage.value?.seqNo === data) {
          handleTaskComplete();
        }
      }
    } catch (e: any) {
      message.error(e?.desc || '导入失败！');
    } finally {
      loading.value = false;
    }
  } else {
    message.warning('请选择文件');
  }
};

const handleCloseResultModal = () => {
  resultModal.value = undefined;
  resultTaskSeqNo.value = undefined;
};

const reImport = () => {
  handleCloseResultModal();
  reUpload();
};

/** 错误信息文件下载 */
const handleDownloadErrorFile = async () => {
  if (!resultModal.value?.file?.url) {
    return;
  }
  try {
    await downloadByALinkElement(resultModal.value?.file?.url, resultModal.value?.file?.name);
  } catch (error: any) {
    message.error(error?.message || '下载异常');
  }
};

const uploadHook = async (file: File) => {
  // 校验文件类型
  const extension = file.name.slice(file.name.lastIndexOf('.') + 1);
  const { fileFormat, fileSize } = configInfo.value;
  const acceptList = fileTypeMap[fileFormat]?.accept || [];
  if (!acceptList.includes(extension)) {
    message.warning('文件格式不符合要求，请重新选择');
    return false;
  }
  const maxSize = fileSize || 500;
  if (file.size > maxSize * 1024 * 1024) {
    message.warning(`文件包最大限制为${maxSize}MB，请拆分后再进行导入`);
    return false;
  }
  const uploadParams: { file: File } = { file };
  loading.value = true;
  uploadFile2Server(uploadParams)
    .then((res: unknown) => {
      loading.value = false;
      const { fileId } = res as TFile;
      fileObj.value = { ...file, fileId, name: file.name };
      fileList.value = [file];
    })
    .catch(() => {
      message.error('文件服务异常！');
      loading.value = false;
    });
  return false;
};

const linkToTaskCenter = () => {
  taskVisible.value = true;
  handleCloseResultModal();
  onClose();
};

const handleOk = () => {};

const handleTaskComplete = async () => {
  if (!resultTaskSeqNo.value) {
    return;
  }
  const res = await http.get('/api/auth/taskInfos/actions/getBySeq', {
    seqNo: resultTaskSeqNo.value,
  });
  const success = res.successQty || 0;
  const failed = res.failQty || 0;
  const message = res.result;
  const type: ResultType['type'] = res.resultStatus === 1 ? 'success' : 'failed';
  let fileRes = {
    presignedUrl: '',
    fileName: '',
  };
  if (res.fileId && type === 'failed') {
    try {
      fileRes = await http.post(
        '/api/building/file/service/proxy/getGetUrl',
        `fileId=${res.fileId}`,
        {
          headers: {
            'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8',
          },
        },
      );
    } catch (e) {
      console.error(e);
    }
  }
  const result: ResultType = {
    success,
    failed,
    type,
    message,
    file: fileRes.presignedUrl
      ? {
          url: fileRes.presignedUrl,
          name: fileRes.fileName,
        }
      : undefined,
  };
  resultModal.value = result;
};

const handleDeleteSure = async () => {
  await validate();
  tip.value = '删除';
  Modal.confirm({
    content: '确定删除选中项吗?',
    okText: '确认',
    cancelText: '取消',
    centered: true,
    async onOk() {
      const reqBody = {
        locationId: props.locationId,
        opUserId: props.opUserId,
        taskCode: 'user_face_info_delete',
        taskFullName: '人脸信息删除',
        paramJson: JSON.stringify(
          map(modelForm.paramJson, (i: any) => {
            const objectId = first(split(i.value, '-'))!;
            return {
              level: idLevelMap[objectId],
              objectId,
            };
          }),
        ),
      };
      try {
        loading.value = true;
        await http.post('/api/building/task/center/v1/delete ', reqBody, {
          headers: {
            Accept: 'application/json',
          },
        });
        resultModal.value = { type: 'loading' };
      } catch (e: any) {
        message.error(e?.desc || '批量删除人脸失败！');
      } finally {
        loading.value = false;
      }
    },
  });
};

const getConfig = async () => {
  configLoading.value = true;
  try {
    const res = await http.get(`/api/auth/taskImportCfgs/v1/getCfg`, {
      locationId: props.locationId,
      taskCode: props.taskCode,
    });
    configInfo.value = res;
  } catch (err: any) {
    message.error(err?.desc || '获取配置信息失败！');
  } finally {
    configLoading.value = false;
  }
};

const messageHandle = (e: any) => {
  const data: { type: string; params: MessageType } = e.data;
  if (data?.type !== 'TaskCenterMessage') {
    return;
  }
  const params = data?.params;
  console.log('message......', data);
  if (params?.seqNo === resultTaskSeqNo.value && params?.changeType === ChangeType.Complete) {
    handleTaskComplete();
  } else {
    lastTaskCenterMessage.value = params;
  }
};

onMounted(() => {
  window.addEventListener('message', messageHandle);
});

onBeforeUnmount(() => {
  window.removeEventListener('message', messageHandle);
});

watch(isDeleteFace, (val) => {
  if (val && treeData.value.length === 0) {
    http
      .get('/api/auth/userSelect/locationPersons', { locationId: props.locationId })
      .then((data) => {
        treeData.value = getTreeItems(data, {
          getPersonItemKey(itemId: string, parentId: string) {
            if (!parentId) {
              return itemId;
            }
            const _id = `${itemId}-${parentId}`;
            return _id;
          },
        });
      });
  }
});

watch(
  () => props.open,
  () => {
    if (props.open) {
      getConfig();
    }
  },
);

watch(activeKey, () => {
  resetFields();
  fileObj.value = { fileId: '' } as TFile;
});

watch(
  () => [props.importMode, props.open],
  () => {
    if (props.open) {
      activeKey.value = props.importMode || tabItems[0].key;
    }
  },
);
</script>

<template>
  <Modal destroyOnClose centered v-model:open="modalOpen" @cancel="onClose" @ok="handleOk">
    <template #title>
      <div>
        <Tabs v-if="taskCode === 'user_face_info_import'" v-model:activeKey="activeKey">
          <Tabs.TabPane
            v-for="item in faceTabs"
            :key="item.key"
            :tab="[item.label, title].join('')"
          />
        </Tabs>
        <span v-else-if="importMode">{{ title || '导入' }}</span>
        <Tabs v-else v-model:activeKey="activeKey">
          <Tabs.TabPane v-for="item in tabItems" :key="item.key" :tab="item.label" />
        </Tabs>
      </div>
    </template>
    <Spin :spinning="configLoading">
      <template v-if="isDeleteFace">
        <a-form :label-col="{ span: 8 }" :wrapper-col="{ span: 16 }" autocomplete="off">
          <a-form-item
            label="删除人脸范围"
            v-bind="validateInfos.paramJson"
            style="margin-right: 36px"
          >
            <a-tree-select
              :maxTagCount="1"
              style="width: 100%"
              :tree-data="treeData"
              tree-checkable
              treeCheckStrictly
              tree-default-expand-all
              allow-clear
              show-checked-strategy="SHOW_ALL"
              placeholder="请选择部门/人员"
              tree-node-filter-prop="name"
              :height="400"
              virtual
              v-model:value="modelForm.paramJson"
              @select="
                (__v: any, _v: any) => {
                  idLevelMap[_v.id] = _v.level;
                }
              "
              :fieldNames="{
                label: 'name',
                value: 'key',
                children: 'children',
              }"
            />
          </a-form-item>
        </a-form>
      </template>
      <template v-else>
        <header class="import-title">
          <div v-if="tips">
            <span>你可以</span>
            <span v-if="configInfo?.fileFormat === 2">上传压缩包</span>
            <template v-else>
              <a
                v-if="activeKey === 1"
                :style="{ color: token.colorPrimary }"
                @click="triggerInsertVerify"
              >
                下载空表格模板
              </a>
              <a v-else :style="{ color: token.colorPrimary }" @click="triggerVerify"
                >下载已有数据</a
              >
            </template>
            <span> {{ tips }} </span>
            <Popover v-if="configInfo?.fileFormat === 2" placement="right" :title="null">
              <template #content>
                <div class="import-popup" v-if="activeKey === 2">
                  <p>更新人脸规则：</p>
                  <p>1.仅支持已存在的部门人员的人脸照片更新;</p>
                  <p>2.若导入的人员不存在于部门中，则更新无效;</p>
                  <p>3.不支持删除人脸，删除人脸请使用删除人脸功能。</p>
                </div>
                <div class="import-popup" v-else>
                  <p>照片规则：</p>
                  <p>1.请上传ZIP压缩包，照片仅支持.jpg格式的图片;</p>
                  <p>2.{{ configInfo?.guideDesc || 'zip包每张人员照片命名规则为：手机号/账号' }}</p>
                  <img :src="exampleImg" />
                </div>
              </template>
              <InfoCircleOutlined class="tips-icon" />
            </Popover>
          </div>
          <div v-if="promptInformation" class="tip-box">
            <ExclamationCircleOutlined style="margin-right: 5px; color: coral" />
            {{ promptInformation }}
          </div>
        </header>
        <Spin :spinning="loading">
          <main class="import-body">
            <div v-if="fileObj?.fileId" class="upload-area">
              <i
                :class="[
                  'icon-ym',
                  'file-icon',
                  fileObj.fileId ? 'file-icon-hl' : '',
                  `icon-ym-file-${fileTypeMap[configInfo?.fileFormat]?.type}`,
                ]"
              ></i>
              <div class="file-name">{{ fileObj.name }}</div>
              <div class="desc">
                <a :style="{ color: token.colorPrimary }" @click="reUpload">重新上传</a>
              </div>
            </div>
            <UploadDragger
              v-else
              action=""
              :multiple="true"
              :maxCount="1"
              v-model:fileList="fileList"
              :before-upload="uploadHook"
              :itemRender="() => null"
            >
              <div className="upload-area">
                <i
                  :class="[
                    'icon-ym',
                    'file-icon',
                    fileObj.fileId ? 'file-icon-hl' : '',
                    `icon-ym-file-${fileTypeMap[configInfo?.fileFormat]?.type}`,
                  ]"
                ></i>
                <div class="file-tip">{{ configInfo?.guideDesc }}</div>
                <div class="desc">
                  <span>将文件拖拽到此或</span>
                  <a :style="{ color: token.colorPrimary }">点击上传</a>
                </div>
              </div>
            </UploadDragger>
          </main>
        </Spin>
      </template>
    </Spin>
    <template #footer>
      <div class="modal-footer right" v-if="isDeleteFace">
        <Button @click="onClose"> 取消 </Button>
        <Button type="primary" @click="handleDeleteSure" :loading="loading" :disabled="loading">
          确定
        </Button>
      </div>
      <div class="modal-footer" v-else>
        <Button type="primary" @click="handleImport"> 导入 </Button>
      </div>
    </template>
  </Modal>

  <ResultDialog
    :result="resultModal"
    :tip="tip"
    :onLinkTaskCenter="linkToTaskCenter"
    @cancel="handleCloseResultModal"
    @close="onClose"
    @download-error-file="handleDownloadErrorFile"
    @re-import="reImport"
  />

  <Verify
    title="导出已有数据"
    :open="verifyVisible"
    :taskCode="taskCode"
    :phoneNumber="phoneNumber"
    @ok="handleVerify"
    @close="verifyVisible = false"
    :envMode="envMode"
  />

  <TaskCenterDrawer
    :open="taskVisible"
    @close="taskVisible = false"
    :import-meta-env="importMetaEnv"
  />
</template>

<style lang="scss" scoped>
.import-tabs-wrap {
  position: relative;
  left: -8px;
  display: flex;
  flex: 1 1 0;
  align-items: center;
  :deep(div[class$='-tabs-nav']) {
    margin: 0;
    &::before {
      display: none;
    }
  }
}
.import-title {
  padding-bottom: 20px;
  text-align: center;
  span {
    font-size: 14px;
    color: #1d2129;
    vertical-align: middle;
  }
  a {
    margin-left: 4px;
    font-size: 14px;
    vertical-align: middle;
  }
  .tips-icon {
    margin-left: 4px;
    font-size: 12px;
    color: #86909c;
    vertical-align: middle;
  }
  .tip-box {
    display: flex;
    justify-content: center;
    align-items: center;
    font-size: 12px;
    color: #86909c;
  }
}
.import-body {
  text-align: center;
  background-color: #f2f3f5;
  border-radius: 4px;
  .upload-area {
    padding: 0 0 10px;
  }
  :deep(div[class$='-upload-drag']) {
    background-color: #f2f3f5;
    border: none;
    border-radius: 4px;
    :deep(div[class$='-upload-btn']) {
      padding: 0;
    }
  }
  .file-icon {
    font-size: 68px;
    color: #c9cdd4;
  }
  .file-icon-hl {
    color: #1d2129;
  }
  p {
    margin: 12px 0;
    font-size: 12px;
    color: #86909c;
  }
  .file-name {
    margin-bottom: 10px;
    color: #1d2129;
  }
  .file-tip {
    margin-bottom: 10px;
    font-size: 12px;
    color: #86909c;
  }
  .desc {
    font-size: 12px;
    a {
      margin-left: 4px;
    }
  }
}
.import-popup {
  p {
    margin: 0;
    font-size: 14px;
    color: #4e5969;
  }
  img {
    width: 234px;
    height: auto;
    margin-top: 8px;
  }
}
.modal-footer {
  padding: 16px 24px;
  text-align: center;

  &.right {
    text-align: right;
  }
}
</style>
