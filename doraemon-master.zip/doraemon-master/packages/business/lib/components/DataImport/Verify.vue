<script lang="ts" setup>
import { ref, computed, reactive } from 'vue';
import { theme, message, Modal, Form, Input } from 'ant-design-vue';
import { MailOutlined } from '@ant-design/icons-vue';
import useHttp from '../../hooks/useHttp';
import useCountDown from '../../hooks/useCountDown';

const props = defineProps<{
  exporting?: boolean;
  open: boolean;
  phoneNumber?: string | null;
  taskCode: string;
  title?: string;
  envMode: string;
}>();
const emit = defineEmits<{
  (event: 'close'): void;
  (event: 'ok', val: string): void;
}>();

const { token } = theme.useToken();
const http = useHttp();
const loading = ref<boolean>(false);
const modalOpen = computed(() => {
  return props.open;
});

const { time, handleStart, handleEnd } = useCountDown(59);
const formState = reactive({
  userAccount: props.phoneNumber as string,
  verificationCode: '',
});

const rulesRef = reactive({
  verificationCode: [{ required: true, message: '请输入验证码' }],
});

const onSendCode = async () => {
  const params = {
    debugSwitchStatus: props.envMode === 'prod' ? 0 : 1, // 调试模式 0否 1是
    userAccount: props.phoneNumber,
    verifyBusinessType: props.taskCode,
    verifyCodeType: 1, // 验证码类型:1短信，2邮件
  };
  try {
    const res: any = await http.post(
      '/api/building/userauth/verifyCode',
      { ...params },
      {
        headers: {
          Accept: 'application/json',
        },
      },
    );
    formState.verificationCode = res;
    handleStart();
  } catch (error: any) {
    message.error(error?.desc || '获取验证码失败');
  } finally {
    loading.value = false;
  }
};

const handleCheck = async () => {
  const params = {
    userAccount: formState.userAccount,
    verificationCode: formState.verificationCode,
    verifyBusinessType: props.taskCode,
    verifyCodeType: 1,
  };
  loading.value = true;
  try {
    const res: any = await http.post(
      '/api/building/userauth/verify',
      { ...params },
      {
        headers: {
          Accept: 'application/json',
        },
      },
    );
    handleEnd();
    formState.verificationCode = '';
    emit('ok', res);
    emit('close');
  } catch (error: any) {
    message.error(error?.desc || '验证码校验失败！');
  } finally {
    loading.value = false;
  }
};
</script>

<template>
  <Modal
    destroyOnClose
    :title="title || '弹窗面板'"
    centered
    v-model:open="modalOpen"
    @cancel="emit('close')"
    okText="导出"
    :okButtonProps="{ loading: loading || exporting }"
    @ok="handleCheck"
    cancelText="取消"
  >
    <Form
      style="margin-top: 20px"
      name="loginPhoneForm"
      ref="formRef"
      :model="formState"
      autocomplete="off"
      :rules="rulesRef"
      layout="vertical"
    >
      <Form.Item name="userAccount" label="手机号" :rules="[{ required: true }]">
        <Input class="login-input" v-model:value="formState.userAccount" disabled />
      </Form.Item>
      <Form.Item name="verificationCode" label="验证码（确认管理员身份）">
        <Input
          class="login-input"
          v-model:value="formState.verificationCode"
          :maxlength="6"
          placeholder="请输入验证码"
        >
          <template #prefix>
            <MailOutlined class="login-input-icon" />
          </template>
          <template #suffix>
            <a
              class="send-code-button"
              :style="{ color: token.colorPrimary }"
              v-if="!time"
              @click="onSendCode"
              >获取验证码</a
            >
            <span class="send-code-time" v-else>{{ time }}s</span>
          </template>
        </Input>
      </Form.Item>
    </Form>
  </Modal>
</template>
