<script lang="ts" setup>
import {
  Loading3QuartersOutlined,
  CheckCircleFilled,
  CloseCircleFilled,
} from '@ant-design/icons-vue';
import { Modal, Button, theme } from 'ant-design-vue';

export type ResultType = {
  type: 'loading' | 'success' | 'failed';
  success?: number;
  failed?: number;
  file?: any;
  message?: string;
};

export interface TaskDialogProps {
  tip: string;
  result?: ResultType;
  onLinkTaskCenter?: () => void;
}

withDefaults(defineProps<TaskDialogProps>(), {
  onLinkTaskCenter: () => {},
});

defineEmits<{
  (e: 'cancel'): void;
  (e: 'downloadErrorFile'): void;
  (e: 'close'): void;
  (e: 'reImport'): void;
}>();

const { token } = theme.useToken();
</script>

<template>
  <Modal
    :width="480"
    :z-index="1001"
    :open="!!result"
    @cancel="$emit('cancel')"
    destroyOnClose
    centered
    :closable="false"
  >
    <template #title>
      <div>
        <Loading3QuartersOutlined
          v-if="result?.type === 'loading'"
          :style="{ color: token.colorPrimary }"
          spin
          class="loading-icon"
        />
        <CheckCircleFilled
          v-else-if="result?.type === 'success'"
          :style="{ color: token.colorSuccess }"
          class="loading-icon"
        />
        <CloseCircleFilled
          v-else-if="result?.type === 'failed'"
          :style="{ color: token.colorError }"
          class="loading-icon"
        />
        <span v-if="result?.type === 'loading'" class="loading-title">{{ tip }}中</span>
        <span v-else-if="result?.type === 'success'" class="loading-title">{{ tip }}成功</span>
        <span v-else-if="result?.type === 'failed'" class="loading-title">{{ tip }}失败</span>
      </div>
    </template>
    <div v-if="result?.type === 'loading'" class="loading-content">
      正在{{ tip }}中，可前往
      <a :style="{ color: token.colorPrimary }" @click="onLinkTaskCenter"> 任务中心 </a>
      查看结果
    </div>
    <div v-if="result?.type === 'success'" class="loading-content">
      已成功导入 {{ result.success }} 条数据
    </div>
    <template v-if="result?.type === 'failed'">
      <div
        v-if="result.success === 0 && result.failed === 0 && result.message"
        class="loading-content"
      >
        {{ result.message }}
      </div>
      <div v-else class="loading-content">
        成功导入 {{ result.success }} 条， 失败 {{ result.failed }} 条
      </div>
    </template>
    <template #footer>
      <div style="margin-top: 20px">
        <Button v-if="result?.file" type="link" @click="$emit('downloadErrorFile')"
          >下载错误信息</Button
        >
        <Button @click="$emit('close')">关闭</Button>
        <Button v-if="result?.type === 'failed'" type="primary" @click="$emit('reImport')"
          >重新导入</Button
        >
      </div>
    </template>
  </Modal>
</template>

<style lang="scss" scoped>
.loading-icon {
  color: v-bind('token.colorPrimary');
}
.loading-title {
  margin-left: 16px;
  font-weight: 600;
}
.loading-content {
  color: #4e5969;
  margin-top: 20px;
}
</style>
