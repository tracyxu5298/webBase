<script setup lang="ts">
import { withDefaults } from 'vue';
import { Empty, Spin } from 'ant-design-vue';
import { useWidgetConfig } from '../../hooks';

interface Props {
  isEmpty?: boolean;
  loading?: boolean;
}

withDefaults(defineProps<Props>(), {
  isEmpty: false,
  loading: false,
});

const simpleImage = Empty.PRESENTED_IMAGE_SIMPLE;
const { title } = useWidgetConfig();
</script>

<template>
  <div class="workbench-card">
    <div class="header">
      <div class="title">
        <slot name="title">
          <span>{{ title }}</span>
        </slot>
      </div>
      <div>
        <slot name="button"></slot>
      </div>
    </div>
    <div class="body">
      <Spin class="body-center" v-if="loading" />
      <template v-else>
        <div class="body-center" v-if="isEmpty">
          <Empty description="暂无数据" :image="simpleImage" />
        </div>
        <slot name="body" v-else></slot>
      </template>
    </div>
  </div>
</template>

<style scoped lang="scss">
.workbench-card {
  width: 100%;
  height: 100%;
  border-radius: 10px;
  display: flex;
  flex-direction: column;
  background: linear-gradient(180deg, rgba(255, 255, 255, 0.8) 0%, rgba(255, 255, 255, 0.4) 100%);
  backdrop-filter: blur(20px);
  -webkit-backdrop-filter: blur(20px);
  box-shadow:
    0px 1px 2px 0px #0000000a,
    inset 0px 0 0px 1px rgb(255 255 255 / 20%);
  .header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    width: 100%;
    height: 56px;
    min-height: 56px;
    padding: 0 20px;
    .title {
      font-weight: 600;
      font-size: 16px;
    }
  }
  .body {
    flex: 1;
    overflow: hidden;
    .body-center {
      display: flex;
      justify-content: center;
      align-items: center;
      height: 100%;
    }
  }
}
</style>
