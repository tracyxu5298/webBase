<script setup lang="ts">
import { useRoute } from 'vue-router';

const route = useRoute();
</script>

<template>
  <h1>当前路径不存在 {{ route.fullPath }}</h1>
  <!-- /a/b?id=123#one -->
  <!-- <pre>{{ route }}</pre> -->
</template>
