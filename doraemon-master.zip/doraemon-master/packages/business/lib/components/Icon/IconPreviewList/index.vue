<script lang="ts" setup>
import { message, Tabs, Row, Col } from 'ant-design-vue';
import { ref, unref } from 'vue';
import { ymIconJson } from '../data/ymIcon';
import { ymCustomJson } from '../data/ymCustom';

import { useCopyToClipboard } from './useCopyToClipboard';

const ymIconList = ymIconJson.glyphs.map((o) => `icon-ym-${o.font_class}`);
const ymCustomList = ymCustomJson.glyphs.map((o) => `ym-custom-${o.font_class}`);

const activeKey = ref('1');

function handleCopy(item: string) {
  const { isSuccessRef } = useCopyToClipboard(item);
  unref(isSuccessRef) && message.success('复制成功');
}
</script>

<template>
  <Tabs v-model:activeKey="activeKey" class="demo-icons">
    <Tabs.TabPane key="1" tab="ymIcon图标">
      <Row>
        <Col
          :span="6"
          v-for="item in ymIconList"
          :key="item"
          @click="handleCopy('icon-ym ' + item)"
          :title="item"
          class="icon-item"
        >
          <i :class="'icon-ym ' + item" />
          <span>{{ item }}</span>
        </Col>
      </Row>
    </Tabs.TabPane>
    <Tabs.TabPane key="2" tab="ymCustom图标" force-render
      ><Row>
        <Col
          :span="6"
          v-for="item in ymCustomList"
          :key="item"
          @click="handleCopy('ym-custom ' + item)"
          :title="item"
          class="icon-item"
        >
          <i :class="'ym-custom ' + item" />
          <span>{{ item }}</span>
        </Col>
      </Row></Tabs.TabPane
    >
  </Tabs>
</template>
<style scoped lang="scss">
.demo-icons {
  width: 100%;
  height: 100%;
  :deep(.ant-tabs-content) {
    height: 100%;
  }
  :deep(.ant-tabs-tabpane) {
    overflow: auto;
    height: 100%;
  }
  .icon-item {
    display: flex;
    align-items: center;
    overflow: hidden;
    height: 40px;
    padding: 0 10px;
    text-overflow: ellipsis;
    white-space: nowrap;
    color: #6b7a99;
    border: 1px dashed transparent;
    cursor: pointer;
    i {
      margin-right: 14px;
      font-size: 16px;
      line-height: 40px;
      vertical-align: top;
    }
    &:hover {
      border-color: #1890ff;
      i {
        font-size: 30px;
      }
    }
  }
}
</style>
../data/ymCustom.ts../data/ymIcon.ts
