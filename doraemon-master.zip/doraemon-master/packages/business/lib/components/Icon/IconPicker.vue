<script lang="ts" setup>
import { Form, Modal as AModal, theme, Input, Button, Tabs, InputSearch } from 'ant-design-vue';
import type { CSSProperties } from 'vue';
import { reactive, ref, watch, toRefs } from 'vue';
import { cloneDeep } from 'lodash-es';
import { ymIconJson } from './data/ymIcon';
import { ymCustomJson } from './data/ymCustom';

defineOptions({ name: 'JnpfIconPicker', inheritAttrs: false });

const props = defineProps({
  value: String,
  placeholder: { type: String, default: '请选择' },
  disabled: { type: Boolean, default: false },
});

const emit = defineEmits(['update:value', 'change']);

interface IState {
  keyword: string;
  activeKey: string;
  ymIcon: string[];
  ymCustom: string[];
  ymIconList: string[];
  ymCustomList: string[];
}

const { token } = theme.useToken();

const ymIcon = ymIconJson.glyphs.map((o) => `icon-ym icon-ym-${o.font_class}`);
const ymCustom = ymCustomJson.glyphs.map((o) => `ym-custom ym-custom-${o.font_class}`);

const formItemContext = Form.useInjectFormItemContext();
const innerValue = ref('');
const active = ref('');
const visible = ref(false);
const state: IState = reactive({
  keyword: '',
  activeKey: '',
  ymIcon,
  ymCustom,
  ymIconList: [],
  ymCustomList: [],
});

const { keyword, activeKey, ymIconList, ymCustomList } = toRefs(state);

watch(
  () => props.value,
  (val: any) => {
    innerValue.value = val;
  },
  { immediate: true },
);

// 切换tab：清空搜索栏，渲染列表
watch(
  () => state.activeKey,
  (val) => {
    if (!val) return;
    state.keyword = '';
    handleSearch();
  },
);
watch(
  () => visible.value,
  (val) => {
    if (!val) state.activeKey = '';
  },
);

function openSelectModal() {
  if (props.disabled) return;
  visible.value = true;
  active.value = innerValue.value;
  state.activeKey = '1';
}
function handleCancel() {
  visible.value = false;
}
function handleSubmit() {
  innerValue.value = active.value;
  emit('update:value', innerValue.value);
  emit('change', innerValue.value);
  formItemContext.onFieldChange();
  handleCancel();
}
function handleClear() {
  active.value = '';
}
function handleIconClick(item: any) {
  active.value = item;
}
function handleSearch() {
  const key = state.activeKey === '1' ? 'ymIcon' : 'ymCustom';
  const keyList = state.activeKey === '1' ? 'ymIconList' : 'ymCustomList';
  if (state.keyword) {
    state[keyList] = state[key].filter((o) => o.indexOf(state.keyword) > -1);
  } else {
    state[keyList] = cloneDeep(state[key]);
  }
}
const isActiveStyle: CSSProperties = {
  color: token.value.colorPrimary,
  borderColor: token.value.colorPrimary,
};
</script>

<template>
  <div class="icon-picker" :class="[$attrs.class]">
    <Input v-model:value="innerValue" :placeholder="placeholder" readonly allowClear>
      <template #addonAfter>
        <span @click="openSelectModal">选择</span>
      </template>
      <template #suffix v-if="innerValue">
        <i :class="innerValue"></i>
      </template>
    </Input>
    <AModal
      v-model:visible="visible"
      :width="1000"
      class="icon-picker-modal"
      centered
      :maskClosable="false"
      :keyboard="false"
    >
      <template #title>
        <div class="icon-picker-modal-title">
          图标选择
          <InputSearch
            placeholder="请输入图标名称"
            allowClear
            v-model:value="keyword"
            @search="handleSearch"
            class="icon-picker-modal-title-input"
          />
        </div>
      </template>
      <template #closeIcon>
        <!-- <ModalClose :canFullscreen="false" @cancel="handleCancel" /> -->
      </template>
      <template #footer>
        <Button danger @click="handleClear()">清空</Button>
        <Button @click="handleCancel()">取消</Button>
        <Button type="primary" @click="handleSubmit()">确定</Button>
      </template>
      <div class="icon-picker-main">
        <Tabs v-model:activeKey="activeKey">
          <Tabs.TabPane key="1" tab="ymIcon图标">
            <div class="scroll-wrap">
              <div class="icon-box-list">
                <Button
                  v-for="(item, index) in ymIconList"
                  :key="index"
                  @click="handleIconClick(item)"
                  class="icon-item"
                  :style="item === active ? isActiveStyle : {}"
                >
                  <i :class="item" />
                </Button>
              </div>
            </div>
          </Tabs.TabPane>
          <Tabs.TabPane key="2" tab="ymCustom图标">
            <div class="scroll-wrap">
              <div class="icon-box-list">
                <Button
                  v-for="(item, index) in ymCustomList"
                  :key="index"
                  @click="handleIconClick(item)"
                  class="icon-item"
                  :style="item === active ? isActiveStyle : {}"
                >
                  <i :class="item" />
                </Button>
              </div>
            </div>
          </Tabs.TabPane>
        </Tabs>
      </div>
    </AModal>
  </div>
</template>
<style lang="scss" scoped>
.icon-picker {
  width: 100%;

  :deep(.ant-input-group-addon) {
    cursor: pointer;
    padding: 0;
    span {
      display: inline-block;
      line-height: 30px;
      padding: 0 11px;
    }
  }
  :deep(.ant-input-suffix) {
    i {
      line-height: 20px;
      color: #909399;
    }
  }
}
.icon-picker-modal-title {
  display: flex;
  align-items: center;
  font-weight: 400;
  font-size: 18px;
  &-input {
    width: 300px;
    margin-left: 10px;
  }
}
.icon-picker-main {
  overflow: hidden;
  .scroll-wrap {
    overflow: auto;
    width: 100%;
    height: 60vh;
    .icon-item {
      width: 60px;
      height: 60px;
      padding: 0;
      margin: 8px 0 0 8px;
      text-align: center;
      transition: transform 0.3s;
      line-height: 60px;
      &:hover i {
        transform: scale(1.8);
      }
      i {
        display: inline-block;
        font-size: 24px;
        transition: 0.3s;
      }
    }
  }
}
</style>
