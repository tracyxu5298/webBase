<script lang="ts" setup>
import { computed, inject } from 'vue';
import { theme, Layout, TypographyText } from 'ant-design-vue';
import type { CustomConfig } from './useCustomConfig';
import defaultLogo from './assets/logo_128.png';
import defaultBg from './assets/login_bg_2x.jpg';
import defaultXQBg from './assets/xqbg.jpg';

defineProps<{
  loading: boolean;
  config: CustomConfig;
}>();

const { appVersion } = inject('loginProps') || ({} as any);

const { token } = theme.useToken();

const defaultBgImage = computed(() =>
  window.location.host.includes('xq.') ? defaultXQBg : defaultBg,
);
</script>

<template>
  <Layout class="login-layout-root">
    <Layout
      :class="{ 'login-layout': true, 'login-layout-bg': true, loading: loading }"
      :style="{
        backgroundImage: loading ? '' : `url(${config.loginPicture || defaultBgImage})`,
        backgroundColor: token.colorBgLayout,
      }"
    >
      <Layout.Header class="login-layout-header" :style="{ backgroundColor: 'transparent' }">
        <div class="login-header-logo-skeleton" v-if="loading"></div>
        <div class="login-header-logo" v-else>
          <div class="login-header-logo-img">
            <img :src="config.loginLogoUrl || defaultLogo" alt="" />
          </div>
          <TypographyText class="name">
            {{ config.loginTitle || '星磐·数字基座' }}
          </TypographyText>
        </div>
      </Layout.Header>
      <Layout.Content class="login-layout-wrap">
        <div class="login-layout-slogan-wrap">
          <!-- <div class="login-layout-slogan-skeleton" v-if="loading"></div>
          <TypographyParagraph class="login-layout-slogan" v-else>
            {{ config.loginContent || '立己达人，信以致远' }}
          </TypographyParagraph> -->
        </div>
        <div class="login-layout-content">
          <slot></slot>
        </div>
      </Layout.Content>
      <Layout.Footer class="login-layout-footer">
        <div v-if="loading" class="login-layout-footer-skeleton" />
        <template v-else>
          <span v-if="config.locationName">主办：{{ config.locationName }}</span>
          <span v-else
            >Copyright©{{ new Date().getFullYear() }} leedarson.com. All rights reserved</span
          >
          <span>技术支持：厦门立达信数字教育科技有限公司</span>
          <span>{{ appVersion ? `版本号：${appVersion}` : '' }}</span>
        </template>
      </Layout.Footer>
    </Layout>
  </Layout>
</template>
<style lang="scss" scoped>
.login-header-logo {
  display: flex;
  align-items: center;
  height: 40px;
  gap: 8px;
  .name {
    font-size: 24px;
    font-weight: 400;
    letter-spacing: 1px;
  }
  .login-header-logo-img {
    min-width: 40px;
    height: 40px;
    img {
      float: left;
      height: 100%;
    }
  }
}

.login-header-logo-skeleton {
  width: 120px;
  height: 32px;
  background-color: #eeeff4;
  border-radius: 8px;
}
.login-layout {
  min-width: 1280px;
  &-root {
    overflow: auto;
    min-height: 100%;
  }
}
.login-layout-header {
  display: flex;
  height: 64px;
  line-height: 32px;
  padding: 16px 48px;
  // box-shadow:
  //   0px 9px 28px 8px rgba(0, 0, 0, 0.04),
  //   0px 3px 6px -4px rgba(0, 0, 0, 0.08),
  //   0px 6px 16px 0px rgba(0, 0, 0, 0.04);
}
.login-layout-footer {
  padding: 12px 0;
  font-size: 12px;
  text-align: center;
  color: #8c8c8c;
  background: transparent;
  line-height: 20px;
  &-skeleton {
    width: 660px;
    height: 12px;
    margin: 4px auto;
    background-color: #eeeff4;
  }
  span {
    padding: 0 12px;
  }
}

.login-layout-bg {
  background-position: left center;
  background-repeat: no-repeat;
  background-size: cover;
}

.login-layout-wrap {
  display: flex;
  justify-content: center;
  padding: 48px;
}

.login-layout-content {
  display: flex;
  align-items: center;
}

.login-layout-slogan-wrap {
  width: 910px;
  // margin: 8% 40px 0 0;
}

// @media (height <= 720px) {
//   .login-layout-slogan-wrap {
//     margin-top: 4%;
//   }
// }

// .login-layout-slogan {
//   font-size: 30px;
//   font-weight: 600;
//   line-height: 58px;
// }

// .login-layout-slogan-skeleton {
//   width: 270px;
//   height: 58px;
//   background-color: #fff;
//   border-radius: 8px;
// }
</style>
