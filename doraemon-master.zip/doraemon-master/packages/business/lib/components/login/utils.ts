import type { Rule } from 'ant-design-vue/es/form';
import { regExpPassword } from '../../utils';

export const validatePassword = async (_rule: Rule, value: string) => {
  if (!value) {
    return Promise.reject('请输入密码');
  }

  if (value.length > 20 || value.length < 8) {
    return Promise.reject('请设置8-20位字母/数字/特殊符号至少3种组合');
  }

  if (!value.match(regExpPassword)) {
    return Promise.reject('您设置的密码安全等级较低，请重新输入');
  }

  return Promise.resolve();
};
