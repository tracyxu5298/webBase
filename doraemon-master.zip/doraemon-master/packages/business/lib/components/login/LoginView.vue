<script lang="ts" setup>
import { Spin, Tabs } from 'ant-design-vue';
import { ref, unref, provide, reactive, computed } from 'vue';
import { useRoute } from 'vue-router';
import useLocations from '../locations/useLocations';
import type { LocationByUserType, LocationItem } from '../../hooks';
import { TypeEnum, StepEnum } from './constants';
import LoginLayout from './LoginLayout.vue';
import LoginAccountForm from './LoginAccountForm.vue';
import LoginPhoneForm from './LoginPhoneForm.vue';
import LoginLocationSelect from './LoginLocationSelect.vue';
import LoginResetPassword from './LoginResetPassword.vue';
import LoginScanMeta from './LoginScanMeta.vue';
import useCustomConfig from './useCustomConfig';
import { useErrorTimes } from './useLogin';
import type { ResetPasswordProps } from './type';
import loginScan from './assets/login-scan.png';
import loginAccount from './assets/login-account.png';
import useConfigStore from '../../stores/useConfigStore';

// 定义 route 时传入的变量
const props = defineProps<{
  agreementDomain?: string;
  envMode?: string;
  appVersion?: string;
  hideLayout?: boolean;
  defaultTab?: TypeEnum;
  showThirdLogin?: boolean;
}>();

const emit = defineEmits<{
  (event: 'afterLogin', data: LocationItem): void;
  (event: 'forgetPassword', data: { tab: TypeEnum }): void;
}>();

const route = useRoute();

provide('loginProps', props);

const errorTimesState = useErrorTimes();

const { customConfig, loadingCustomConfig } = useCustomConfig({ hideLayout: props.hideLayout });

const step = ref<StepEnum>(StepEnum.LOGIN);
const spinning = ref(false);
/** 绑定手机号需要 account */
const accountInfo = reactive<{
  account?: string;
  password?: string;
  phoneNumber?: string;
}>({});
const _propsTab = props.hideLayout ? props.defaultTab : route.query.mode || props.defaultTab;
const tab = ref((_propsTab as TypeEnum) || TypeEnum.ACCOUNT);
const locations = ref<LocationByUserType[] | null>(null);

const configStore = useConfigStore();
const disableScan = computed(() => unref(configStore.data)?.disableScan);
const disableSMS = computed(() => unref(configStore.data)?.disableSMS);

const { onSelected } = useLocations();

const onLogin = (data: LocationItem, homePageAddress?: string) => {
  emit('afterLogin', data);

  if (props.hideLayout) {
    return;
  }

  if (route.query.from && route.query.from !== '/') {
    window.location.replace(decodeURIComponent(route.query.from as string));
    return;
  }

  if (homePageAddress) {
    // 有需要跳转直接使用 location.href, 否则可能会出现全屏未生效的问题
    window.location.replace(homePageAddress);
  } else {
    // 旧版本应用会取内存里面的 token，用户手动输入login登录不刷新的话，可能出现 token 还是旧的情况
    // router.push({ path: '/', replace: true });
    window.location.replace('/');
  }
};

const onForgetPassword = () => {
  emit('forgetPassword', { tab: tab.value });
};

const onNextStep = (value: StepEnum) => {
  step.value = value;
};

const onResetPassword = (data: ResetPasswordProps) => {
  accountInfo.password = data.password || '';
  accountInfo.account = data.account || '';
  accountInfo.phoneNumber = data.phoneNumber || '';
  if (data.isBindMobile && data.isDefaultPwd) {
    onNextStep(StepEnum.RESET_PASSWORD_BIND_PHONE);
    return;
  }
  if (data.isBindMobile) {
    onNextStep(StepEnum.BIND_PHONE);
    return;
  }
  onNextStep(StepEnum.RESET_PASSWORD);
};

const onLoading = (value: boolean) => {
  spinning.value = value;
};

const _onSelectedCallback = (selectedLocation?: LocationItem, homePageAddress?: string) => {
  // 如果没有选中的组织，则说明当前选择的是学生家长
  // 1030 无法登录除教职工以外的身份。
  // 只弹窗提示后，停留当前页面无需下一步处理
  if (selectedLocation) {
    onLogin(selectedLocation, homePageAddress);
  } else {
    spinning.value = false;
  }
};

const onLoginFormSuccess = (data?: LocationByUserType[]) => {
  const _locations = data || [];

  if (_locations.length) {
    locations.value = _locations;
  }

  if (
    _locations.length === 1 &&
    _locations[0].locations?.length === 1 &&
    !_locations[0].locations[0].children?.length
  ) {
    const _location = _locations[0];
    onSelected(_location.locations[0], _location.userType, _onSelectedCallback);
  } else {
    onNextStep(StepEnum.LOCATION);
    spinning.value = false;
  }
};

const onChangeLoginType = () => {
  step.value = step.value === StepEnum.SCAN ? StepEnum.LOGIN : StepEnum.SCAN;
};
</script>

<template>
  <component
    :is="hideLayout ? 'div' : LoginLayout"
    :loading="loadingCustomConfig"
    :config="customConfig"
  >
    <div :class="['login-wrap', hideLayout ? 'login-wrap-hide-layout' : '']">
      <Spin :spinning="spinning">
        <div
          v-if="!disableScan && [StepEnum.LOGIN, StepEnum.SCAN].includes(step)"
          class="login-scan"
          @click="onChangeLoginType"
        >
          <img v-if="step === StepEnum.SCAN" :src="loginAccount" />
          <img v-else :src="loginScan" />
          <span>{{ step === StepEnum.SCAN ? '账号登录' : '扫码登录' }}</span>
        </div>
        <div class="login-content" :style="{ minHeight: showThirdLogin ? '512px' : '430px' }">
          <LoginLocationSelect
            v-if="step === StepEnum.LOCATION"
            :locations="locations"
            @back="onNextStep(StepEnum.LOGIN)"
            @loading="onLoading"
            @afterChanged="onLogin"
          />
          <LoginScanMeta
            v-else-if="step === StepEnum.SCAN"
            @success="onLoginFormSuccess"
            @resetPassword="onResetPassword"
            @forgetPassword="onForgetPassword"
          />
          <LoginResetPassword
            v-else-if="
              [
                StepEnum.RESET_PASSWORD,
                StepEnum.RESET_PASSWORD_BIND_PHONE,
                StepEnum.BIND_PHONE,
              ].includes(step)
            "
            :step="step"
            :password="accountInfo.password"
            :account="accountInfo.account"
            :phoneNumber="accountInfo.phoneNumber"
            @back="onNextStep(StepEnum.LOGIN)"
            @loading="onLoading"
            @success="onLoginFormSuccess"
          />
          <div v-else class="login-form">
            <Tabs class="login-form-tab" v-model:activeKey="tab" centered :tabBarGutter="24">
              <Tabs.TabPane :key="TypeEnum.ACCOUNT" tab="账号登录">
                <LoginAccountForm
                  :openRegister="customConfig.openRegister"
                  :errorTimesState="errorTimesState"
                  @loading="onLoading"
                  @success="onLoginFormSuccess"
                  @resetPassword="onResetPassword"
                  @forgetPassword="onForgetPassword"
                />
              </Tabs.TabPane>
              <Tabs.TabPane v-if="!disableSMS" :key="TypeEnum.PHONE" tab="短信登录">
                <LoginPhoneForm
                  :openRegister="customConfig.openRegister"
                  :errorTimesState="errorTimesState"
                  @loading="onLoading"
                  @success="onLoginFormSuccess"
                  @resetPassword="onResetPassword"
                  @forgetPassword="onForgetPassword"
                />
              </Tabs.TabPane>
            </Tabs>
          </div>
        </div>
      </Spin>
    </div>
  </component>
</template>

<style lang="scss" scoped>
.login-wrap {
  position: relative;
  background-color: #fff;
  border-radius: 4px;
  box-shadow:
    rgb(0 0 0 / 20%) 0 3px 5px -1px,
    rgb(0 0 0 / 14%) 0 6px 10px 0,
    rgb(0 0 0 / 12%) 0 1px 18px 0;
  :deep(.login-input) {
    padding: 7px 11px 9px;
  }
  :deep(.login-input-icon) {
    padding-right: 4px;
    font-size: 16px;
    color: rgb(0 0 0 / 45%);
  }
}

.login-scan {
  position: absolute;
  top: 0;
  left: 0;
  display: flex;
  align-items: center;
  cursor: pointer;
  user-select: none;
  img {
    width: 64px;
    height: 64px;
  }
  span {
    padding: 0 8px;
    border-radius: 8px;
    margin-left: -20px;
    font-size: 12px;
    color: #fa8c16;
    border: 1px solid #fa8c16;
  }
}

.login-wrap-hide-layout {
  box-shadow: none;
  .login-form {
    padding: 28px;
  }
}

.login-content {
  display: flex;
  flex-direction: column;
  width: 410px;
  > div {
    width: 100%;
    height: 100%;
  }
}

.login-form {
  padding: 28px 32px 32px;
  :deep(.login-form-tab div[class$='-tabs-nav']) {
    margin: 0 auto 40px;
  }
  :deep(.login-form-tab div[class$='-tabs-tab-btn']) {
    font-size: 15px;
  }
}
</style>
