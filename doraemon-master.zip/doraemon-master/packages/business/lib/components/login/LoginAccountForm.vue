<script lang="ts" setup>
import { computed, reactive } from 'vue';
import { Form, Input, Row, Col, Checkbox, InputPassword } from 'ant-design-vue';
import { UserOutlined, LockOutlined } from '@ant-design/icons-vue';
import type { AccountFormState, LoginEmit } from './type';
import useLogin, { MAX_ERROR_TIMES } from './useLogin';
import LoginFormOperates from './LoginFormOperates.vue';
import { decryptByAesCbc } from '../../utils';

const props = defineProps(['openRegister', 'errorTimesState']);

const emit = defineEmits<LoginEmit>();

const { errorTimes, captchaSrc, refreshCaptcha, onLoginByAccountPsw, onForgetPassword } = useLogin({
  emit,
  errorTimesState: props.errorTimesState,
});

const _account = decryptByAesCbc(localStorage.getItem('username') || '');

const formState = reactive<AccountFormState>({
  account: _account,
  password: decryptByAesCbc(localStorage.getItem('password') || ''),
  remember: !!_account,
});

const isCaptcha = computed(() => errorTimes!.value >= MAX_ERROR_TIMES);

const disabled = computed(() => {
  return !(formState.account && formState.password);
});
</script>

<template>
  <Form name="loginAccountForm" :model="formState" autocomplete="off" @finish="onLoginByAccountPsw">
    <Form.Item name="account" :rules="[{ required: true, message: '请输入账号' }]">
      <Input
        class="login-input"
        autocomplete="off"
        v-model:value="formState.account"
        placeholder="请输入账号"
      >
        <template #prefix>
          <UserOutlined class="login-input-icon" />
        </template>
      </Input>
    </Form.Item>

    <Form.Item name="password" :rules="[{ required: true, message: '请输入密码' }]">
      <InputPassword
        class="login-input"
        v-model:value="formState.password"
        autoComplete="new-password"
        placeholder="请输入密码"
      >
        <template #prefix>
          <LockOutlined class="login-input-icon" />
        </template>
      </InputPassword>
    </Form.Item>
    <Form.Item
      v-if="isCaptcha"
      name="captcha"
      :rules="[{ required: true, message: '请输入图形验证码' }]"
    >
      <Row>
        <Col :span="17">
          <Input
            class="login-input"
            v-model:value="formState.captcha"
            placeholder="请输入图形验证码"
          />
        </Col>
        <Col :span="7" class="captcha-image">
          <img :src="captchaSrc" @click="refreshCaptcha" />
        </Col>
      </Row>
    </Form.Item>
    <LoginFormOperates
      :disabled="disabled"
      :openRegister="openRegister"
      :onForgetPassword="onForgetPassword"
    >
      <template #remember>
        <Form.Item name="remember" no-style>
          <Checkbox v-model:checked="formState.remember">记住账号密码</Checkbox>
        </Form.Item>
      </template>
    </LoginFormOperates>
  </Form>
</template>

<style lang="scss" scoped>
.login-form-link {
  float: right;
}
.captcha-image {
  display: flex;
  justify-content: center;
  align-items: center;
  img {
    max-width: 92px;
    height: 32px;
    cursor: pointer;
  }
}
</style>
