<script lang="ts" setup>
import { ref } from 'vue';
import { Button, Modal } from 'ant-design-vue';
import LoginView from './LoginView.vue';
import LoginForgetView from './LoginForgetView.vue';
import type { TypeEnum } from './constants';

defineProps<{
  /** 隐私协议 domain */
  agreementDomain?: string;
  /** 运行环境 */
  envMode?: string;
  showThirdLogin?: boolean;
}>();

const emit = defineEmits<{
  (event: 'afterLogin'): void;
}>();

const open = ref<boolean>(false);
const isForget = ref<boolean>(false);
const loginTab = ref<TypeEnum>();

const showModal = () => {
  open.value = true;
};

const onForgetPassword = (params: { tab: TypeEnum }) => {
  isForget.value = true;
  loginTab.value = params.tab;
};

const onLogin = () => {
  isForget.value = false;
};

const onAfterLogin = () => {
  open.value = false;
  isForget.value = false;
  emit('afterLogin');
};

const onClose = () => {
  isForget.value = false;
};
</script>

<template>
  <slot name="trigger" :show="showModal">
    <Button type="primary" @click="showModal">登录</Button>
  </slot>
  <Modal
    v-model:open="open"
    width="458px"
    centered
    :footer="null"
    :maskClosable="false"
    @cancel="onClose"
  >
    <LoginForgetView v-if="isForget" :env-mode="envMode" hideLayout @back="onLogin" />
    <LoginView
      v-else
      hide-layout
      class="login-view-modal"
      :style="{ minHeight: showThirdLogin ? '512px' : '428px' }"
      :agreement-domain="agreementDomain"
      :env-mode="envMode"
      :default-tab="loginTab"
      :show-third-login="showThirdLogin"
      @after-login="onAfterLogin"
      @forget-password="onForgetPassword"
    ></LoginView>
  </Modal>
</template>

<style lang="scss" scoped>
.login-view-modal {
  :deep(.login-scan) {
    left: -24px;
    top: -20px;
    border-radius: 8px;
    overflow: hidden;
  }
}
</style>
