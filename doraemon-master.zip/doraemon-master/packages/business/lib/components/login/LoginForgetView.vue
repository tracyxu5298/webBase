<script lang="ts" setup>
import { computed, reactive, ref, h, provide } from 'vue';
import type { FormInstance } from 'ant-design-vue';
import {
  TypographyParagraph,
  Steps,
  Form,
  Input,
  Button,
  InputPassword,
  Result,
  Checkbox,
} from 'ant-design-vue';
import { TabletOutlined, LockOutlined } from '@ant-design/icons-vue';
import { useRoute, useRouter } from 'vue-router';
import type { Rule } from 'ant-design-vue/es/form';
import { message, theme } from 'ant-design-vue';
import { MD5Encrypt, RSAEncrypt, regExpPhoneNumber } from '../../utils';
import { useHttp, useCountDown, type LocationByUserType } from '../../hooks';
import LoginLayout from './LoginLayout.vue';
import type { ForgetPasswordFormState } from './type';
import useCustomConfig from './useCustomConfig';
import { validatePassword } from './utils';

// 定义 route 时传入的变量
const props = defineProps<{
  envMode?: string;
  appVersion?: string;
  hideLayout?: boolean;
}>();

const emit = defineEmits<{
  (event: 'back'): void;
  (event: 'success', data?: LocationByUserType[]): void;
  (event: 'loading', loading: boolean): void;
}>();

provide('loginProps', props);

const { token } = theme.useToken();

const formRef = ref<FormInstance>();
const loading = ref(false);
const step = ref(0);
const code = ref(); // 手机短信验码验证成功后, 服务端返回的授权码

const router = useRouter();
const route = useRoute();

const { customConfig, loadingCustomConfig } = useCustomConfig({ hideLayout: props.hideLayout });

const http = useHttp();
const { time, handleStart } = useCountDown(59);

const formState = reactive<ForgetPasswordFormState>({
  phoneNumber: '',
  captcha: '',
  password1: '',
  password2: '',
  debug: props.envMode !== 'prod' && props.envMode !== 'production',
});

const disabled = computed(() => {
  if (step.value === 1) {
    return !(formState.password1 && formState.password2);
  }
  return !(formState.phoneNumber && formState.captcha);
});

const onFinish = async (values: ForgetPasswordFormState) => {
  emit('loading', true);
  try {
    if (step.value === 0) {
      const data = await http.post('/api/building/anon/v1/vcode/checkVerificationCodeForget', {
        phoneNumber: RSAEncrypt(values.phoneNumber),
        phoneVerificationCode: values.captcha,
      });
      code.value = data;
    } else {
      await http.post('/api/auth/anon/v1/password/forgetPassword', {
        phoneNumber: RSAEncrypt(formState.phoneNumber),
        newPassword: RSAEncrypt(MD5Encrypt(values.password1)),
        code: code.value,
      });
    }
    step.value = step.value + 1;
  } catch (error: any) {
    message.error(error?.desc || '密码设置失败');
  } finally {
    emit('loading', false);
  }
};

const validatePass = async (_rule: Rule, value: string) => {
  try {
    await validatePassword(_rule, value);
    if (formState.password2) {
      formRef.value?.validateFields('password2');
    }
    return Promise.resolve();
  } catch (error) {
    return Promise.reject(error);
  }
};

const validatePass2 = async (_rule: Rule, value: string) => {
  if (!value) {
    return Promise.reject('请再次输入新的登录密码');
  }

  if (value !== formState.password1) {
    return Promise.reject('两次密码不一致');
  }

  return Promise.resolve();
};

const onSendCode = async () => {
  if (loading.value) {
    return;
  }

  try {
    await formRef.value?.validateFields('phoneNumber');
  } catch (error) {
    return;
  }

  loading.value = true;

  try {
    const res = await http.get('/api/building/anon/v1/vcode/sendVerificationCodeLimit', {
      debugSwitchStatus: formState.debug ? 1 : 0,
      phoneNumber: RSAEncrypt(formState.phoneNumber),
    });
    message.success('验证码已发送，请查收');

    // 调试模式自动写入验证码
    if (formState.debug && res?.verificationCode) {
      formState.captcha = res.verificationCode;
    }
    handleStart();
  } catch (error: any) {
    message.error(error?.desc || '获取验证码失败');
  } finally {
    loading.value = false;
  }
};

const onBack = () => {
  if (props.hideLayout) {
    emit('back');
  } else {
    router.replace({ path: '/Login', query: route.query });
  }
};
</script>

<template>
  <component
    :is="hideLayout ? 'div' : LoginLayout"
    :loading="loadingCustomConfig"
    :config="customConfig"
  >
    <div :class="['login-forget-password', hideLayout ? 'forget-hide-layout' : '']" v-if="step < 2">
      <TypographyParagraph class="login-forget-password-title"> 忘记密码 </TypographyParagraph>
      <Steps
        progress-dot
        class="login-forget-password-step"
        size="small"
        :current="step"
        :items="[
          {
            title: '验证手机',
          },
          {
            title: '设置密码',
          },
          {
            title: '重置成功',
          },
        ]"
      ></Steps>

      <Form
        class="login-forget-password-form"
        name="loginForgetPasswordForm1"
        ref="formRef"
        autocomplete="off"
        :model="formState"
        @finish="onFinish"
        v-if="step === 0"
      >
        <Form.Item
          name="phoneNumber"
          :rules="[
            { required: true, message: '请输入手机号码' },
            { pattern: regExpPhoneNumber, message: '请输入正确的手机号码', trigger: 'blur' },
          ]"
        >
          <Input
            class="login-input"
            :maxlength="11"
            v-model:value="formState.phoneNumber"
            placeholder="请输入手机号码"
          >
            <template #prefix>
              <TabletOutlined class="login-input-icon" />
            </template>
          </Input>
        </Form.Item>
        <Form.Item name="captcha">
          <Input
            class="login-input"
            v-model:value="formState.captcha"
            :maxlength="6"
            placeholder="请输入验证码"
          >
            <template #suffix>
              <a
                class="send-code-button"
                :style="{ color: token.colorPrimary }"
                v-if="!time"
                @click="onSendCode"
                >获取验证码</a
              >
              <span class="send-code-time" v-else>{{ time }}s</span>
            </template>
          </Input>
        </Form.Item>
        <Form.Item name="debug" no-style v-if="envMode !== 'prod' && envMode !== 'production'">
          <Checkbox v-model:checked="formState.debug">调试模式</Checkbox>
        </Form.Item>
        <Form.Item>
          <Button
            class="login-forget-password-button"
            block
            :disabled="disabled"
            type="primary"
            size="large"
            html-type="submit"
          >
            下一步
          </Button>
        </Form.Item>
      </Form>
      <Form
        class="login-forget-password-form"
        name="loginForgetPasswordForm2"
        autocomplete="off"
        :model="formState"
        @finish="onFinish"
        v-else-if="step === 1"
      >
        <Form.Item name="password1" :rules="[{ validator: validatePass, trigger: 'blur' }]">
          <InputPassword
            class="login-input"
            v-model:value="formState.password1"
            autocomplete="new-password"
            placeholder="请设置8-20位字母/数字/特殊符号至少3种组合"
          >
            <template #prefix>
              <LockOutlined class="login-input-icon" />
            </template>
          </InputPassword>
        </Form.Item>
        <Form.Item name="password2" :rules="[{ validator: validatePass2, trigger: 'blur' }]">
          <InputPassword
            class="login-input"
            v-model:value="formState.password2"
            autocomplete="new-password"
            placeholder="请再次输入新的登录密码"
          >
            <template #prefix>
              <LockOutlined class="login-input-icon" />
            </template>
          </InputPassword>
        </Form.Item>
        <Form.Item>
          <Button
            class="login-forget-password-button"
            block
            :disabled="disabled"
            type="primary"
            size="large"
            html-type="submit"
          >
            确定
          </Button>
        </Form.Item>
      </Form>
      <div class="login-password-back">
        <a :style="{ color: token.colorPrimary }" @click="onBack">返回登录</a>
      </div>
    </div>
    <div
      :class="[
        'login-forget-password',
        'login-forget-password-result',
        hideLayout ? 'forget-hide-layout' : '',
      ]"
      v-else
    >
      <Result status="success" :title="h('div', { class: 'result-title' }, '密码重置成功')">
        <template #extra>
          <Button key="console" type="primary" size="large" @click="onBack">前往登录</Button>
        </template>
      </Result>
    </div>
  </component>
</template>

<style lang="scss" scoped>
.login-forget-password {
  display: flex;
  flex-direction: column;
  width: 410px;
  min-height: 482px;
  padding: 32px;
  background-color: #fff;
  border-radius: 4px;
  box-shadow:
    rgb(0 0 0 / 20%) 0 3px 5px -1px,
    rgb(0 0 0 / 14%) 0 6px 10px 0,
    rgb(0 0 0 / 12%) 0 1px 18px 0;
  &-form {
    // margin-top: 40px;
    :deep(.login-input) {
      padding: 7px 11px 9px;
    }
  }
  &-step {
    margin: 56px 0 56px -16px;
  }
  &-title {
    margin: 0;
    font-size: 16px;
    font-weight: 600;
    line-height: 22px;
    color: rgb(0 0 0 / 85%);
  }
  &-button {
    margin-top: 16px;
    font-size: 15px;
  }
  &-result {
    display: flex;
    justify-content: center;
    align-items: center;
    .result-title {
      font-weight: 600;
      color: #1f1f1f;
    }
  }
}

:deep(
    .login-forget-password-step.antv-steps.antv-steps-dot.antv-steps-small .antv-steps-item-content
  ) {
  width: 120px;
}

.forget-hide-layout {
  box-shadow: none;
  padding: 16px 32px;
}

.login-password-back {
  padding: 8px 0;
  text-align: center;
  a {
    line-height: 24px;
  }
}
.login-input-icon {
  padding-right: 4px;
  font-size: 16px;
  color: rgb(0 0 0 / 45%);
}
.send-code-time {
  color: rgb(0 0 0 / 45%);
}
</style>
