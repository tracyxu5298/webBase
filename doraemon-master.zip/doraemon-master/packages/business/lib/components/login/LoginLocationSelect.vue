<script lang="ts" setup>
import { TypographyText } from 'ant-design-vue';
import { ArrowLeftOutlined } from '@ant-design/icons-vue';
import LocationSelector from '../locations/LocationSelector.vue';
import type { LocationByUserType, LocationItem } from '../../hooks';

defineProps<{
  locations: LocationByUserType[] | null;
}>();

const emit = defineEmits<{
  (event: 'back'): void;
  (event: 'afterChanged', location: LocationItem, homePageAddress?: string): void;
  (event: 'loading', loading: boolean): void;
}>();

const onBack = () => {
  emit('back');
};

const onLoading = (value: boolean) => {
  emit('loading', value);
};

const onAfterChanged = (location: LocationItem, homePageAddress?: string) => {
  emit('afterChanged', location, homePageAddress);
};
</script>

<template>
  <div class="location-section">
    <div class="location-section-back">
      <TypographyText class="back-text" @click="onBack">
        <ArrowLeftOutlined class="back-icon" />
        返回
      </TypographyText>
    </div>
    <div class="location-list">
      <LocationSelector
        show-last-login
        :locations="locations"
        @loading="onLoading"
        @afterChanged="onAfterChanged"
      />
    </div>
  </div>
</template>

<style lang="scss" scoped>
.location-section {
  display: flex;
  flex-direction: column;
  padding-bottom: 32px;
  overflow: hidden;
}

.location-section-back {
  padding: 28px 20px 20px;
  .back-text {
    cursor: pointer;
  }
  .back-icon {
    margin-right: 4px;
    color: rgb(0 0 0 / 45%);
  }
}

.location-list {
  padding: 0 20px;
  display: flex;
  flex-direction: column;
  height: 440px;
  overflow: hidden;
}
</style>
