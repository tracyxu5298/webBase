<script setup lang="ts">
import { computed } from 'vue';
import { useRoute } from 'vue-router';
import codeMeta from './assets/code-meta.png';
import logoDing from './assets/logo-ding.png';
import logoWeChat from './assets/logo-wechat.png';

const route = useRoute();
const isDing = computed(() => route.params.type === 'ding');
</script>

<template>
  <div class="login-third-scan">
    <div class="login-third-scan-label">
      <img v-if="isDing" :src="logoDing" />
      <img v-else :src="logoWeChat" />
      使用{{ isDing ? '钉钉' : '微信' }}扫一扫登录
    </div>
    <h2>「立达信账号」</h2>
    <div class="login-third-scan-code">
      <img :src="codeMeta" />
    </div>
  </div>
</template>

<style lang="scss" scoped>
.login-third-scan {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  height: 100%;
  &-code {
    width: 208px;
    height: 208px;
    margin-bottom: 16px;
    img {
      width: 100%;
    }
  }
  p {
    margin: 0;
  }
  &-label {
    margin-bottom: 16px;
    img {
      margin-right: 8px;
      width: 36px;
    }
  }
  h2 {
    margin: 0 24px 24px;
  }
}
</style>
