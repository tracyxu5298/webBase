<script lang="ts" setup>
import { computed, ref, inject } from 'vue';
import { theme, Form, Button, Checkbox } from 'ant-design-vue';
import { useRoute, useRouter } from 'vue-router';
import logoWeChat from './assets/logo-wechat.png';
import logoSmartedu from './assets/logo-smartedu.png';
import logoDing from './assets/logo-ding.png';

const props = defineProps<{
  disabled: boolean;
  openRegister?: number;
  onForgetPassword?: () => void;
}>();

const { token } = theme.useToken();
const router = useRouter();
const route = useRoute();

const { agreementDomain, envMode, hideLayout, showThirdLogin } =
  inject('loginProps') || ({} as any);

const disabledSubmit = computed(() => props.disabled || !agreement.value);

const agreement = ref(envMode !== 'prod' && envMode !== 'production');

const onForget = () => {
  if (hideLayout) {
    props.onForgetPassword?.();
    return;
  }
  router.push({ path: '/Login/Forget', query: route.query });
};

const onOpenThird = (type: string) => {
  window.open(
    `${window.location.origin}/Login/Third/${type}`,
    '_blank',
    `width=680,height=600,menubar=no,toolbar=no,location=no,left=${Math.floor((window.innerWidth - 680) / 2)},top=${Math.floor((window.innerHeight - 600) / 2) + 60}`,
  );
};
</script>

<template>
  <Form.Item class="login-form-operates">
    <slot name="remember"></slot>
    <a :style="{ color: token.colorPrimary }" class="login-form-link" @click="onForget"
      >忘记密码？</a
    >
    <!-- <a class="login-form-link" v-if="!openRegister">快速注册</a> -->
  </Form.Item>

  <Form.Item>
    <Button
      class="login-form-button"
      :disabled="disabledSubmit"
      block
      type="primary"
      size="large"
      html-type="submit"
      >登录</Button
    >
    <p class="agreement-checkbox">
      <Checkbox v-model:checked="agreement">我已阅读并同意</Checkbox>
      <a
        :style="{ color: token.colorPrimary }"
        target="_blank"
        :href="`${agreementDomain}/user-agreement.html`"
        >用户服务协议</a
      >
      和
      <a
        :style="{ color: token.colorPrimary }"
        target="_blank"
        :href="`${agreementDomain}/privacy-policy.html`"
        >隐私政策</a
      >
    </p>
  </Form.Item>
  <div class="third-login" v-if="showThirdLogin">
    <p>其他登录方式</p>
    <ul>
      <li @click="onOpenThird('weChat')">
        <img :src="logoWeChat" />
      </li>
      <li @click="onOpenThird('ding')">
        <img :src="logoDing" />
      </li>
      <li>
        <a href="https://auth.smartedu.cn/uias/login" target="_blank"
          ><img :src="logoSmartedu"
        /></a>
      </li>
    </ul>
  </div>
</template>

<style lang="scss" scoped>
.login-form-link {
  float: right;
  margin-left: 24px;
}
.agreement-checkbox {
  margin: 12px 0 0;
}

.login-form-button {
  font-size: 15px;
}

.third-login {
  p {
    padding-top: 12px;
    text-align: center;
    font-size: 12px;
    margin: 0;
    color: v-bind('token.colorTextDescription');
  }
  ul {
    margin: 16px 0 0;
    display: flex;
    align-items: center;
    justify-content: center;
    list-style: none;
    padding: 0;
    gap: 16px;
  }
  li {
    width: 36px;
    height: 36px;
    cursor: pointer;
    img {
      width: 100%;
    }
  }
}
</style>
