export enum TypeEnum {
  ACCOUNT = 'account',
  PHONE = 'phone',
  FORGOT_PASSWORD = 'forgot',
}

export const TypeList = [
  {
    value: TypeEnum.ACCOUNT,
    label: '账号登录',
  },
  {
    value: TypeEnum.PHONE,
    label: '短信登录',
  },
];

export enum StepEnum {
  'LOGIN',
  'LOCATION',
  'RESET_PASSWORD',
  'RESET_PASSWORD_BIND_PHONE',
  'BIND_PHONE',
  'SCAN',
}
