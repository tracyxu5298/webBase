import type { LocationByUserType } from '../../hooks';

export interface AccountFormState {
  account: string;
  password: string;
  captcha?: string;
  captchaSignature?: string;
  remember?: boolean;
}

export interface ResetPasswordFormState {
  password: string;
  phoneNumber: string;
  captcha: string;
  debug: boolean;
}

export interface ForgetPasswordFormState {
  phoneNumber: string;
  captcha: string;
  password1: string;
  password2: string;
  debug: boolean;
}

export interface PhoneFormState {
  phoneNumber: string;
  captcha: string;
  debug: boolean;
}

export interface ResetPasswordProps {
  /** 修改手机号时需要账号 */
  account?: string;
  /** 判断新旧密码是否一样 */
  password?: string;
  phoneNumber?: string;
  /** 是否需要修改密码 */
  isDefaultPwd: boolean;
  /** 是否需要绑定手机 */
  isBindMobile: boolean;
}

export interface LoginEmit {
  (event: 'success', data: LocationByUserType[]): void;
  (event: 'resetPassword', data: ResetPasswordProps): void;
  (event: 'forgetPassword'): void;
  (event: 'loading', loading: boolean): void;
}
