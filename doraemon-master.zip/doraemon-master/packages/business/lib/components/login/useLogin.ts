import type { Ref, ComputedRef } from 'vue';
import { ref, computed } from 'vue';
import { message } from 'ant-design-vue';
import { MD5Encrypt, RSAEncrypt, encryptByAesCbc } from '../../utils';
import useAuthStore from '../../stores/useAuthStore';
import { useHttp, type LocationByUserType } from '../../hooks';
import type { AccountFormState, PhoneFormState, LoginEmit } from './type';

export const MAX_ERROR_TIMES = 2;

const getCaptchaRandomNumber = () => `${Date.parse(Date()) + Math.floor(Math.random() * 100)}`;

interface ErrorTimesValue {
  errorTimes: Ref<number>;
  captchaSrc: ComputedRef<string>;
  captchaSignature: Ref<string>;
  getErrorTimes: () => Promise<void>;
  refreshCaptcha: () => void;
}

const LOGIN_ERROR_TIMES_KEY = 'loginErrorTimes';

export const useErrorTimes = (): ErrorTimesValue => {
  const http = useHttp();
  const _errorTimes = localStorage.getItem(LOGIN_ERROR_TIMES_KEY);
  const errorTimes = ref(_errorTimes ? +_errorTimes : 0);
  const captchaSignature = ref(_errorTimes ? getCaptchaRandomNumber() : '');

  const captchaSrc = computed(
    () =>
      `/api2/building/anon/v2/kaptcha/actions/getVerificationCode?randomNumber=${captchaSignature.value}`,
  );

  const refreshCaptcha = () => {
    captchaSignature.value = getCaptchaRandomNumber();
  };

  const getErrorTimes = async () => {
    // 超过2次不需要请求接口获取错误次数
    if (errorTimes.value >= MAX_ERROR_TIMES) {
      refreshCaptcha();
      return;
    }
    try {
      const res = await http.get('/api/building/anon/getErrorTimesByIp');
      errorTimes.value = parseInt(res || 0, 10);
      if (errorTimes.value >= MAX_ERROR_TIMES) {
        localStorage.setItem(LOGIN_ERROR_TIMES_KEY, `${errorTimes.value}`);
      }
      refreshCaptcha();
    } catch (error) {
      // do sth
    }
  };

  return { errorTimes, captchaSrc, captchaSignature, getErrorTimes, refreshCaptcha };
};

interface AfterLoginOptions {
  tokenHeaderName: string;
  accessToken: string;
  expireTime: number;
  refreshToken: string;
  refreshExpireTime: number;
  phoneNumber: string;
  isDefaultPwd: boolean;
  isBindMobile: boolean;
  locations: LocationByUserType[];
}

const useLogin = ({
  emit,
  errorTimesState,
}: {
  emit: LoginEmit;
  errorTimesState?: ErrorTimesValue;
}) => {
  const http = useHttp();
  const store = useAuthStore();
  const { getErrorTimes, captchaSignature, errorTimes, captchaSrc, refreshCaptcha } =
    errorTimesState || {};

  // 登录成功后，获取用户信息，跳转选择组织
  const onAfterLogin = async (options: AfterLoginOptions, password?: string, account?: string) => {
    localStorage.removeItem(LOGIN_ERROR_TIMES_KEY);

    const { isDefaultPwd, isBindMobile, locations, phoneNumber } = options;

    // set token
    store.set({
      tokenKey: options.tokenHeaderName,
      token: options.accessToken,
      tokenExpire: options.expireTime,
      refreshToken: options.refreshToken,
      refreshExpire: options.refreshExpireTime,
    });

    http.setHeader({
      token: '',
      cuser_token: '',
      [options.tokenHeaderName]: options.accessToken,
    });

    if (isDefaultPwd || !isBindMobile) {
      emit('loading', false);
      /** 云端 isBindMobile: false 则是未绑定手机，所以这里加 ！ */
      emit('resetPassword', {
        password,
        account,
        phoneNumber,
        isBindMobile: !isBindMobile,
        isDefaultPwd,
      });
      return;
    }

    emit('success', locations);
  };

  const onLoginByAccountPsw = async (values: AccountFormState) => {
    emit('loading', true);
    const { password, remember, ...rest } = values;
    try {
      const res = await http.post('/api/building/anon/loginByPassword', {
        ...rest,
        captchaSignature: captchaSignature!.value,
        password: RSAEncrypt(MD5Encrypt(password)),
      });

      // 记住密码
      if (remember) {
        localStorage.setItem('username', encryptByAesCbc(values.account));
        localStorage.setItem('password', encryptByAesCbc(values.password));
      } else {
        localStorage.removeItem('username');
        localStorage.removeItem('password');
      }

      if (res.accessToken) {
        await onAfterLogin(res, password, values.account);
      } else {
        emit('loading', false);
      }
    } catch (error: any) {
      getErrorTimes!();
      message.error(error?.desc || '登录失败');
      emit('loading', false);
    }
  };

  const onLoginByPhoneCode = async (values: PhoneFormState) => {
    emit('loading', true);
    const { phoneNumber, ...rest } = values;
    try {
      const res = await http.post('/api/building/anon/loginByPhone', {
        ...rest,
        phoneNumber: RSAEncrypt(phoneNumber),
      });

      if (res.accessToken) {
        await onAfterLogin(res);
      } else {
        emit('loading', false);
      }
    } catch (error: any) {
      getErrorTimes!();
      message.error(error?.desc || '登录失败');
      emit('loading', false);
    }
  };

  const onForgetPassword = () => {
    emit('forgetPassword');
  };

  return {
    errorTimes,
    captchaSrc,
    onAfterLogin,
    refreshCaptcha,
    onLoginByAccountPsw,
    onLoginByPhoneCode,
    onForgetPassword,
  };
};

export default useLogin;
