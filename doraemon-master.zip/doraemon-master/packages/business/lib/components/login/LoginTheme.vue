<script setup lang="ts">
import { ConfigProvider } from 'ant-design-vue';
import zhCN from 'ant-design-vue/es/locale/zh_CN';
import { themes } from '../../themes';

const token = window.location.host.includes('xq.') ? themes.pink : themes.blue;
</script>

<template>
  <ConfigProvider prefixCls="antv" :locale="zhCN" :theme="{ token }">
    <RouterView />
  </ConfigProvider>
</template>
