<script lang="ts" setup>
import { computed, reactive, ref, inject } from 'vue';
import { message, theme, Form, Input, Checkbox } from 'ant-design-vue';
import type { FormInstance } from 'ant-design-vue';
import { TabletOutlined } from '@ant-design/icons-vue';
import { RSAEncrypt, regExpPhoneNumber } from '../../utils';
import { useHttp, useCountDown } from '../../hooks';
import type { PhoneFormState, LoginEmit } from './type';
import useLogin from './useLogin';
import LoginFormOperates from './LoginFormOperates.vue';

const props = defineProps(['openRegister', 'errorTimesState']);
const emit = defineEmits<LoginEmit>();

const { envMode } = inject('loginProps') || ({} as any);
const { token } = theme.useToken();

const { onLoginByPhoneCode, onForgetPassword } = useLogin({
  emit,
  errorTimesState: props.errorTimesState,
});
const http = useHttp();
const { time, handleStart } = useCountDown(59);

const formRef = ref<FormInstance>();

const formState = reactive<PhoneFormState>({
  phoneNumber: '',
  captcha: '',
  debug: envMode !== 'prod' && envMode !== 'production',
});

const rulesRef = reactive<any>({
  phoneNumber: [
    { required: true, message: '请输入手机号码' },
    { pattern: regExpPhoneNumber, message: '请输入正确的手机号码', trigger: 'blur' },
  ],
  captcha: [{ required: true, message: '请输入验证码' }],
});

const loading = ref(false);

const disabled = computed(() => {
  return !(formState.phoneNumber && formState.captcha);
});

const onSendCode = async () => {
  if (loading.value) {
    return;
  }

  try {
    await formRef.value?.validateFields('phoneNumber');
  } catch (error) {
    // console.log(error);
    return;
  }

  loading.value = true;

  try {
    const res = await http.get('/api/building/anon/captcha', {
      debug: formState.debug ? 1 : 0,
      phoneNumber: RSAEncrypt(formState.phoneNumber),
    });
    message.success('验证码已发送，请查收');

    // 调试模式自动写入验证码
    if (formState.debug && res?.captcha) {
      formState.captcha = res.captcha;
    }
    handleStart();
  } catch (error: any) {
    message.error(error?.desc || '获取验证码失败');
  } finally {
    loading.value = false;
  }
};
</script>

<template>
  <Form
    name="loginPhoneForm"
    ref="formRef"
    :model="formState"
    autocomplete="off"
    :rules="rulesRef"
    @finish="onLoginByPhoneCode"
  >
    <Form.Item name="phoneNumber">
      <Input
        class="login-input"
        :maxlength="11"
        v-model:value="formState.phoneNumber"
        placeholder="请输入手机号码"
      >
        <template #prefix>
          <TabletOutlined class="login-input-icon" />
        </template>
      </Input>
    </Form.Item>
    <Form.Item name="captcha">
      <Input
        class="login-input"
        v-model:value="formState.captcha"
        :maxlength="6"
        placeholder="请输入验证码"
      >
        <template #suffix>
          <a
            class="send-code-button"
            :style="{ color: token.colorPrimary }"
            v-if="!time"
            @click="onSendCode"
            >获取验证码</a
          >
          <span class="send-code-time" v-else>{{ time }}s</span>
        </template>
      </Input>
    </Form.Item>

    <LoginFormOperates
      :disabled="disabled"
      :openRegister="openRegister"
      :onForgetPassword="onForgetPassword"
    >
      <template #remember>
        <Form.Item name="debug" no-style v-if="envMode !== 'prod' && envMode !== 'production'">
          <Checkbox v-model:checked="formState.debug">调试模式</Checkbox>
        </Form.Item>
      </template>
    </LoginFormOperates>
  </Form>
</template>

<style lang="scss" scoped>
.send-code-button {
  padding-left: 4px;
  font-size: 14px;
}
.send-code-time {
  color: rgb(0 0 0 / 45%);
}
</style>
