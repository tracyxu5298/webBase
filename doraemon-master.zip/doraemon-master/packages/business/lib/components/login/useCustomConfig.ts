import { ref, onBeforeMount } from 'vue';
import { useRoute } from 'vue-router';
import useHttp from '../../hooks/useHttp';

export interface CustomConfig {
  loginPicture: string;
  loginTitle: string;
  loginContent: string;
  loginLogoUrl: string;
  locationName: string;
  openRegister: number;
}

const useCustomConfig = ({ hideLayout }: { hideLayout?: boolean }) => {
  const http = useHttp();
  const route = useRoute();

  const dedicatedWebsite = route.query.n;
  const customConfig = ref({} as CustomConfig);
  const loadingCustomConfig = ref(dedicatedWebsite ? true : false);

  const getCustomConfig = async () => {
    if (!dedicatedWebsite) {
      document.title = '星磐·数字基座';
      return;
    }
    loadingCustomConfig.value = true;
    try {
      const res = await http.get(
        '/api/auth/anon/v1/frontend/locations/actions/getLocationDedicatedConfig',
        { dedicatedWebsite },
      );
      customConfig.value = (res || {}) as CustomConfig;
      document.title = customConfig.value.loginTitle || '星磐·数字基座';
    } catch (error) {
      // do sth
    } finally {
      loadingCustomConfig.value = false;
    }
  };

  onBeforeMount(() => {
    if (!hideLayout) {
      getCustomConfig();
    }
  });

  return { customConfig, loadingCustomConfig, getCustomConfig };
};

export default useCustomConfig;
