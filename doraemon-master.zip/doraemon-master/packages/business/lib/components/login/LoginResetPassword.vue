<script lang="ts" setup>
import { computed, reactive, inject, ref } from 'vue';
import type { Rule } from 'ant-design-vue/es/form';
import type { FormInstance } from 'ant-design-vue';
import {
  message,
  theme,
  Form,
  InputPassword,
  Input,
  Checkbox,
  TypographyParagraph,
  Button,
} from 'ant-design-vue';
import { TabletOutlined, LockOutlined } from '@ant-design/icons-vue';
import useLocations from '../locations/useLocations';
import { MD5Encrypt, RSAEncrypt, regExpPhoneNumber } from '../../utils';
import { useHttp, useCountDown, type LocationByUserType } from '../../hooks';
import type { ResetPasswordFormState } from './type';
import { StepEnum } from './constants';
import { validatePassword } from './utils';

const props = defineProps<{
  account?: string;
  password?: string;
  phoneNumber?: string;
  step: StepEnum;
}>();

const emit = defineEmits<{
  (event: 'back'): void;
  (event: 'success', data?: LocationByUserType[]): void;
  (event: 'loading', loading: boolean): void;
}>();

const { token } = theme.useToken();
const http = useHttp();
const { envMode } = inject('loginProps') || ({} as any);
const loading = ref(false);
const formRef = ref<FormInstance>();
// 倒计时
const { time, handleStart } = useCountDown(59);
// 组织列表，修改成功后还是要直接进入选择组织
const { locations, getLocations } = useLocations();

const formState = reactive<ResetPasswordFormState>({
  password: '',
  phoneNumber: '',
  captcha: '',
  debug: envMode !== 'prod' && envMode !== 'production',
});

/** 修改密码 */
const _resetPsw = async (values: ResetPasswordFormState) => {
  try {
    const res = await http.post<any>('/api/building/reset/password', {
      password: RSAEncrypt(MD5Encrypt(values.password)),
      captcha: values.captcha,
      phoneNumber: RSAEncrypt(props.phoneNumber || ''),
    });
    if (!res?.reSetResult) {
      message.error(res?.reSetMsg || '密码设置失败');
      return Promise.reject();
    }

    return Promise.resolve();
  } catch (error: any) {
    message.error(error?.desc || '密码设置失败');
    return Promise.reject();
  }
};

/** 绑定手机并修改密码 */
const _resetPswAndBindMobile = async (values: ResetPasswordFormState) => {
  try {
    await http.post<any>('/api/building/reset/pwdAndMobile', {
      account: props.account,
      password: RSAEncrypt(MD5Encrypt(values.password)),
      captcha: values.captcha,
      phoneNumber: RSAEncrypt(values.phoneNumber),
    });
    return Promise.resolve();
  } catch (error: any) {
    message.error(error?.desc || '设置失败');
    return Promise.reject();
  }
};

/** 绑定手机 */
const _bindMobile = async (values: ResetPasswordFormState) => {
  try {
    await http.post<any>('/api/building/bind/phoneNumber', {
      account: props.account,
      captcha: values.captcha,
      phoneNumber: RSAEncrypt(values.phoneNumber),
    });
    return Promise.resolve();
  } catch (error: any) {
    message.error(error?.desc || '绑定失败');
    return Promise.reject();
  }
};

/** 点击表单确定按钮 */
const onFinish = async (values: ResetPasswordFormState) => {
  emit('loading', true);
  try {
    if (props.step === StepEnum.RESET_PASSWORD_BIND_PHONE) {
      await _resetPswAndBindMobile(values);
    } else if (props.step === StepEnum.BIND_PHONE) {
      await _bindMobile(values);
    } else {
      await _resetPsw(values);
    }
  } catch (error: any) {
    emit('loading', false);
    // 第一阶段报错不需要往下
    return;
  }

  // 修改密码后手动获取组织列表
  try {
    await getLocations();

    emit('success', locations.value);
  } catch (error) {
    emit('loading', false);
    // 跳转下一步 手动选择组织
    emit('success');
  }
};

/** 校验密码 */
const validatePass = async (_rule: Rule, value: string) => {
  if (!value) {
    return Promise.reject('请输入密码');
  }

  if (value === props.password) {
    return Promise.reject('新密码不能与旧密码相同，请重新输入');
  }

  return validatePassword(_rule, value);
};

/** 发送验证码 */
const onSendCode = async () => {
  if (loading.value) {
    return;
  }

  try {
    await formRef.value?.validateFields('phoneNumber');
  } catch (error) {
    // catch
    return;
  }

  loading.value = true;
  const phoneNumber = RSAEncrypt(formState.phoneNumber);

  try {
    const res = await http.get('/api/building/anon/captcha', {
      debug: formState.debug ? 1 : 0,
      phoneNumber,
      checkAccountFlag: false,
    });

    message.success('验证码已发送，请查收');

    // 调试模式自动写入验证码
    if (formState.debug && res?.captcha) {
      formState.captcha = res.captcha;
    }

    handleStart();
  } catch (error: any) {
    message.error(error?.desc || '获取验证码失败');
  } finally {
    loading.value = false;
  }
};

/** 发送重置密码验证码 */
const onSendResetCode = async () => {
  if (loading.value || !props.phoneNumber) {
    return;
  }

  loading.value = true;

  try {
    const res = await http.get('/api/building/v1/vcode/sendVerificationCode', {
      debugSwitchStatus: formState.debug ? 1 : 0,
      phoneNumber: RSAEncrypt(props.phoneNumber),
    });

    message.success('验证码已发送，请查收');

    // 调试模式自动写入验证码
    if (formState.debug && res?.verificationCode) {
      formState.captcha = res.verificationCode;
    }

    handleStart();
  } catch (error: any) {
    message.error(error?.desc || '获取验证码失败');
  } finally {
    loading.value = false;
  }
};

const tips = computed(() => {
  if (props.step === StepEnum.RESET_PASSWORD_BIND_PHONE) {
    return '您正在使用默认密码，为了您的账号安全，请设置新密码并绑定手机。';
  }
  if (props.step === StepEnum.BIND_PHONE) {
    return '为了您的账号安全，请绑定手机。';
  }
  return '您正在使用默认密码登录，为了您的账号安全，请设置新密码。';
});

const disabled = computed(() => {
  if (props.step === StepEnum.RESET_PASSWORD_BIND_PHONE) {
    return !(formState.phoneNumber && formState.captcha && formState.password);
  }
  if (props.step === StepEnum.BIND_PHONE) {
    return !(formState.phoneNumber && formState.captcha);
  }
  return !formState.password;
});

const _phoneNumber = computed(() =>
  props.phoneNumber ? props.phoneNumber.replace(/^(\d{3})\d{4}(\d{4})$/, '$1****$2') : '',
);
</script>

<template>
  <div class="login-password">
    <TypographyParagraph
      class="login-password-tips"
      :style="{
        marginTop: step === StepEnum.BIND_PHONE ? '8px' : '16px',
      }"
    >
      {{ tips }}
    </TypographyParagraph>
    <TypographyParagraph
      :style="{
        margin: '8px 0 4px',
        fontSize: '20px',
      }"
      v-if="_phoneNumber && [StepEnum.RESET_PASSWORD].includes(step)"
    >
      {{ _phoneNumber }}
    </TypographyParagraph>

    <Form
      class="login-password-form"
      ref="formRef"
      :name="`loginPasswordForm${step}`"
      :model="formState"
      :style="{
        marginTop: step === StepEnum.BIND_PHONE ? '40px' : '16px',
      }"
      autocomplete="off"
      @finish="onFinish"
    >
      <Form.Item
        v-if="[StepEnum.RESET_PASSWORD].includes(step)"
        name="captcha"
        :rules="[{ required: true, message: '请输入验证码' }]"
      >
        <Input
          class="login-input"
          v-model:value="formState.captcha"
          :maxlength="6"
          autocomplete="new-password"
          placeholder="请输入验证码"
        >
          <template #suffix>
            <a
              :style="{ color: token.colorPrimary }"
              class="send-code-button"
              v-if="!time"
              @click="onSendResetCode"
              >获取验证码</a
            >
            <span class="send-code-time" v-else>{{ time }}s</span>
          </template>
        </Input>
      </Form.Item>
      <Form.Item
        v-if="[StepEnum.RESET_PASSWORD_BIND_PHONE, StepEnum.RESET_PASSWORD].includes(step)"
        name="password"
        :rules="[{ validator: validatePass, trigger: 'blur' }]"
      >
        <InputPassword
          v-model:value="formState.password"
          autocomplete="new-password"
          placeholder="请设置8-20位字母/数字/特殊符号至少3种组合"
          class="login-input"
        >
          <template #prefix>
            <LockOutlined class="login-input-icon" />
          </template>
        </InputPassword>
      </Form.Item>
      <Form.Item
        v-if="[StepEnum.RESET_PASSWORD_BIND_PHONE, StepEnum.BIND_PHONE].includes(step)"
        name="phoneNumber"
        :rules="[
          { required: true, message: '请输入手机号码' },
          { pattern: regExpPhoneNumber, message: '请输入正确的手机号码', trigger: 'blur' },
        ]"
      >
        <Input
          class="login-input"
          :maxlength="11"
          v-model:value="formState.phoneNumber"
          placeholder="请输入手机号码"
        >
          <template #prefix>
            <TabletOutlined class="login-input-icon" />
          </template>
        </Input>
      </Form.Item>
      <Form.Item
        v-if="[StepEnum.RESET_PASSWORD_BIND_PHONE, StepEnum.BIND_PHONE].includes(step)"
        name="captcha"
        :rules="[{ required: true, message: '请输入验证码' }]"
      >
        <Input
          class="login-input"
          v-model:value="formState.captcha"
          :maxlength="6"
          placeholder="请输入验证码"
        >
          <template #suffix>
            <a
              :style="{ color: token.colorPrimary }"
              class="send-code-button"
              v-if="!time"
              @click="onSendCode"
              >获取验证码</a
            >
            <span class="send-code-time" v-else>{{ time }}s</span>
          </template>
        </Input>
      </Form.Item>
      <Form.Item v-if="envMode !== 'prod' && envMode !== 'production'" name="debug" no-style>
        <Checkbox v-model:checked="formState.debug">调试模式</Checkbox>
      </Form.Item>
      <Form.Item>
        <Button
          class="login-password-form-button"
          block
          size="large"
          :disabled="disabled"
          type="primary"
          html-type="submit"
        >
          确定
        </Button>
      </Form.Item>
    </Form>
    <div
      class="login-password-back"
      :style="{
        marginTop: step === StepEnum.BIND_PHONE ? '16px' : '-8px',
      }"
    >
      <a :style="{ color: token.colorPrimary }" @click="emit('back')">返回登录</a>
    </div>
  </div>
</template>

<style lang="scss" scoped>
.login-password {
  display: flex;
  flex-direction: column;
  padding: 24px 48px;
}

.login-password-tips {
  margin: 8px 0 0;
  line-height: 22px;
  color: rgb(0 0 0 / 65%);
}

.login-password-form-button {
  margin-top: 12px;
  font-size: 15px;
}

.login-password-back {
  padding: 8px 0;
  margin-top: 16px;
  text-align: center;
  a {
    line-height: 24px;
  }
}
</style>
