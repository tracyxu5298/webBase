<script setup lang="ts">
import { onBeforeMount, onBeforeUnmount, ref } from 'vue';
import { Spin } from 'ant-design-vue';
import { CheckCircleFilled, RedoOutlined } from '@ant-design/icons-vue';
import QRCode from 'qrcode';
import { Http } from '@lexikos/doraemon-network';
import useLogin from './useLogin';
import type { LoginEmit } from './type';

const emit = defineEmits<LoginEmit>();
const { onAfterLogin } = useLogin({ emit });

const loading = ref(true);
const scanned = ref(false);
const expired = ref(false);
const base64 = ref('');
let expiredTimer = 0;
let scanTimer = 0;
let authTimer = 0;

// 接口文档
// https://confluence.leedarson.com/pages/viewpage.action?pageId=136930088

// 生成二维码
async function generateQRCode() {
  try {
    loading.value = true;
    scanned.value = false;
    expired.value = false;
    clearTimeout(expiredTimer);
    clearInterval(scanTimer);
    clearInterval(authTimer);
    const response = await Http.getInstance().get('/api/building/anon/desktop/login/getQRCode');
    pollCodeStatus(response.expires);
    const text = JSON.stringify({
      target: 1,
      path: `/app-platform/mine/scan-code-login?scanCode=${response.scanCode}`,
    });
    base64.value = await QRCode.toDataURL(text, { margin: 0 });
    loading.value = false;
    pollScanStatus(response.scanCode);
  } catch (e) {
    console.error(e);
  }
}

// 轮询二维码有效情况(目前Web倒计时)
function pollCodeStatus(expires: number) {
  clearTimeout(expiredTimer);
  expiredTimer = window.setTimeout(() => {
    expired.value = true; // 二维码失效
    clearTimeout(expiredTimer);
    clearInterval(scanTimer);
    clearInterval(authTimer);
  }, expires * 1000);
}

// 轮询App扫描二维码情况
function pollScanStatus(scanCode: string) {
  scanTimer = window.setInterval(async () => {
    try {
      const response = await Http.getInstance().get(
        `/api/building/anon/desktop/login/checkQRCode?scanCode=${scanCode}`,
      );
      if (response.status === 1) {
        scanned.value = true;
        clearInterval(scanTimer);
        pollCodeStatus(response.expires);
        pollAuthStatus(response.authCode);
      }
    } catch (e) {
      // console.log('pollScanStatus', e);
    }
  }, 1500);
}

// 轮询App授权二维码情况
function pollAuthStatus(authCode: string) {
  authTimer = window.setInterval(async () => {
    try {
      const response = await Http.getInstance().get(
        `/api/building/anon/desktop/loginByQRCode?authCode=${authCode}`,
      );
      clearTimeout(expiredTimer);
      clearInterval(authTimer);
      onAfterLogin(response);
    } catch (e) {
      // console.log('pollAuthStatus', e);
    }
  }, 1500);
}

onBeforeMount(() => {
  generateQRCode();
});

onBeforeUnmount(() => {
  clearTimeout(expiredTimer);
  clearInterval(scanTimer);
  clearInterval(authTimer);
});
</script>

<template>
  <div class="login-scan-meta">
    <div class="login-scan-meta-code">
      <Spin v-if="loading" />
      <template v-else>
        <img :src="base64" />
        <CheckCircleFilled class="result" v-if="scanned && !expired" />
        <div class="invalid" v-if="expired" @click="generateQRCode">
          <RedoOutlined /> 刷新二维码
        </div>
      </template>
    </div>
    <p>打开麦塔校园App</p>
    <p>扫一扫登录</p>
  </div>
</template>

<style lang="scss" scoped>
.login-scan-meta {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  flex: 1;
  &-code {
    width: 208px;
    height: 208px;
    margin-bottom: 16px;
    position: relative;
    align-content: center;
    text-align: center;
    img {
      width: 100%;
      height: 100%;
    }
    .invalid,
    .result {
      width: 100%;
      height: 100%;
      position: absolute;
      top: 0;
      left: 0;
      background: rgba(0, 0, 0, 0.5);
      align-content: center;
      text-align: center;
    }
    .result {
      color: #52c41a;
      font-size: 24px;
      display: block;
    }
    .invalid {
      color: #fff;
      cursor: pointer;
    }
  }
  p {
    margin: 0;
  }
}
</style>
