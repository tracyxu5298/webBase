<script lang="ts" setup>
import { onMounted, reactive, ref } from 'vue';
import { Form, Input, Button } from 'ant-design-vue';
import SelectorPersonScope from './SelectorPersonScope.vue';
import SelectorDepartment from './SelectorDepartment.vue';
import SelectorLocation from './SelectorLocation.vue';
import SelectorLocationModal from './SelectorLocationModal.vue';
import SelectorPerson from './SelectorPerson.vue';
import SelectorAcrossLocationPerson from './SelectorAcrossLocationPerson.vue';
import SelectorStudent from './SelectorStudent.vue';
import SelectorStudentScope from './SelectorStudentScope.vue';
import SelectorGradeClass from './SelectorGradeClass.vue';
import SelectorAcrossLocationStudent from './SelectorAcrossLocationStudent.vue';
import SelectorSpace from './SelectorSpace.vue';
import SelectorDeviceScope from './SelectorDeviceScope.vue';
import SelectorDevice from './SelectorDevice.vue';
import SelectorAcrossLocationPersonScope from './SelectorAcrossLocationPersonScope.vue';
import SelectorAcrossLocationStudentScope from './SelectorAcrossLocationStudentScope.vue';
import SelectorPosition from './SelectorPosition.vue';
import SelectorSeparatedPerson from './SelectorSeparatedPerson.vue';

import type { SelectorItem } from './types';
import { StudentItemLevelEnum } from './types';

defineOptions({
  name: 'SelectorDemo',
});

const selectorAcrossLocationPersonRef = ref();
const formState = reactive<any>({
  location: ['2015', '2224'],
  username: '',
  department1: null,
  department: [],
  clazz1: [],
  clazz: [],
  clazz21: '',
  clazz11: [],
  space: [],
  devices: [],
  deviceScope: [],
  // clazz: [
  //   {
  //     id: '73',
  //     name: '幼儿园',
  //     level: 2,
  //     locationName: null,
  //     identifier: null,
  //     isLeaf: true,
  //     disabled: false,
  //     checkable: true,
  //   },
  //   {
  //     id: '1670740543855460354',
  //     name: '六年级4班',
  //     level: 4,
  //     locationName: null,
  //     identifier: null,
  //     isLeaf: true,
  //     disabled: false,
  //     checkable: true,
  //   },
  //   {
  //     id: '1670740541632479235',
  //     name: '一年级2023级',
  //     level: 3,
  //     locationName: null,
  //     identifier: null,
  //     isLeaf: false,
  //     disabled: false,
  //     checkable: true,
  //   },
  // ],
  checkedKeys21: '',
  checkedKeys11: [],
  checkedKeys2: '1367766865382461960',
  checkedKeys1: [],
  checkedKeys: [
    {
      id: '1367766865382411521',
      name: '牛魔王',
      level: 2,
    },
    {
      id: '1367766865382461945',
      name: '无法无天',
      level: 2,
    },
    // {
    //   id: '1362563485377078884',
    //   name: '开发团队云组织一项目一172',
    //   level: 0,
    // },
  ],
  checkedKeys1s: [],
  checkedKeyss: [
    {
      id: '73',
      name: '幼儿园',
      level: 2,
      locationName: null,
      identifier: null,
      parentId: '172',
      key: '73',
      isLeaf: false,
      disabled: false,
      checkable: true,
      label: '幼儿园',
      value: '73',
      originLabel: '幼儿园',
    },
    {
      id: '74',
      name: '小学',
      level: 2,
      locationName: null,
      identifier: null,
      parentId: '172',
      key: '74',
      isLeaf: false,
      disabled: false,
      checkable: true,
      label: '小学',
      value: '74',
      originLabel: '小学',
    },
  ],
  checkedKeys11s: '',
  // checkedKeys: [
  //   {
  //     id: '1367766865382455209',
  //     name: '小高',
  //     level: 2,
  //     isLeaf: true,
  //     checkable: true,
  //     locationName: 'devcloud',
  //     phoneNumber: '15659803847',
  //     avatar: null,
  //     position: '',
  //   },
  //   {
  //     id: '1367766865382461850',
  //     name: '张帅二',
  //     level: 2,
  //     isLeaf: true,
  //     checkable: true,
  //     locationName: 'devcloud',
  //     phoneNumber: '15013131313',
  //     avatar: null,
  //     position: '主管',
  //     disabled: false,
  //   },
  // ],
  acrossStudentScope: [
    {
      id: '1000',
      name: '小学',
      level: 2,
    },
  ],
  position: ['23725'],
  // position: '23725',
  // separatedPerson: '1367766865382464284',
  separatedPerson: ['1367766865382464284', '1367766865382718132'],
});

const disabledIds = ref<string[]>(['1367766865382461834']);

const checkedKeys2 = ref([]);
const checkedNodes2 = ref<SelectorItem[]>([]);

const handleChange = (value: SelectorItem[]) => {
  console.log('form 选中的值', { value });
};
const handleChange2 = (value: SelectorItem[], nodes: SelectorItem[]) => {
  console.log('选中的值', { value, nodes });
  checkedNodes2.value = nodes || [];
};

const onFinish = (values: any) => {
  console.log('Success:', values);
};

const onFinishFailed = (errorInfo: any) => {
  console.log('Failed:', errorInfo);
};

onMounted(() => {
  // setTimeout(() => {
  //   formState.checkedKeys = [
  //     {
  //       id: '1367766865382461850',
  //       name: '张帅二',
  //       level: 2,
  //       isLeaf: true,
  //       checkable: true,
  //       locationName: 'devcloud',
  //       phoneNumber: '15013131313',
  //       avatar: null,
  //       position: '主管',
  //       disabled: false,
  //     },
  //   ];
  //   formState.checkedKeys1 = ['1367766865382461850'];
  // }, 2000);
});

const onShow = () => {
  selectorAcrossLocationPersonRef.value?.open();
};
</script>

<template>
  <div style="background-color: #fff; padding: 20px; overflow: scroll">
    <Button
      style="width: 200px"
      @click="
        disabledIds = [
          '1367766865382409452',
          '1367766865382461834',
          '1367766865382461884',
          '1367766865382378215',
          '1687081133557846017',
          '21',
          '1666386106619977729',
        ]
      "
    >
      点击改变disabled
    </Button>
    <p style="margin: 20px 10px 10px">默认下拉框 form 里面使用</p>

    <Form
      :model="formState"
      name="basic"
      :label-col="{ span: 4 }"
      :wrapper-col="{ span: 14 }"
      autocomplete="off"
      @finish="onFinish"
      @finishFailed="onFinishFailed"
    >
      <Form.Item label="选择离职人员">
        <SelectorSeparatedPerson
          :multiple="true"
          v-model:value="formState.separatedPerson"
          :disabled-item-ids="['1367766865382454815']"
        ></SelectorSeparatedPerson>
      </Form.Item>
      <Form.Item label="选择职位">
        <SelectorPosition :multiple="true" v-model:value="formState.position"></SelectorPosition>
      </Form.Item>
      <Form.Item label="选择组织弹窗">
        <SelectorLocationModal
          :multiple="true"
          v-model:value="formState.location"
          :disabled-item-ids="['2222', '2111']"
        ></SelectorLocationModal>
      </Form.Item>
      <Form.Item
        label="Username"
        name="username"
        :rules="[{ required: true, message: 'Please input your username!' }]"
      >
        <Input v-model:value="formState.username" />
      </Form.Item>
      <Form.Item
        label="选择年级/班级"
        name="clazz"
        :rules="[{ required: true, message: '选择年级/班级必填' }]"
      >
        <SelectorGradeClass
          v-model:value="formState.clazz"
          :disabled-item-ids="['1670740543826100226', '73']"
          :scope="StudentItemLevelEnum.class"
        />
      </Form.Item>

      <Form.Item label="单选班级">
        <SelectorGradeClass :multiple="false" :scope="StudentItemLevelEnum.class" />
      </Form.Item>

      <Form.Item label="单选年级" name="clazz1" :rules="[{ required: true, message: '年级必填' }]">
        <SelectorGradeClass
          v-model:value="formState.clazz1"
          :multiple="false"
          :scope="StudentItemLevelEnum.grade"
        />
      </Form.Item>
      <Form.Item label="单选跨组织学生" name="clazz21">
        <SelectorAcrossLocationStudent v-model:value="formState.clazz21" :multiple="false" />
      </Form.Item>
      <Form.Item
        label="跨组织选择学生"
        name="clazz11"
        :rules="[{ required: true, message: '选择学生必填' }]"
      >
        <SelectorAcrossLocationStudent
          v-model:value="formState.clazz11"
          :disabled-item-ids="['1670740543826100226', '73']"
        />
      </Form.Item>
      <Form.Item
        label="单选跨组织选择人员"
        name="checkedKeys21"
        :rules="[{ required: true, message: '选择人员必填' }]"
      >
        <SelectorAcrossLocationPerson v-model:value="formState.checkedKeys21" :multiple="false" />
      </Form.Item>
      <Form.Item
        label="跨组织选择人员"
        name="checkedKeys11"
        :rules="[{ required: true, message: '选择人员必填' }]"
      >
        <SelectorAcrossLocationPerson
          v-model:value="formState.checkedKeys11"
          :disabled-item-ids="disabledIds"
        />
      </Form.Item>
      <Form.Item
        label="单选选择人员"
        name="checkedKeys2"
        :rules="[{ required: true, message: '选择人员必填' }]"
      >
        <SelectorPerson v-model:value="formState.checkedKeys2" :multiple="false" />
      </Form.Item>
      <Form.Item
        label="选择人员"
        name="checkedKeys1"
        :rules="[{ required: true, message: '选择人员必填' }]"
      >
        <SelectorPerson
          v-model:value="formState.checkedKeys1"
          :disabled-item-ids="disabledIds"
          @change="(keys: any) => console.log(keys, 1111)"
        />
      </Form.Item>
      <Form.Item
        label="选择人员范围"
        name="checkedKeys"
        :rules="[{ required: true, message: '给我填 ！！！' }]"
      >
        <SelectorPersonScope
          v-model:value="formState.checkedKeys"
          :disabled-item-ids="disabledIds"
          title="自定义弹窗标题"
          placeholder="自定义"
          @change="handleChange"
        />
      </Form.Item>

      <Form.Item
        label="单选选择学生"
        name="checkedKeys11s"
        :rules="[{ required: true, message: '选择学生必填' }]"
      >
        <SelectorStudent
          v-model:value="formState.checkedKeys11s"
          :multiple="false"
          :disabled-item-ids="disabledIds"
          placeholder="选择111111111个"
          @change="(keys: any) => console.log(keys, 1111)"
        />
      </Form.Item>

      <Form.Item
        label="选择学生"
        name="checkedKeys1s"
        :rules="[{ required: true, message: '选择学生必填' }]"
      >
        <SelectorStudent
          v-model:value="formState.checkedKeys1s"
          :disabled-item-ids="disabledIds"
          @change="(keys: any) => console.log(keys, 1111)"
        />
      </Form.Item>
      <Form.Item
        label="选择学生范围"
        name="checkedKeyss"
        :rules="[{ required: true, message: '给我填 ！！！' }]"
      >
        <SelectorStudentScope
          v-model:value="formState.checkedKeyss"
          :disabled-item-ids="disabledIds"
          title="自定义弹窗标题"
          placeholder="自定义"
          @change="handleChange"
        />
      </Form.Item>
      <Form.Item
        label="选择部门"
        name="department"
        :rules="[{ required: true, message: '部门必选' }]"
      >
        <SelectorDepartment treeCheckable treeCheckStrictly v-model:value="formState.department" />
      </Form.Item>
      <Form.Item
        label="单选部门"
        name="department1"
        :rules="[{ required: true, message: '部门必选' }]"
      >
        <SelectorDepartment
          :multiple="false"
          v-model:value="formState.department1"
          placeholder="请选择一个部门1111111111111"
        />
      </Form.Item>
      <Form.Item
        label="选择组织"
        name="location"
        :rules="[{ required: true, message: '选择组织必填' }]"
      >
        <SelectorLocation v-model:value="formState.location" :disabled-item-ids="['172']" />
      </Form.Item>
      <Form.Item label="选择部门">
        <SelectorDepartment />
      </Form.Item>
      <Form.Item label="选择组织">
        <SelectorLocation />
      </Form.Item>
      <Form.Item label="跨组织选择学生范围" name="acrossStudentScope">
        <SelectorAcrossLocationStudentScope
          :root-selectable="true"
          v-model:value="formState.acrossStudentScope"
        />
      </Form.Item>
      <Form.Item label="跨组织选择人员范围">
        <SelectorAcrossLocationPersonScope :root-selectable="true" />
      </Form.Item>
      <Form.Item label="单选空间">
        <SelectorSpace :multiple="false" />
      </Form.Item>
      <Form.Item label="选择空间" name="space">
        <SelectorSpace v-model:value="formState.space" />
      </Form.Item>
      <Form.Item
        label="选择设备"
        name="devices"
        :rules="[{ required: true, message: '选择设备必填' }]"
      >
        <SelectorDevice
          v-model:value="formState.devices"
          :disabled-item-ids="['1510173162823110657', '1510217804124491777']"
        />
      </Form.Item>

      <Form.Item
        label="选择设备范围"
        name="deviceScope"
        :rules="[{ required: true, message: '选择设备必填' }]"
      >
        <SelectorDeviceScope
          v-model:value="formState.deviceScope"
          :disabled-item-ids="['1510173162823110657', '1510217804124491777']"
        />
      </Form.Item>
      <Form.Item :wrapper-col="{ offset: 8, span: 16 }">
        <Button type="primary" html-type="submit">Submit</Button>
      </Form.Item>
    </Form>

    <SelectorPersonScope v-model:value="checkedKeys2" @change="handleChange2">
      <template #trigger="{ show }">
        <Button style="width: 140px" @click="show">选择人员</Button>
      </template>
    </SelectorPersonScope>

    <pre style="margin-top: 10px; max-height: 200px; overflow: scroll">{{
      JSON.stringify(checkedKeys2, null, ' ')
    }}</pre>

    <div style="width: 200px">
      <SelectorAcrossLocationPerson @change="console.log" />
    </div>

    <SelectorAcrossLocationPerson
      ref="selectorAcrossLocationPersonRef"
      @change="console.log"
      :showTrigger="false"
    />

    <Button style="width: 140px" @click="onShow">打开弹窗</Button>
  </div>
</template>
