<script lang="ts" setup>
import { computed, onBeforeMount, reactive, ref, watch } from 'vue';
import { Form, message, Select, Tabs } from 'ant-design-vue';
import {
  cloneDeep,
  filter,
  find,
  forEach,
  includes,
  isEqual,
  map,
  remove,
  uniqBy,
} from 'lodash-es';
import { useHttp, useLocationId } from '../../hooks';
import TreeSelectPane from './components/TreeSelectPane.vue';
import { getTreeItems } from './utils';
import { PersonItemLevelEnum, SelectorShowTypeEnum } from './types';
import type {
  SelectorItem,
  PersonScopeProps,
  SelectorEmits,
  SelectorScopeValue,
  PersonScopeScope,
} from './types';
import Item from './components/Item.vue';
import SelectorWrap from './components/SelectorWrap.vue';
import usePersonItemsData from './components/usePersonItemsData';

defineOptions({
  name: 'SelectorPersonScope',
});

const props = withDefaults(defineProps<PersonScopeProps>(), {
  title: '选择人员范围',
  placeholder: '请选择人员范围',
  showTrigger: true,
});

const emit = defineEmits<SelectorEmits<SelectorItem, SelectorItem[]>>();

const fieldNames = {
  label: 'name',
  value: 'id',
};

const formItemContext = Form.useInjectFormItemContext();

const http = useHttp();
const { personItemsMap, getPersonItemKey } = usePersonItemsData();

const selectorWrapRef = ref();

const _scope = props.scope || [
  PersonItemLevelEnum.location,
  PersonItemLevelEnum.role,
  PersonItemLevelEnum.userGroup,
];

const tabData = [
  {
    key: PersonItemLevelEnum.location,
    tab: '组织架构',
    searchPlaceholder: '搜索部门或人员',
    showType: SelectorShowTypeEnum.tree,
    uri: '/api/auth/userSelect/locationPersons',
  },
  {
    key: PersonItemLevelEnum.role,
    tab: '角色',
    searchPlaceholder: '搜索角色',
    showType: SelectorShowTypeEnum.list,
    uri: '/api/auth/userSelect/locationRoles',
  },
  {
    key: PersonItemLevelEnum.userGroup,
    tab: '用户组',
    searchPlaceholder: '搜索用户组',
    showType: SelectorShowTypeEnum.list,
    uri: '/api/auth/userSelect/locationUserGroups',
  },
].filter((i) => _scope.includes(i.key as PersonScopeScope));

const activeTab = ref(tabData[0].key);

type TreeDataMap = Record<
  number,
  {
    loading: boolean;
    data: SelectorItem[];
    checked: SelectorItem[];
  }
>;

const treeDataMap = reactive<TreeDataMap>(
  tabData.reduce((all: TreeDataMap, i) => {
    all[i.key] = {
      loading: false,
      data: [],
      checked: [],
    };
    return all;
  }, {}),
);
/** 用户点击确定的最终值 */
const finalValue = ref<SelectorScopeValue[]>([]);
/** 选中的数据集合，右边已选数据源 */
const checkedNodes = ref<SelectorItem[]>([]);
/** 临时存储打开时选中数据，中途删除，用户点取消时弹窗取消时需要撤销 */
const snapCheckedNodes = ref<SelectorItem[]>([]);

const locationId = computed(() => {
  return props.locationId || useLocationId().value;
});

watch(
  () => props.disabledItemIds,
  (newVal) => {
    if (!newVal) {
      return;
    }
    Object.keys(treeDataMap).forEach((key: any) => {
      treeDataMap[key].data = getTreeItems(cloneDeep(treeDataMap[key].data) as SelectorItem[], {
        disabledIds: newVal,
      });
    });
  },
);

// 更新值
watch(finalValue, (newVal, oldVal) => {
  /** 下拉框回来的值需要处理，有时候只有 label 和 value */
  const _newVal = map(newVal, (i) => {
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const { option, ...rest } = i;
    if (option) {
      return {
        ...option,
        ...rest,
      };
    }
    return i;
  });

  emit('update:value', _newVal);

  formItemContext.onFieldChange();

  const _newValIds = _newVal.map((i) => i.id);

  // 下拉框删除，同时更新弹窗的选中数据
  if (newVal.length < oldVal.length) {
    checkedNodes.value = filter(checkedNodes.value, (i) => _newValIds.includes(i.id));
  }

  if (
    !isEqual(
      _newValIds,
      map(props.value, (i) => i.id),
    )
  ) {
    /** 选中值改变的回调 */
    emit(
      'change',
      _newVal,
      filter(checkedNodes.value, (i) => _newValIds.includes(i.id)),
    );
  }
});

watch(
  () => props.value,
  (newVal) => {
    if (
      isEqual(
        map(newVal, (i) => i.id),
        map(finalValue.value, (i) => i.id),
      )
    ) {
      return;
    }

    // 清空
    if (!newVal || !newVal?.length) {
      finalValue.value = [];
      checkedNodes.value = [];
      return;
    }

    finalValue.value = map(cloneDeep(newVal), (i) => ({
      ...i,
      key: i.key || i.id,
      value: i.id,
      label: i.name,
      disabled: props.disabledItemIds?.includes(i.id),
    }));

    checkedNodes.value = cloneDeep(finalValue.value);
  },
);

// 选择人员弹窗
const onOpen = () => {
  // 每次打开存储临时缓存，
  // 用户删除后，点击取消时有可能需要撤销回去
  snapCheckedNodes.value = cloneDeep(checkedNodes.value);
};

// 已选人员删除
const onRemove = (item: SelectorItem) => {
  if (!item) {
    return;
  }
  checkedNodes.value = checkedNodes.value.filter((i) => i.id !== item.id);
};

// 确定选择人员
const onOk = () => {
  finalValue.value = map(cloneDeep(checkedNodes.value), (i) => ({
    ...i,
    value: i.id,
    label: i.name,
  }));
  // 关闭清空临时存储的选择数据
  snapCheckedNodes.value = [];
};

// 关闭选择人员弹窗
const onCancel = () => {
  // 点击取消恢复上次确定的内容
  if (finalValue.value.length) {
    const _items = map(finalValue.value, (i) => {
      // 先查找是否在选中的数据中
      const c = find(checkedNodes.value, (j) => j.id === i.value);
      if (c) {
        return c;
      }
      // 没有则是上次选中的数据里
      return find(snapCheckedNodes.value, (j) => j.id === i.value);
    }).filter(Boolean);
    checkedNodes.value = cloneDeep(_items) as SelectorItem[];
  } else {
    checkedNodes.value = [];
  }
  // 关闭清空临时存储的选择数据
  snapCheckedNodes.value = [];
};
// 清空
const onClearAll = () => {
  // disabled 不能清
  checkedNodes.value = checkedNodes.value.filter((i) => i.disabled);
};
// 当前页签选中的数据，用来查找，当前勾选或者反选的数据
const currentTabCheckedIds = computed(() => {
  if (activeTab.value === PersonItemLevelEnum.location) {
    return checkedNodes.value
      .filter((i) =>
        [
          PersonItemLevelEnum.location,
          PersonItemLevelEnum.department,
          PersonItemLevelEnum.user,
        ].includes(i.level as PersonItemLevelEnum),
      )
      .map((i) => i.id);
  }
  return checkedNodes.value.filter((i) => i.level === activeTab.value).map((i) => i.id);
});

// 树选择选中值发生变化的回调
const onChecked = (checkedValue: string[], e: any) => {
  const _checkedNodes = (e?.checkedNodes || []) as SelectorItem[];

  // 全量替换当前 tab 选中的值
  const _newData = uniqBy(
    cloneDeep([
      ...checkedNodes.value.filter((i) => !currentTabCheckedIds.value.includes(i.id)),
      ..._checkedNodes,
    ]),
    'id',
  );

  if (e.checked) {
    // 选中，添加并去重
    return _newData;
  }

  // 取消选中的
  const _removeKeys = remove(currentTabCheckedIds.value, (i) => !includes(checkedValue, i));
  // 从选中的人员里面过滤被删除的
  return filter(_newData, (i) => !_removeKeys.includes(i.id));
};

const fetchTreeData = async (key: PersonItemLevelEnum, uri: string) => {
  try {
    treeDataMap[key].loading = true;
    const res = await http.get<SelectorItem[]>(uri, { locationId: locationId.value });
    treeDataMap[key].data = getTreeItems(cloneDeep(res || []), {
      disabledIds: props.disabledItemIds,
      getPersonItemKey,
    });
  } catch (error: any) {
    message.error(error?.desc || '获取数据出错，请重试');
  } finally {
    treeDataMap[key].loading = false;
  }
};

const onShow = (show: () => void) => {
  if (!props.disabled) {
    show();
  }
};

const open = () => {
  selectorWrapRef.value?.showModal();
};

defineExpose({ open });

onBeforeMount(() => {
  // 初始值
  if (props.value?.length) {
    finalValue.value = map(cloneDeep(props.value), (i) => ({
      ...i,
      key: i.key || i.id,
      value: i.id,
      label: i.name,
      disabled: props.disabledItemIds?.includes(i.id),
    }));

    checkedNodes.value = cloneDeep(finalValue.value);
  }

  forEach(tabData, (i) => fetchTreeData(i.key, i.uri));
});
</script>

<template>
  <SelectorWrap
    ref="selectorWrapRef"
    :title="title"
    :checked-length="checkedNodes.length"
    @open="onOpen"
    @ok="onOk"
    @cancel="onCancel"
    @clear-all="onClearAll"
  >
    <template v-if="showTrigger" #select="{ show }">
      <slot name="trigger" :show="show">
        <Select
          v-model:value="finalValue"
          labelInValue
          style="width: 100%"
          :placeholder="placeholder"
          max-tag-count="responsive"
          mode="multiple"
          :fieldNames="fieldNames"
          :options="checkedNodes"
          :open="false"
          :disabled="disabled"
          @click="onShow(show)"
        ></Select>
      </slot>
    </template>
    <template #select-data>
      <Tabs prefixCls="person-scope-selector-tabs" v-model:activeKey="activeTab" size="small">
        <Tabs.TabPane v-for="item in tabData" :key="item.key" :tab="item.tab">
          <TreeSelectPane
            v-model:checked="checkedNodes"
            description-key="position"
            :show-checked-strategy="
              item.key === PersonItemLevelEnum.location ? 'SHOW_PARENT' : 'SHOW_ALL'
            "
            :max-count="maxCount"
            :loading="treeDataMap[item.key].loading"
            :tree-data="treeDataMap[item.key].data"
            :search-placeholder="item.searchPlaceholder"
            :show-type="item.showType"
            :extraHeight="46"
            :items-checked-map="
              item.key === PersonItemLevelEnum.location ? personItemsMap : undefined
            "
            :on-checked="onChecked"
          />
        </Tabs.TabPane>
      </Tabs>
    </template>
    <template #select-result>
      <Item
        v-for="item in checkedNodes"
        allow-clear
        :key="item.id"
        :data="item"
        :description="item.position"
        @remove="onRemove"
      ></Item>
    </template>
  </SelectorWrap>
</template>

<style lang="scss" scoped>
:deep(.person-scope-selector-tabs-nav) {
  margin: 8px 20px 0px 0;
}
</style>
