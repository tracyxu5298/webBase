<script lang="ts" setup>
import { reactive, onBeforeMount, ref, unref, computed, watch } from 'vue';
import { Http } from '@lexikos/doraemon-network';
import {
  message,
  Select,
  Table,
  Modal,
  Spin,
  Form,
  FormItem,
  InputSearch,
  type FormInstance,
} from 'ant-design-vue';
import {
  type LocationTreeSelectorProps,
  type LocationSelectorItem,
  LocationScopeEnum,
} from './types';
import { isEqual } from 'lodash-es';

defineOptions({
  name: 'SelectorLocation',
});

const props = withDefaults(defineProps<LocationTreeSelectorProps>(), {
  multiple: true,
  scope: LocationScopeEnum.all,
  placeholder: '请选择组织',
});

const emit = defineEmits<{
  (event: 'update:value', value: string | string[]): void;
}>();

const formItemContext = Form.useInjectFormItemContext();
const open = ref<boolean>(false);
const loading = ref<boolean>();
const data = ref<any[]>([]);
const finalValue = ref<string | string[]>();
// const checkedNodes = ref<SelectorItem[]>([]);

const displayData = computed(() => {
  if (formState.name || formState.schoolGrade > -1 || formState.schoolType > -1) {
    const temp: any[] = [];
    data.value.forEach((item) => {
      if (
        !(
          (formState.name && item.name.indexOf(formState.name) === -1) ||
          (formState.schoolGrade > -1 &&
            (!item.schoolGradeList ||
              item.schoolGradeList.indexOf(formState.schoolGrade) === -1)) ||
          (formState.schoolType > -1 &&
            (!item.schoolType || item.schoolType.indexOf(formState.schoolType) === -1))
        )
      ) {
        temp.push(item);
      }
    });
    return temp;
  }
  return data.value;
});

const fieldNames = {
  label: 'name',
  value: 'id',
};

const schoolGradeLabel = {
  0: '幼儿园',
  1: '小学',
  2: '初中',
  3: '高中',
  4: '大学',
  5: '中高职',
};

const schoolTypeLabel = {
  0: '公立',
  1: '私立',
};

const schoolGradeOptions = [
  { value: -1, label: '全部学段' },
  { value: 0, label: schoolGradeLabel[0] },
  { value: 1, label: schoolGradeLabel[1] },
  { value: 2, label: schoolGradeLabel[2] },
  { value: 3, label: schoolGradeLabel[3] },
  { value: 4, label: schoolGradeLabel[4] },
  { value: 5, label: schoolGradeLabel[5] },
];

const schoolTypeOptions = [
  { value: -1, label: '全部主体' },
  { value: 0, label: schoolTypeLabel[0] },
  { value: 1, label: schoolTypeLabel[1] },
];

const formRef = ref<FormInstance>();
const formState = reactive({
  name: undefined,
  schoolGrade: -1,
  schoolType: -1,
});

const columns = [
  {
    title: '姓名',
    dataIndex: 'name',
    key: 'name',
  },
  {
    title: '学段类型',
    dataIndex: 'schoolGradeList',
    key: 'schoolGradeList',
    customRender: (value: { text: (keyof typeof schoolGradeLabel)[] }) =>
      value.text.map((key) => schoolGradeLabel[key]).join('/') || '/',
  },
  {
    title: '办学主体',
    dataIndex: 'schoolType',
    key: 'schoolType',
    customRender: (value: { text: keyof typeof schoolTypeLabel }) =>
      schoolTypeLabel[value.text] || '/',
  },
];

const rowSelection = reactive<{ selectedRowKeys: string[]; selectedRow: any[] }>({
  selectedRowKeys: [],
  selectedRow: [],
});

const setCheckboxProps = (item: any) => {
  const chkProps: any = {};
  if (props.disabledItemIds && item.id && props.disabledItemIds.indexOf(item.id) !== -1) {
    chkProps.disabled = true;
  }
  return chkProps;
};

const onSelectChange = (selectedRowKeys: (string | number)[], selectedRow: any[]) => {
  rowSelection.selectedRowKeys = selectedRowKeys as string[];
  rowSelection.selectedRow = selectedRow as any[];
};

const fetch = async () => {
  if (loading.value) {
    return;
  }
  try {
    loading.value = true;
    const res = await Http.getInstance().get<LocationSelectorItem[]>(
      '/api/auth/userSelect/locationRelationship',
      {
        scope: props.scope,
        locationId: props.locationId || '',
      },
    );
    data.value = res || [];
  } catch (error: any) {
    data.value = [];
    message.error(error?.desc || '获取数据出错，请重试');
  } finally {
    loading.value = false;
  }
};

const handleOpen = () => {
  rowSelection.selectedRowKeys = unref(finalValue);
  formState.name = undefined;
  formState.schoolGrade = -1;
  formState.schoolType = -1;
  open.value = true;
};

const handleOk = () => {
  // checkedNodes.value = unref(rowSelection.selectedRow);
  finalValue.value = unref(rowSelection.selectedRowKeys);
  emit('update:value', unref(rowSelection.selectedRowKeys));
  formItemContext.onFieldChange();
  open.value = false;
};

const handleCancel = () => {
  open.value = false;
};

watch(
  () => props.value,
  (newVal) => {
    if (isEqual(newVal, finalValue.value)) {
      return;
    }
    finalValue.value = newVal;
  },
  { immediate: true },
);
watch(
  finalValue,
  (newVal) => {
    emit('update:value', newVal!);
    formItemContext.onFieldChange();
  },
  { immediate: true },
);

onBeforeMount(() => {
  fetch();
});
</script>

<template>
  <Select
    :open="false"
    :mode="!multiple ? undefined : 'multiple'"
    max-tag-count="responsive"
    style="width: 100%"
    v-model:value="finalValue"
    :fieldNames="fieldNames"
    :loading="loading"
    :options="data"
    :placeholder="placeholder"
    @click="handleOpen"
  ></Select>
  <Modal
    v-if="open"
    destroyOnClose
    width="800px"
    :body-style="{ height: '530px' }"
    centered
    title="选择组织"
    :open="open"
    :maskClosable="false"
    @ok="handleOk"
    @cancel="handleCancel"
  >
    <Spin :spinning="false">
      <div class="form-header">
        <Form name="searchForm" ref="formRef" :model="formState" autocomplete="off" layout="inline">
          <FormItem name="name">
            <InputSearch placeholder="搜索组织" v-model:value="formState.name" />
          </FormItem>
          <FormItem name="schoolGrade">
            <Select
              placeholder="选择学段类型"
              v-model:value="formState.schoolGrade"
              :options="schoolGradeOptions"
              style="width: 160px"
            ></Select>
          </FormItem>
          <FormItem name="schoolType">
            <Select
              placeholder="选择办学主体"
              v-model:value="formState.schoolType"
              :options="schoolTypeOptions"
              style="width: 160px"
            ></Select>
          </FormItem>
        </Form>
      </div>
      <Table
        rowKey="id"
        size="small"
        :scroll="{ y: '60vh' }"
        :data-source="displayData"
        :loading="loading"
        :columns="columns"
        :showExpandColumn="false"
        :row-selection="{
          type: !multiple ? 'radio' : 'checkbox',
          selectedRowKeys: rowSelection.selectedRowKeys,
          getCheckboxProps: setCheckboxProps,
          hideDefaultSelections: true,
          selections: [Table.SELECTION_ALL, Table.SELECTION_INVERT, Table.SELECTION_NONE],
          onChange: onSelectChange,
        }"
      />
    </Spin>
  </Modal>
</template>

<style lang="scss" scoped>
.form-header {
  margin: 8px 0;
}
</style>
