<script lang="ts" setup>
import { computed, unref, ref, watch } from 'vue';
import { Form, message, Select } from 'ant-design-vue';
import { cloneDeep, concat, find, isArray, isEqual, map, filter, uniqBy } from 'lodash-es';
import { useHttp, useLocationId } from '../../hooks';
import TreeSelectPane from './components/TreeSelectPane.vue';
import { getTreeItems, filterItemsByIds } from './utils';
import {
  PersonItemLevelEnum,
  type SelectorItem,
  type SelectorProps,
  type SelectorEmits,
} from './types';
import Item from './components/Item.vue';
import SelectorWrap from './components/SelectorWrap.vue';
import usePersonItemsData from './components/usePersonItemsData';

defineOptions({
  name: 'SelectorPerson',
});

const props = withDefaults(defineProps<SelectorProps>(), {
  multiple: true,
  title: '选择人员',
  placeholder: '请选择人员',
  showTrigger: true,
});

const emit = defineEmits<SelectorEmits<SelectorItem, string | string[]>>();

const fieldNames = {
  label: 'name',
  value: 'id',
};

const formItemContext = Form.useInjectFormItemContext();

const http = useHttp();
const { personItemsMap, getPersonItemKey } = usePersonItemsData();

const isInit = ref<boolean>();
// 用户点击确定的值
const treeData = ref<SelectorItem[]>([]);
const finalValue = ref<string | string[]>();
const checkedNodes = ref<SelectorItem[]>([]);
const loading = ref<boolean>(false);
const loadingDefaultUser = ref<boolean>(false);
/** 临时存储打开时选中数据，中途删除，用户点取消时弹窗取消时需要撤销 */
const snapCheckedNodes = ref<SelectorItem[]>([]);
const selectorWrapRef = ref();
const locationId = computed(() => {
  return props.locationId || useLocationId().value;
});

// 单选并且选中的就是不可反选的则 disabled
const disabled = computed(
  () => props.disabled || (!props.multiple && checkedNodes.value[0]?.disabled),
);

/**
 * 编辑时回显用户信息
 */
const fetchUserInfo = async (userIds: string | string[]) => {
  if (!userIds || !userIds?.length) {
    return;
  }

  try {
    loadingDefaultUser.value = true;
    const res = await http.post<SelectorItem[]>(
      '/api/auth/userSelect/users',
      isArray(userIds) ? userIds : [userIds],
    );

    loadingDefaultUser.value = false;

    return (res || []).map((i) => {
      if (i.departmentIds?.length) {
        i.departmentIds.forEach((d: string) => {
          getPersonItemKey(i.id, d);
        });
      }
      return {
        ...i,
        disabled: props.disabledItemIds?.includes(i.id),
      };
    });
  } catch (error: any) {
    loadingDefaultUser.value = false;
    message.error(error?.desc || '获取数据出错，请重试');
    return [];
  }
};

const finallyTreeData = computed(() => {
  if (!treeData.value) {
    return [];
  }
  return getTreeItems(cloneDeep(treeData.value), {
    disabledIds: props.disabledItemIds,
    getCheckable: (level) => level === PersonItemLevelEnum.user,
    getPersonItemKey,
  });
});

// 更新值
watch(finalValue, (newVal, oldVal) => {
  emit('update:value', newVal!);

  formItemContext.onFieldChange();

  const _checkedNodes = newVal
    ? checkedNodes.value.filter((i) => (isArray(newVal) ? newVal.includes(i.id) : newVal === i.id))
    : [];

  // 多选
  if (isArray(newVal)) {
    // 下拉框删除
    if (oldVal && newVal.length < oldVal.length) {
      checkedNodes.value = cloneDeep(_checkedNodes);
    }
  } else {
    // 单选时没有值直接清空选中的节点
    if (!newVal) {
      checkedNodes.value = [];
    }
  }

  if (!isEqual(newVal, props.value)) {
    emit('change', newVal!, cloneDeep(_checkedNodes));
  }
});

const isNilOrEmptyArray = (val?: string | string[]) => {
  return !val || (Array.isArray(val) && !val.length);
};

watch(
  () => props.value,
  (newVal) => {
    if (
      isEqual(newVal, finalValue.value) ||
      (isNilOrEmptyArray(newVal) && isNilOrEmptyArray(finalValue.value))
    ) {
      return;
    }

    // 清空
    if (!newVal || !newVal?.length) {
      finalValue.value = newVal;
      checkedNodes.value = [];
      return;
    }

    // 单选
    if (!isArray(newVal)) {
      fetchUserInfo(newVal).then((res) => {
        checkedNodes.value = res as SelectorItem[];
        finalValue.value = newVal;
      });
      return;
    }

    // 多选
    const addIds: string[] = [];
    const result: SelectorItem[] = [];

    newVal.forEach((i) => {
      const _item = checkedNodes.value.find((j) => j.id === i);
      if (_item) {
        result.push(_item);
      } else {
        addIds.push(i);
      }
    });

    // 外部增加值
    if (addIds.length) {
      fetchUserInfo(addIds).then((res) => {
        checkedNodes.value = concat(result, res as SelectorItem[]);
      });
    } else {
      checkedNodes.value = cloneDeep(result);
    }

    finalValue.value = newVal;
  },
  {
    immediate: true,
  },
);

// 选择人员弹窗
const onOpen = () => {
  if (!isInit.value) {
    fetchTreeData();
  }
  // 每次打开存储临时缓存，
  // 用户删除后，点击取消时有可能需要撤销回去
  snapCheckedNodes.value = cloneDeep(checkedNodes.value);
};
// 已选人员删除
const onRemove = (item: SelectorItem) => {
  if (!item) {
    return;
  }
  checkedNodes.value = checkedNodes.value.filter((i) => i.id !== item.id);
};

// 确定选择人员
const onOk = () => {
  if (props.multiple) {
    finalValue.value = checkedNodes.value.map((i) => i.id);
  } else {
    finalValue.value = checkedNodes.value[0]?.id;
  }
  // 关闭清空临时存储的选择数据
  snapCheckedNodes.value = [];
};

// 关闭选择人员弹窗
const onCancel = () => {
  // 点击取消恢复上次确定的内容
  if (props.multiple) {
    if (finalValue.value?.length) {
      const _items = map(finalValue.value, (i) => {
        // 先查找是否在选中的数据中
        const c = find(checkedNodes.value, (j) => j.id === i);
        if (c) {
          return c;
        }
        // 没有则是上次选中的数据里
        return find(snapCheckedNodes.value, (j) => j.id === i);
      }).filter(Boolean);

      checkedNodes.value = cloneDeep(_items) as SelectorItem[];
    } else {
      checkedNodes.value = [];
    }
  } else {
    checkedNodes.value = cloneDeep(snapCheckedNodes.value);
  }
  // 关闭清空临时存储的选择数据
  snapCheckedNodes.value = [];
};

const onClearAll = () => {
  // disabled 不能清
  checkedNodes.value = checkedNodes.value.filter((i) => i.disabled);
};

// 树选择选中值发生变化的回调
const onChecked = (checkedValue: string[], e: any) => {
  const _checkedNodes = (e?.checkedNodes || []) as SelectorItem[];

  if (e.checked) {
    // 选中，添加并去重
    return uniqBy(cloneDeep([...checkedNodes.value, ..._checkedNodes]), 'id');
  }

  // 取消选中的
  return filter(
    cloneDeep(checkedNodes.value),
    (i) => checkedValue.includes(i.id) || i.userStatus === 'deleted',
  );
};

const setDefaultValue = (items?: SelectorItem[]) => {
  if (!props.value || (props.multiple && !props.value.length)) {
    return;
  }
  if (!items?.length) {
    finalValue.value = props.value;
    return;
  }

  // 查找当前选中的数据
  let _checked = checkedNodes.value.length
    ? unref(checkedNodes)
    : filterItemsByIds(items, isArray(props.value) ? props.value : [props.value], []);
  if (props.disabledItemIds?.length) {
    _checked = _checked.map((i) => ({
      ...i,
      disabled: props.disabledItemIds!.includes(i.id),
    }));
  }

  checkedNodes.value = _checked;
  finalValue.value = props.value;
};

const fetchTreeData = async () => {
  try {
    loading.value = true;
    const res = await http.get<SelectorItem[]>('/api/auth/userSelect/locationPersons', {
      locationId: locationId.value,
    });
    treeData.value = res || [];
    setDefaultValue(res);
    isInit.value = true;
  } catch (error: any) {
    setDefaultValue();
    message.error(error?.desc || '获取数据出错，请重试');
    console.log('SelectorPerson', error);
  } finally {
    loading.value = false;
  }
};

const onShow = (show: () => void) => {
  if (!disabled.value) {
    show();
  }
};

const open = () => {
  selectorWrapRef.value?.showModal();
};

defineExpose({ open });
</script>

<template>
  <SelectorWrap
    ref="selectorWrapRef"
    :title="title"
    :checked-length="checkedNodes.length"
    @open="onOpen"
    @ok="onOk"
    @cancel="onCancel"
    @clear-all="onClearAll"
  >
    <template v-if="showTrigger" #select="{ show }">
      <slot name="trigger" :show="show">
        <Select
          style="width: 100%"
          max-tag-count="responsive"
          :mode="maxCount === 1 || !multiple ? undefined : 'multiple'"
          :loading="loading"
          v-model:value="finalValue"
          :fieldNames="fieldNames"
          :placeholder="placeholder"
          :options="checkedNodes"
          :open="false"
          :disabled="disabled"
          @click="onShow(show)"
        ></Select>
      </slot>
    </template>
    <template #select-data>
      <TreeSelectPane
        v-model:checked="checkedNodes"
        description-key="position"
        search-placeholder="搜索人员"
        :multiple="multiple"
        :max-count="maxCount"
        :loading="loading"
        :tree-data="finallyTreeData"
        :items-checked-map="personItemsMap"
        :on-checked="onChecked"
      />
    </template>
    <template #select-result>
      <Item
        v-for="item in checkedNodes"
        allow-clear
        :key="item.id"
        :data="item"
        :description="item.position"
        @remove="onRemove"
      ></Item>
    </template>
  </SelectorWrap>
</template>
