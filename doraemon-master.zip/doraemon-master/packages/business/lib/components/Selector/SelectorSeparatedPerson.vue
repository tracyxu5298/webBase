<script lang="ts" setup>
import { reactive, ref, unref, computed, watch } from 'vue';
import { Http } from '@lexikos/doraemon-network';
import {
  message,
  Select,
  Table,
  Modal,
  Spin,
  Form,
  FormItem,
  InputSearch,
  type TableProps,
} from 'ant-design-vue';
import type { SelectorItem } from './types';
import { type LocationTreeSelectorProps, LocationScopeEnum } from './types';
import { isEqual } from 'lodash-es';

defineOptions({
  name: 'SelectorSeparatedPerson',
});

const props = withDefaults(defineProps<LocationTreeSelectorProps>(), {
  multiple: true,
  scope: LocationScopeEnum.all,
  placeholder: '请选择离职人员',
});

const emit = defineEmits<{
  (event: 'update:value', value: string | string[]): void;
}>();

const open = ref<boolean>(false);
const loading = ref<boolean>();
const data = ref<any[]>([]);
const finalValue = ref<string[]>();
const checkedNodes = ref<SelectorItem[]>([]);

const displayData = computed(() => {
  return data.value;
});

const fieldNames = {
  label: 'userName',
  value: 'userId',
};

const pageData = reactive<{
  total: number;
  pageNum: number;
  pageSize: number;
  condition?: string;
}>({
  total: 0,
  pageNum: 1,
  pageSize: 10,
  condition: undefined,
});

const pagination = computed(() => ({
  total: pageData.total,
  current: pageData.pageNum,
  pageSize: pageData.pageSize,
  showSizeChanger: true,
}));

const columns = [
  {
    title: '姓名',
    dataIndex: 'userName',
    key: 'userName',
  },
  {
    title: '手机号',
    dataIndex: 'tel',
    key: 'tel',
  },
  {
    title: '工号',
    dataIndex: 'jobNo',
    key: 'jobNo',
  },
];

const rowSelection = reactive<{ selectedRowKeys: string[]; selectedRow: any[] }>({
  selectedRowKeys: [],
  selectedRow: [],
});

const setCheckboxProps = (item: any) => {
  const chkProps: any = {};
  if (props.disabledItemIds && item.userId && props.disabledItemIds.indexOf(item.userId) !== -1) {
    chkProps.disabled = true;
  }
  return chkProps;
};

const onSelectChange = (selectedRowKeys: (string | number)[], selectedRow: any[]) => {
  rowSelection.selectedRowKeys = selectedRowKeys as string[];
  rowSelection.selectedRow = selectedRow.map((row, index) => {
    if (!row) {
      return checkedNodes.value.find((item) => item.userId === selectedRowKeys[index]);
    }
    return row;
  });
};

const fetch = async (index?: number) => {
  if (loading.value) {
    return;
  }
  try {
    loading.value = true;
    const res = await Http.getInstance().post<any>('/api/auth/departureUsers/page', {
      pageNum: index || pageData.pageNum,
      pageSize: pageData.pageSize,
      condition: pageData.condition,
    });
    if (res) {
      data.value = res.result || [];
      if (res.total) pageData.total = res.total;
      if (res.pageNum) pageData.pageNum = res.pageNum;
      if (res.pageSize) pageData.pageSize = res.pageSize;
    }
  } catch (error: any) {
    data.value = [];
    message.error(error?.desc || '获取数据出错，请重试');
  } finally {
    loading.value = false;
  }
};

const fetchByUserIds = async (ids: string | string[]) => {
  if (!ids) {
    return false;
  }

  const userIds = Array.isArray(ids) ? ids : [ids];

  const res = await Http.getInstance().post<any>('/api/auth/departureUsers/page', {
    pageNum: 1,
    pageSize: userIds.length,
    userIds,
  });
  if (res) {
    checkedNodes.value = res.result;
  }
};

const handleSearch = (searchKey: string) => {
  pageData.condition = searchKey;
  fetch(1);
};

const handleTableChange: TableProps['onChange'] = (page) => {
  if (page.pageSize && page.pageSize !== pageData.pageSize) {
    pageData.pageSize = page.pageSize;
  }
  fetch(page.current);
};

const handleOpen = () => {
  pageData.condition = undefined;
  fetch(1);
  rowSelection.selectedRowKeys = unref(finalValue) || [];
  open.value = true;
};

const handleOk = () => {
  checkedNodes.value = unref(rowSelection.selectedRow);
  finalValue.value = unref(rowSelection.selectedRowKeys);
  emit('update:value', unref(rowSelection.selectedRowKeys));
  open.value = false;
};

const handleCancel = () => {
  open.value = false;
};

watch(
  () => props.value,
  (newVal) => {
    if (isEqual(newVal, finalValue.value)) {
      return;
    }

    finalValue.value = typeof newVal === 'string' ? [newVal] : newVal;

    if (props.value && !open.value && !checkedNodes.value.length) {
      fetchByUserIds(props.value);
    }
  },
  { immediate: true },
);

watch(
  finalValue,
  (newVal) => {
    emit('update:value', newVal!);
  },
  { immediate: true },
);
</script>

<template>
  <Select
    :open="false"
    :mode="!multiple ? undefined : 'multiple'"
    max-tag-count="responsive"
    allowClear
    style="width: 100%"
    v-model:value="finalValue"
    :fieldNames="fieldNames"
    :loading="loading"
    :options="checkedNodes"
    :placeholder="placeholder"
    @click="handleOpen"
  ></Select>
  <Modal
    v-if="open"
    destroyOnClose
    width="800px"
    :body-style="{ minHeight: '530px' }"
    centered
    title="选择离职人员"
    :open="open"
    :maskClosable="false"
    @ok="handleOk"
    @cancel="handleCancel"
  >
    <Spin :spinning="false">
      <div class="form-header">
        <Form name="searchForm" autocomplete="off" layout="inline">
          <FormItem name="name">
            <InputSearch allowClear placeholder="搜索姓名/手机号/工号" @search="handleSearch" />
          </FormItem>
        </Form>
      </div>
      <Table
        rowKey="userId"
        size="small"
        :scroll="{ y: '60vh' }"
        :data-source="displayData"
        :pagination="pagination"
        :loading="loading"
        :columns="columns"
        :showExpandColumn="false"
        :row-selection="{
          type: !multiple ? 'radio' : 'checkbox',
          selectedRowKeys: rowSelection.selectedRowKeys,
          getCheckboxProps: setCheckboxProps,
          hideDefaultSelections: true,
          preserveSelectedRowKeys: true,
          onChange: onSelectChange,
        }"
        @change="handleTableChange"
      />
    </Spin>
  </Modal>
</template>

<style lang="scss" scoped>
.form-header {
  margin: 8px 0;
}
</style>
