<script lang="ts" setup>
import { computed, onBeforeMount, ref, watch } from 'vue';
import { Form, message, Select } from 'ant-design-vue';
import { cloneDeep, filter, find, includes, isEqual, map, uniqBy } from 'lodash-es';
import { useHttp, useLocationId } from '../../hooks';
import TreeSelectPane from './components/TreeSelectPane.vue';
import { getTreeItems, searchPagesize } from './utils';
import {
  StudentItemLevelEnum,
  LocationScopeEnum,
  type SelectorItem,
  type SelectorEmits,
  type AcrossLocationStudentScopeProps,
  type SearchParams,
} from './types';
import Item from './components/Item.vue';
import SelectorWrap from './components/SelectorWrap.vue';
import { LocationLevel } from '../../enums';

defineOptions({
  name: 'SelectorAcrossLocationStudentScope',
});

const props = withDefaults(defineProps<AcrossLocationStudentScopeProps>(), {
  scope: LocationScopeEnum.all,
  title: '选择学生范围',
  placeholder: '请选择学生范围',
  showTrigger: true,
});

const emit = defineEmits<SelectorEmits<SelectorItem, SelectorItem[]>>();

const fieldNames = {
  label: 'name',
  value: 'id',
};

const formItemContext = Form.useInjectFormItemContext();

const http = useHttp();

// 用户点击确定的值
const treeData = ref<SelectorItem[]>([]);
const finalValue = ref<SelectorItem[]>([]);
const checkedNodes = ref<SelectorItem[]>([]);
const loading = ref<boolean>(false);
const loadingDefaultUser = ref<boolean>(false);
/** 临时存储打开时选中数据，中途删除，用户点取消时弹窗取消时需要撤销 */
const snapCheckedNodes = ref<SelectorItem[]>([]);
const selectorWrapRef = ref();

const locationId = computed(() => {
  return props.locationId || useLocationId().value;
});

// 更新值
watch(finalValue, (newVal, oldVal) => {
  /** 下拉框回来的值需要处理，有时候只有 label 和 value */
  const _newVal = map(newVal, (i) => {
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const { option, ...rest } = i;
    if (option) {
      return {
        ...option,
        ...rest,
      };
    }
    return i;
  });

  emit('update:value', _newVal);

  formItemContext.onFieldChange();

  const _newValIds = _newVal.map((i) => i.id);

  // 下拉框删除，同时更新弹窗的选中数据
  if (newVal.length < oldVal.length) {
    checkedNodes.value = filter(checkedNodes.value, (i) => _newValIds.includes(i.id));
  }

  if (
    !isEqual(
      _newValIds,
      map(props.value, (i) => i.id),
    )
  ) {
    emit('change', _newVal, cloneDeep(checkedNodes.value.filter((i) => _newValIds.includes(i.id))));
  }
});

watch(
  () => props.value,
  (newVal) => {
    if (
      isEqual(
        map(newVal, (i) => i.id),
        map(finalValue.value, (i) => i.id),
      )
    ) {
      return;
    }

    // 清空
    if (!newVal || !newVal?.length) {
      finalValue.value = [];
      checkedNodes.value = [];
      return;
    }

    finalValue.value = map(cloneDeep(newVal), (i) => ({
      ...i,
      key: i.key || i.id,
      value: i.id,
      label: i.name,
      disabled: props.disabledItemIds?.includes(i.id),
    }));

    checkedNodes.value = cloneDeep(finalValue.value);
  },
);

watch(
  () => props.disabledItemIds,
  (newVal) => {
    treeData.value = map(treeData.value, (i) => {
      if (i.children?.length) {
        return {
          ...i,
          children: getTreeItems(i.children, {
            disabledIds: newVal,
          }),
        };
      }
      return i;
    });
  },
);

// 选择学生弹窗
const onOpen = () => {
  // 每次打开存储临时缓存，
  // 用户删除后，点击取消时有可能需要撤销回去
  snapCheckedNodes.value = cloneDeep(checkedNodes.value);
};
// 已选学生删除
const onRemove = (item: SelectorItem) => {
  if (!item) {
    return;
  }
  checkedNodes.value = checkedNodes.value.filter((i) => i.id !== item.id);
};

// 确定选择学生
const onOk = () => {
  finalValue.value = map(cloneDeep(checkedNodes.value), (i) => ({
    ...i,
    value: i.id,
    label: i.name,
  }));
  // 关闭清空临时存储的选择数据
  snapCheckedNodes.value = [];
};

// 关闭选择学生弹窗
const onCancel = () => {
  // 点击取消恢复上次确定的内容
  if (finalValue.value?.length) {
    const _items = map(finalValue.value, (i) => {
      // 先查找是否在选中的数据中
      const c = find(checkedNodes.value, (j) => j.id === i.value);
      if (c) {
        return c;
      }
      // 没有则是上次选中的数据里
      return find(snapCheckedNodes.value, (j) => j.id === i.value);
    }).filter(Boolean);

    checkedNodes.value = cloneDeep(_items) as SelectorItem[];
  } else {
    checkedNodes.value = [];
  }
  // 关闭清空临时存储的选择数据
  snapCheckedNodes.value = [];
};

const onClearAll = () => {
  // disabled 不能清
  checkedNodes.value = checkedNodes.value.filter((i) => i.disabled);
};

// 树选择选中值发生变化的回调
const onChecked = (__checkedValue: string[], e: any) => {
  const _checkedNodes = (e?.checkedNodes || []) as SelectorItem[];
  const _halfCheckedKeys = (e?.halfCheckedKeys || []) as string[];
  const targetNodeId = e?.node?.id;

  // 未加载出来的已选数据在 checkedValue 里会丢掉 要过滤出来
  const _newData = uniqBy(
    [
      ...checkedNodes.value.filter(
        (i) => !(i._t_ || _halfCheckedKeys.includes(i.id) || i.id === targetNodeId),
      ),
      ..._checkedNodes.map((i) => ({ ...i, _t_: Date.now() })),
    ],
    'id',
  );

  return _newData;
};

// 异步加载组织数据
const onLoadData = (treeNode: any, loadedKeys: string[]) => {
  return new Promise<void>((resolve, reject) => {
    const { level, id, children } = treeNode.dataRef || {};
    // 非组织
    if (level !== StudentItemLevelEnum.location || includes(loadedKeys, id) || children) {
      resolve();
      return;
    }

    // 获取当前组织下的学生
    http
      .get<SelectorItem[]>('/api/campusbase/locationStudents', {
        locationId: id,
      })
      .then((res) => {
        if (res?.[0]?.children?.length) {
          treeNode.dataRef.children = getTreeItems(res[0].children, {
            disabledIds: props.disabledItemIds,
          });
        } else {
          treeNode.dataRef.children = [];
          treeNode.dataRef.isLeaf = true;
        }

        treeData.value = [...treeData.value];
        resolve();
      })
      .catch((error: any) => {
        message.error(error?.desc || '获取数据失败，请重试');
        reject();
      });
  });
};

const fetchTreeData = async () => {
  try {
    loading.value = true;
    const res = await http.get<SelectorItem[]>('/api/auth/userSelect/locationRelationship', {
      locationId: locationId.value,
      scope: props.scope,
      locationLevel: LocationLevel.School,
    });
    treeData.value =
      map(res, (i) => {
        // eslint-disable-next-line @typescript-eslint/no-unused-vars
        const { children, ...rest } = i;
        return {
          ...rest,
          key: i.id,
          checkable: !!props.rootSelectable,
          isLeaf: false,
          disabled: props.disabledItemIds?.includes(i.id),
        };
      }) || [];
  } catch (error: any) {
    message.error(error?.desc || '获取数据出错，请重试');
  } finally {
    loading.value = false;
  }
};

// 远程搜索
const onSearchService = async (params: SearchParams) => {
  try {
    const res = await http.get<{ total: number; list: SelectorItem[] }>(
      '/api/campusbase/searchStudents',
      {
        ...params,
        pageSize: searchPagesize,
        scope: props.scope,
        type: 2, // 搜索班级学生
      },
    );
    const _data = {
      ...res,
      list: res?.list?.length
        ? res.list.map((i) => {
            return {
              ...i,
              key: i.id,
              disabled: props.disabledItemIds?.includes(i.id),
            };
          })
        : [],
    };
    return Promise.resolve(_data);
  } catch (error) {
    return Promise.reject(error);
  }
};

const onShow = (show: () => void) => {
  if (!props.disabled) {
    show();
  }
};

const open = () => {
  selectorWrapRef.value?.showModal();
};

defineExpose({ open });

onBeforeMount(() => {
  if (props.value?.length) {
    finalValue.value = map(cloneDeep(props.value), (i) => ({
      ...i,
      key: i.key || i.id,
      value: i.id,
      label: i.name,
      disabled: props.disabledItemIds?.includes(i.id),
    }));

    checkedNodes.value = cloneDeep(finalValue.value);
  }
  fetchTreeData();
});
</script>

<template>
  <SelectorWrap
    ref="selectorWrapRef"
    :title="title"
    :checked-length="checkedNodes.length"
    @open="onOpen"
    @ok="onOk"
    @cancel="onCancel"
    @clear-all="onClearAll"
  >
    <template v-if="showTrigger" #select="{ show }">
      <slot name="trigger" :show="show">
        <Select
          style="width: 100%"
          labelInValue
          max-tag-count="responsive"
          mode="multiple"
          v-model:value="finalValue"
          :loading="loadingDefaultUser"
          :fieldNames="fieldNames"
          :placeholder="placeholder"
          :options="checkedNodes"
          :open="false"
          :disabled="disabled"
          @click="onShow(show)"
        ></Select>
      </slot>
    </template>
    <template #select-data>
      <TreeSelectPane
        v-model:checked="checkedNodes"
        description-key="identifier"
        :description-search-key="['locationName', 'identifier']"
        search-placeholder="搜索班级或学生"
        show-checked-strategy="SHOW_PARENT"
        :current-location-id="locationId"
        :max-count="maxCount"
        :loading="loading"
        :tree-data="treeData"
        :on-load-data="onLoadData"
        :on-search-service="onSearchService"
        :on-checked="onChecked"
      />
    </template>
    <template #select-result>
      <Item
        v-for="item in checkedNodes"
        allow-clear
        :key="item.id"
        :data="item"
        :description="`${item.locationName || ''}${
          item.locationName && item.identifier ? '-' : ''
        }${item.identifier || ''}`"
        @remove="onRemove"
      ></Item>
    </template>
  </SelectorWrap>
</template>
