import { forEach, includes, map, unionBy } from 'lodash-es';
import { PersonItemLevelEnum, type SelectorItem } from './types';

export const searchPagesize = 30;
export const PERSON_ID_SPLIT = '__';

/**
 * 数据转换
 * @param {SelectorItem[]} items
 * @return {SelectorItem[]}
 */
function getTreeItems<T extends Pick<SelectorItem, 'id' | 'children' | string>>(
  items: T[],
  {
    disabledIds,
    childrenKey = 'children',
    parentId = '',
    getCheckable,
    getPersonItemKey,
  }: {
    disabledIds?: string[];
    childrenKey?: string;
    parentId?: string;
    getCheckable?: (level: number) => boolean;
    getPersonItemKey?: (itemId: string, parentId: string) => string;
  } = {},
): T[] {
  return map(items, (item) => {
    const _children = item[childrenKey];

    const children =
      Array.isArray(_children) && _children.length > 0
        ? getTreeItems(_children, {
            disabledIds,
            childrenKey,
            parentId: item.id,
            getCheckable,
            getPersonItemKey,
          })
        : undefined;

    let key = item.key || item.id;

    if (getPersonItemKey && item.level === PersonItemLevelEnum.user) {
      key = getPersonItemKey(item.id, parentId);
    }

    return {
      ...item,
      parentId,
      key,
      [childrenKey]: children,
      isLeaf: !children?.length,
      disabled: includes(disabledIds, item.id),
      checkable: getCheckable ? getCheckable(item.level) : true,
    };
  });
}

/**
 * 搜索数据
 * @param {SelectorItem[]} items
 * @return {SelectorItem[]}
 */
function searchItems<T extends Pick<SelectorItem, 'id' | 'children' | string>>(
  items: T[],
  keyword: string,
  result: T[],
): T[] {
  forEach(items, (item) => {
    const { children, ...rest } = item;
    const match = new RegExp(keyword, 'i');
    if (
      rest.checkable &&
      (match.test(rest.name) ||
        match.test(rest.firstLetter) ||
        match.test(rest.phoneNumber) ||
        match.test(rest.jobNo))
    ) {
      result.push(rest as T);
    }
    if (children?.length) {
      searchItems(children, keyword, result);
    }
  });

  return unionBy(result, 'id');
}

/**
 * 过滤数据
 * @param {SelectorItem[]} items
 * @return {SelectorItem[]}
 */
function filterItemsByIds<T extends Pick<SelectorItem, 'id' | 'children' | string>>(
  items: T[],
  itemIds: string[],
  result: T[],
): T[] {
  forEach(items, (item) => {
    if (includes(itemIds, item.id)) {
      result.push(item);
    }
    if (item.children?.length) {
      filterItemsByIds(item.children, itemIds, result);
    }
  });

  return unionBy(result, 'id');
}

export { getTreeItems, searchItems, filterItemsByIds };
