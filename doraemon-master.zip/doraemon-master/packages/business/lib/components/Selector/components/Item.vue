<script lang="ts" setup>
import { theme, TypographyParagraph, Tag } from 'ant-design-vue';
import { CloseCircleFilled } from '@ant-design/icons-vue';
import { computed } from 'vue';
import type { SelectorItem } from '../types';

const props = defineProps<{
  allowClear?: boolean;
  more?: boolean;
  data: SelectorItem;
  description?: string;
  currentLocationId?: string;
}>();

defineEmits<{
  (event: 'remove', value: SelectorItem): void;
}>();

const { token } = theme.useToken();
const name = computed(() => `${props.data.name}` || '/');

const _description = computed(() => {
  return props.description ? `（${props.description}）` : '';
});

const showTag = computed(
  () => props.currentLocationId && props.currentLocationId === props.data.id,
);

const colorFillTertiary = token.value.colorFillTertiary;
</script>

<template>
  <div class="selector-checked-item">
    <slot name="left"></slot>
    <div
      :class="[
        'selector-checked-item-content',
        data.checkable || allowClear ? 'content-hover' : '',
      ]"
    >
      <div class="selector-checked-item-main">
        <TypographyParagraph
          class="name"
          ellipsis
          :content="name"
          :title="name"
          :style="{
            maxWidth: _description || showTag ? '74%' : '100%',
            color: data.disabled ? token.colorTextDescription : token.colorTextBase,
            cursor: data.disabled ? 'not-allowed' : 'pointer',
          }"
        />
        <TypographyParagraph
          class="desc"
          ellipsis
          :content="_description"
          :title="_description"
          :style="{
            color: token.colorTextDescription,
          }"
          v-if="_description"
        />
        <Tag v-if="showTag" class="tag" color="processing">当前组织</Tag>
      </div>
      <div
        class="selector-checked-item-clear"
        v-if="allowClear && !data.disabled"
        @click="$emit('remove', data)"
      >
        <CloseCircleFilled
          :style="{
            cursor: 'pointer',
            color: token.colorTextQuaternary,
          }"
        />
      </div>
    </div>
  </div>
</template>

<style lang="scss" scoped>
.selector-checked-item {
  display: flex;
  align-items: center;
  &-content {
    display: flex;
    flex: 1;
    align-items: center;
    gap: 6px;
    padding: 3px 2px 3px 8px;
    margin-right: 8px;
    border-radius: 4px;
    line-height: 22px;
    overflow: hidden;
    width: 100%;
    &.content-hover:hover {
      background-color: v-bind('colorFillTertiary');
    }
  }
  &-main {
    flex: 1;
    display: flex;
    align-items: center;
    overflow: hidden;
    width: 100%;
    .name {
      flex: none;
    }
    .name,
    .desc {
      line-height: 22px;
      margin: 0;
    }
    .tag {
      margin-left: 4px;
    }
  }
  &-clear {
    padding: 0 7px;
  }
}
</style>
