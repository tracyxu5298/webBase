<script lang="ts" setup>
import { ref, computed } from 'vue';
import { Empty, Button, Modal } from 'ant-design-vue';

defineOptions({
  name: 'SelectorWrap',
});

defineProps<{
  title: string;
  checkedLength: number;
}>();

const emit = defineEmits<{
  /** 点击清空 */
  (event: 'clearAll'): void;
  /** 弹窗确定 */
  (event: 'ok'): void;
  /** 弹窗点击取消 */
  (event: 'cancel'): void;
  /** 点击打开弹窗 */
  (event: 'open'): void;
}>();

const simpleImage = Empty.PRESENTED_IMAGE_SIMPLE;

const open = ref<boolean>(false);

// 打开弹窗
const showModal = () => {
  open.value = true;
  emit('open');
};

// 确定选择人员
const handleOk = () => {
  open.value = false;
  emit('ok');
};

// 关闭选择人员弹窗
const handleCancel = () => {
  open.value = false;
  emit('cancel');
};

const getPopupContainer = () => document.body;

const height = computed(() => `${document.body.clientHeight - 280}px`);

defineExpose({ showModal });
</script>

<template>
  <slot name="select" :show="showModal"></slot>
  <Modal
    v-if="open"
    destroyOnClose
    width="800px"
    centered
    :title="title || '选择'"
    :open="open"
    :maskClosable="false"
    :getPopupContainer="getPopupContainer"
    @ok="handleOk"
    @cancel="handleCancel"
  >
    <div class="selector-wrap" :style="{ height }">
      <div class="selector-wrap-data">
        <slot name="select-data"></slot>
      </div>
      <div class="selector-wrap-checked">
        <div class="selector-wrap-checked-title">
          <span> 已选：{{ checkedLength ? `（${checkedLength}）` : '' }} </span>
          <Button size="small" danger type="link" @click="emit('clearAll')">清空</Button>
        </div>
        <div class="selector-wrap-checked-list">
          <slot name="select-result"></slot>
          <Empty
            v-if="!checkedLength"
            :image="simpleImage"
            description="暂无内容"
            :style="{ marginTop: '50px' }"
          />
        </div>
      </div>
    </div>
  </Modal>
</template>

<style lang="scss" scoped>
.selector-wrap {
  display: flex;
  border-top: 1px solid #ebebeb;
  border-bottom: 1px solid #ebebeb;
  margin: 16px -24px 20px;
  padding: 0 24px;
  &-data,
  &-checked {
    flex: 1;
    width: 100px;
    height: 100%;
  }
  &-data {
    border-right: 1px solid #ebebeb;
  }
  &-checked {
    display: flex;
    flex-direction: column;
    padding-bottom: 16px;
    &-title {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin: 8px 0 0 24px;
      line-height: 38px;
    }
    &-list {
      display: flex;
      flex-direction: column;
      gap: 8px;
      overflow-y: auto;
      flex: 1;
      padding: 8px 16px 0 24px;
      margin-left: -8px;
      margin-right: -24px;
    }
  }
}
</style>
