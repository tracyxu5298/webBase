import { reactive } from 'vue';
import { PERSON_ID_SPLIT } from '../utils';

const usePersonItemsData = () => {
  const personItemsMap = reactive<Record<string, string[]>>({});

  const getPersonItemKey = (itemId: string, parentId: string) => {
    if (!parentId) {
      return itemId;
    }
    const _id = `${itemId}${PERSON_ID_SPLIT}${parentId}`;
    if (!personItemsMap[itemId]?.includes(_id)) {
      personItemsMap[itemId] = personItemsMap[itemId] ? [...personItemsMap[itemId], _id] : [_id];
    }
    return _id;
  };

  return { personItemsMap, getPersonItemKey };
};

export default usePersonItemsData;
