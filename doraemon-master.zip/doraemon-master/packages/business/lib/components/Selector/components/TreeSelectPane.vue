<script lang="ts" setup>
import { computed, onBeforeMount, reactive, ref, watch } from 'vue';
import {
  message,
  Empty,
  Spin,
  Form,
  InputSearch,
  Checkbox,
  Tree,
  Pagination,
} from 'ant-design-vue';
import type { CheckInfo } from 'ant-design-vue/es/vc-tree/props';
import { clone, filter, map, trim, uniq, uniqBy } from 'lodash-es';
import { SelectorShowTypeEnum } from '../types';
import type { SelectorItem, SearchParams } from '../types';
import { PERSON_ID_SPLIT, searchItems, searchPagesize } from '../utils';
import Item from './Item.vue';

const props = withDefaults(
  defineProps<{
    treeData: SelectorItem[];
    checked: any[];
    loading?: boolean;
    maxCount?: number;
    searchPlaceholder?: string;
    showType?: SelectorShowTypeEnum;
    multiple?: boolean;
    extraHeight?: number;
    currentLocationId?: string;
    /** 名字后面展示字段 key */
    descriptionKey?: string;
    descriptionSearchKey?: string | string[];
    itemsCheckedMap?: Record<string, string[]>;
    showCheckedStrategy?: 'SHOW_ALL' | 'SHOW_PARENT';
    onLoadData?: (treeNode: any, loadedKeys: string[]) => Promise<void>;
    /**
     * 点击复选框的回调
     */
    onChecked?: (checkedValue: string[], e: any) => SelectorItem[];
    /**
     * 自定义搜索框
     * @param {string} keyword
     */
    onSearchService?: (params: SearchParams) => Promise<{
      total: number;
      list: SelectorItem[];
    }>;
  }>(),
  {
    showType: SelectorShowTypeEnum.tree,
    multiple: true,
    extraHeight: 0,
    showCheckedStrategy: 'SHOW_ALL',
  },
);

const emit = defineEmits<{
  (event: 'update:checked', checkedNodes: any[]): void;
}>();

const fieldNames = {
  label: 'name',
};

const simpleImage = Empty.PRESENTED_IMAGE_SIMPLE;

// 选中的数据
const checkedKeys = ref<string[]>([]);
// 展开数据
const expandedKeys = ref<string[]>();
// 已经加载过的数据 key
const loadedKeys = ref<string[]>([]);
// 搜索
const searchQuery = reactive({
  keyword: '',
  pageNum: 0,
});
const searching = ref(false);
const total = ref(0);
// 搜索
const searchResult = ref<SelectorItem[] | null>(null);
// 搜索
const searchResultAllData = ref<SelectorItem[] | null>(null);

// 所有选中的 key 集合
const allCheckedKeys = computed(() => {
  return map(props.checked, (i) => i.id);
});

const setCheckedKeys = (value: string[]) => {
  checkedKeys.value = clone(value);
};

// 向外部更新选中的节点（v-model:value）
const updateChecked = (__checked: SelectorItem[]) => {
  let _checked = __checked;

  // 默认选中的操作
  if (props.multiple) {
    if (props.maxCount && _checked.length > props.maxCount) {
      message.info(`最多选择 ${props.maxCount} 项`);
      const _checkedKeys = props.itemsCheckedMap
        ? props.checked.reduce((all: string[], item: SelectorItem) => {
            return all.concat(props.itemsCheckedMap?.[item.id] || [item.key || item.id]);
          }, [])
        : props.checked.map((i) => i.id);
      setCheckedKeys(_checkedKeys);
      return;
    }
  } else {
    // 单选只要最后选的那个
    _checked = __checked.slice(-1);
  }

  // 重新处理有映射的值
  let _checkedKeys: string[] = [];
  // 树的节点有映射的值时
  if (props.itemsCheckedMap && _checked.length) {
    _checkedKeys = _checked.reduce((all: string[], item: SelectorItem) => {
      return all.concat(props.itemsCheckedMap?.[item.id] || [item.key || item.id]);
    }, []);
  } else {
    _checkedKeys = _checked.map((i) => i.key || i.id);
  }

  emit('update:checked', _checked);
  setCheckedKeys(_checkedKeys);
};

// 点击搜索结果人员
const onClickItem = (item: SelectorItem) => {
  if (item.disabled) {
    return;
  }

  if (allCheckedKeys.value.includes(item.id)) {
    updateChecked(filter(props.checked, (i) => i.id !== item.id));
  } else {
    updateChecked([...props.checked, item]);
  }
};

// 操作复选框
const _onChecked = (checkedValue: any, e: CheckInfo) => {
  const { id: _nodeId, key: _nodeKey } = e?.node || {};
  // 选中的节点
  let _checkedValues = (checkedValue || []) as string[];
  let _checkedNodes = e?.checkedNodes || [];

  // 数据联动，需要过滤出需要去掉的子节点
  const excludeNodeIds: string[] = [];
  if (props.showCheckedStrategy === 'SHOW_PARENT') {
    let _checkedNodesPositions = e?.checkedNodesPositions || [];
    if (_checkedNodesPositions.length) {
      const _nodesPos: string[] = [];
      _checkedNodesPositions = _checkedNodesPositions
        .sort((a: any, b: any) => a.pos?.length - b.pos?.length)
        .forEach((i: any) => {
          const _key = i.node.key || i.node.id;
          if (_nodesPos.find((p) => i.pos.startsWith(`${p}-`))) {
            excludeNodeIds.push(_key);
          } else {
            _nodesPos.push(i.pos);
          }
        });
    }

    if (excludeNodeIds.length) {
      // 选中的keys
      _checkedValues = _checkedValues.filter((i) => !excludeNodeIds.includes(i));
      _checkedNodes = _checkedNodes.filter((i) => !excludeNodeIds.includes(i.key || i.id));
    }
  }

  if (e?.checked === false) {
    // 人员用 includes， 非人员则精准匹配
    _checkedValues = _nodeKey.includes(PERSON_ID_SPLIT)
      ? _checkedValues.filter((i) => !i.includes(_nodeId))
      : _checkedValues.filter((i) => i !== _nodeId);
    _checkedNodes = _checkedNodes.filter((i) => i.id !== _nodeId);
  }

  // 有数据映射需要去重
  if (props.itemsCheckedMap) {
    _checkedValues = uniq(_checkedValues.map((i) => i?.split(PERSON_ID_SPLIT)[0]));
    _checkedNodes = uniqBy(_checkedNodes, 'id');
  }

  // 有自定的选择操作
  if (props.onChecked) {
    const _checked = props.onChecked(_checkedValues, {
      ...e,
      checkedNodes: _checkedNodes,
    });
    // 要以外部处理的结果为准
    updateChecked(_checked);
  } else {
    updateChecked(_checkedNodes);
  }
};

// 外部搜索接口
const onSearchService = async (params: SearchParams) => {
  if (!props.onSearchService) {
    return;
  }

  searching.value = true;
  try {
    const res = await props.onSearchService({ ...params, pageNum: params.pageNum || 1 });

    const _list = res.list || [];

    searchResult.value = _list;
    total.value = res.total || 0;
  } catch (error: any) {
    console.log('file: TreeSelectPane.vue:183 ~ onSearchService ~ error:', error);
    message.error(error?.desc || '获取数据出错，请重试');
  } finally {
    searching.value = false;
  }
};

const onSearch = async (value: any) => {
  if (searchQuery.keyword === value) {
    return;
  }
  searchQuery.keyword = value || '';
  if (!trim(value)) {
    searchResult.value = null;
    searchResultAllData.value = null;
    searchQuery.pageNum = 0;
    return;
  }
  /** 有自定义的搜索走自定义 */
  if (props.onSearchService) {
    searchQuery.pageNum = 1;
  } else {
    searchResultAllData.value = searchItems(props.treeData, searchQuery.keyword, []);
    searchQuery.pageNum = 1;
    total.value = searchResultAllData.value.length;
  }
};

const onLoadTreeData = (treeNode: any) => {
  return new Promise<void>((resolve) => {
    const { id } = treeNode.dataRef || {};
    props.onLoadData!(treeNode, loadedKeys.value)
      .then(() => {
        resolve();
      })
      .catch(() => {
        resolve();
        // 要去掉当前节点展开，否则会无线循环
        expandedKeys.value = expandedKeys.value?.filter((i) => i !== id);
      });
  });
};

const formatSearchDescription = (item: any) => {
  if (props.descriptionSearchKey) {
    if (Array.isArray(props.descriptionSearchKey)) {
      const arr: string[] = [];
      props.descriptionSearchKey.forEach((key) => {
        // 描述字段和名称字段相同则不显示
        if (item[key] && item[key] !== item.name) {
          arr.push(item[key]);
        }
      });
      return arr.join('-');
    } else {
      return item[props.descriptionSearchKey];
    }
  } else if (props.descriptionKey) {
    return item[props.descriptionKey];
  }
};

watch(searchQuery, (newVal) => {
  if (!newVal.pageNum) {
    return;
  }
  if (props.onSearchService) {
    onSearchService({
      pageNum: newVal.pageNum,
      keyword: newVal.keyword,
    });
  } else {
    if (!searchResultAllData.value) {
      searchResult.value = null;
    }
    searchResult.value = searchResultAllData.value!.slice(
      (newVal.pageNum - 1) * searchPagesize,
      newVal.pageNum * searchPagesize,
    );
  }
});

watch(
  () => props.checked,
  (newVal, oldVal) => {
    if (checkedKeys.value.length === newVal.length) {
      return;
    }
    // 点击清空会到这里
    if (newVal.length === 0 && oldVal.length) {
      setCheckedKeys([]);
    } else if (newVal.length < oldVal.length) {
      // 进行了一个删除操作
      const newKeys = newVal.map((i) => i.id);
      // 如果是人员（出现在多个部门，需要把多个都删掉）
      if (props.itemsCheckedMap) {
        setCheckedKeys(
          filter(
            checkedKeys.value,
            (i) => newKeys.findIndex((j) => i?.split(PERSON_ID_SPLIT)[0].includes(j)) !== -1,
          ),
        );
      } else {
        setCheckedKeys(filter(checkedKeys.value, (i) => newKeys.includes(i)));
      }
    }
  },
);

// 设置默认展示的节点
watch(
  () => props.treeData,
  (newVal) => {
    // 跨组织选择器第一级只有一个节点时默认展开
    if (
      props.onLoadData &&
      props.showType === SelectorShowTypeEnum.tree &&
      newVal.length === 1 &&
      !expandedKeys.value?.length
    ) {
      onLoadTreeData({ dataRef: newVal[0] });
      expandedKeys.value = [newVal[0].id];
      return;
    }

    // 远程加载的数据、展示为列表、无数据源、已有展开数据
    if (
      props.onLoadData ||
      props.showType === SelectorShowTypeEnum.list ||
      !newVal?.length ||
      expandedKeys.value?.length
    ) {
      return;
    }
    expandedKeys.value = [newVal[0].id];
  },
  {
    immediate: true,
  },
);

const height = computed(() => document.body.clientHeight - 360 - props.extraHeight);

const loadData = computed(() => (props.onLoadData ? onLoadTreeData : undefined));

onBeforeMount(() => {
  // 初始赋值
  if (props.checked?.length) {
    if (props.itemsCheckedMap) {
      setCheckedKeys(
        props.checked.reduce((all: string[], item: SelectorItem) => {
          return all.concat(props.itemsCheckedMap?.[item.id] || [item.key || item.id]);
        }, []),
      );
    } else {
      setCheckedKeys(props.checked.map((i) => i.id));
    }
  }
});
</script>

<template>
  <Spin :spinning="loading">
    <div class="selector-person-tree-pane">
      <div class="selector-person-tree-search-wrap">
        <Form.Item noStyle>
          <InputSearch
            class="selector-person-tree-search"
            :placeholder="searchPlaceholder || '搜索'"
            :loading="searching"
            allowClear
            @search="onSearch"
          />
        </Form.Item>
        <slot name="search-input-extra"></slot>
      </div>
      <div
        class="selector-person-tree-search-list"
        v-if="searchResult"
        :style="{ height: `${height}px` }"
      >
        <Item
          class="search-person-item"
          v-for="item in searchResult"
          :key="item.id"
          :data="item"
          :description="formatSearchDescription(item)"
          @click="onClickItem(item)"
        >
          <template #left>
            <Checkbox
              class="search-person-item-checkbox"
              :disabled="item.disabled"
              :checked="allCheckedKeys.includes(item.id)"
            ></Checkbox>
          </template>
        </Item>
        <Pagination
          v-if="total"
          class="selector-person-tree-search-pagination"
          v-model:current="searchQuery.pageNum"
          simple
          :pageSize="searchPagesize"
          :total="total"
        />
        <Empty
          v-if="searchResult?.length === 0"
          :image="simpleImage"
          description="暂无内容"
          :style="{ marginTop: '40px' }"
        />
      </div>
      <div
        :class="[
          'selector-person-tree-main',
          showType === SelectorShowTypeEnum.list ? 'show-list' : '',
        ]"
        v-show="!searchResult"
      >
        <Tree
          v-if="treeData.length > 0"
          checkable
          virtual
          v-model:checkedKeys="checkedKeys"
          v-model:expandedKeys="expandedKeys"
          prefix-cls="selector-person-tree"
          :height="height"
          :selectable="false"
          :loadedKeys="loadedKeys"
          :fieldNames="fieldNames"
          :load-data="loadData"
          :tree-data="treeData"
          @check="_onChecked"
        >
          <template #title="item">
            <Item
              :data="item"
              :currentLocationId="currentLocationId"
              :description="descriptionKey ? item[descriptionKey] : ''"
            />
          </template>
          <template #switcherIcon="{ dataRef, defaultIcon }">
            <component
              :is="defaultIcon"
              :class="dataRef.checkable || dataRef.isLeaf ? '' : 'switcher-expand-node'"
            />
          </template>
        </Tree>
        <Empty
          v-if="!treeData.length && !loading"
          :image="simpleImage"
          description="暂无内容"
          :style="{ marginTop: '40px' }"
        />
      </div>
    </div>
  </Spin>
</template>

<style lang="scss" scoped>
.selector-person-tree-pane {
  overflow-x: hidden;
  overflow-y: auto;
  padding-bottom: 16px;
  padding-top: 16px;
  .load-button {
    margin-top: 16px;
    margin-left: 36px;
  }
}

.selector-person-tree-search-wrap {
  display: flex;
  padding-right: 16px;
  margin-bottom: 16px;
  gap: 8px;
}

.selector-person-tree-search {
  flex: 1;
}

.selector-person-tree-search-list {
  margin-right: 16px;
  overflow-x: hidden;
  overflow-y: auto;
}

.selector-person-tree-search-pagination {
  text-align: center;
  margin-top: 20px;
}

:deep(.load-button span[class$='-btn-loading-icon']) {
  margin-right: 8px;
}

.selector-person-tree-main {
  &.show-list {
    :deep(.selector-person-tree .selector-person-tree-switcher-noop) {
      width: 2px;
    }
  }
}

.search-person-item {
  margin: 0 0 8px 0px;
  padding: 0 0 0 2px;
  cursor: pointer;
  &-checkbox {
    margin-right: 4px;
  }
}

:deep(.selector-person-tree-list-holder) {
  overflow-x: hidden;
}

:deep(.selector-person-tree-list-scrollbar) {
  width: 6px !important;
}

:deep(.selector-person-tree-list-scrollbar-thumb) {
  background: rgb(0 0 0 / 25%) !important;
  border-radius: 4px !important;
}

:deep(.selector-person-tree-treenode) {
  width: 100%;
  padding-bottom: 8px;
}
:deep(.selector-person-tree .selector-person-tree-checkbox + span) {
  overflow: hidden;
}

:deep(.selector-person-tree .selector-person-tree-switcher) {
  line-height: 28px;
}
:deep(.selector-person-tree-treenode .switcher-expand-node::after) {
  position: absolute;
  top: 0;
  z-index: 1;
  display: inline-block;
  width: 340px;
  height: 28px;
  content: '';
}
:deep(.selector-person-tree-node-content-wrapper) {
  flex: 1;
  overflow: hidden;
}
:deep(.selector-person-tree-node-content-wrapper .selector-checked-item) {
  margin-left: -8px;
}
:deep(.selector-person-tree .selector-person-tree-checkbox) {
  margin-block-start: 0;
}
:deep(
    .selector-person-tree
      .selector-person-tree-node-content-wrapper.selector-person-tree-node-selected
  ),
:deep(.selector-person-tree .selector-person-tree-node-content-wrapper:hover),
:deep(.selector-person-tree .selector-person-tree-checkbox + span:hover),
:deep(
    .selector-person-tree .selector-person-tree-checkbox + span.selector-person-tree-node-selected
  ) {
  background-color: transparent;
}
// :deep(
//     .selector-person-tree
//       .selector-person-tree-checkbox-indeterminate
//       .selector-person-tree-checkbox-inner:after
//   ) {
//   background-color: transparent;
// }
</style>
