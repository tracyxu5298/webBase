<script lang="ts" setup>
import { LoadingOutlined } from '@ant-design/icons-vue';
import { Input } from 'ant-design-vue';

defineProps<{
  placeholder: string;
}>();
</script>

<template>
  <div>
    <!-- 解决有值时刚开始会先出现 ID 的问题 -->
    <Input :placeholder="placeholder">
      <template #suffix>
        <LoadingOutlined
          :style="{
            color: 'rgba(0, 0, 0, 0.25)',
            fontSize: '12px',
          }"
        />
      </template>
    </Input>
  </div>
</template>
