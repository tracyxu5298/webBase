<script lang="ts" setup>
import { onMounted, reactive, ref } from 'vue';
import { theme, Form, Button, Select, Dropdown } from 'ant-design-vue';
import { FilterOutlined } from '@ant-design/icons-vue';
import { Http } from '@lexikos/doraemon-network';
import { map } from 'lodash-es';

interface OptionItem {
  label: string;
  value: string;
}

const emit = defineEmits<{
  (
    event: 'change',
    data: {
      type: string | null;
      tag: string | null;
    },
  ): void;
}>();

const { token } = theme.useToken();
const open = ref(false);
const formRef = ref();
const formState = ref<any>({
  type: null,
  tag: null,
  inSearch: false,
});
const optionsData = reactive<{
  types: {
    data: OptionItem[];
    loading: boolean;
  };
  tags: {
    data: OptionItem[];
    loading: boolean;
  };
}>({
  types: {
    data: [],
    loading: false,
  },
  tags: {
    data: [],
    loading: false,
  },
});

const onSubmit = () => {
  formState.value.inSearch = !!(formState.value.type || formState.value.tag);
  emit('change', { type: formState.value.type, tag: formState.value.tag });
  open.value = false;
};

const resetForm = () => {
  formRef.value.resetFields();
  formState.value.inSearch = false;
  open.value = false;
  emit('change', { type: null, tag: null });
};

const fetchTypesData = async () => {
  try {
    optionsData.types.loading = true;
    const res = await Http.getInstance().get<{ id: string; name: string }[]>(
      '/api/product/deviceType/all',
    );
    optionsData.types.data = map(res || [], (i) => ({ label: i.name, value: i.id }));
  } catch (error: any) {
    console.log('file: DeviceFilter.vue:47 ~ fetchTypesData ~ error:', error);
  } finally {
    optionsData.types.loading = false;
  }
};

const fetchTagsData = async () => {
  try {
    optionsData.tags.loading = true;
    const res = await Http.getInstance().get<{ id: string; name: string }[]>(
      '/api/building/v1/label/list',
    );
    optionsData.tags.data = map(res || [], (i) => ({ label: i.name, value: i.id }));
  } catch (error: any) {
    console.log('file: DeviceFilter.vue:61 ~ fetchTagsData ~ error:', error);
  } finally {
    optionsData.tags.loading = false;
  }
};

onMounted(() => {
  fetchTypesData();
  fetchTagsData();
});
</script>

<template>
  <Dropdown placement="bottomRight" v-model:open="open" arrow :trigger="['click']">
    <Button>
      <template #icon>
        <FilterOutlined
          :style="{ color: formState.inSearch ? token.colorPrimary : token.colorTextTertiary }"
        />
      </template>
    </Button>
    <template #overlay>
      <Form
        name="basic"
        ref="formRef"
        :model="formState"
        :label-col="{ span: 23 }"
        :wrapper-col="{ span: 24 }"
        class="device-filter-form"
      >
        <Form.Item labelAlign="left" class="device-filter-form-item" label="设备类型" name="type">
          <Select
            allowClear
            v-model:value="formState.type"
            placeholder="请选择"
            :options="optionsData.types.data"
            :loading="optionsData.types.loading"
          >
          </Select>
        </Form.Item>

        <Form.Item labelAlign="left" class="device-filter-form-item" label="设备标签" name="tag">
          <Select
            allowClear
            v-model:value="formState.tag"
            placeholder="请选择"
            :options="optionsData.tags.data"
            :loading="optionsData.tags.loading"
          >
          </Select>
        </Form.Item>

        <Form.Item class="device-filter-form-button" style="text-align: right">
          <Button style="margin-right: 10px" @click="resetForm">重置</Button>
          <Button type="primary" @click="onSubmit">筛选</Button>
        </Form.Item>
      </Form>
    </template>
  </Dropdown>
</template>

<style lang="scss" scoped>
.device-filter-form {
  padding: 16px;
  width: 360px;
  &-item {
    margin-bottom: 12px;
  }
  &-button {
    padding: 4px 0;
    margin-bottom: 0;
  }
}
</style>
