<script lang="ts" setup>
import { computed, onBeforeMount, ref, watch } from 'vue';
import { Http } from '@lexikos/doraemon-network';
import { Form, Empty, theme, message, Select, Tree } from 'ant-design-vue';
import { includes, map, forEach } from 'lodash-es';
import {
  type LocationTreeSelectorProps,
  type LocationSelectorItem,
  type SelectorTreeEmits,
  LocationScopeEnum,
} from './types';
import type { DataNode } from 'ant-design-vue/es/vc-tree/interface';

defineOptions({
  name: 'SelectorLocation',
});

const props = withDefaults(defineProps<LocationTreeSelectorProps>(), {
  multiple: true,
  scope: LocationScopeEnum.all,
  placeholder: '请选择组织',
});

const emit = defineEmits<SelectorTreeEmits>();

const fieldNames = {
  label: 'name',
  value: 'id',
  children: 'childs',
};
const simpleImage = Empty.PRESENTED_IMAGE_SIMPLE;
const { token } = theme.useToken();
const formItemContext = Form.useInjectFormItemContext();
const getPopupContainer = (triggerNode: any) => triggerNode?.parentNode;

const open = ref<boolean>(false);
const selectedKeys = ref<string[]>([]); // 单选的时候 value
const checkedKeys = ref<string[]>([]); // 多选的时候 value
const treeData = ref<DataNode[]>([]);
const treeDataMap = ref<Record<string, DataNode>>({});
const options = ref<{ label: string; value: string }[]>([]);
const loading = ref(false);

const fetch = async () => {
  if (loading.value) {
    return;
  }
  try {
    loading.value = true;
    const res = await Http.getInstance().get<LocationSelectorItem[]>(
      '/api/auth/locationSelect/locations',
      {
        scope: props.scope,
        locationId: props.locationId || '',
      },
    );

    treeDataMap.value = {};

    getOptionItems(res || []);
    treeData.value = getTreeItems(res || []);
    getTreeItemsMap(treeData.value);
  } catch (error: any) {
    treeData.value = [];
    message.error(error?.desc || '获取数据出错，请重试');
  } finally {
    loading.value = false;
    if (props.value) {
      if (props.multiple) {
        if (props.value.length && props.value[0] && typeof props.value[0] === 'string') {
          // 节点选择完全受控
          checkedKeys.value = props.value as string[];
        } else {
          checkedKeys.value = [];
        }
      } else {
        if (typeof props.value === 'string') {
          selectedKeys.value = [props.value as string];
        } else {
          selectedKeys.value = [];
        }
      }
    } else {
      selectedKeys.value = [];
      checkedKeys.value = [];
    }
  }
};

function onOpenChange(_open: boolean) {
  open.value = _open;
}

function getAllNodeIds(items: DataNode[], res: string[]) {
  forEach(items, (item) => {
    res.push(item.id);
    if (item.childs && item.childs.length > 0) {
      getAllNodeIds(item.childs, res);
    }
  });
}

function updateCheckCount(items: DataNode[]) {
  forEach(items, (item) => {
    let count = 0;
    if (item.childs && item.childs.length > 0) {
      updateCheckCount(item.childs);

      forEach(item.childs, (i) => {
        const currentCheck = checkedKeys.value.indexOf(i.id) > -1;
        if (currentCheck) {
          count += i.selectedCount + 1;
        } else {
          count += i.selectedCount;
        }
      });
    }
    item.selectedCount = count;
  });
}

const onSelect = (_selectedKeys: any, e: any) => {
  if (_multiple.value) {
    return;
  }

  let _label: string[] = [];
  if (e.node) {
    _label = [e.node.name];
  }

  open.value = false;

  emit('update:value', _selectedKeys?.[0]);
  emit('change', _selectedKeys?.[0], _label, null);

  formItemContext.onFieldChange();
};

const onCheck = (_checkedKeys: any, e: any) => {
  if (!_multiple.value) {
    return;
  }

  checkedKeys.value = _checkedKeys.checked;
  updateCheckCount(treeData.value);

  const _value: string[] = map(e.checkedNodes, (i: DataNode) => i.id) || undefined;
  const _label: string[] = map(e.checkedNodes, (i: DataNode) => i.name) || [];

  emit('update:value', _value);
  emit('change', _value, _label, null);

  formItemContext.onFieldChange();
};

const onCheckAll = (nodes: DataNode[]) => {
  const nodeIds: string[] = [];
  getAllNodeIds(nodes, nodeIds);
  forEach(nodeIds, (i) => {
    if (!checkedKeys.value.find((j) => j === i)) {
      checkedKeys.value.push(i);
    }
  });
  updateCheckCount(treeData.value);

  emit('update:value', checkedKeys.value);
  emit(
    'change',
    checkedKeys.value,
    map(checkedKeys.value, (i: string) => treeDataMap.value[i].name),
    null,
  );
  formItemContext.onFieldChange();
};

const onUncheckAll = (nodes: DataNode[]) => {
  const nodeIds: string[] = [];
  getAllNodeIds(nodes, nodeIds);
  checkedKeys.value = checkedKeys.value.filter((i) => !nodeIds.find((j) => j === i));
  updateCheckCount(treeData.value);

  emit('update:value', checkedKeys.value);
  emit(
    'change',
    checkedKeys.value,
    map(checkedKeys.value, (i: string) => treeDataMap.value[i].name),
    null,
  );
  formItemContext.onFieldChange();
};

const onChange = (value: any, option: any) => {
  if (_multiple.value) {
    checkedKeys.value = value;
    updateCheckCount(treeData.value);
  } else {
    selectedKeys.value = value;
  }

  const _value: string[] = map(option, (i: any) => i.value) || undefined;
  const _label: string[] = map(option, (i: any) => i.label) || [];

  if (props.multiple) {
    emit('update:value', _value);
    emit('change', _value, _label, null);
  } else {
    emit('update:value', _value?.[0] || '');
    emit('change', _value?.[0] || '', _label, null);
  }
  formItemContext.onFieldChange();
};

watch(
  () => props.value,
  (newVal) => {
    if (newVal) {
      if (props.multiple) {
        if (newVal.length && newVal[0] && typeof newVal[0] === 'string') {
          // 节点选择完全受控
          checkedKeys.value = newVal as string[];
        } else {
          checkedKeys.value = [];
        }
      } else {
        if (typeof newVal === 'string') {
          selectedKeys.value = [newVal as string];
        } else {
          selectedKeys.value = [];
        }
      }
    } else {
      selectedKeys.value = [];
      checkedKeys.value = [];
    }
  },
);

function getTreeItemsMap(items: DataNode[]) {
  forEach(items, (item) => {
    const _children = item.childs;
    treeDataMap.value[item.id] = item;
    if (Array.isArray(_children) && _children.length > 0) {
      getTreeItemsMap(_children);
    }
  });
}

function getTreeItems(items: LocationSelectorItem[], parentId?: string): DataNode[] {
  return map(items, (item) => {
    const _children = item.childs;
    const children =
      Array.isArray(_children) && _children.length > 0
        ? getTreeItems(_children, item.id)
        : undefined;
    let total = 0;
    forEach(children, (item) => {
      total += item.selectedTotal + 1;
    });

    return {
      ...item,
      parentId,
      key: item.id,
      selectedCount: 0,
      selectedTotal: total,
      isLeaf: !children?.length,
      disabled: includes(props.disabledItemIds, item.id),
      selectable: !props.multiple,
      checkable: props.multiple,
      childs: children,
    };
  });
}

function getOptionItems(items: LocationSelectorItem[]) {
  forEach(items, (item) => {
    const _children = item.childs;
    options.value.push({ label: item.name, value: item.id });
    if (Array.isArray(_children) && _children.length > 0) {
      getOptionItems(_children);
    }
  });
}

const _multiple = computed(() => (props.multiple ? true : false));

onBeforeMount(() => {
  fetch();
});
</script>

<template>
  <Select
    allowClear
    maxTagCount="responsive"
    class="tree-wrapper"
    :open="open"
    :mode="_multiple ? 'multiple' : undefined"
    :placeholder="placeholder"
    :value="_multiple ? checkedKeys : selectedKeys"
    :getPopupContainer="getPopupContainer"
    :options="options"
    @change="onChange"
    @dropdownVisibleChange="onOpenChange"
  >
    <template #dropdownRender>
      <a-form-item-rest v-if="!loading && treeData.length > 0">
        <Tree
          virtual
          defaultExpandAll
          :checkStrictly="_multiple"
          :checkable="_multiple"
          :multiple="_multiple"
          :selectable="!_multiple"
          :height="256"
          :fieldNames="fieldNames"
          :treeData="treeData"
          v-model:checkedKeys="checkedKeys"
          :selectedKeys="selectedKeys"
          @select="onSelect"
          @check="onCheck"
        >
          <template v-if="_multiple" #title="{ name, selectedTotal, selectedCount, childs }">
            <div class="tree-node-wrapper">
              <div :title="name">{{ name }}</div>
              <div
                v-if="childs && childs.length > 0 && selectedCount !== selectedTotal"
                class="tree-node-action"
                @click.stop="onCheckAll(childs)"
              >
                全选
              </div>
              <div
                v-if="childs && childs.length > 0 && selectedCount === selectedTotal"
                class="tree-node-action"
                @click.stop="onUncheckAll(childs)"
              >
                取消全选
              </div>
            </div>
          </template>
        </Tree>
      </a-form-item-rest>
      <div v-else class="info-wrapper">
        <a-spin v-if="loading" />
        <a-empty
          style="flex-shrink: 0"
          v-if="!loading && treeData.length === 0"
          :image="simpleImage"
        />
      </div>
    </template>
  </Select>
</template>

<style lang="scss" scoped>
.tree-wrapper {
  cursor: default;
}
.tree-node-wrapper {
  display: flex;
  justify-content: flex-start;
  align-items: center;
  overflow: hidden;
}
.tree-node-action {
  margin-left: 8px;
  padding: 0 8px;
  height: 100%;
  flex-shrink: 0;
  color: v-bind('token.colorPrimary');
}
.info-wrapper {
  min-height: 100px;
  display: flex;
  align-items: center;
  justify-content: center;
}
</style>
