<script lang="ts" setup>
import { computed, onBeforeMount, ref, watch } from 'vue';
import { Http } from '@lexikos/doraemon-network';
import { Form, message, Cascader } from 'ant-design-vue';
import { cloneDeep, includes, isEqual, map, uniqBy } from 'lodash-es';
import type { SelectorEmits, CascaderItem, SelectorGradeClassProps } from './types';
import TreeSelectLoadingInput from './components/TreeSelectLoadingInput.vue';
import { filterItemsByIds } from './utils';

defineOptions({
  name: 'SelectorGradeClass',
});

const props = withDefaults(defineProps<SelectorGradeClassProps>(), {
  multiple: true,
  placeholder: '请选择年级/班级',
});

const emit = defineEmits<SelectorEmits<CascaderItem | CascaderItem[], CascaderItem[]>>();

const fieldNames = {
  label: 'name',
  value: 'id',
};
const getPopupContainer = (triggerNode: any) => triggerNode?.parentNode;
const dropdownStyle = { maxHeight: '400px', overflow: 'auto' };

const formItemContext = Form.useInjectFormItemContext();

const treeData = ref<CascaderItem[] | null>(null);
const finalValue = ref<string[][] | string[]>();
const checkedNodes = ref<CascaderItem[]>([]);
const loading = ref(false);

/**
 * 数据转换
 * @param {CascaderItem[]} items
 * @return {CascaderItem[]}
 */
function getCascaderItems(
  items: CascaderItem[],
  {
    disabledIds,
    parentIds = [],
  }: {
    disabledIds?: string[];
    parentIds?: string[];
  } = {},
): CascaderItem[] {
  return map(items, (item) => {
    const _children = item.children;
    const _parentIds = [...parentIds, item.id];

    const children =
      Array.isArray(_children) && _children.length > 0
        ? getCascaderItems(_children, { disabledIds, parentIds: _parentIds })
        : undefined;

    return {
      ...item,
      children,
      disabled: includes(disabledIds, item.id),
      parentIds: _parentIds,
    };
  });
}

const fetch = async () => {
  if (loading.value) {
    return;
  }
  try {
    loading.value = true;
    const res = await Http.getInstance().get<CascaderItem[]>(`/api/campusbase/locationGradeClazz`, {
      scope: props.scope || '',
      locationId: props.locationId || '',
    });
    treeData.value = res || [];
  } catch (error: any) {
    treeData.value = [];
    message.error(error?.desc || '获取数据出错，请重试');
  } finally {
    loading.value = false;
  }
};

const finallyTreeData = computed(() => {
  if (!treeData.value) {
    return [];
  }
  return getCascaderItems(cloneDeep(treeData.value), {
    disabledIds: props.disabledItemIds,
  });
});

// 同步数据
const syncFinalValue = (items: CascaderItem[], propsValue: CascaderItem[]) => {
  const _items = filterItemsByIds(
    items,
    map(propsValue, (i) => i.id),
    [],
  );

  finalValue.value = props.multiple ? map(_items, (i) => i.parentIds) : _items[0]?.parentIds || [];
  checkedNodes.value = _items;
};

watch(finallyTreeData, (newVal) => {
  if (!props.value?.length) {
    finalValue.value = [];
    return;
  }

  if (!newVal?.length || finalValue.value) {
    return;
  }

  syncFinalValue(newVal, props.value);
});

// 更新值
watch(
  () => props.value,
  (newVal) => {
    if (finalValue.value) {
      const _value = props.multiple
        ? map(finalValue.value as string[][], (i) => i.slice(-1)[0])
        : (finalValue.value as string[]).slice(-1);

      if (
        isEqual(
          map(newVal, (i) => i.id),
          _value,
        )
      ) {
        return;
      }
    }

    // 清空
    if (!newVal || !newVal?.length) {
      finalValue.value = [];
      return;
    }

    syncFinalValue(finallyTreeData.value, newVal);
  },
);

const disabledCheckedNodes = computed(() => checkedNodes.value.filter((i) => i.disabled));

const onChange = (_keys: any, selectedOptions: CascaderItem[] | CascaderItem[][]) => {
  let _nodes: any[] = [];
  if (selectedOptions) {
    _nodes = props.multiple
      ? selectedOptions.map((i) => i.slice(-1)[0])
      : selectedOptions.slice(-1);
  }

  if (disabledCheckedNodes.value.length) {
    _nodes = uniqBy([..._nodes, ...disabledCheckedNodes.value], 'id');
  }

  checkedNodes.value = _nodes;
  emit('update:value', _nodes);
  emit('change', _nodes, selectedOptions);
  formItemContext.onFieldChange();
};

const disabled = computed(() => {
  // 单选 并且当前选中的是不可操作的
  if (!props.multiple && disabledCheckedNodes.value.length) {
    return disabledCheckedNodes.value[0].disabled;
  }
  return props.disabled;
});

onBeforeMount(() => {
  fetch();
});
</script>

<template>
  <TreeSelectLoadingInput v-if="!treeData" :placeholder="placeholder" />
  <div v-else>
    <Cascader
      showSearch
      maxTagCount="responsive"
      v-model:value="finalValue"
      :multiple="multiple"
      :changeOnSelect="changeOnSelect"
      :placeholder="placeholder"
      :disabled="disabled"
      :getPopupContainer="getPopupContainer"
      :options="finallyTreeData"
      :loading="loading"
      :dropdownStyle="dropdownStyle"
      :fieldNames="fieldNames"
      @change="onChange as any"
    ></Cascader>
  </div>
</template>
