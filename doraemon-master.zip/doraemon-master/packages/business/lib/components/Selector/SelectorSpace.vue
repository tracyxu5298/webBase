<script lang="ts" setup>
import { computed, onBeforeMount, ref, watch } from 'vue';
import { Http } from '@lexikos/doraemon-network';
import { message, TreeSelect } from 'ant-design-vue';
import { cloneDeep, isArray, isEqual, isObject, isString } from 'lodash-es';
import {
  type TreeSelectorProps,
  type SelectorItem,
  type SelectorTreeEmits,
  type SelectorTreeValue,
} from './types';
import { getTreeItems } from './utils';

defineOptions({
  name: 'SelectorSpace',
});

const props = withDefaults(defineProps<TreeSelectorProps>(), {
  multiple: true,
  placeholder: '请选择空间',
});

const emit = defineEmits<SelectorTreeEmits>();

const fieldNames = {
  label: 'name',
  value: 'id',
  children: 'children',
};

const getPopupContainer = (triggerNode: any) => triggerNode?.parentNode;
const SHOW_ALL = TreeSelect.SHOW_ALL;

type FinalValue = SelectorTreeValue[] | string[] | SelectorTreeValue | string;

const finalValue = ref<FinalValue>();
const treeData = ref<SelectorItem[] | null>(null);
const loading = ref(false);

const fetch = async () => {
  if (loading.value) {
    return;
  }
  try {
    loading.value = true;
    const res = await Http.getInstance().get<SelectorItem[]>('/api/building/space/findTree', {
      flag: '0',
      locationId: props.locationId || '',
    });
    treeData.value = res || [];
  } catch (error: any) {
    treeData.value = [];
    message.error(error?.desc || '获取数据出错，请重试');
  } finally {
    loading.value = false;
    if (props.value) {
      const _value = props.value as string[];
      // 多选
      if (props.multiple && _value.length) {
        // 节点选择完全受控
        finalValue.value = (
          !props.treeCheckStrictly && isString(_value[0])
            ? _value.map((i) => ({
                value: i,
              }))
            : _value
        ) as FinalValue;
      } else {
        finalValue.value = _value;
      }
    }
  }
};

const onChange = (value: FinalValue, label: string[], extra: any) => {
  let _value = value;
  let _label = label;
  // 多选
  if (props.multiple) {
    const _val = value as SelectorTreeValue[] | string[];
    // 多选有值，且值时对象
    if (_val?.length && isObject(_val[0])) {
      _value = _val.map((i) => (i as SelectorTreeValue).value);
      _label = _val.map((i) => (i as SelectorTreeValue).label);
    }
  }

  emit('update:value', _value as string | string[]);
  emit('change', _value as string | string[], _label, extra);
};

watch(
  () => props.value,
  (newVal) => {
    if (!newVal) {
      finalValue.value = undefined;
      return;
    }

    // 值相等
    if (
      isEqual(newVal, finalValue.value) ||
      (isArray(finalValue.value) &&
        isObject(finalValue.value?.[0]) &&
        isEqual(
          newVal,
          (finalValue.value as SelectorTreeValue[]).map((i) => i.value),
        ))
    ) {
      return;
    }

    // 多选 节点选择完全受控
    if (props.multiple && !props.treeCheckStrictly) {
      const _newVal = newVal as string[];
      if (!_newVal.length) {
        finalValue.value = [];
        return;
      }

      finalValue.value = (
        isString(_newVal[0])
          ? _newVal.map((i) => ({
              value: i,
            }))
          : _newVal
      ) as FinalValue;
    } else {
      finalValue.value = newVal as string | string[];
    }
  },
);

const finallyTreeData = computed(() => {
  if (!treeData.value) {
    return [];
  }
  return getTreeItems<SelectorItem>(cloneDeep(treeData.value), {
    disabledIds: props.disabledItemIds,
  });
});

const _multiple = computed(() => (props.multiple ? true : false));

onBeforeMount(() => {
  fetch();
});
</script>
<template>
  <TreeSelect
    showSearch
    virtual
    treeDefaultExpandAll
    maxTagCount="responsive"
    treeNodeFilterProp="name"
    v-model:value="finalValue"
    :showCheckedStrategy="SHOW_ALL"
    :treeCheckStrictly="_multiple"
    :treeCheckable="_multiple"
    :multiple="_multiple"
    :height="400"
    :placeholder="placeholder"
    :getPopupContainer="getPopupContainer"
    :treeData="finallyTreeData"
    :loading="loading"
    :fieldNames="fieldNames"
    @change="onChange"
  ></TreeSelect>
</template>
