<script lang="ts" setup>
import { computed, onBeforeMount, ref, shallowRef, watch } from 'vue';
import { Form, message, Select } from 'ant-design-vue';
import { cloneDeep, concat, find, isArray, isEqual, map } from 'lodash-es';
import { useHttp } from '../../hooks';
import TreeSelectPane from './components/TreeSelectPane.vue';
import { filterItemsByIds, getTreeItems } from './utils';
import {
  type SelectorItem,
  type SelectorProps,
  type SelectorEmits,
  DeviceItemLevelEnum,
} from './types';
import Item from './components/Item.vue';
import SelectorWrap from './components/SelectorWrap.vue';
import DeviceFilter from './components/DeviceFilter.vue';

defineOptions({
  name: 'SelectorSpaceDevice',
});

const props = withDefaults(defineProps<SelectorProps>(), {
  multiple: true,
  title: '选择设备',
  placeholder: '请选择设备',
  showTrigger: true,
});

const emit = defineEmits<SelectorEmits<SelectorItem, string | string[]>>();

const fieldNames = {
  label: 'name',
  value: 'id',
};

const formItemContext = Form.useInjectFormItemContext();

const http = useHttp();

interface FilterData {
  type: string | null;
  tag: string | null;
}

// 用户点击确定的值
const treeData = shallowRef<SelectorItem[]>([]);
const finalValue = ref<string | string[]>();
const checkedNodes = ref<SelectorItem[]>([]);
const loading = ref<boolean>(false);
/** 临时存储打开时选中数据，中途删除，用户点取消时弹窗取消时需要撤销 */
const snapCheckedNodes = ref<SelectorItem[]>([]);
const selectorWrapRef = ref();
const filterData = ref<FilterData>({
  type: null,
  tag: null,
});

// 单选并且选中的就是不可反选的则 disabled
const disabled = computed(
  () => props.disabled || (!props.multiple && checkedNodes.value[0]?.disabled),
);

const finallyTreeData = computed(() => {
  if (!treeData.value) {
    return [];
  }
  return getTreeItems(cloneDeep(treeData.value), {
    disabledIds: props.disabledItemIds,
    getCheckable: (level) => level === DeviceItemLevelEnum.device,
  });
});

// 更新值
watch(finalValue, (newVal, oldVal) => {
  emit('update:value', newVal!);

  formItemContext.onFieldChange();
  const _checkedNodes = newVal
    ? checkedNodes.value.filter((i) => (isArray(newVal) ? newVal.includes(i.id) : newVal === i.id))
    : [];

  // 多选
  if (isArray(newVal)) {
    // 下拉框删除
    if (oldVal && newVal.length < oldVal.length) {
      checkedNodes.value = cloneDeep(_checkedNodes);
    }
  } else {
    // 单选时没有值直接清空选中的节点
    if (!newVal) {
      checkedNodes.value = [];
    }
  }

  if (!isEqual(newVal, props.value)) {
    emit('change', newVal!, cloneDeep(_checkedNodes));
  }
});

watch(
  () => props.value,
  (newVal) => {
    if (!finallyTreeData.value?.length) {
      return;
    }

    if (isEqual(newVal, finalValue.value)) {
      return;
    }

    // 清空
    if (!newVal || !newVal?.length) {
      finalValue.value = newVal;
      checkedNodes.value = [];
      return;
    }

    // 单选
    if (!isArray(newVal)) {
      finalValue.value = newVal;
      checkedNodes.value = filterItemsByIds(finallyTreeData.value, [newVal], []);
      return;
    }

    // 多选
    const addIds: string[] = [];
    const result: SelectorItem[] = [];

    newVal.forEach((i) => {
      const _item = checkedNodes.value.find((j) => j.id === i);
      if (_item) {
        result.push(_item);
      } else {
        addIds.push(i);
      }
    });

    // 外部增加值
    if (addIds.length) {
      const _addList = filterItemsByIds(finallyTreeData.value, addIds, []);
      checkedNodes.value = concat(result, _addList);
    } else {
      checkedNodes.value = cloneDeep(result);
    }

    finalValue.value = newVal;
  },
);

// 选择人员弹窗
const onOpen = () => {
  // 每次打开存储临时缓存，
  // 用户删除后，点击取消时有可能需要撤销回去
  snapCheckedNodes.value = cloneDeep(checkedNodes.value);
};
// 已选人员删除
const onRemove = (item: SelectorItem) => {
  if (!item) {
    return;
  }
  checkedNodes.value = checkedNodes.value.filter((i) => i.id !== item.id);
};

// 确定选择人员
const onOk = () => {
  if (props.multiple) {
    finalValue.value = checkedNodes.value.map((i) => i.id);
  } else {
    finalValue.value = checkedNodes.value[0]?.id;
  }
  // 关闭清空临时存储的选择数据
  snapCheckedNodes.value = [];
};

// 关闭选择人员弹窗
const onCancel = () => {
  // 点击取消恢复上次确定的内容
  if (props.multiple) {
    if (finalValue.value?.length) {
      const _items = map(finalValue.value, (i) => {
        // 先查找是否在选中的数据中
        const c = find(checkedNodes.value, (j) => j.id === i);
        if (c) {
          return c;
        }
        // 没有则是上次选中的数据里
        return find(snapCheckedNodes.value, (j) => j.id === i);
      }).filter(Boolean);

      checkedNodes.value = cloneDeep(_items) as SelectorItem[];
    } else {
      checkedNodes.value = [];
    }
  } else {
    checkedNodes.value = cloneDeep(snapCheckedNodes.value);
  }
  // 关闭清空临时存储的选择数据
  snapCheckedNodes.value = [];
};

const onClearAll = () => {
  // disabled 不能清
  checkedNodes.value = checkedNodes.value.filter((i) => i.disabled);
};

const setDefaultValue = (items?: SelectorItem[]) => {
  if (!props.value || (props.multiple && !props.value.length)) {
    return;
  }
  if (!items?.length) {
    finalValue.value = props.value;
    return;
  }

  // 查找当前选中的数据
  let _checked = filterItemsByIds(items, isArray(props.value) ? props.value : [props.value], []);
  if (props.disabledItemIds?.length) {
    _checked = _checked.map((i) => ({
      ...i,
      disabled: props.disabledItemIds!.includes(i.id),
    }));
  }
  checkedNodes.value = _checked;
  finalValue.value = props.value;
};

const fetchTreeData = async (params: Partial<FilterData> = {}) => {
  try {
    loading.value = true;
    const res = await http.post<SelectorItem[]>(
      '/api/controller/device/actions/getDeviceSpaceTree',
      {
        labelId: params.tag || '',
        deviceTypeId: params.type || '',
        locationId: props.locationId || '',
      },
    );
    treeData.value = res || [];
    setDefaultValue(res);
  } catch (error: any) {
    setDefaultValue();
    message.error(error?.desc || '获取数据出错，请重试');
  } finally {
    loading.value = false;
  }
};

const onChangeFilter = (_data: FilterData) => {
  const { type, tag } = _data;
  // 数据变化再进行获取数据
  if (filterData.value.type !== type || filterData.value.tag !== tag) {
    filterData.value = _data;
    fetchTreeData({ type, tag });
  }
};

const onShow = (show: () => void) => {
  if (!props.disabled) {
    show();
  }
};

const open = () => {
  selectorWrapRef.value?.showModal();
};

defineExpose({ open });

onBeforeMount(() => {
  fetchTreeData();
});
</script>

<template>
  <SelectorWrap
    ref="selectorWrapRef"
    :title="title"
    :checked-length="checkedNodes.length"
    @open="onOpen"
    @ok="onOk"
    @cancel="onCancel"
    @clear-all="onClearAll"
  >
    <template v-if="showTrigger" #select="{ show }">
      <slot name="trigger" :show="show">
        <Select
          style="width: 100%"
          max-tag-count="responsive"
          :mode="maxCount === 1 || !multiple ? undefined : 'multiple'"
          :loading="loading"
          v-model:value="finalValue"
          :fieldNames="fieldNames"
          :placeholder="placeholder"
          :options="checkedNodes"
          :open="false"
          :disabled="disabled"
          @click="onShow(show)"
        ></Select>
      </slot>
    </template>
    <template #select-data>
      <TreeSelectPane
        v-model:checked="checkedNodes"
        search-placeholder="搜索设备"
        :multiple="multiple"
        :max-count="maxCount"
        :loading="loading"
        :tree-data="finallyTreeData"
      >
        <template #search-input-extra>
          <DeviceFilter @change="onChangeFilter" />
        </template>
      </TreeSelectPane>
    </template>
    <template #select-result>
      <Item
        v-for="item in checkedNodes"
        allow-clear
        :key="item.id"
        :data="item"
        @remove="onRemove"
      ></Item>
    </template>
  </SelectorWrap>
</template>
