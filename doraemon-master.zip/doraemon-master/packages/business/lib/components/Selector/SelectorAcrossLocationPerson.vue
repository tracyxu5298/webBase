<script lang="ts" setup>
import { computed, onBeforeMount, ref, watch } from 'vue';
import { Form, message, Select } from 'ant-design-vue';
import {
  cloneDeep,
  concat,
  filter,
  find,
  includes,
  isArray,
  isEqual,
  map,
  uniqBy,
} from 'lodash-es';
import { useHttp, useLocationId } from '../../hooks';
import TreeSelectPane from './components/TreeSelectPane.vue';
import { getTreeItems, searchPagesize } from './utils';
import {
  PersonItemLevelEnum,
  LocationScopeEnum,
  type SelectorItem,
  type SelectorEmits,
  type AcrossLocationPersonProps,
  type SearchParams,
} from './types';
import Item from './components/Item.vue';
import SelectorWrap from './components/SelectorWrap.vue';
import { LocationLevel } from '../../enums';
import usePersonItemsData from './components/usePersonItemsData';

defineOptions({
  name: 'SelectorAcrossLocationPerson',
});

const props = withDefaults(defineProps<AcrossLocationPersonProps>(), {
  multiple: true,
  scope: LocationScopeEnum.all,
  title: '选择人员',
  placeholder: '请选择人员',
  showTrigger: true,
});

const emit = defineEmits<SelectorEmits<SelectorItem, string | string[]>>();

const fieldNames = {
  label: 'name',
  value: 'id',
};

const formItemContext = Form.useInjectFormItemContext();

const http = useHttp();
const { personItemsMap, getPersonItemKey } = usePersonItemsData();

// 用户点击确定的值
const treeData = ref<SelectorItem[]>([]);
const finalValue = ref<string | string[]>();
const checkedNodes = ref<SelectorItem[]>([]);
const loading = ref<boolean>(false);
const loadingDefaultUser = ref<boolean>(false);
/** 临时存储打开时选中数据，中途删除，用户点取消时弹窗取消时需要撤销 */
const snapCheckedNodes = ref<SelectorItem[]>([]);
const selectorWrapRef = ref();

const locationId = computed(() => {
  return props.locationId || useLocationId().value;
});

// 单选并且选中的就是不可反选的则 disabled
const disabled = computed(
  () => props.disabled || (!props.multiple && checkedNodes.value[0]?.disabled),
);

/**
 * 编辑时回显用户信息
 */
const fetchUserInfo = async (userIds: string | string[]) => {
  if (!userIds || !userIds?.length) {
    return;
  }

  try {
    loadingDefaultUser.value = true;
    const res = await http.post<SelectorItem[]>(
      '/api/auth/userSelect/users',
      isArray(userIds) ? userIds : [userIds],
    );

    loadingDefaultUser.value = false;

    return (res || []).map((i) => {
      if (i.departmentIds?.length) {
        i.departmentIds.forEach((d: string) => {
          getPersonItemKey(i.id, d);
        });
      }
      return {
        ...i,
        disabled: props.disabledItemIds?.includes(i.id),
      };
    });
  } catch (error: any) {
    loadingDefaultUser.value = false;
    message.error(error?.desc || '获取数据出错，请重试');
    return [];
  }
};

// 更新值
watch(finalValue, (newVal, oldVal) => {
  emit('update:value', newVal!);

  formItemContext.onFieldChange();

  const _checkedNodes = newVal
    ? checkedNodes.value.filter((i) => (isArray(newVal) ? newVal.includes(i.id) : newVal === i.id))
    : [];

  // 多选
  if (isArray(newVal)) {
    // 下拉框删除
    if (oldVal && newVal.length < oldVal.length) {
      checkedNodes.value = cloneDeep(_checkedNodes);
    }
  } else {
    // 单选时没有值直接清空选中的节点
    if (!newVal) {
      checkedNodes.value = [];
    }
  }

  if (!isEqual(newVal, props.value)) {
    emit('change', newVal!, cloneDeep(_checkedNodes));
  }
});

watch(
  () => props.value,
  (newVal) => {
    if (!treeData.value?.length) {
      return;
    }

    if (isEqual(newVal, finalValue.value)) {
      return;
    }

    // 清空
    if (!newVal || !newVal?.length) {
      finalValue.value = newVal;
      checkedNodes.value = [];
      return;
    }

    // 单选
    if (!isArray(newVal)) {
      fetchUserInfo(newVal).then((res) => {
        if (res) {
          checkedNodes.value = res;
          finalValue.value = newVal;
        }
      });
      return;
    }

    // 多选
    const addIds: string[] = [];
    const result: SelectorItem[] = [];

    newVal.forEach((i) => {
      const _item = checkedNodes.value.find((j) => j.id === i);
      if (_item) {
        result.push(_item);
      } else {
        addIds.push(i);
      }
    });

    // 外部增加值
    if (addIds.length) {
      fetchUserInfo(addIds).then((res) => {
        if (res) {
          checkedNodes.value = concat(result, res);
          finalValue.value = newVal;
        }
      });
    } else {
      checkedNodes.value = cloneDeep(result);
      finalValue.value = newVal;
    }
  },
);

watch(
  () => props.disabledItemIds,
  (newVal) => {
    treeData.value = map(treeData.value, (i) => {
      if (i.children?.length) {
        return {
          ...i,
          children: getTreeItems(i.children, {
            disabledIds: newVal,
            getCheckable: (level) => level === PersonItemLevelEnum.user,
          }),
        };
      }
      return i;
    });
  },
);

// 选择人员弹窗
const onOpen = () => {
  // 每次打开存储临时缓存，
  // 用户删除后，点击取消时有可能需要撤销回去
  snapCheckedNodes.value = cloneDeep(checkedNodes.value);
};
// 已选人员删除
const onRemove = (item: SelectorItem) => {
  if (!item) {
    return;
  }
  checkedNodes.value = checkedNodes.value.filter((i) => i.id !== item.id);
};

// 确定选择人员
const onOk = () => {
  if (props.multiple) {
    finalValue.value = checkedNodes.value.map((i) => i.id);
  } else {
    finalValue.value = checkedNodes.value[0]?.id;
  }
  // 关闭清空临时存储的选择数据
  snapCheckedNodes.value = [];
};

// 关闭选择人员弹窗
const onCancel = () => {
  // 点击取消恢复上次确定的内容
  if (props.multiple) {
    if (finalValue.value?.length) {
      const _items = map(finalValue.value, (i) => {
        // 先查找是否在选中的数据中
        const c = find(checkedNodes.value, (j) => j.id === i);
        if (c) {
          return c;
        }
        // 没有则是上次选中的数据里
        return find(snapCheckedNodes.value, (j) => j.id === i);
      }).filter(Boolean);

      checkedNodes.value = cloneDeep(_items) as SelectorItem[];
    } else {
      checkedNodes.value = [];
    }
  } else {
    checkedNodes.value = cloneDeep(snapCheckedNodes.value);
  }
  // 关闭清空临时存储的选择数据
  snapCheckedNodes.value = [];
};

const onClearAll = () => {
  // disabled 不能清
  checkedNodes.value = checkedNodes.value.filter((i) => i.disabled);
};

// 树选择选中值发生变化的回调
const onChecked = (checkedValue: string[], e: any) => {
  const _checkedNodes = (e?.checkedNodes || []) as SelectorItem[];

  if (e.checked) {
    // 选中，添加并去重
    return uniqBy(cloneDeep([...checkedNodes.value, ..._checkedNodes]), 'id');
  }

  // 取消选中的
  return filter(cloneDeep(checkedNodes.value), (i) => checkedValue.includes(i.id));
};

// 异步加载组织数据
const onLoadData = (treeNode: any, loadedKeys: string[]) => {
  return new Promise<void>((resolve, reject) => {
    const { level, id, children, departmentIds } = treeNode.dataRef || {};
    // 非组织
    if (level !== PersonItemLevelEnum.location || includes(loadedKeys, id) || children) {
      resolve();
      return;
    }

    // 获取当前组织下的人员
    http
      .get<SelectorItem[]>('/api/auth/userSelect/locationPersons', {
        locationId: id,
        locationLevel: LocationLevel.Bureau,
      })
      .then((res) => {
        if (res?.[0]?.children?.length) {
          const departmentId = res[0].id || departmentIds?.[0] || '';
          const _data = getTreeItems(res[0].children, {
            disabledIds: props.disabledItemIds,
            getCheckable: (level) => level === PersonItemLevelEnum.user,
            getPersonItemKey,
            parentId: departmentId,
          });
          treeNode.dataRef.children = cloneDeep(_data);
        } else {
          treeNode.dataRef.children = [];
          treeNode.dataRef.isLeaf = true;
        }

        treeData.value = [...treeData.value];
        resolve();
      })
      .catch((error: any) => {
        message.error(error?.desc || '获取数据失败，请重试');
        reject();
      });
  });
};

const fetchTreeData = async () => {
  try {
    loading.value = true;
    const res = await http.get<SelectorItem[]>('/api/auth/userSelect/locationRelationship', {
      locationId: locationId.value,
      scope: props.scope,
    });
    treeData.value =
      map(res, (i) => {
        // eslint-disable-next-line @typescript-eslint/no-unused-vars
        const { children, ...rest } = i;
        return {
          ...rest,
          key: i.id,
          checkable: false,
          isLeaf: false,
          disabled: props.disabledItemIds?.includes(i.id),
        };
      }) || [];
  } catch (error: any) {
    message.error(error?.desc || '获取数据出错，请重试');
  } finally {
    loading.value = false;
  }
};

// 远程搜索
const onSearchService = async (params: SearchParams) => {
  try {
    const res = await http.get<{ total: number; list: SelectorItem[] }>(
      '/api/auth/userSelect/locationPerson',
      {
        ...params,
        pageSize: searchPagesize,
        scope: props.scope,
      },
    );
    const list = res?.list?.length
      ? res.list.map((i) => {
          if (i.departmentIds?.length) {
            i.departmentIds.forEach((departmentId: string) => {
              getPersonItemKey(i.id, departmentId);
            });
          }
          return {
            ...i,
            disabled: props.disabledItemIds?.includes(i.id),
          };
        })
      : [];
    return Promise.resolve({ ...res, list });
  } catch (error) {
    return Promise.reject(error);
  }
};

const onShow = (show: () => void) => {
  if (!disabled.value) {
    show();
  }
};

const open = () => {
  selectorWrapRef.value?.showModal();
};

defineExpose({ open });

onBeforeMount(() => {
  fetchTreeData();
  if (props.value) {
    fetchUserInfo(props.value).then((res) => {
      if (res) {
        checkedNodes.value = res;
        finalValue.value = props.value;
      }
    });
  }
});
</script>

<template>
  <SelectorWrap
    ref="selectorWrapRef"
    :title="title"
    :checked-length="checkedNodes.length"
    @open="onOpen"
    @ok="onOk"
    @cancel="onCancel"
    @clear-all="onClearAll"
  >
    <template v-if="showTrigger" #select="{ show }">
      <slot name="trigger" :show="show">
        <Select
          style="width: 100%"
          max-tag-count="responsive"
          :mode="maxCount === 1 || !multiple ? undefined : 'multiple'"
          :loading="loadingDefaultUser"
          v-model:value="finalValue"
          :fieldNames="fieldNames"
          :placeholder="placeholder"
          :options="checkedNodes"
          :open="false"
          :disabled="disabled"
          @click="onShow(show)"
        ></Select>
      </slot>
    </template>
    <template #select-data>
      <TreeSelectPane
        v-model:checked="checkedNodes"
        description-key="position"
        :description-search-key="['locationName', 'position']"
        search-placeholder="搜索人员"
        :current-location-id="locationId"
        :multiple="multiple"
        :max-count="maxCount"
        :loading="loading"
        :tree-data="treeData"
        :items-checked-map="personItemsMap"
        :on-load-data="onLoadData"
        :on-search-service="onSearchService"
        :on-checked="onChecked"
      />
    </template>
    <template #select-result>
      <Item
        v-for="item in checkedNodes"
        allow-clear
        :key="item.id"
        :data="item"
        :description="`${item.locationName || ''}${item.locationName && item.position ? '-' : ''}${
          item.position || ''
        }`"
        @remove="onRemove"
      ></Item>
    </template>
  </SelectorWrap>
</template>
