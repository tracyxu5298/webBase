/** 选择人员范围 */
export { default as SelectorPersonScope } from './SelectorPersonScope.vue';
/** 跨组织选择人员 */
export { default as SelectorAcrossLocationPerson } from './SelectorAcrossLocationPerson.vue';
/** 跨组织选择人员范围 */
export { default as SelectorAcrossLocationPersonScope } from './SelectorAcrossLocationPersonScope.vue';
/** 选择人员 */
export { default as SelectorPerson } from './SelectorPerson.vue';
/** 选择部门 */
export { default as SelectorDepartment } from './SelectorDepartment.vue';
/** 选择组织 */
export { default as SelectorLocation } from './SelectorLocation.vue';
/** 选择组织弹窗 */
export { default as SelectorLocationModal } from './SelectorLocationModal.vue';
/** 选择学生 */
export { default as SelectorStudent } from './SelectorStudent.vue';
/** 选择学生范围 */
export { default as SelectorStudentScope } from './SelectorStudentScope.vue';
/** 跨组织选择学生 */
export { default as SelectorAcrossLocationStudent } from './SelectorAcrossLocationStudent.vue';
/** 跨组织选择学生范围 */
export { default as SelectorAcrossLocationStudentScope } from './SelectorAcrossLocationStudentScope.vue';
/** 选择年级/班级 */
export { default as SelectorGradeClass } from './SelectorGradeClass.vue';
/** 选择空间 */
export { default as SelectorSpace } from './SelectorSpace.vue';
/** 选择设备范围 */
export { default as SelectorDeviceScope } from './SelectorDeviceScope.vue';
/** 选择设备 */
export { default as SelectorDevice } from './SelectorDevice.vue';
/** 选择职位 */
export { default as SelectorPosition } from './SelectorPosition.vue';
/** 选择离职人员 */
export { default as SelectorSeparatedPerson } from './SelectorSeparatedPerson.vue';

// export { default as AllSelectorDemo } from './Demo.vue';

export * from './types';
