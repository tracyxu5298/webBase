import type { TreeSelectProps } from 'ant-design-vue';

/** 跨组织选择人员时查询得数据范围 */
export enum LocationScopeEnum {
  /** 全部组织 */
  all = 'all',
  /** 祖先组织 */
  ancestor = 'ancestor',
  /** 父级组织 */
  parent = 'parent',
  /** 儿孙组织 */
  descendant = 'descendant',
  /** 儿子组织 */
  children = 'children',
  /** 兄弟组织 */
  sibling = 'sibling',
}

/** 选项的类型 0组织 1部门 2人员 3角色 4用户组 */
export enum PersonItemLevelEnum {
  /** 0组织 */
  location = 0,
  /** 1部门 */
  department,
  /** 2人员 */
  user,
  /** 3角色 */
  role,
  /** 4用户组 */
  userGroup,
}

/** 选项的类型 1学校 2学段 3年级 4班级 21学院 22专业 */
export enum StudentItemLevelEnum {
  /** 0组织 */
  location = 0,
  /** 1学校 */
  school = 1,
  /** 2学段 */
  section = 2,
  /** 3年级 */
  grade = 3,
  /** 4班级 */
  class = 4,
  /** 21学生 */
  student = 5,
  /** 21学院 */
  academy = 21,
  /** 22专业 */
  major = 22,
}

/** 设备选项的类型 1空间 2设备 */
export enum DeviceItemLevelEnum {
  /** 空间 */
  space = 0,
  /** 设备 */
  device = 1,
}

/**
 * 选项的选择类型
 * @params {list} 列表
 * @params {tree} 树
 */
export enum SelectorShowTypeEnum {
  /** 列表展示 */
  list = 'list',
  /** 树展示 */
  tree = 'tree',
}

/**
 * 选择器选项的值
 */
export interface SelectorItem {
  /** 组织/部门/人员 id */
  id: string;
  /** 组织/部门/人员 名称 */
  name: string;
  /**
   * 人员数据类型 0组织 1部门 2人员 3角色 4用户组
   * 学生数据类型 1学段 2人员 3年级 4班级 21学院 22专业
   * */
  level: PersonItemLevelEnum | StudentItemLevelEnum | DeviceItemLevelEnum;
  /** 组织名称 */
  locationName?: string;
  locationId?: string;
  /** 职位 */
  position?: string;
  children?: SelectorItem[];
  /** 根据组件传入的参数 {disabledItemIds} 来生成的数据 */
  disabled?: boolean;
  /** 树选择 拿到数据处理后会新增的参数 */
  checkable?: boolean;
  isLeaf?: boolean;
  /** 用户状态（未审核:unreviewed，审核未通过:auditFailed，正常:normal，已删除:deleted） */
  userStatus: 'unreviewed' | 'auditFailed' | 'normal' | 'deleted';
  [key: string]: any;
}

/**
 * 人员选择器组件入参
 */
export interface SelectorProps<T = string> {
  /**
   * (v-model) 双向绑定数据
   */
  value?: string | T[];
  /**
   * 弹窗的 title
   */
  title?: string;
  /**
   * 是否多选 默认 true
   */
  multiple?: boolean;
  /**
   * 最大可选数量
   */
  maxCount?: number;
  /**
   * 不可操作得人员 id 列表
   */
  disabledItemIds?: string[];
  /**
   * 输入框 placeholder
   */
  placeholder?: string;
  /**
   * 输入框 disabled
   */
  disabled?: boolean;
  /**
   * 是否展示触发弹窗区域 默认 true
   */
  showTrigger?: boolean;
  /**
   * 自定义数据源组织 id
   */
  locationId?: string;
}

/**
 * 人员选择器回调事件
 */
export interface SelectorEmits<T = SelectorItem, K = string[]> {
  (event: 'change', keys: K, items: T[]): void;
  (event: 'update:value', value: K): void;
}

export interface SelectorTreeValue {
  label: string;
  value: string;
  disabled: boolean;
}

export interface SelectorTreeEmits {
  (event: 'change', value: string | string[], label: string[], extra: any): void;
  (event: 'update:value', value: string | string[]): void;
}

/**
 * 范围选择器的 Value
 * 受 labelInValue 影响 需要补上 label&value
 */
export interface SelectorScopeValue extends SelectorItem {
  label: string;
  value: string | number;
  option?: SelectorItem;
}

/** 人员及范围选择器的页签可选 */
export type PersonScopeScope =
  | PersonItemLevelEnum.location
  | PersonItemLevelEnum.role
  | PersonItemLevelEnum.userGroup;

/** 人员及范围选择器入参 */
export interface PersonScopeProps extends Omit<SelectorProps<SelectorItem>, 'multiple' | 'value'> {
  /**
   * 跨组织可选范围
   */
  value?: SelectorScopeValue[];
  /**
   * 可选页签的类型
   * 默认 组织架构/角色/用户组
   */
  scope?: PersonScopeScope[];
}

/** 跨组织人员选择器入参 */
export type AcrossLocationPersonProps = SelectorProps & {
  /**
   * 跨组织可选范围
   */
  scope?: LocationScopeEnum;
};

/** 人员及范围选择器入参 */
export interface AcrossLocationPersonScopeProps
  extends Omit<SelectorProps<SelectorItem>, 'multiple' | 'value'> {
  /**
   * 跨组织可选范围
   */
  value?: SelectorScopeValue[];
  /**
   * 跨组织可选范围
   */
  scope?: LocationScopeEnum;
  /** 根节点是否可选 */
  rootSelectable?: boolean;
}

/** 搜索数据参数 */
export interface SearchParams {
  pageNum: number;
  keyword: string;
}

/** 部门数据 */
export interface DepartmentSelectorItem {
  id: string;
  name: string;
  children: DepartmentSelectorItem[];
}

/** 组织数据 */
export interface LocationSelectorItem {
  /** 组织id */
  id: string;
  /** 组织名称 */
  name: string;
  childs?: LocationSelectorItem[];
}

/** 树选择（下拉框形式） */
export interface TreeSelectorProps extends /* @vue-ignore */ TreeSelectProps {
  value?: string | string[];
  placeholder?: string;
  multiple?: boolean;
  disabledItemIds?: string[];
  /**
   * 自定义数据源组织 id
   */
  locationId?: string;
}

export type LocationTreeSelectorProps = TreeSelectorProps & {
  scope?: LocationScopeEnum;
};

/** 学生范围选择器入参 */
export interface StudentScopeProps extends Omit<SelectorProps<SelectorItem>, 'multiple' | 'value'> {
  /**
   * 跨组织可选范围
   */
  value?: SelectorScopeValue[];
}

export interface CascaderItem extends SelectorItem {
  parentIds: string[];
  children?: CascaderItem[];
}

/** 选择年级班级 */
export interface SelectorGradeClassProps {
  placeholder?: string;
  multiple?: boolean;
  disabledItemIds?: string[];
  disabled?: boolean;
  /**
   * (v-model) 双向绑定数据
   */
  value?: CascaderItem[];
  /**
   * 数据可选的层级
   */
  scope?: StudentItemLevelEnum;
  /** （单选时生效）当此项为 true 时，点选每级菜单选项值都会发生变化 */
  changeOnSelect?: boolean;
  /**
   * 自定义数据源组织 id
   */
  locationId?: string;
}

/** 跨组织人员选择器入参 */
export type AcrossLocationStudentProps = SelectorProps & {
  /**
   * 跨组织可选范围
   */
  scope?: LocationScopeEnum;
};

/** 学生范围选择器入参 */
export interface AcrossLocationStudentScopeProps
  extends Omit<SelectorProps<SelectorItem>, 'multiple' | 'value'> {
  /**
   * 跨组织可选范围
   */
  value?: SelectorScopeValue[];
  /**
   * 跨组织可选范围
   */
  scope?: LocationScopeEnum;
  /** 根节点是否可选 */
  rootSelectable?: boolean;
}

/** 学生范围选择器入参 */
export interface DeviceScopeProps extends Omit<SelectorProps<SelectorItem>, 'multiple' | 'value'> {
  /**
   * 跨组织可选范围
   */
  value?: SelectorScopeValue[];
}
