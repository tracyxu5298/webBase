<script lang="ts" setup>
defineOptions({
  name: 'MicroAppPlaceholder',
});
</script>

<template>
  <slot />
</template>
