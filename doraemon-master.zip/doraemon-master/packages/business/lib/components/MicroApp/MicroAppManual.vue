<script lang="ts" setup>
import { onBeforeUnmount, onMounted, ref, unref } from 'vue';
import { loadMicroApp } from 'qiankun';
import type { MicroApp } from 'qiankun';

export interface MicroAppManualProps {
  /** 秒级别, 默认 '0s' */
  time?: number;
  /** 应用名称 */
  name: string;
  /** 应用服务地址 */
  entry: string;
  /** 传递给子应用属性组 */
  props?: Record<string, any>;
}

defineOptions({
  name: 'MicroAppManual',
});

const microAppManualProps = withDefaults(defineProps<MicroAppManualProps>(), { time: 0 });

const app = ref<MicroApp | null>();
const app$ = ref();
let timer: any;

function loadApp() {
  clearTimeout(timer);
  timer = setTimeout(() => {
    app.value = loadMicroApp(
      {
        name: microAppManualProps.name,
        entry: microAppManualProps.entry,
        container: unref(app$),
        props: microAppManualProps?.props,
      },
      {
        singular: false,
        sandbox: {
          experimentalStyleIsolation: true,
          speedy: true,
        },
      },
    );
  }, microAppManualProps.time * 1000);
}

async function unloadApp() {
  clearTimeout(timer);
  const microApp = unref(app);
  if (microApp && microApp.getStatus() === 'MOUNTED') {
    await microApp.unmount();
  }
  app.value = null;
}

onMounted(loadApp);

onBeforeUnmount(unloadApp);
</script>

<template>
  <div ref="app$" :class="['doraemon-manual', microAppManualProps.name]" />
  <slot />
</template>

<style lang="scss">
.doraemon-manual {
  /* 隐藏因插入子应用布局导致高度的变化 */
  div[data-qiankun^='mqtt-platform'] #root {
    width: 0;
    height: 0;

    div[class^='not_found'] {
      display: none;
    }
    div[class^='notice_center'] {
      display: none;
    }
  }
}
</style>
