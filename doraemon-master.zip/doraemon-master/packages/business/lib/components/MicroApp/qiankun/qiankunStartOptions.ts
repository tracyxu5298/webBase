import type { FrameworkConfiguration } from 'qiankun';

/**
 * 启动 qiankun, start 方法配置参数
 * https://qiankun.umijs.org/zh/api#startopts
 */
const qiankunStartOptions: FrameworkConfiguration = {
  prefetch: false,
  singular: false,
  // 自定义的 fetch 方法
  async fetch(url: any, args?: Record<string, any>) {
    // 拉取线上至本地服务
    const options = args ?? {};
    // 内网访问外网的时候，运营商（深信服）会动态注入/cookie/flash.js,动态插入的脚本加载异常导致微应用加载失败的问题
    if (url.includes('/cookie/flash')) {
      return {
        async text() {
          return '';
        },
      } as any;
    }
    return window.fetch(url, options);
  },
  // 指定部分特殊的动态加载的微应用资源（css/js) 不被 qiankun 劫持处理
  excludeAssetFilter(url: string) {
    // 引用第三方 js,css 资源不进行拦截
    const excludeAssets = [
      /amap\.com/i,
      /mars3d\/3d\.js/i,
      /\/(imp2(-stu|-edu)?)\/.*\.chunk\.css$/i,
      /cookie\/flash\.js/i,
    ];
    return !!excludeAssets.find((regExp) => regExp.test(url));
  },
};

export default qiankunStartOptions;
