export { default as qiankunRegisterApps } from './qiankunRegisterApps';
export * from './qiankunRegisterAppsProps';
export { default as qiankunStartOptions } from './qiankunStartOptions';
export { default as qiankunRegisterLifeCycles } from './qiankunRegisterLifeCycles';
export type { FrameworkLifeCycles } from 'qiankun';
export { addGlobalUncaughtErrorHandler } from 'qiankun';
