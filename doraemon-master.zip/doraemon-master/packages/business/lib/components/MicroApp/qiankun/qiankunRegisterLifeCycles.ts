import type { LoadableApp } from 'qiankun';
import type { IQiankunRegisterAppsProps } from './qiankunRegisterAppsProps';

// https://qiankun.umijs.org/zh/api#registermicroappsapps-lifecycles
const qiankunRegisterLifeCycles = {
  beforeLoad: [
    (app: LoadableApp<IQiankunRegisterAppsProps>) => {
      console.log('[主应用] before load %c%s', 'color: green;', app.name);
      return Promise.resolve();
    },
  ],
  beforeMount: [
    (app: LoadableApp<IQiankunRegisterAppsProps>) => {
      console.log('[主应用] before mount %c%s', 'color: green;', app.name);
      return Promise.resolve();
    },
  ],
  afterMount: [
    (app: LoadableApp<IQiankunRegisterAppsProps>) => {
      console.log('[主应用] after mount %c%s', 'color: green;', app.name);
      return Promise.resolve();
    },
  ],
  beforeUnmount: [
    (app: LoadableApp<IQiankunRegisterAppsProps>) => {
      console.log('[主应用] before unmount %c%s', 'color: green;', app.name);
      return Promise.resolve();
    },
  ],
  afterUnmount: [
    (app: LoadableApp<IQiankunRegisterAppsProps>) => {
      console.log('[主应用] after unmount %c%s', 'color: green;', app.name);
      return Promise.resolve();
    },
  ],
};

export default qiankunRegisterLifeCycles;
