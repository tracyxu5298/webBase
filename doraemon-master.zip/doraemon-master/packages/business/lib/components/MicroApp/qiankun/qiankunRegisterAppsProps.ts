export interface IQiankunRegisterAppsProps {
  token: string;
  shared: any;
  source: string /** 标记来源哪个基座，适配老的应用和后期 */;
}

/**
 * 注册微应用, 主应用需要传递给微应用的数据
 * https://qiankun.umijs.org/zh/api#registermicroappsapps-lifecycles
 * @param {boolean} loading - 微应用加载状态
 */
function qiankunRegisterAppsProps(
  shared: IQiankunRegisterAppsProps['shared'],
): IQiankunRegisterAppsProps {
  return {
    shared,
    token: localStorage.getItem('token') || '',
    source: 'doraemon',
  };
}

export default qiankunRegisterAppsProps;
