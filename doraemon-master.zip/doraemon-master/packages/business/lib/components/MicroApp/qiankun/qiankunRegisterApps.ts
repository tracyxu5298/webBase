import type { RegistrableApp } from 'qiankun';
import { map } from 'lodash-es';
import qiankunRegisterAppsProps from './qiankunRegisterAppsProps';
import type { IQiankunRegisterAppsProps } from './qiankunRegisterAppsProps';

// https://qiankun.umijs.org/zh/api#registermicroappsapps-lifecycles
const qiankunRegisterApps = (
  apps: (RegistrableApp<IQiankunRegisterAppsProps> & { appPath: string })[],
  activeRule: (appPath: string, location: Location) => boolean,
  shared: IQiankunRegisterAppsProps['shared'],
): Array<RegistrableApp<IQiankunRegisterAppsProps>> => {
  const props = qiankunRegisterAppsProps(shared);

  return map(apps, (app) => ({
    ...app,
    props,
    activeRule: activeRule?.bind(null, app.appPath!),
  }));
};

export default qiankunRegisterApps;
