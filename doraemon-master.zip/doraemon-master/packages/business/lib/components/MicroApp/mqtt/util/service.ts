import { Http } from '@lexikos/doraemon-network';

type TSub = {
  topic: string;
  clientId: string;
  bid: string;
};
/**
 * 发起订阅通知
 */
export const mqttNotifySub = async (data: TSub) => {
  const res = await Http.getInstance().post('/api/building/v2/client/notify/sub', data);
  return {
    data: res,
  };
};

// 取消订阅通知
export const mqttNotifyUnsub = async (data: TSub) => {
  const res = await Http.getInstance().post('/api/building/v2/client/notify/unsub', data);
  return {
    data: res,
  };
};

// clientId
export const getClientId = async (data: { uuid: string }) => {
  const res = await Http.getInstance().get('/api/building/v2/client/getClientId', data);
  return res;
};
