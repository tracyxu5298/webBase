import Mqtt from './Mqtt';

const mqtt = new Mqtt();

export { mqtt };
export { default as TOPIC } from './constants';
