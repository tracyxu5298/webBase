<script lang="ts" setup>
import type { Callback } from '../util/lib/mqtt/types';
import mqttApplication from '../util/mqttApplication';
import { map } from 'lodash-es';
import type { PropType } from 'vue';
import { onBeforeUnmount, onUpdated } from 'vue';

const props = defineProps({
  topics: {
    type: Array as PropType<string[]>,
    default: () => [],
  },
  mqttActions: {
    type: Object as PropType<Record<string, Callback>>,
    default: () => ({}),
  },
});

const emits = defineEmits(['init', 'message']);

const connectMqttSuccess = () => {};
const end = () => {
  mqttApplication.mqttServiceInstance.end({
    force: true,
    options: {},
  });
};
const connect = () => {
  mqttApplication.mqttSubscribe(
    {
      topics: props.topics,
      mqttActions: props.mqttActions,
      isConnect: false,
    },
    connectMqttSuccess,
  );
};
const manualSubOrUnsub = (...args: any) => {
  if (!mqttApplication.getStoreMqttInfo().accessToken) {
    return;
  }
  (mqttApplication.manualSubOrUnsub as any)(...args);
};
const unsubscribeTopics = map(props.topics, (topic) => {
  return mqttApplication.mqttStateObservable.subscribe(
    topic,
    (message) => {
      if (!message) return;
      emits('message', { message, topic });
    },
    false,
  );
});

const unsubscribeIsConnected = mqttApplication.mqttStateObservable.subscribeIsConnected((b) => {
  if (!b) {
    return;
  }
  console.log('<imp-mqtt-subscriber> 已连接。');
  connect();
  emits('init', {
    notifySubOrUnSubToEndApi: mqttApplication.notifySubOrUnSubToEndApi,
    manualSubOrUnsub,
    end,
    connect,
  });
});

onUpdated(() => {
  mqttApplication.checkMqttStatusOfRetryMqtt(1000);
});

onBeforeUnmount(() => {
  unsubscribeIsConnected?.();
  unsubscribeTopics.forEach((cb) => {
    return cb?.();
  });
  mqttApplication.clearInterval();
});
</script>

<template>
  <div class="hidden"></div>
</template>
<style lang="scss" scoped>
.hidden {
  display: none;
}
</style>
