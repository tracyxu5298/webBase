import type { Store } from 'pinia';

export type Callback = (...args: any[]) => void;

export type IStoreState = Store<'useMqttStore', {}>;
