export type TopicUrls =
  | 'center/device'
  | 'msg/exception'
  | 'widget/statusBySpaceAndSystem'
  | 'widget/abnormal'
  | 'widget/alarm'
  | 'widget/defense'
  | 'center/device'
  | 'sas/screen'
  | 'fault/record'
  | 'alarm/record'
  | 'parkingPlace/gateStatus'
  | 'log/main'
  | 'log/detail'
  | 'person/monitor/records'
  | 'actionCallback/device'
  | 'space_device/status'
  | 'patrol/detail'
  | 'patrol/space'
  | 'notify/systemMessage'
  | 'notify/requestUnreadNum'
  | 'traffic/teacher'
  | 'traffic/parent'
  | 'campus/recordControlResult'
  | 'campus/live'
  | 'campus/livePersonnelBehavior'
  | 'campus/tour/clazz'
  | 'campus/recordControlResult'
  | 'campus/recordingDevice/info'
  | 'campus/comment/notify'
  | 'layout_device/status'
  | 'connect/renameDevice'
  | 'clazzroom/statistics/grade'
  | 'clazzroom/statistics/clazz'
  | 'sas/home/alarm'
  | 'dataCenter/energyAuditSpace'
  | 'dataCenter/energyAudit'
  | 'dataCenter/lowCarbonOpenTask'
  | 'dataCenter/lowCarbonOpenSpace'
  | 'sas/data/overview/venue'
  | 'traffic/imp'
  | 'sync/task'
  | 'auth/taskCenterMsgReadStatus'
  | 'campus/livePersonnelBehavior'
  | 'campus/multiAccess'
  | 'campus/live'
  | 'data/assembly/student'
  | 'data/assembly/hostel'
  | 'drill/center'
  | 'quality/skippingData';

type Topics = {
  CENTER_DEVICE: TopicUrls;
  SAS_SCREEN: TopicUrls;
  FAULT_RECORD: TopicUrls;
  ALARM_RECORD: TopicUrls;
  PARKING_PLACE_GATE_STATUS: TopicUrls;
  LOG_MAIN: TopicUrls;
  LOG_DETAIL: TopicUrls;
  PERSON_MONITOR_RECORDS: TopicUrls;
  ACTION_CALLBACK_DEVICE: TopicUrls;
  SPACE_DEVICE_STATUS: TopicUrls;
  PATROL_DETAIL: TopicUrls;
  PATROL_SPACE: TopicUrls;
  SYSTEM_MESSAGE_NOTIFY: TopicUrls;
  UNREAD_MESSAGE_NUM_NOTIFY: TopicUrls;
  TOPIC_TRAFFIC_TEACHER: TopicUrls;
  TOPIC_TRAFFIC_PARENT: TopicUrls;
  RECORD_CONTROL_RESULT: TopicUrls;
  TOPIC_LIVE: TopicUrls;
  CLOUD_LIVE: TopicUrls;
  CLOUD_LIVE_BEHAVIOR: TopicUrls;
  CAMPUS_TOUR_CLAZZ: TopicUrls;
  RECORD_CONTROL: TopicUrls;
  RECORD_DEVICE_INFO: TopicUrls;
  LAYOUT_DEVICE_STATUS: TopicUrls;
  RENAME_DEVICE_TOPIC: TopicUrls;
  CLAZZROOM_STATISTICS_GRADE_QUEUE: TopicUrls;
  CLAZZROOM_STATISTICS_CLAZZ_QUEUE: TopicUrls;
  SAS_HOME_ALARM: TopicUrls;
  DATA_CENTER_ENERGY_AUDIT_SPACE: TopicUrls;
  DATA_CENTER_ENERGY_AUDIT: TopicUrls;
  DATA_CENTER_LOW_CARBON_OPEN_TASK: TopicUrls;
  DATA_CENTER_LOW_CARBON_OPEN_SPACE: TopicUrls;
  SAS_DATA_OVERVIEW_VENUE: TopicUrls;
  TOPIC_TRAFFIC_IMP: TopicUrls;
  SYNC_TASK: TopicUrls;
  TASK_CENTER_MSG_STATUS: TopicUrls;
  LIVE_PERSONNEL_BEHAVIOR: TopicUrls;
  LIVE_MULTI_ACCESS: TopicUrls;
  CAMPUS_LIVE: TopicUrls;
  DATA_ASSEMBLY_STUDENT: TopicUrls;
  DATA_ASSEMBLY_HOSTEL: TopicUrls;
  CONTINGENCY_DRILL_CENTER: TopicUrls;
  SPORT_JUMP_ROPING: TopicUrls;
  [topic: string]: TopicUrls;
};

const MQTT_TOPICS: Topics = {
  deviceStatus: 'center/device', // 设备状态通知
  msgException: 'msg/exception', // 系统异常
  widgetDeviceStatusTopic: 'widget/statusBySpaceAndSystem', // 启用推送widget设备信息(widgetShow使用)
  widgetAbnormalTopic: 'widget/abnormal', // 启用推送widget异常信息(widgetShow使用)
  widgetAlarmTopic: 'widget/alarm', // 启用推送widget异常信息(widgetShow使用)
  widgetDefenseTopic: 'widget/defense', // 启用推送布撤防信息(widgetShow使用)

  // 以下启用的主题
  CENTER_DEVICE: 'center/device', // 设备状态通知
  SAS_SCREEN: 'sas/screen', // SAS大屏人脸推送
  FAULT_RECORD: 'fault/record', // 设备故障告警弹窗
  ALARM_RECORD: 'alarm/record', // 系统自定义告警
  PARKING_PLACE_GATE_STATUS: 'parkingPlace/gateStatus', // 闸口实时监控推送
  LOG_MAIN: 'log/main', // 主记录日志结果推送
  LOG_DETAIL: 'log/detail', // 明细记录日志结果推送
  PERSON_MONITOR_RECORDS: 'person/monitor/records', // 安防布控未处理记录
  ACTION_CALLBACK_DEVICE: 'actionCallback/device', // 方法回调
  SPACE_DEVICE_STATUS: 'space_device/status', // 空间设备状态主题
  PATROL_DETAIL: 'patrol/detail', // 设备巡检结果推送
  PATROL_SPACE: 'patrol/space', // 空间巡检结果推送
  SYSTEM_MESSAGE_NOTIFY: 'notify/systemMessage', // 全局消息通知
  UNREAD_MESSAGE_NUM_NOTIFY: 'notify/requestUnreadNum', // 接收mqtt，请求更新未读消息数
  TRAFFIC_TEACHER: 'traffic/teacher', // 教师端校车行车推送
  TRAFFIC_PARENT: 'traffic/parent', // 家长端校车行车推送
  RECORD_CONTROL_RESULT: 'campus/recordControlResult', // 录播控制结果
  TOPIC_LIVE: 'campus/livePersonnelBehavior', // 云上课堂，参与者页面推送
  CLOUD_LIVE: 'campus/live', //直播操作
  CLOUD_LIVE_BEHAVIOR: 'campus/livePersonnelBehavior', //直播行为
  CAMPUS_TOUR_CLAZZ: 'campus/tour/clazz', // 实时巡课-课堂状态变化
  RECORD_CONTROL: 'campus/recordControlResult', //云上课堂-录播控制结果
  RECORD_DEVICE_INFO: 'campus/recordingDevice/info', // 录播设备信息变更
  CAMPUS_COMMENT_NOTIFY: 'campus/comment/notify',
  TOPIC_TRAFFIC_TEACHER: 'center/device',
  TOPIC_TRAFFIC_PARENT: 'center/device',
  LAYOUT_DEVICE_STATUS: 'layout_device/status', // layout下所有设备状态主题
  RENAME_DEVICE_TOPIC: 'connect/renameDevice', // 编辑设备名称主题
  CLAZZROOM_STATISTICS_GRADE_QUEUE: 'clazzroom/statistics/grade', // 文明校园 -- 今日数据
  CLAZZROOM_STATISTICS_CLAZZ_QUEUE: 'clazzroom/statistics/clazz', // 文明校园 -- 班级视频
  SAS_HOME_ALARM: 'sas/home/alarm', // 安全校园首页，告警变化
  DATA_CENTER_ENERGY_AUDIT_SPACE: 'dataCenter/energyAuditSpace', // 能耗诊断---诊断过程
  DATA_CENTER_ENERGY_AUDIT: 'dataCenter/energyAudit', // 能耗诊断--整个诊断状态变化
  DATA_CENTER_LOW_CARBON_OPEN_TASK: 'dataCenter/lowCarbonOpenTask', // 节能模式--整个状态的变化
  DATA_CENTER_LOW_CARBON_OPEN_SPACE: 'dataCenter/lowCarbonOpenSpace', // 节能模式--开启的列表变化,
  SAS_DATA_OVERVIEW_VENUE: 'sas/data/overview/venue', // 安全校园-场馆预约-数据总览,
  TOPIC_TRAFFIC_IMP: 'traffic/imp', // 校车出行 - 行车监控
  SYNC_TASK: 'sync/task',
  TASK_CENTER_MSG_STATUS: 'auth/taskCenterMsgReadStatus',
  LIVE_PERSONNEL_BEHAVIOR: 'campus/livePersonnelBehavior', // 直播行为
  LIVE_MULTI_ACCESS: 'campus/multiAccess', // 直播听课多端访问
  CAMPUS_LIVE: 'campus/live', //云上课堂-直播操作
  DATA_ASSEMBLY_STUDENT: 'data/assembly/student', //数据总览-出入考勤
  DATA_ASSEMBLY_HOSTEL: 'data/assembly/hostel', //数据总览-宿舍考勤
  CONTINGENCY_DRILL_CENTER: 'drill/center', //应急管理 -- 指挥大屏
  SPORT_JUMP_ROPING: 'quality/skippingData', // 智慧体育-跳绳训练
};

export default MQTT_TOPICS;
