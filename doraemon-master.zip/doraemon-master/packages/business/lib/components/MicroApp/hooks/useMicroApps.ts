// import { computed, unref, ref, watchEffect } from 'vue';
// import {
//   filter,
//   toLower,
//   includes,
//   map,
//   replace,
//   trimStart,
//   split,
//   join,
//   isEmpty,
//   some,
//   delay,
//   debounce,
// } from 'lodash-es';
// import type { FrameworkLifeCycles } from 'qiankun';
// import { registerMicroApps, start } from 'qiankun';
// import type { IQiankunRegisterAppsProps } from '../qiankun';
// import {
//   qiankunRegisterLifeCycles as qkRegisterLifeCycles,
//   qiankunStartOptions,
//   qiankunRegisterApps,
// } from '../qiankun';
// import type { ImportMetaEnvExtra } from '../../../types';
// import { ApplicationType } from '../../../enums';
// import type { Application } from '../../../types';
// import { microAppCompositionURL, microAppLocalRegister } from '.';

// export interface MicroAppProps {
//   /** 待注册的应用列表 */
//   applications: Application[];
//   /** 激活微应用的activeRule规则 */
//   activeRule: Parameters<typeof qiankunRegisterApps>[1];
//   shared?: IQiankunRegisterAppsProps['shared'];
//   importMetaEnv: ImportMetaEnvExtra;
//   qiankunRegisterLifeCycles?: FrameworkLifeCycles<any>;
//   hideClassFn?: (...args: any[]) => boolean;
// }

// /**
//  * 1. 获取所有应用列表后apps，进行微应用注册；
//  * 2. 根据路由的前缀，非对应的隐藏, 仅显示当前激活路径的应用
//  * 3. 全局loading控制，已注册的列表， 未注册的列表并不提示不可点击
//  * 4. 应用列表有更新，先卸载注册失败的，再进行注册
//  * 5. 以上仅实现了1,2；3,4改造中
//  * @return {Record<string, any>} { loader, loading, apps }
//  */
// export function useMicroApps(
//   qiankunParams: Omit<MicroAppProps, 'qiankunRegisterLifeCycles'>,
//   qiankunRegisterLifeCycles: FrameworkLifeCycles<any> = qkRegisterLifeCycles,
// ) {
//   const loading = ref(false);
//   // const qiankunInitd = ref(false);

//   const { activeRule, importMetaEnv, shared } = qiankunParams;

//   const apps = computed(() => {
//     const microApps = filter(qiankunParams.applications, (app) => {
//       const appCode = toLower(app.code);
//       const excludeApps = [
//         toLower('Workbench'),
//         toLower('SystemSettings'),
//         toLower('ApplicationCenter'),
//         toLower('DataCenter'),
//         toLower('OrganizationCenter'),
//         toLower('NoticeCenter'),
//       ];
//       const appPath = toLower(app.path);
//       const lowApps = [toLower('/LowcodeApps'), toLower('/ThirdApps')];
//       let isTrue = !some(excludeApps, (p) => includes(p, appCode)) && !isEmpty(app.path);
//       isTrue = isTrue && !some(lowApps, (l) => includes(appPath, l));
//       return isTrue;
//     });

//     const finalMicroApps = map(microApps, (microApp) => {
//       const appCode = toLower(replace(microApp.code, /:/g, '-'));
//       let url;

//       url = microAppCompositionURL(microApp, importMetaEnv);

//       if (import.meta.env.DEV) {
//         url = microAppLocalRegister(microApp, url);
//       }

//       let newMicroPath = trimStart(microApp.path, '/');
//       let path = microApp.path;

//       /*
//         1.无论新旧应用path都可能存在‘xxx/yyy?fullPath=xxx/yyy’，均需要去掉问号，否则激活不了应用;
//         2.entry的路径也来源来path，所以问号需要去掉，否则导致拉取的服务不对
//        */
//       if ([ApplicationType.old].includes(microApp.type)) {
//         const paths = split(microApp.path, '/');
//         newMicroPath = split(newMicroPath, '?')[0];
//         const _path = paths[paths.length - 1];
//         path = `/${_path}`;
//       }

//       if ([ApplicationType.new].includes(microApp.type)) {
//         const tmpPath = trimStart(replace(microApp.path, 'micro-', ''), '/');
//         newMicroPath = split(tmpPath, '/')[0];
//         path = split(microApp.path, '?')[0];

//         if (newMicroPath === 'school-affairs-desktop') {
//           newMicroPath = path.replace(/^\/?micro-/i, '');
//         }
//       }

//       const urls = url.startsWith('http') ? [newMicroPath, ''] : [url, newMicroPath, ''];

//       return {
//         name: appCode,
//         appPath: path,
//         container: `#${appCode}`,
//         entry: join(urls, '/'),
//         loader: setLoading,
//       };
//     });

//     return finalMicroApps;
//   });

//   /* 每个子应用加载中的状态 */
//   function setLoading(_loading: boolean, wait: number = 300) {
//     if (_loading) {
//       loading.value = _loading;
//       return;
//     }

//     delay(() => (loading.value = _loading), wait);
//   }

//   /*
//   修复测试手动删除应用，手动刷新页面应用中心，数据先从localStorage接口后更新，
//   导致触发2次， application已做重复判断
//   */
//   const registerApps = debounce((finalApps) => {
//     if (finalApps.length) {
//       // qiankunInitd.value = true;
//       console.log('已注册的应用列表:::', finalApps);
//       registerMicroApps(
//         qiankunRegisterApps(finalApps, activeRule!, shared!),
//         qiankunRegisterLifeCycles,
//       );
//       start(qiankunStartOptions);
//     }
//   }, 500);

//   watchEffect(() => {
//     try {
//       const finalApps = unref(apps);
//       registerApps(finalApps);
//     } catch (e) {
//       console.error('MicroAppView.vue', e);
//     }
//   });

//   return { apps, loading, setLoading };
// }
