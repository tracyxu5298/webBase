// import { reduce, uniq, concat, assign, some } from 'lodash-es';
// import { ApplicationType } from '../../../enums';
// import { useOldUrl } from '../../../hooks';
// import type { ImportMetaEnvExtra, Application } from '../../../types';
// export * from './useMicroApps';

// /**
//  * 本地调试统一改.env.local 下的 VITE_DEBUG_MICRO_MAP;
//  * 为空直接访问对应环境的线上服务
//  * @type {Application} microApp
//  */
// export function microAppLocalRegister(microApp: Application, url: string) {
//   const debugArr = JSON.parse(import.meta.env.VITE_MICRO_MAP_LOCAL_REGISTER || '[]');
//   const { debugAppWhite, debugAppWhiteMap } = reduce(
//     debugArr,
//     (debugMap: any = {}, next) => {
//       const [debugKey, debugAddress] = next;
//       debugMap.debugAppWhite = uniq(concat(debugMap.debugAppWhite, [debugKey]));
//       debugMap.debugAppWhiteMap = assign(debugMap.debugAppWhiteMap, {
//         [debugKey]: debugAddress,
//       });
//       return debugMap;
//     },
//     { debugAppWhite: [] as string[], debugAppWhiteMap: {} as Record<string, any> },
//   );

//   let k: string;
//   if (some(debugAppWhite, (u) => (k = u) && microApp.path.includes(u))) {
//     // @ts-expect-error /* ts误报绕过 */
//     url = debugAppWhiteMap[k];
//   }
//   return url;
// }

// export function microAppCompositionURL(microApp: Application, importMetaEnv: ImportMetaEnvExtra) {
//   if ([ApplicationType.third, ApplicationType.new].includes(microApp.type)) {
//     return ''; // importMetaEnv.VITE_IMP_PREFIX; // "/imp"
//   }
//   const oldUrl = useOldUrl(importMetaEnv);
//   return oldUrl.value;
// }
