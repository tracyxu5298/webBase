export { default as MicroAppView } from './MicroAppView.vue';
export { default as MicroAppPlaceholder } from './MicroAppPlaceholder.vue';
export { default as MicroAppManual } from './MicroAppManual.vue';
export * from './qiankun';
export * from './mqtt';
