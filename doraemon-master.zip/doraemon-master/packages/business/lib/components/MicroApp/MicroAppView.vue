<script lang="ts" setup>
import { computed, watch } from 'vue';
import { endsWith, startsWith, noop, replace, delay } from 'lodash-es';
import { useRouter } from 'vue-router';
import type { MicroAppProps } from './useMicroApps';
import { useMicroApps } from './useMicroApps';
import { addGlobalUncaughtErrorHandler } from './qiankun';
import { message, Spin } from 'ant-design-vue';

const props = withDefaults(defineProps<MicroAppProps>(), {
  applications: [] as any,
  activeRule: noop as MicroAppProps['activeRule'],
});

const router = useRouter();

const { apps, loading, setLoading } = useMicroApps(props, props.qiankunRegisterLifeCycles);

const currentPath = computed(() => {
  const c = router.currentRoute.value.path;
  return endsWith(c, '/') ? c : `${c}/`;
});

function hideNode(path: string) {
  /* 应用path中带有?形式的，这里会将?包括在内的及后面参数全部替换成空串 */
  const appPath = replace(path, /\?.*/g, '');
  const afterAppPath = endsWith(appPath, '/') ? appPath : `${appPath}/`;

  return !startsWith(currentPath.value, afterAppPath);
}

// 延迟隐藏loading，防止addGlobalUncaughtErrorHandler拦截不到，导致loading一直显示
watch(
  loading,
  (newVal) => {
    delay(() => {
      if (newVal) {
        setLoading(false, 0);
      }
    }, 2 * 1000);
  },
  { immediate: true },
);

addGlobalUncaughtErrorHandler((event: Event | string) => {
  const { message: msg } = event as any;
  setLoading(false, 1000);

  if (msg && msg.includes('died in status LOADING_SOURCE_CODE')) {
    message.error('应用加载失败!');
    return;
  }
});

const hideClassFn = computed(() => {
  const fn = props.hideClassFn ? props.hideClassFn : hideNode;
  return fn;
});
</script>

<template>
  <Spin tip="应用加载中" :spinning="loading" class="spin-wrapper" />
  <div
    v-for="app in apps"
    :key="app.name"
    :id="app.name"
    :class="{ hide: hideClassFn(app.appPath) }"
    class="micro-app-view"
  />
  <slot />
</template>

<style scoped lang="scss">
.spin-wrapper {
  transform: translate(-50%, -50%);
  position: absolute;
  left: 50%;
  z-index: 9999;
  top: 50%;
}

.hide {
  display: none;
}
</style>
