<script setup lang="ts">
import { computed, useSlots } from 'vue';
import type { TableProps, PaginationProps } from 'ant-design-vue';
import { Table, Pagination } from 'ant-design-vue';
import { pageSizeOptions } from '../../utils/constants';

interface Props extends Omit<TableProps, 'pagination'> {
  pagination: PaginationProps | false;
}

type SlotNames =
  | 'expandIcon'
  | 'footer'
  | 'expandedRowRender'
  | 'bodyCell'
  | 'emptyText'
  | 'expandedRowRender'
  | 'expandColumnTitle'
  | 'expandIcon'
  | 'headerCell';

const props = defineProps<Props>();
const emits = defineEmits<{
  (e: 'changePagination', page: number, pageSize: number): void;
}>();

const slots = useSlots();

const slotList = computed(() => {
  return Object.keys(slots).filter((i) => !i?.includes('tableView')) as SlotNames[];
});

const onChangePagination = (_current: number, _pageSize: number) => {
  emits('changePagination', _current, _pageSize);
};
</script>

<template>
  <div class="table-view">
    <div class="table-view-main">
      <slot name="tableViewHeader"></slot>
      <Table
        v-bind="props"
        prefix-cls="antv-sticky-table"
        showHeader
        sticky
        :pagination="false"
        size="middle"
      >
        <template v-for="item in slotList" :key="item" v-slot:[item]="scope">
          <slot :name="item" :scope="scope" v-bind="scope || {}"></slot>
        </template>
      </Table>
      <Pagination
        v-if="props.dataSource?.length && props.pagination !== false"
        show-size-changer
        class="table-view-pagination"
        :current="props.pagination.current"
        :total="props.pagination.total"
        :pageSize="props.pagination.pageSize || 15"
        :show-total="(t: number) => `共${t}条`"
        :pageSizeOptions="pageSizeOptions"
        @change="onChangePagination"
      >
        <template #buildOptionText="props">
          <span>{{ props.value }}条/页</span>
        </template>
      </Pagination>
    </div>
  </div>
</template>

<style lang="scss" scoped>
.table-view {
  padding: 20px 0;
  height: 100%;
  overflow: hidden;
  display: flex;
  flex-direction: column;
}

.table-view-main {
  padding: 0 20px;
  flex: 1;
  display: flex;
  overflow-y: scroll;
  overflow-x: hidden;
  flex-direction: column;
  :deep(.antv-sticky-table-sticky-scroll) {
    opacity: 0;
  }
}

.table-view-pagination {
  margin: 20px 0 0;
  text-align: right;
}
</style>
