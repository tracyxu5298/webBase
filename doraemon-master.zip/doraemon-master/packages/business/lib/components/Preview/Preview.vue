<script lang="ts" setup>
import { ref } from 'vue';
import { message, Modal, Spin, Space, Button, theme } from 'ant-design-vue';
import { FileZipOutlined } from '@ant-design/icons-vue';
import { downloadByALinkElement } from '../../utils/download';

const previewRef = ref();
const loading = ref(false);
const { token } = theme.useToken();

interface State {
  visible: boolean;
  loading: boolean;
  title: string;
  url: string;
  file: any;
}

const state = ref<State>({
  visible: false,
  loading: false,
  title: '',
  url: '',
  file: {},
});

defineExpose({ init });

const zipTypeList = ['rar', 'zip', 'arj', 'z', '7z'];
const isZip = ref(false);

function init(file: { fileId: string; fileName: string; fullUrl: string; fileType?: string }) {
  if (!file) {
    handleCancel();
    return message.error('文件不支持预览');
  }

  isZip.value = zipTypeList.includes(file.fileType || '');

  if (file.fileId == state.value?.file.fileId) {
    loading.value = false;
  } else {
    loading.value = true;
  }

  state.value.file = file;
  state.value.visible = true;
  state.value.title = '文档预览 - ' + file.fileName;
  const token = localStorage.getItem('token') as string;
  state.value.url =
    `/filePreview/onlinePreview?url=` + encodeURIComponent(btoa(file.fullUrl)) + '&token=' + token;
}
function handleCancel() {
  state.value.visible = false;
}

const iframeLoaded = () => {
  loading.value = false;
};

/** 文件下载 */
async function handleDownload() {
  if (!state.value.file.fullUrl) {
    return;
  }
  try {
    await downloadByALinkElement(state.value.file.fullUrl, state.value.file.fileName);
  } catch (error: any) {
    message.error(error?.message || '下载异常');
  }
}
</script>
<template>
  <div class="full-modal" ref="previewRef">
    <Modal
      v-model:open="state.visible"
      prefix-cls="file-preview-full-modal"
      :footer="null"
      :closable="false"
      :keyboard="false"
      :maskClosable="false"
      width="100%"
      :getContainer="() => previewRef"
      destroy-on-close
    >
      <template #title>
        <div class="full-modal-header">
          <div class="header-title">
            <p class="header-txt">{{ state.title }}</p>
          </div>
          <Space class="options" :size="10">
            <Button @click="handleDownload()">下载</Button>
            <Button @click="handleCancel()">取消</Button>
          </Space>
        </div>
      </template>
      <div class="basic-content">
        <Spin
          size="large"
          :spinning="loading && !isZip"
          style="position: absolute; top: 50%; left: 50%"
        ></Spin>
        <iframe
          v-if="state.visible && !isZip"
          :src="state.url"
          width="100%"
          style="border: none"
          height="100%"
          @load="iframeLoaded"
        ></iframe>
        <div class="zip-preview" v-if="isZip">
          <div class="icon">
            <FileZipOutlined></FileZipOutlined>
          </div>
          <div class="file-name">
            <a class="link" @click="handleDownload()">{{ state.file?.fileName }}</a>
          </div>
        </div>
      </div>
    </Modal>
  </div>
</template>
<style lang="scss" scoped>
.full-modal {
  :deep(.file-preview-full-modal) {
    padding-bottom: 0;
    margin: 0;
    top: 0 !important;
    right: 0 !important;
    bottom: 0 !important;
    left: 0 !important;
    width: 100% !important;
    height: 100%;
    max-width: 100%;
  }
  :deep(.file-preview-full-modal-content) {
    display: flex;
    flex-direction: column;
    height: 100%;
    border-radius: 0;
    padding: 0 0;
  }
  :deep(.file-preview-full-modal-body) {
    flex: 1;
    padding: 10px !important;
  }
  .basic-content {
    height: 100%;
    overflow: hidden;
  }
}

.full-modal-header {
  padding: 0 20px;
  border-bottom: 1px solid #f0f0f0;
  height: 60px;
  display: flex;
  justify-content: space-between;
  align-items: center;
  .header-title {
    height: 60px;
    width: 320px;
    .header-logo {
      display: inline-block;
      width: auto;
      height: 60px;
      vertical-align: top;
      margin-right: 3px;
      font-size: 30px;
    }

    .header-txt {
      line-height: 60px;
      display: inline-block;
      margin: 0;
      font-size: 18px;
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
      cursor: pointer;
      max-width: 80vw !important;
      font-weight: 400;
    }
  }
  .options {
    width: 320px;
    justify-content: flex-end;
  }
  .ant-steps {
    width: auto;
    .ant-steps-item {
      width: 150px;
    }
  }
}

.zip-preview {
  height: 100%;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  .icon {
    font-size: 80px;
    color: v-bind('token.colorPrimary');
  }
  .file-name {
    font-size: 16px;
  }
  .link {
    color: v-bind('token.colorText');
    &:hover {
      color: v-bind('token.colorPrimary');
    }
  }
}
</style>
