<script lang="ts" setup>
import { computed } from 'vue';
import { useRoute } from 'vue-router';

// 混合应用, 比如 appCode = "SystemSettings"
// 应用路径
// `/${appCode}`
// 手工页面菜单路径 - 偏好设置
// `/${appCode}/PreferenceSettings`
// 低码页面菜单路径
// `/${appCode}/LowcodePage/${moduleId}`
// 外链页面菜单路径
// `/${appCode}/IframePage?src=${src}`

// 纯低码应用, 比如 appCode = "Xyz"
// 应用路径
// '/LowcodeApps/${appCode}'
// 低码页面菜单路径
// '/LowcodeApps/${appCode}/LowcodePage/${moduleId}'
// 外链菜单页面路径
// '/LowcodeApps/${appCode}/IframePage?src=${src}'
// 第三方应用系统内打开
// /ThirdApps/${appCode}?src=${src}

const route = useRoute();
const src = computed(() => route.query.src as string);
</script>

<template>
  <iframe v-if="src" :src="src"></iframe>
  <div v-else>{{ src }}</div>
</template>

<style scoped>
iframe {
  display: block;
  width: 100%;
  height: 100%;
  border: none;
}
</style>
