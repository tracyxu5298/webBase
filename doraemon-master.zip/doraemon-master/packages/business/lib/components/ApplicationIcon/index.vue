<script lang="ts" setup>
defineProps(['size', 'icon']);
</script>

<template>
  <div
    class="application-icon"
    :style="{
      width: `${size || 40}px`,
      height: `${size || 40}px`,
    }"
  >
    <img
      :src="icon"
      :class="[icon ? '' : 'icon-error']"
      alt=""
      :onerror="`this.classList.add('icon-error');`"
    />
  </div>
</template>

<style lang="scss" scoped>
.application-icon {
  position: relative;
  display: flex;
  justify-content: center;
  align-items: center;
  overflow: hidden;
  img {
    width: 100%;
  }
  .icon-error {
    &::before {
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      color: transparent;
      background: #e5e6eb;
      border-radius: 12px;
      content: '';
    }
  }
}
</style>
