<script setup lang="ts">
import { computed, ref, watch, nextTick, onBeforeUnmount } from 'vue';
import { useRoute } from 'vue-router';
import { theme } from 'ant-design-vue';
import { useAccessToken, useAccessTokenKey } from '../../hooks';
import useRefreshToken from '../../hooks/useRefreshToken';
import { EMPTY_OBJ } from '../../utils';
import { MQTT_TOPICS, MqttSubscriber } from '..';
import type { ChangeType } from '../../enums/TaskCenter';

type MessageType = {
  unReadQty: number;
  seqNo?: string;
  changeType?: ChangeType;
};

const props = defineProps<{ lowcodeDomain: string }>();
const lowcodeDomain = props.lowcodeDomain;
const ready = ref(false);
const iframeRef = ref<HTMLIFrameElement>();
const route = useRoute();
const { token } = theme.useToken();
const accessToken = useAccessToken();
const accessTokenKey = useAccessTokenKey();
const refreshToken = useRefreshToken();
const isLowcodePage = computed(() => route.path.includes('LowcodePage'));
const iframeKey = computed(() => route.params.appCode as string); // 一个应用一个低码iframe容器
const query = computed(() => {
  return {
    token: accessToken.value,
    tokenKey: accessTokenKey.value,
    refreshToken: refreshToken.value,
    parentOrigin: window.location.origin,
    themeColor: token.value.colorPrimary,
  };
});

function getIframeQueryObject(options?: Record<string, string>) {
  return {
    iframeKey: iframeKey.value,
    ...(options || EMPTY_OBJ),
    ...route.query,
    ...(ready.value ? EMPTY_OBJ : query.value), // 已初始化, 不需要再传这些参数了
  };
}

function getIframeQueryString(iframeQuery: Record<string, string>) {
  const q = Object.keys(iframeQuery)
    .map((key) => `${key}=${encodeURIComponent(iframeQuery[key]) ?? ''}`)
    .join('&');
  if (q) {
    return '?' + q;
  }
  return '';
}

watch(
  () => route.fullPath,
  () => {
    // 1. 非低码页面, 低码变成空白页面, 避免页面切换还能看到上个页面
    if (!isLowcodePage.value) {
      iframeRef.value?.contentWindow?.postMessage?.(
        { type: 'route', params: { path: '/blank' } },
        lowcodeDomain,
      );
      return;
    }
    // 2. 低码页面
    const moduleId = route.path.split('LowcodePage/')[1].split('/'); // string[]
    let iframePath = '';
    if (moduleId.length === 1) {
      // 2.1 当路径参数 moduleId 只有1级时，按低码功能页面处理
      iframePath += `/model/page`;
      const iframeQuery = getIframeQueryObject({ moduleId: moduleId[0] });
      iframePath += getIframeQueryString(iframeQuery);
    } else {
      // 2.2 当路径参数 moduleId 有多级时，直接按低码页面路径处理
      iframePath += `/${moduleId.join('/')}`;
      const iframeQuery = getIframeQueryObject();
      iframePath += getIframeQueryString(iframeQuery);
    }
    console.log('[低码容器] 跳转路径', iframePath);
    // 3. 基座与低码通讯
    if (ready.value) {
      // 3.1 已渲染过低码页面
      iframeRef.value!.contentWindow!.postMessage(
        { type: 'route', params: { path: iframePath } },
        lowcodeDomain,
      );
    } else {
      // 3.2 未渲染过低码页面
      iframePath = lowcodeDomain?.replace(/\/*$/, '') + iframePath;
      nextTick(() => {
        iframeRef.value!.src = iframePath;
      });
    }
  },
  {
    immediate: true,
  },
);

const messageHandle = (event: any) => {
  const data = event?.data || {};
  if (data.type === 'LowcodeIframeReady' && data.params?.iframeKey === iframeKey.value) {
    console.log('[低码容器] 低码端已就绪', data);
    ready.value = true;
  }
};

window.addEventListener('message', messageHandle);

const mqttSubscriber = new MqttSubscriber({
  topics: [MQTT_TOPICS.TASK_CENTER_MSG_STATUS],
  onMessage(res: any) {
    const message: MessageType = res.message || {};
    console.log('message....', message);
    iframeRef.value?.contentWindow?.postMessage?.(
      { type: 'taskCenter', params: message },
      lowcodeDomain,
    );
  },
});

onBeforeUnmount(() => {
  window.removeEventListener('message', messageHandle);
  mqttSubscriber.destroy();
});
</script>
<template>
  <div class="lowcode-iframe-wrap" v-show="isLowcodePage">
    <iframe class="lowcode-iframe-view" ref="iframeRef"></iframe>
  </div>
</template>
<style scoped lang="scss">
.lowcode-iframe-wrap {
  display: block;
  position: absolute;
  border: 0;
  top: 0;
  right: 0;
  bottom: 0;
  left: 220px;
}
.lowcode-iframe-view {
  display: block;
  width: 100%;
  height: 100%;
  border: 0;
  background: transparent;
}
</style>
