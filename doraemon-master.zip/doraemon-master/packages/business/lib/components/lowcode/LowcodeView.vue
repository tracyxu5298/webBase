<!--
  低代码容器组件
  不做实际渲染，低码页面在基座公用 Iframe 渲染
-->
<script setup lang="ts"></script>
<!-- eslint-disable-next-line vue/valid-template-root -->
<template></template>
