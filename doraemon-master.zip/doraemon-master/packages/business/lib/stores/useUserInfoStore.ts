import { ref, onBeforeMount } from 'vue';
import { defineStore } from 'pinia';
import { Http } from '@lexikos/doraemon-network';
import type { UserInfo } from '../types';
import { decryptByAesCbc, encryptByAesCbc } from '../utils';

const STORAGE_KEY = 'userInfo';

export function getUserInfoByLocal(): UserInfo | undefined {
  const localData = decryptByAesCbc(localStorage.getItem(STORAGE_KEY) || ''); // 解密
  if (localData) {
    return JSON.parse(localData) as UserInfo;
  }
  return undefined;
}

const useUserInfoStore = defineStore('userInfo', () => {
  const loading = ref<boolean>(false);
  const loaded = ref<boolean>(false);
  const data = ref<UserInfo | undefined>(getUserInfoByLocal());

  function saveUserInfo(latestData: UserInfo) {
    data.value = latestData;
    localStorage.setItem(STORAGE_KEY, encryptByAesCbc(JSON.stringify(latestData)));
    // 存储个性化登录标识
    if (latestData.dedicatedWebsite) {
      localStorage.setItem('dedicatedWebsite', latestData.dedicatedWebsite);
    } else {
      localStorage.removeItem('dedicatedWebsite');
    }
  }

  async function getUserInfoByRemote() {
    try {
      loading.value = true;
      const response = await Http.getInstance().get('/api/building/v2/actions/getUserInfoVo');
      loaded.value = true;
      delete response.address;
      delete response.applications;
      delete response.company;
      delete response.createTime;
      delete response.clazzIds;
      delete response.locationIds;
      delete response.refreshToken;
      delete response.spaceIds;
      delete response.treePermissions;
      delete response.updateTime;
      // window.__userInfo__ = response;
      saveUserInfo(response); // 同步并保存最新数据
      return response;
    } catch (error) {
      return Promise.reject(error);
    } finally {
      loading.value = false;
    }
  }

  // 本地优先
  async function getUserInfo(): Promise<UserInfo> {
    const localData = getUserInfoByLocal();
    if (localData) {
      getUserInfoByRemote().catch((error) => console.warn('getUserInfo', error));
      return localData;
    }
    return getUserInfoByRemote();
  }

  onBeforeMount(() => {
    getUserInfo();
  });

  return { loading, loaded, data, getUserInfoByRemote, getUserInfoByLocal };
});

export default useUserInfoStore;
