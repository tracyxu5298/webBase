import { ref } from 'vue';
import { defineStore } from 'pinia';
import { isEqual, slice } from 'lodash-es';

const useMqttStore = defineStore('useMqttStore', () => {
  const clientId = ref();
  const mqttState = ref<Record<string, any>>({});

  function setData({ payload: { topic, ...data } }: any): void {
    const key = slice(topic.split('/'), 4).join('/');
    const mqttStateData = mqttState.value;
    const equal = isEqual(mqttStateData[key], data);
    if (!equal) {
      mqttStateData[key] = data;
    }
  }

  function setClientId(_clientId: string): void {
    clientId.value = _clientId;
  }

  return { mqttState, setData, setClientId };
});

export default useMqttStore;
