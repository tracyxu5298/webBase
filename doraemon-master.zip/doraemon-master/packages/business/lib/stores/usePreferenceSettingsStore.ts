import { ref, onMounted } from 'vue';
import { defineStore } from 'pinia';
import pick from 'lodash-es/pick';
import { Http } from '@lexikos/doraemon-network';
import type { PreferenceSettings } from '../types';

// const EVENT_KEY = 'event_preference_settings';
const STORAGE_KEY = 'preferenceSettings';

export const defaultPreferenceSettings: PreferenceSettings = {
  theme: 'blue',
  layout: 'side',
  workbenchBg: 'none',
};

const usePreferenceSettingsStore = defineStore('preferenceSettingsStore', () => {
  // console.log('usePreferenceSettingsStore 只执行一次');
  const loading = ref<boolean>(false);
  const loaded = ref<boolean>(false);
  const data = ref<PreferenceSettings | undefined>(_getLocalPreferenceSettings()); // 偏好设置（主题 && 布局）

  // 本地获取
  function _getLocalPreferenceSettings(): PreferenceSettings | undefined {
    try {
      const localData = localStorage.getItem(STORAGE_KEY);
      if (localData) {
        return JSON.parse(localData) as PreferenceSettings;
      }
    } catch (error) {
      console.error('_getLocalPreferenceSettings', error);
    }
    return undefined;
  }

  // 远程获取(对外开放方法: 个人偏好未设置, 组织偏好有设置, 需要同步到个人偏好)
  async function getRemotePreferenceSettings(): Promise<PreferenceSettings> {
    try {
      loading.value = true;
      const response = await Http.getInstance().get('/api/auth/themeConfig');
      loaded.value = true;
      _savePreferenceSettings(response);
      return response;
    } catch (error) {
      console.error('getRemotePreferenceSettings', error);
      if (!data.value) {
        _savePreferenceSettings(defaultPreferenceSettings);
      }
      return defaultPreferenceSettings;
    } finally {
      loading.value = false;
    }
  }

  // 本地优先
  async function _getPreferenceSettings(): Promise<PreferenceSettings> {
    localStorage.removeItem('themeSettings'); // TODO: 7.2.0 增加，后续去掉
    const localData = _getLocalPreferenceSettings();
    if (localData) {
      getRemotePreferenceSettings().catch((error) => console.error('getPreferenceSettings', error));
      return localData;
    }
    return getRemotePreferenceSettings();
  }

  // 保存
  async function setPreferenceSettings(value: PreferenceSettings) {
    try {
      const response = await Http.getInstance().post('/api/auth/themeConfig', value);
      _savePreferenceSettings(value);
      return response;
    } catch (error) {
      console.error('setPreferenceSettings', error);
      return Promise.reject(error);
    }
  }

  // 本地持久化 && 同步
  function _savePreferenceSettings(newValue: PreferenceSettings) {
    const finalValue = pick({ ...defaultPreferenceSettings, ...data.value, ...newValue }, [
      'layout',
      'theme',
      'workbenchBg',
    ]);
    if (
      finalValue.layout !== data.value?.layout ||
      finalValue.theme !== data.value.theme ||
      finalValue.workbenchBg !== data.value.workbenchBg
    ) {
      data.value = finalValue;
      window.localStorage.setItem(STORAGE_KEY, JSON.stringify(finalValue));
      // window.dispatchEvent(new Event(EVENT_KEY)); // 为了同步子项目风格
    }
    return finalValue;
  }

  // 同步风格（子项目）
  // function _syncPreferenceSettings() {
  //   const localSettings = _getLocalPreferenceSettings();
  //   if (localSettings) {
  //     data.value = localSettings;
  //   }
  // }

  onMounted(() => {
    _getPreferenceSettings();
    // window.addEventListener(EVENT_KEY, _syncPreferenceSettings);
  });

  // onUnmounted(() => {
  // window.removeEventListener(EVENT_KEY, _syncPreferenceSettings);
  // });

  return { data, loading, loaded, setPreferenceSettings, getRemotePreferenceSettings };
});

export default usePreferenceSettingsStore;
