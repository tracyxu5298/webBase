import { ref, onMounted } from 'vue';
import { useRoute } from 'vue-router';
import { defineStore } from 'pinia';
import { Http } from '@lexikos/doraemon-network';
import { DeployWay } from '../enums/DeployWay';
import { useAccessToken, useAccessTokenKey } from '../hooks';
import { ping } from '../utils/ping';

interface DeployConfig {
  deployWay?: DeployWay;
  inSchoolMediaAddress?: string | null; // 直播课局域网媒体服务地址, 如 "http://172.16.168.104:8000"
  impHttpWebsite?: string | null; // 如 "http://impnonsecure.leedarson.com"
  impEduHttpWebsite?: string | null; // 如 "http://impedunonsecure.leedarson.com"
  website?: string | null; // 如 "https://imp.leedarson.com",
  eduWebsite?: string | null; // 如: "https://impedu.leedarson.com"
  edgeWebsite?: string | null;
  eduEdgeWebsite?: string | null;
  nodeId?: string | null;
  isHttp?: string | null;
}

const MEDIA_APPLICATIONS = ['Recording:Broadcasting'];
const KEY = 'deployConfig';

const useDeployConfigStore = defineStore('deployConfig', () => {
  const loading = ref(false);
  const data = ref<DeployConfig | undefined>(getDeployConfigByLocal());
  const route = useRoute();
  const accessToken = useAccessToken();
  const accessTokenKey = useAccessTokenKey();

  function saveDeployConfig(newData: DeployConfig) {
    data.value = { ...data.value, ...newData };
    localStorage.setItem(KEY, JSON.stringify(newData));
  }

  function getDeployConfigByLocal() {
    const localData = localStorage.getItem(KEY);
    if (localData) {
      return JSON.parse(localData);
    }
    return undefined;
  }

  const getDeployConfigByRemote = async () => {
    try {
      loading.value = true;
      const response = await Http.getInstance().get('/api/building/edge/node/getCurrentConfig');
      if (response.impHttpWebsite && response.impHttpWebsite.includes(window.location.origin)) {
        response.isHttp = '1';
      }
      saveDeployConfig(response);
      return response;
    } catch (error: any) {
      console.warn('getDeployConfigByRemote', error);
    } finally {
      loading.value = false;
    }
  };

  function getDeployConfig() {
    const localData = getDeployConfigByLocal();
    if (localData) {
      getDeployConfigByRemote().catch((error) => console.warn('getDeployConfig', error));
      return localData;
    }
    return getDeployConfigByRemote();
  }

  const isMediaApp = (appCode: string) => {
    return MEDIA_APPLICATIONS.includes(appCode);
  };

  const getMediaAppPath = async (appPath: string): Promise<string> => {
    if (
      appPath &&
      data.value &&
      data.value.deployWay === DeployWay.Public &&
      data.value.inSchoolMediaAddress &&
      data.value.impHttpWebsite &&
      !data.value.impHttpWebsite.includes(window.location.origin)
    ) {
      const isPingSchoolMedia = await ping(data.value.inSchoolMediaAddress);
      if (isPingSchoolMedia) {
        const [_path, _search] = appPath.split('?');
        return `${data.value.impHttpWebsite}${_path}${
          _search?.includes('?') ? '&' : '?'
        }_t_=${accessToken.value}&_tk_=${accessTokenKey.value}&fullPath=${_path}&isHttp=1`;
      }
    }
    return '';
  };

  onMounted(() => {
    getDeployConfig();
    if (route.query.isHttp) {
      saveDeployConfig({ isHttp: route.query.isHttp as string });
    }
  });

  return { data, loading, isMediaApp, getMediaAppPath, getDeployConfig };
});

export default useDeployConfigStore;
