import { ref, onBeforeMount } from 'vue';
import { defineStore } from 'pinia';
import type { IConfig } from '../types/Config';

let timer = 0;
const STORAGE_KEY = 'config';

const useConfigStore = defineStore('useConfigStore', () => {
  const loading = ref<boolean>(false);
  const data = ref<IConfig | null>(getConfigByLocal());

  function getConfigByLocal(): IConfig | null {
    const localData = localStorage.getItem(STORAGE_KEY);
    if (localData) {
      const localJson = JSON.parse(localData) as IConfig;
      const lowcode = debugLowcode();
      if (lowcode) {
        localJson.lowcode = lowcode;
      }
      return localJson;
    }
    return null;
  }

  function debugLowcode() {
    if (import.meta.env.VITE_LOWCODE_PROXY && process.env.NODE_ENV === 'development') {
      return import.meta.env.VITE_LOWCODE_PROXY;
    }
    return '';
  }

  async function getConfigByRemote(): Promise<IConfig> {
    try {
      clearTimeout(timer);
      loading.value = true;
      const response = await fetch('/config.json');
      data.value = await response.json();
      localStorage.setItem(STORAGE_KEY, JSON.stringify(data.value));
      const lowcode = debugLowcode();
      if (lowcode) {
        data.value!.lowcode = lowcode;
      }
      return data.value as IConfig;
    } catch (error) {
      console.error('getConfigByRemote', error);
      timer = window.setTimeout(() => getConfig(), 3000);
      return Promise.reject(error);
    } finally {
      loading.value = false;
    }
  }

  async function getConfig(): Promise<IConfig> {
    const localData = getConfigByLocal();
    if (localData) {
      getConfigByRemote().catch((error) => console.warn('getConfig', error));
      return localData;
    }
    return getConfigByRemote();
  }

  onBeforeMount(() => {
    getConfig();
  });

  return { data, loading };
});

export default useConfigStore;
