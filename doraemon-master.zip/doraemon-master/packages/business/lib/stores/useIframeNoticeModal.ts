import { defineStore } from 'pinia';
import { ref } from 'vue';

export const useIframeNoticeModal = defineStore('useIframeNoticeModal', () => {
  const ready = ref(false);
  const iframeRef = ref<HTMLIFrameElement>();
  const visible = ref(false);

  const setReady = (value: boolean) => {
    ready.value = value;
  };

  const setVisible = (value: boolean) => {
    visible.value = value;
  };

  const setIframeRef = (value: HTMLIFrameElement) => {
    iframeRef.value = value;
  };

  return {
    ready,
    visible,
    iframeRef,
    setReady,
    setVisible,
    setIframeRef,
  };
});
