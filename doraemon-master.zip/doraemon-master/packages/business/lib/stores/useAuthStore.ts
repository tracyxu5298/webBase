import { defineStore } from 'pinia';
import { ref } from 'vue';

export const LOCAL_STORAGE_TOKEN_KEY = 'tokenKey';
export const LOCAL_STORAGE_TOKEN = 'token';
export const LOCAL_STORAGE_EXPIRE = 'tokenExpire';
export const LOCAL_STORAGE_REFRESH_TOKEN = 'refreshToken';
export const LOCAL_STORAGE_REFRESH_EXPIRE = 'refreshExpire';

const isNil = (val?: string | null) => {
  return !val || /^(null|undefined|\[object object\])$/i.test(val);
};

const clearStorage = () => {
  [
    LOCAL_STORAGE_TOKEN_KEY,
    LOCAL_STORAGE_TOKEN,
    LOCAL_STORAGE_EXPIRE,
    LOCAL_STORAGE_REFRESH_TOKEN,
    LOCAL_STORAGE_REFRESH_EXPIRE,
  ].forEach((key) => {
    localStorage.removeItem(key);
  });
};

const useAuthStore = defineStore('userAuth', () => {
  let storageToken = localStorage.getItem(LOCAL_STORAGE_TOKEN);
  if (isNil(storageToken)) {
    // 若token为空或值错误，则清除现有值，以免产生错误逻辑
    clearStorage();
    storageToken = '';
  }
  const token = ref(storageToken);
  // const tokenKey = ref(localStorage.getItem(LOCAL_STORAGE_TOKEN_KEY) || 'token');
  const tokenKey = ref('token');
  const tokenExpire = ref(Number(localStorage.getItem(LOCAL_STORAGE_EXPIRE)));
  const refreshToken = ref(localStorage.getItem(LOCAL_STORAGE_REFRESH_TOKEN));
  const refreshExpire = ref(Number(localStorage.getItem(LOCAL_STORAGE_REFRESH_EXPIRE)));

  const set = (options: {
    tokenKey?: string;
    token?: string;
    tokenExpire?: number;
    refreshToken?: string;
    refreshExpire?: number;
  }) => {
    if (!options) {
      return;
    }
    if (options.token && !isNil(options.token)) {
      token.value = options.token;
      localStorage.setItem(LOCAL_STORAGE_TOKEN, options.token);
    }
    if (options.tokenKey) {
      // tokenKey.value = options.tokenKey;
      tokenKey.value = 'token';
      localStorage.setItem(LOCAL_STORAGE_TOKEN_KEY, tokenKey.value);
    }
    if (options.refreshToken) {
      refreshToken.value = options.refreshToken;
      localStorage.setItem(LOCAL_STORAGE_REFRESH_TOKEN, options.refreshToken);
    }
    if (options.tokenExpire) {
      const value = options.tokenExpire * 1000 + Date.now();
      refreshExpire.value = value;
      localStorage.setItem(LOCAL_STORAGE_EXPIRE, String(value));
    }
    if (options.refreshExpire) {
      const value = options.refreshExpire * 1000 + Date.now();
      refreshExpire.value = value;
      localStorage.setItem(LOCAL_STORAGE_REFRESH_EXPIRE, String(value));
    }
  };

  return {
    tokenKey,
    token,
    tokenExpire,
    refreshToken,
    refreshExpire,
    set,
  };
});

export default useAuthStore;
