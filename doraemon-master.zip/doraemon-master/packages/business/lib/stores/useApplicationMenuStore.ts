// import { ref } from 'vue';
// import { defineStore } from 'pinia';
// import { Http } from '@lexikos/doraemon-network';
// import type { IMenu, IMenuState } from '../types/ApplicationMenu';

// const useApplicationMenuStore = defineStore('applicationMenu', () => {
//   const state = ref<Record<string, IMenuState>>({});

//   // async function getApplicationMenus(appCode: string, force = false): Promise<IMenu[]> {
//   async function getApplicationMenus(appCode: string, _force = false): Promise<IMenu[]> {
//     try {
//       // TODO: 因路由 beforeEach 2次，缓存逻辑暂注释
//       // const s = state.value[appCode]; // IMenuState || undefined
//       // if (force === false && s && Array.isArray(s.menus)) {
//       //   return s.menus; // IMenu[]
//       // }
//       state.value[appCode] = { loading: true };
//       const response = await Http.getInstance().get(`/api/auth/applications/${appCode}/menus`);
//       state.value[appCode].menus = response as IMenu[];
//       return response;
//     } catch (error) {
//       console.error('useApplicationMenuStore', error);
//       return Promise.reject(error);
//     } finally {
//       state.value[appCode].loading = false;
//     }
//   }

//   return { state, getApplicationMenus };
// });

// export default useApplicationMenuStore;
import { ref } from 'vue';
import { defineStore } from 'pinia';
import { Http } from '@lexikos/doraemon-network';
import type { IMenu } from '../types/ApplicationMenu';

const useApplicationMenuStore = defineStore('applicationMenu', () => {
  const loading = ref<boolean>(false);
  const data = ref<IMenu[]>([]);

  async function getApplicationMenus(appIdOrAppCode: string): Promise<IMenu[]> {
    try {
      loading.value = true;
      const response = await Http.getInstance().get(
        `/api/auth/applications/${appIdOrAppCode}/menus`,
      );
      data.value = response;
      return response;
    } catch (error) {
      console.error('useApplicationMenuStore', error);
      return Promise.reject(error);
    } finally {
      loading.value = false;
    }
  }

  return { data, loading, getApplicationMenus };
});

export default useApplicationMenuStore;
