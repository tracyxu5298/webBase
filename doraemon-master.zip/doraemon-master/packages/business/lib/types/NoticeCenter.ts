import type { ReadStatus, WebNoticeTarget } from '../enums/NoticeCenter';

export type NoticeGroup = {
  groupType: string;
  groupTypeName: string;
  unReadQty: string;
  lastNotifyTitle: string;
  lastNotifyContent: string;
  lastNotifyTime: number;
};

/** 消息详情定义 */
export type NoticeItem = {
  id: string;
  createTime: string;
  updateTime: string;
  size: string;
  current: string;
  locationId: string;
  applicationId: string;
  webClient: number;
  appClient: number;
  wxaClient: number;
  notifyTime: number;
  notifyStatus: number;
  mqttNotifyStatus: number;
  appNotifyStatus: number;
  title: string;
  content: string;
  readStatus: ReadStatus;
  imageFileId: string;
  imageFileUrl: string;
  videoBuildStatus: number;
  videoFileId: string;
  videoFileUrl: string;
  userType: number;
  cid: string;
  phoneBrand: string;
  appPushInfoDtos: string[];
  userId: string;
  displayMode: number;
  bizSeq: string;
  bizCode: string;
  bizGroupCode: string;
  bizGroupName: string;
  bizDataJson: string;
  retryCount: string;
  exceptionInfo: string;
  impPage: string;
  appPage: string;
  wxaPage: string;
  messageSource: number;
  bizName: string;
  createBy: string;
  updateBy: string;
  ids: [];
  attachmentId: string;
  attachmentName: string;
  isCount: number;
  webPath: string;
  // 新消息接口增加以下两个字段
  /** 打开方式 */
  target: WebNoticeTarget;
  /** 跳转路径 */
  path: string;
};
