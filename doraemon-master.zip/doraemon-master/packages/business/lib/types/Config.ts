// import type { PreferenceSettings } from './PreferenceSettings';

export interface IConfig {
  imp: string;
  boss: string;
  lowcode: string;
  xingpan: string;
  // preferences: PreferenceSettings; // 现在暂不支持
  /** 禁用扫码登录 */
  disableScan?: boolean;
  /** 禁用短信登录 */
  disableSMS?: boolean;
}
