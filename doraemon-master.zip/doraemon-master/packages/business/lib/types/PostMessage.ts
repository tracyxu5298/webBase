import type { MessageArgsProps } from 'ant-design-vue/es/message';
import type { ModalFuncProps } from 'ant-design-vue/es/modal';
import type { NotificationArgsProps } from 'ant-design-vue/es/notification';

// jump 默认为内部跳转，不能带 http://www.xxx.com 和 https://www.xxx.com 否则 pushState 无法跳转
export interface JumpParams {
  url: string;
  state?: any;
  _blank?: boolean; // 为true表示新标签页打开, 通过 window.open 打开，url 必须为完整地址：如 https://www.leedarson.com
  old?: boolean; // 为true表示旧基座的url，需要自动拼接域名地址
}

// 弹窗和抽屉统一层 iframe 处理，业务端自定义弹窗和抽屉行为，url 必须为https://开头的完整路径
export interface IframeParams {
  url: string;
  old?: boolean; // 为true表示旧基座的url，需要自动拼接域名地址
  height?: string; // 类型为string, 所以需要自行带上单位例如：10px，100%，100vh
  width?: string;
  bgStyles?: any; // 背景自定义覆盖当前样式
  withLoading?: boolean; // 默认不展示loading，为 true 才展示 loading
}

export type PostMessageEventType =
  | 'jump'
  | 'message'
  | 'notification'
  | 'openIframe'
  | 'openTaskCenter'
  | 'closeIframe'
  | 'closeLoading'
  | 'back'
  | 'logout'
  | 'modal'
  | 'noticeModalReady'
  | 'closeNoticeModal';

export interface MessageParams extends MessageArgsProps {}

export interface NotificationParams extends NotificationArgsProps {}

export interface ModalFuncParams extends ModalFuncProps {}

export interface PostMessageEventData {
  type: PostMessageEventType;
  params?: JumpParams | IframeParams | MessageArgsProps | NotificationArgsProps | ModalFuncProps;
}
