export interface ImportMetaEnvExtra {
  VITE_IMP2_PREFIX: string;
  VITE_IMP2_EDU_PREFIX: string;
  VITE_IMP2_STU_PREFIX: string;
}
