export interface IPermission {
  code: string;
  name: string;
}

export interface IMenu {
  id: string;
  name: string;
  icon: string;
  type: number; // 11: 目录 - 支持折叠 12: 目录 - 不支持折叠 21: 手工页面 31: 低代码功能 32: 低代码报表 33: 低代码大屏 34: 低代码门户 41: 外链
  // target: string; // 系统内打开, 新标签打开
  checked: number;
  path?: string; // 路由路径, 域名地址
  query?: string; // ?path=model/bbbb&modelId=123
  permissions: IPermission[];
  children?: IMenu[];
}

export interface IMenuState {
  loading: boolean;
  menus?: IMenu[];
}
