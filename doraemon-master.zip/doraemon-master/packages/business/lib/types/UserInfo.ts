import { type LocationLevel } from '../enums/LocationLevel';
import { type LocationType } from '../enums/LocationType';
import { type UserIdentity } from '../enums/UserIdentity';

export interface UserInfo {
  accountId: string; // 帐号标识, 如 "3564"
  // accountName: string; // 帐号, 如 "13779966854"
  // address: string | null;
  adminStatus: number; // 1: 超级管理员, 2: 普通用户
  // applications: object[]; // 旧基座 - 应用中心列表
  // certificateNumber: string | null;
  // certificateType: string | null;
  // childIds: string[]; // 孩子 ids
  // clazzIds: string[]; // 班级 ids
  // company: string | null;
  // containsImport: boolean;
  // containsQuery: boolean /** 是否有查看敏感信息的权限 */;
  coordinate: string; // 坐标，如 "118.082745,24.445676"
  // createTime: number;
  currentChildId: string | null;
  // dataLevel: number; // 数据等级???
  // dataSource: number; // 数据来源???
  dedicatedWebsite?: string /** 自定义登录页的标识，退出的时候要带上 */;
  // email: string;
  // gender: number | null; // 1: 男, 2: 女
  // headImg: string | null;
  headImgUrl: string; // 个人头像地址
  // homePageAddress: string | null; // 首页地址, changeLocation接口中也可以获取
  id: string; // 用户 id
  // indexSpaceFilterCode: string; // 如 "0101"
  // indexSpaceId: string; // 如 "1688368768742330371"
  // indexSpaceName: string; // 如 "立达信演示学校"
  // isInclude3d: boolean | null;
  // jobNo: string; // 工号
  // layoutMode: string;
  locationId: string; // 组织标识
  // locationIds: string[];
  // locationIndustry: string | null; // 组织行业, "Edu": 教育行业, "Manu": 制造业
  locationLevel: LocationLevel; // 组织级别
  locationName: string; // 组织名称
  locationType: LocationType; // 组织类型
  logoFileUrl: string; // 组织徽标
  mqttHost: string; // MQTT 主机, 比如 "testimpmqtt.lexikos.com:8443"
  mqttHostProtocol: string; // MQTT 协议, 比如 "wss"
  mqttPassword: string; // MQTT 密码, 比如 "f4eafcf"
  mqttUuid: string; // MQTT 标识, 比如 "71e3d71cef9e40379d596858e926fc32"
  // network: string; // 内外或外网, 比如 "Internet"
  // nickname: string;
  /**
   * personId 说明
   * 当 userIdentity = 0 时, 即教职工身份, id == userId == personId
   * 当 userIdentity = 1 或 2 时，即学生或家长身份, id == cuserId, 但不等于 personId
   */
  personId: string;
  // personImageUrl: string | null;
  // position: string | null; // 职位
  // refreshToken: string | null;
  /**
   * roleCodes 说明
   * manage: 管理员, ordinary: 普通用户, parent: 家长, student: 学生, 自定义角色
   */
  roleCodes: string[]; // 角色编码, 比如 ["manage"]
  roleName: string; // 角色名称, 比如 "管理员"
  // rootLocationId: string; // 根组织标识, 比如 "2015"
  // rootLocationName: string; // 根组织名称, 比如 "福建省教育局"
  // safeSchoolThirdPartUrl: string | null;
  // spaceIds: string[];
  // state: number; // 用户状态, 2: 启用 4:禁用
  tel: string | null; // 手机号
  // treePermissions: object[]; // 旧基座 - 权限(featurePermissions, functionPermissions, permissionTree,)
  // updateTime: number;
  userIdentity: UserIdentity;
  userName: string;
  // uuid: string | null;
  websocketAddress: string; // WebSocket 地址, 比如 "wss://testimpmqtt.lexikos.com:8443/mqtt"
}
