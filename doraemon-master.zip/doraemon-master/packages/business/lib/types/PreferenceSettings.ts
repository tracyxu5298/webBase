export type PreferenceTheme =
  | 'blue'
  | 'cyan'
  | 'gold'
  | 'green'
  | 'volcano'
  | 'red'
  | 'purple'
  | 'pink';
export type PreferenceWorkbenchBg = PreferenceTheme | 'none';
export type PreferenceLayout = 'side' | 'top';

export interface PreferenceSettings {
  theme: PreferenceTheme; // 主题名称
  layout: PreferenceLayout; // 布局名称
  /** 工作台背景图 */
  workbenchBg: PreferenceWorkbenchBg;
}
