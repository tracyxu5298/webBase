/// <reference types="vite/client" />
/// <reference types="vite-svg-loader" />
declare module 'veaury*';
interface ImportMetaEnv {
  // 来自`.env`
  readonly VITE_APP_NAME: string;
  readonly VITE_IMP2_PREFIX: string;
  readonly VITE_IMP2_EDU_PREFIX: string;
  readonly VITE_IMP2_STU_PREFIX: string;
  // 来自`vite.config.ts`
  readonly BUILDER_NUMBER: string;
  readonly ROOT_VERSION: string;
}

interface ImportMeta {
  readonly env: ImportMetaEnv;
}

declare module '*.vue' {
  import type { DefineComponent } from 'vue';

  const component: DefineComponent<any, any, any>;
  export default component;
}

declare module 'mqtt/*' {
  const component: any;
  export default component;
}

declare module 'ImpPlatform/*' {
  const WidgetComponent: any;
  /** 联邦提供的旧imp组件 */
  export const IMPProvider: any;
  export const initSignedInIoCScope: (...args: any) => void;
  /** 联邦提供的小组件集和t800 */
  export default WidgetComponent;
}
