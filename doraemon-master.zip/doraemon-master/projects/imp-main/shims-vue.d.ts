export {};

declare global {
  interface Window {
    qiankunPlatformStarted: boolean;

    /** imp-web 所有的应用appName => 字面量对应 中划线字面量 */
    MAPS_APP?: any;
    SOURCE__BASE: 'doraemon' | 'boss';
    lds?: any;
    [k: string]: any;
  }
}
