<script setup lang="ts">
import { RouterView } from 'vue-router';
import { usePostMessage, Report, getUserInfoByLocal } from '@lexikos/doraemon-business';

import('ImpPlatform/t800').then(({ default: t800 }) => t800());
usePostMessage();

const report = Report.getInstance();
const userInfo = getUserInfoByLocal();
report.setUserInfo(userInfo);
</script>

<template>
  <RouterView />
</template>
