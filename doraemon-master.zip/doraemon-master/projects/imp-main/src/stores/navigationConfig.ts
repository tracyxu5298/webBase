import { computed } from 'vue';
import { message } from 'ant-design-vue';
import { defineStore } from 'pinia';
import { useNavigationConfig } from '@lexikos/doraemon-business';

export const useNavigationConfigStore = defineStore('navigationConfig', () => {
  const navigationConfig = useNavigationConfig();
  const loading = navigationConfig.loading;
  const data = navigationConfig.data;

  const navigationCodes = computed(() => data.value.map((i) => i.code));

  const fetch = async () => {
    try {
      await navigationConfig.getNavigationConfig();
    } catch (error: any) {
      message.error(error?.msg || '获取数据失败，请刷新页面重试!');
    }
  };

  return { data, loading, navigationCodes, fetch };
});
