import { defineStore } from 'pinia';
import { computed } from 'vue';
import { message } from 'ant-design-vue';
import { useApplications, useApplicationsFavorite } from '@lexikos/doraemon-business';

export const useApplicationsNavStore = defineStore('applicationsNav', () => {
  // 应用列表
  const applications = useApplications();
  const appData = applications.data;
  // 收藏的应用列表
  const applicationsFavorite = useApplicationsFavorite();
  const appFavoriteData = applicationsFavorite.data;

  const $reset = () => {
    applications.resetApplications();
  };

  const fetch = async () => {
    try {
      await Promise.all([
        applications.getApplications(),
        applicationsFavorite.getApplicationsFavorite(),
      ]);
    } catch (error: any) {
      message.error(error?.msg || '获取数据失败，请刷新页面重试!');
    }
  };

  const loading = computed(() => applications.loading.value || applicationsFavorite.loading.value);

  return { appData, appFavoriteData, loading, $reset, fetch };
});
