// import { ref } from 'vue';
// import { defineStore } from 'pinia';
// import { message } from 'ant-design-vue';
// import { useHttp, type Application } from '@lexikos/doraemon-business';

// const KEY = 'applications';

// export const useApplicationsStore = defineStore(KEY, () => {
//   const loading = ref(false);
//   const data = ref<Application[] | undefined>(getApplicationsByLocal());

//   function saveApplications(newValue: Application[]) {
//     data.value = newValue;
//     localStorage.setItem(KEY, JSON.stringify(newValue));
//   }

//   function getApplicationsByLocal(): Application[] | undefined {
//     const localData = localStorage.getItem(KEY);
//     if (localData) {
//       return JSON.parse(localData);
//     }
//     return undefined;
//   }

//   async function getApplicationsByRemote() {
//     try {
//       loading.value = true;
//       const http = useHttp();
//       const response = await http.get<Application[]>('/api/auth/v1/applications');
//       saveApplications(response); // 同步并保存最新数据
//       return response;
//     } catch (error: any) {
//       message.error(error?.msg || '获取应用中心数据失败，请刷新页面重试!');
//       return Promise.reject(error);
//     } finally {
//       loading.value = false;
//     }
//   }

//   async function getApplications(): Promise<Application[]> {
//     const localData = getApplicationsByLocal();
//     if (localData) {
//       getApplicationsByRemote().catch((error) => console.warn('getApplications', error));
//       return localData;
//     }
//     return getApplicationsByRemote();
//   }

//   return { loading, data, getApplications };
// });
