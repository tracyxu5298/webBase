import { defineStore } from 'pinia';
import { message } from 'ant-design-vue';
import { useApplications } from '@lexikos/doraemon-business';

export const useApplicationsStore = defineStore('applications', () => {
  const applications = useApplications();
  const loading = applications.loading;
  const loaded = applications.loaded;
  const data = applications.data;

  const $reset = () => {
    applications.resetApplications();
  };

  const fetch = async () => {
    try {
      await applications.getApplications();
    } catch (error: any) {
      message.error(error?.msg || '获取数据失败，请刷新页面重试!');
    }
  };

  return { data, loaded, loading, $reset, fetch };
});
