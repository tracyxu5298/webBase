import { ref, unref } from 'vue';
import { defineStore } from 'pinia';
import { cloneDeep } from 'lodash-es';
import type { LocationQuery } from 'vue-router';
import type { Application } from '@lexikos/doraemon-business';
import { useNavigationConfigStore } from './navigationConfig';
import { APPLICATIONS_CODE } from '@/helpers/constants';

// const SESSION_STORAGE_APPLICATION_TAB = 'applicationTabs';
// const SESSION_STORAGE_RECENT_APP_CODE = 'recentAppCode';
// const SESSION_STORAGE_RECENT_APPS_PATH = 'recentAppLastPath';

export const useApplicationTabsStore = defineStore('applicationTabs', () => {
  const navigationConfigStore = useNavigationConfigStore();

  // const _tabs = JSON.parse(
  //   sessionStorage.getItem(SESSION_STORAGE_APPLICATION_TAB) || '[]',
  // ) as Application[];
  const _tabs = JSON.parse('[]') as Application[];
  const data = ref<Application[]>(_tabs);
  // 最近访问的应用
  const recentAppCode = ref('');
  /**
   * 保存最近使用的接口时间
   */
  const recentAppTimeCache = ref<Record<string, number>>({});

  const recentAppCache = ref<
    Record<
      string,
      {
        path: string;
        state?: Record<string, any>;
      } | null
    >
  >(
    // JSON.parse(sessionStorage.getItem(SESSION_STORAGE_RECENT_APPS_PATH) || '{}'),
    JSON.parse('{}'),
  );

  const add = (item: Application) => {
    if (data.value.find((i) => i.code === item.code)) {
      return;
    }
    // 主导航应用不需要应用标签
    // 应用中心固定展示 tab 也不需要维护
    if (
      unref(navigationConfigStore.navigationCodes).includes(item.code) ||
      item.code === APPLICATIONS_CODE
    ) {
      return;
    }

    data.value = [...data.value, item];
    // sessionStorage.setItem(SESSION_STORAGE_APPLICATION_TAB, JSON.stringify(data.value));
  };

  const remove = (code: string) => {
    data.value = data.value.filter((i) => i.code !== code);
    recentAppCache.value = {
      ...recentAppCache.value,
      [code]: null,
    };
    // sessionStorage.setItem(SESSION_STORAGE_APPLICATION_TAB, JSON.stringify(data.value));
    // sessionStorage.setItem(SESSION_STORAGE_RECENT_APPS_PATH, JSON.stringify(recentAppCache.value));
  };

  // 保存最近点击地址
  const saveRecentApp = (
    app: Application,
    _route: {
      // fullPath: string;
      path: string;
      query: LocationQuery;
    },
  ) => {
    recentAppCode.value = app.code;
    // sessionStorage.setItem(SESSION_STORAGE_RECENT_APP_CODE, app.code);

    recentAppCache.value = {
      ...recentAppCache.value,
      [app.code]: { ..._route, state: cloneDeep(history.state) },
    };
    // sessionStorage.setItem(SESSION_STORAGE_RECENT_APPS_PATH, JSON.stringify(recentAppCache.value));
  };

  const getRecentApp = (code?: string) => {
    const _code = code || recentAppCode.value || '';
    // const _code =
    //   code || recentAppCode.value || sessionStorage.getItem(SESSION_STORAGE_RECENT_APP_CODE) || '';
    return recentAppCache.value[_code];
  };

  const saveRecentAppTime = (code: string) => {
    recentAppTimeCache.value = {
      ...recentAppTimeCache.value,
      [code]: Date.now(),
    };
  };

  return {
    data,
    recentAppCache,
    recentAppTimeCache,
    saveRecentAppTime,
    add,
    remove,
    saveRecentApp,
    getRecentApp,
  };
});
