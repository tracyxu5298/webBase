import type { PiniaPluginContext } from 'pinia';

const listenerPiniaPlugin = ({ store }: PiniaPluginContext) => {
  // 响应 store 变化
  // store.$subscribe(() => {});
  // 响应 store actions
  store.$onAction(
    ({
      name, // action 名称
      store, // store 实例，类似 `someStore`
      args, // 传递给 action 的参数数组
      after, // 在 action 返回或解决后的钩子
      onError, // action 抛出或拒绝的钩子
    }) => {
      // 为这个特定的 action 调用提供一个共享变量
      const startTime = Date.now();
      // 这将在执行 "store "的 action 之前触发。
      console.log(`${store.$id} Start "${name}" with params:`, args);

      // 这将在 action 成功并完全运行后触发。
      // 它等待着任何返回的 promise
      after((result) => {
        const diff = Date.now() - startTime;
        console.log(`${store.$id} Finished "${name}" after ${diff}ms. Result:`, result);
      });

      // 如果 action 抛出或返回一个拒绝的 promise，这将触发
      onError((error) => {
        const diff = Date.now() - startTime;
        console.warn(`${store.$id} Failed "${name}" after ${diff}ms. Error:`, error);
      });
    },
  );
};

export default listenerPiniaPlugin;
