import { defineStore } from 'pinia';
import { ref } from 'vue';
import { Http } from '@lexikos/doraemon-network';

export const useNotificationStore = defineStore('useNotificationStore', () => {
  const unReadNum = ref(0);
  const taskCenterRedDotShow = ref(false);
  const taskCenterMessage = ref();

  function $reset() {
    unReadNum.value = 0;
  }

  function setTaskCenterRedDotShow(flag: boolean) {
    taskCenterRedDotShow.value = flag;
  }

  function setTaskCenterMessage(message: any) {
    window.postMessage(
      {
        type: 'TaskCenterMessage',
        params: message,
      },
      '*',
    );
    taskCenterMessage.value = message;
  }

  function setUnReadNum(num: number) {
    unReadNum.value = num;
  }

  async function fetchUnReadNum(params: { userId: string; userType: string }) {
    const defaultParams = {
      ...params,
      clientType: 'WEB',
    };
    const res = await Http.getInstance().get(
      '/api/building/v1/systemMessages/actions/getUnreadNumByUser',
      defaultParams,
    );
    setUnReadNum(res);
  }

  return {
    unReadNum,
    setUnReadNum,
    fetchUnReadNum,
    taskCenterRedDotShow,
    setTaskCenterRedDotShow,
    taskCenterMessage,
    setTaskCenterMessage,
    $reset,
  };
});
