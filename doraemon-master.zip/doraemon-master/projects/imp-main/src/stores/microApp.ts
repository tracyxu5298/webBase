import { ref } from 'vue';
import { defineStore } from 'pinia';

export type UseMicroApp = typeof useMicroApp;
export const useMicroApp = defineStore('micro-app', () => {
  /* 微应用卸载 状态 */
  const microAppUnmounting = ref(false);
  /* 微应用挂载 状态 */
  const microAppLoading = ref(false);

  function $reset() {
    microAppUnmounting.value = false;
    microAppLoading.value = false;
  }

  function setMicroAppUnmounting(unmounting: boolean = false) {
    microAppUnmounting.value = unmounting;
  }

  function setMicroAppLoading(loading: boolean = false) {
    microAppLoading.value = loading;
  }

  return { setMicroAppUnmounting, setMicroAppLoading, microAppLoading, microAppUnmounting, $reset };
});
