// import { ref, onBeforeMount } from 'vue';
// import { defineStore } from 'pinia';
// import { message } from 'ant-design-vue';
// import { Http } from '@lexikos/doraemon-network';
// import { type Application } from '@lexikos/doraemon-business';

// const KEY = 'navigationConfig';

// export const useNavigationConfigStore = defineStore(KEY, () => {
//   const loading = ref(false);
//   const data = ref<Application[] | undefined>(getNavigationConfigByLocal());

//   function saveNavigationConfig(newData: Application[]) {
//     data.value = newData;
//     localStorage.setItem(KEY, JSON.stringify(newData));
//   }

//   function getNavigationConfigByLocal(): Application[] | undefined {
//     const localData = localStorage.getItem(KEY);
//     if (localData) {
//       return JSON.parse(localData);
//     }
//     return undefined;
//   }

//   async function getNavigationConfigByRemote() {
//     try {
//       loading.value = true;
//       const response = await Http.getInstance().get<Application[]>('/api/auth/navigationConfig');
//       saveNavigationConfig(response); // 同步并保存最新数据
//       return response;
//     } catch (error: any) {
//       message.error(error?.msg || '导航栏数据获取失败，请刷新页面重试!');
//       return Promise.reject(error);
//     } finally {
//       loading.value = false;
//     }
//   }

//   // 本地优先
//   async function getNavigationConfig(): Promise<Application[]> {
//     const localData = getNavigationConfigByLocal();
//     if (localData) {
//       getNavigationConfigByRemote().catch((error) => console.warn('getNavigationConfig', error));
//       return localData;
//     }
//     return getNavigationConfigByRemote();
//   }

//   onBeforeMount(() => {
//     getNavigationConfig();
//   });

//   return { loading, data, getNavigationConfig };
// });
