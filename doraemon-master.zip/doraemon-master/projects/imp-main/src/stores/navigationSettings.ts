import { computed, ref } from 'vue';
import { message } from 'ant-design-vue';
import { defineStore } from 'pinia';
import type { Application } from '@lexikos/doraemon-business';
import { useNavigationConfig } from '@lexikos/doraemon-business';

export const SELF_NAVIGATION_CONFIG_ID = '-self';
export const SELF_ORG_NAVIGATION_CONFIG_ID = '-self-org';

export enum OwnerTypeEnum {
  self = 1,
  role = 2,
  org = 3,
}

export interface NavigatorSettingRole {
  id: string;
  roleName: string;
}

export interface NavigatorSetting {
  id: string;
  ownerType: OwnerTypeEnum;
  createBy?: string;
  updateBy?: string;
  createTime?: string;
  updateTime?: string;
  locationId?: string;
  roles: NavigatorSettingRole[];
  navigation: Application[];
}

export const useNavigationSettingsStore = defineStore('navigationSettings', () => {
  const navigationConfig = useNavigationConfig();
  const loadingMainNav = navigationConfig.loading;
  const dataConfig = navigationConfig.data;
  const loaded = ref(false);

  const loadingSettings = ref(false);

  const fetch = async () => {
    try {
      navigationConfig.getNavigationConfig();
    } catch (error: any) {
      message.error(error?.msg || '获取数据失败，请刷新页面重试!');
    } finally {
      loaded.value = true;
    }
  };

  const dataPerson = computed(() => {
    return [
      {
        id: SELF_NAVIGATION_CONFIG_ID,
        ownerType: OwnerTypeEnum.self,
        roles: [],
        navigation: dataConfig.value,
      },
    ];
  });

  const loading = computed(() => loadingSettings.value || loadingMainNav.value);

  return { data: dataPerson, loading, loaded, fetch };
});
