import { computed } from 'vue';
import { message } from 'ant-design-vue';
import { defineStore } from 'pinia';
import { useApplicationsFavorite } from '@lexikos/doraemon-business';
import type { Application } from '@lexikos/doraemon-business';

export const useApplicationsFavoriteStore = defineStore('applicationsFavorite', () => {
  const applicationsFavorite = useApplicationsFavorite();
  const loading = applicationsFavorite.loading;
  const data = applicationsFavorite.data;

  const applicationFavoriteIds = computed(() => data.value.map((i) => i.id));

  const fetch = async () => {
    try {
      await applicationsFavorite.getApplicationsFavorite();
    } catch (error: any) {
      message.error(error?.msg || '获取数据失败，请刷新页面重试!');
    }
  };

  const update = (values: Application[]) => {
    applicationsFavorite.saveApplicationsFavorite(values);
  };

  const $reset = () => {
    update([]);
  };

  const add = (value: Application) => {
    update([...data.value, value]);
  };

  const remove = (value: Application) => {
    update(data.value.filter((i) => i.id !== value.id));
  };

  return { data, applicationFavoriteIds, loading, $reset, add, update, remove, fetch };
});
