import FederationWidget from 'ImpPlatform/dashboard-widgets';
import { applyPureReactInVue } from 'veaury';
import { computed, ref, onUnmounted, onMounted, unref } from 'vue';

export default function useIMPWidget() {
  let timer: NodeJS.Timeout;
  const WorkbenchWidget = applyPureReactInVue(FederationWidget);
  const loaded = ref<boolean>(false);

  onMounted(() => {
    timer = setInterval(() => {
      if (window?.lds) {
        loaded.value = true;
        clearInterval(timer);
      }
    }, 300);
  });

  onUnmounted(() => {
    clearInterval(timer);
  });

  return computed(() => (unref(loaded) ? WorkbenchWidget : null));
}
