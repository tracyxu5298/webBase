import blue from '../assets/images/Workbench/blue.jpg';
import cyan from '../assets/images/Workbench/cyan.jpg';
import green from '../assets/images/Workbench/green.jpg';
import gold from '../assets/images/Workbench/gold.jpg';
import volcano from '../assets/images/Workbench/volcano.jpg';
import red from '../assets/images/Workbench/red.jpg';
import purple from '../assets/images/Workbench/purple.jpg';
import pink from '../assets/images/Workbench/pink.jpg';
import blueThumbnail from '../assets/images/Workbench/thumbnail/blue.jpg';
import cyanThumbnail from '../assets/images/Workbench/thumbnail/cyan.jpg';
import greenThumbnail from '../assets/images/Workbench/thumbnail/green.jpg';
import goldThumbnail from '../assets/images/Workbench/thumbnail/gold.jpg';
import volcanoThumbnail from '../assets/images/Workbench/thumbnail/volcano.jpg';
import redThumbnail from '../assets/images/Workbench/thumbnail/red.jpg';
import purpleThumbnail from '../assets/images/Workbench/thumbnail/purple.jpg';
import pinkThumbnail from '../assets/images/Workbench/thumbnail/pink.jpg';
import { usePreferenceSettingsStore, type PreferenceTheme } from '@lexikos/doraemon-business';
import { computed, unref } from 'vue';

const workbenchBgMap: Record<string, string> = {
  blue,
  cyan,
  green,
  gold,
  volcano,
  red,
  purple,
  pink,
};

const workbenchBgThumbnailMap: Record<string, string> = {
  blue: blueThumbnail,
  cyan: cyanThumbnail,
  green: greenThumbnail,
  gold: goldThumbnail,
  volcano: volcanoThumbnail,
  red: redThumbnail,
  purple: purpleThumbnail,
  pink: pinkThumbnail,
};

export const useWorkbenchBg = () => {
  const store = usePreferenceSettingsStore();

  const getThemeWorkbenchBgImg = (theme: PreferenceTheme, thumbnail = false) =>
    thumbnail ? workbenchBgThumbnailMap[theme] : workbenchBgMap[theme];

  const currentThemeWorkbenchBgImg = computed(
    () => workbenchBgMap[unref(store.data)?.workbenchBg || ''],
  );

  return { getThemeWorkbenchBgImg, currentThemeWorkbenchBgImg };
};
