import type { PropType } from 'vue';
import {
  computed,
  ref,
  unref,
  type Component,
  h,
  watchEffect,
  onBeforeUnmount,
  defineComponent,
} from 'vue';

import type { ToggleEyesProps } from '@/components/TextMask';
import { ToggleEyes } from '@/components/TextMask';
import { useUserInfoStore } from '@lexikos/doraemon-business';

export type UseSensitiveMaskOptions = Partial<Omit<ToggleEyesProps, 'value' | 'onChange'>>;

/**
 * 敏感信息打码勾子
 */
export const useSensitiveMask = ({
  suffixText,
  isLink,
  prefixText,
}: UseSensitiveMaskOptions = {}) => {
  const userInfoStore = useUserInfoStore();

  const masked = ref(!!(unref(userInfoStore.data) as any).containsQuery);

  const containsQuery = computed(() => !!(unref(userInfoStore.data) as any).containsQuery);

  const eyesIcon = computed<Component<ToggleEyesProps>>(() => {
    return defineComponent({
      props: {
        suffixText: {
          type: String,
        },
        isLink: {
          type: Boolean,
        },
        prefixText: {
          type: String,
        },
        masked: {
          type: Boolean,
          default: false,
        },
        onChange: {
          type: Object as PropType<any>,
        },
      },
      setup(props) {
        return () =>
          containsQuery.value
            ? h(ToggleEyes as Component, {
                suffixText: props.suffixText || suffixText,
                isLink: props.isLink || isLink,
                prefixText: props.prefixText || prefixText,
                value: props.masked || !masked.value,
                onChange: props.onChange || (() => setMasked(!masked.value)),
              })
            : [props.prefixText || prefixText, props.suffixText || suffixText]
                .filter(Boolean)
                .join('');
      },
    });
  });

  const cleanEffect = watchEffect(() => {
    setMasked(containsQuery.value);
  });

  function setMasked(bol: boolean) {
    masked.value = bol;
  }

  onBeforeUnmount(cleanEffect);

  return {
    /** 是否有查看敏感信息权限 */
    containsQuery,
    /** 小眼睛图标 */
    eyesIcon,
    /** 是否打码状态 */
    masked,
    /** 设置打码状态 */
    setMasked,
  };
};
