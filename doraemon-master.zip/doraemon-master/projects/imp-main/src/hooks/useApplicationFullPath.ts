import { ref, watchEffect } from 'vue';
import { useRoute } from 'vue-router';
import type { Application } from '@lexikos/doraemon-business';
import {
  getFullPathByAppPath,
  getLocalAppFullPaths,
  setLocalAppFullPath,
} from '@lexikos/doraemon-business';

const useApplicationFullPath = () => {
  const data = ref<string[]>(getLocalAppFullPaths());
  const route = useRoute();

  const _set = (_fullPath: string) => {
    // 打开新页签需要存储是否全屏标识
    if (_fullPath && !data.value.includes(_fullPath)) {
      setLocalAppFullPath(_fullPath);
      data.value = [...data.value, _fullPath];
    }
  };

  /**
   * 点击应用时调用，会主动处理
   * @param app 应用
   */
  const set = (app: Application) => {
    _set(getFullPathByAppPath(app.path));
  };

  watchEffect(() => {
    // 路由参数上带着 fullPath 也进行全屏处理
    _set(route.query.fullPath as string);
  });

  return { data, set };
};

export default useApplicationFullPath;
