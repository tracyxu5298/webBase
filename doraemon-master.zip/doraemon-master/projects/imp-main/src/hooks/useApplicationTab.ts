import { useRoute } from 'vue-router';
import { filter, map } from 'lodash-es';
import { computed, unref } from 'vue';
import type { ComputedRef } from 'vue';
import { ApplicationBelong } from '@lexikos/doraemon-business';
import { getAppPathToLower } from '@/helpers/util';
import { useApplicationsStore } from '@/stores/applications';
import { useNavigationConfigStore } from '@/stores/navigationConfig';
import { APPLICATIONS_PATH } from '@/helpers/constants';

const useApplicationTab = (): {
  /**
   * 展示应用中心 Tab
   */
  showTab: ComputedRef<boolean>;
} => {
  const route = useRoute();
  const applicationsStore = useApplicationsStore();

  // 主导航数据
  const navigationConfigStore = useNavigationConfigStore();

  // 应用中心的应用 path 集合
  const appPaths = computed(() =>
    map(
      filter(
        unref(applicationsStore.data),
        (i) =>
          !!i.path &&
          !(
            unref(navigationConfigStore.navigationCodes).includes(i.code) ||
            i.belong === ApplicationBelong.system
          ),
      ),
      (app) => getAppPathToLower(app),
    ),
  );

  // 是否需要展示 Tab
  const showTab = computed(() => {
    if (route.path === '/') {
      return false;
    }

    // startsWith 需要加上斜杠否则 /dataCenter 会匹配到 /data
    const _path = `${route.path.toLowerCase()}/`;

    // 应用中心默认展示
    if (_path.startsWith(`${APPLICATIONS_PATH.toLowerCase()}/`)) {
      return true;
    }

    // 检查当前路径是否是应用中心应用
    return appPaths.value.findIndex((i: string) => _path.startsWith(`${i}/`)) >= 0;
  });

  return { showTab };
};

export default useApplicationTab;
