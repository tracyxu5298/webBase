import {
  MqttSubscriber,
  mqttApplication,
  MQTT_TOPICS,
  useMqttStore,
  useUserId,
  useAccessToken,
  useUserInfoStore,
} from '@lexikos/doraemon-business';
import { forEach, includes, isEqual } from 'lodash-es';
import { ref, computed, watchEffect, unref, onUnmounted, onMounted } from 'vue';
import { useNotificationStore } from '@/stores/useNotification';
import { useIsParentOrStudent } from '@lexikos/doraemon-business';

let unsubscribeIsConnected: any;
/** 是否已监听 visibilitychange 事件 */
let isListenVisibilityChange = false;

const useMqttGlobal = () => {
  const userInfoStore = useUserInfoStore();
  const notificationStore = useNotificationStore();
  const mqttStore = useMqttStore();
  const userId = useUserId();
  const accessToken = useAccessToken();
  const isParentOrStudent = useIsParentOrStudent();
  const once = ref(true);

  const TOPICS = [
    MQTT_TOPICS.SYSTEM_MESSAGE_NOTIFY,
    MQTT_TOPICS.UNREAD_MESSAGE_NUM_NOTIFY,
    MQTT_TOPICS.TASK_CENTER_MSG_STATUS,
  ];

  const userType = computed(() => {
    return isParentOrStudent.value ? '2' : '1'; // 1: B端, 2: C端
  });

  const onVisibilityChange = () => {
    if (document.visibilityState === 'visible') {
      if (userId.value && !mqttApplication.mqttStateObservable.getIsConnected()) {
        notificationStore.fetchUnReadNum({ userId: userId.value, userType: userType.value });
        mqttApplication.mqttSubscribe(
          {
            topics: [],
            mqttActions: {},
            isConnect: true,
          },
          mqttSubscribeSuccessCallback,
        );
      }
    } else {
      mqttApplication.mqttServiceInstance?.end({
        force: true,
        options: {},
      });
    }
  };

  const mqttSubscribeSuccessCallback = () => {
    const mqttSubscriber = new MqttSubscriber({
      topics: TOPICS,
      onMessage({ topic, message }: any) {
        if (includes(topic, MQTT_TOPICS.TASK_CENTER_MSG_STATUS)) {
          notificationStore.setTaskCenterRedDotShow(!!message?.unReadQty);
          notificationStore.setTaskCenterMessage(message);
          return;
        }
        notificationStore.fetchUnReadNum({ userId: userId.value!, userType: userType.value });
      },
    });

    unsubscribeIsConnected = mqttApplication.mqttStateObservable.subscribeIsConnected((b) => {
      if (b) {
        forEach(TOPICS, (topic) => {
          if (includes(topic, MQTT_TOPICS.TASK_CENTER_MSG_STATUS)) {
            mqttSubscriber.manualSubOrUnsub(true, { topic, bid: userId.value! });
          }
          mqttSubscriber.manualSubOrUnsub(true, {
            topic,
            bid: `${userType.value}:${userId.value!}`,
          });
        });
        unsubscribeIsConnected?.();
      }
    });
  };

  // 获取初始数据
  // 里面需要用到组织类型，需要等待用户信息获取完毕后
  watchEffect(() => {
    if (userId.value) {
      once.value = false;
      const userInfo = unref(userInfoStore.data)!;
      const mqttOptions = {
        accessToken: accessToken.value,
        websocketAddress: userInfo.websocketAddress,
        mqttPassword: userInfo.mqttPassword,
        mqttUuid: userInfo.mqttUuid,
      };
      if (isEqual(mqttOptions, mqttApplication.getStoreMqttInfo())) {
        return;
      }

      /** 链接前先尝试断开mqtt链接 */
      mqttApplication.mqttServiceInstance?.end({
        force: true,
        options: {},
      });
      mqttApplication.setStore(mqttStore, mqttOptions);
      notificationStore.fetchUnReadNum({ userId: userId.value, userType: userType.value });
      mqttApplication.mqttSubscribe(
        {
          topics: [],
          mqttActions: {},
          isConnect: true,
        },
        mqttSubscribeSuccessCallback,
      );
    }
  });

  onMounted(() => {
    if (!isListenVisibilityChange) {
      document.addEventListener('visibilitychange', onVisibilityChange);
      isListenVisibilityChange = true;
    }
  });

  onUnmounted(() => {
    document.removeEventListener('visibilitychange', onVisibilityChange);
    isListenVisibilityChange = false;
  });

  return { mqttStore };
};

export default useMqttGlobal;
