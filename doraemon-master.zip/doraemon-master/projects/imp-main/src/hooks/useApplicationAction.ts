import { unref } from 'vue';
import { useRouter } from 'vue-router';
import { message } from 'ant-design-vue';
import {
  useHttp,
  ApplicationTarget,
  ApplicationBelong,
  ApplicationType,
  useThirdApplication,
  useDeployConfigStore,
  openNewWindow,
} from '@lexikos/doraemon-business';
import type { Application } from '@lexikos/doraemon-business';
import { clone, cloneDeep } from 'lodash-es';
import useApplicationFullPath from './useApplicationFullPath';
import { useApplicationTabsStore } from '@/stores/applicationTabs';
import { getFinalMicroAppPath } from '@/helpers/util';
import { useNavigationConfigStore } from '@/stores/navigationConfig';
import { APPLICATIONS_CODE } from '@/helpers/constants';

const MAX_APPS_COUNT = 10;

const useApplicationAction = () => {
  const router = useRouter();
  const http = useHttp();
  const applicationTabsStore = useApplicationTabsStore();
  const navigationConfigStore = useNavigationConfigStore();
  const appFullPath = useApplicationFullPath();
  const { getThirdAppInfo } = useThirdApplication();
  const deployConfigStore = useDeployConfigStore();

  const setUserRecentApp = async (app: Application) => {
    const { belong, code } = app;

    // 除系统应用外的应用打开后要记录最近使用
    if (belong === ApplicationBelong.system) {
      return;
    }

    const recentAppTime = unref(applicationTabsStore.recentAppTimeCache);
    // 最近使用 app，一分钟内不需要发起多次标记
    if (recentAppTime[code] && Date.now() - recentAppTime[code] < 60000) {
      return;
    }

    try {
      await http.post('api/auth/v1/userRecentApp', {
        appCode: code,
      });
      // 更新时间
      applicationTabsStore.saveRecentAppTime(code);
    } catch (error: any) {
      console.log('setUserRecentApp error', error);
    }
  };

  const onOpenNewTab = (app: Application) => {
    /**
     * 新标签打开需要存储是否全屏标识
     */
    appFullPath.set(app);
    let _path = app.path;
    /**
     * 打开新页签，需要判断是否携带 token
     */
    if (_path.includes('${AUTH_TOKEN}')) {
      _path = _path.replace('${AUTH_TOKEN}', localStorage.getItem('token') || '');
    }
    if (_path.includes('${REFRESH_TOKEN}')) {
      _path = _path.replace('${REFRESH_TOKEN}', localStorage.getItem('refreshToken') || '');
    }
    openNewWindow(_path);
  };

  const _routerPush = async (app: Application) => {
    // 跳转
    const _recentRoute = unref(applicationTabsStore.recentAppCache)[app.code];
    if (_recentRoute) {
      // cloneDeep 不加会导致页面刷新, 暂时未知原因
      router.push(cloneDeep(_recentRoute));
    } else {
      router.push(app.path);
    }
  };

  const getFinalAppInfo = async (_app: Application) => {
    // 旧应用的地址需要处理地址
    let app = getFinalMicroAppPath(clone(_app));

    // 第三方应用，获取云端的地址
    if (app.type === ApplicationType.third) {
      app = await getThirdAppInfo(app);
    }

    return app;
  };

  /**
   *
   * @param _app 应用
   * @param param1 checkTarget 是否需要检查点击打开新页签
   * @returns
   */
  const push = async (_app: Application, { checkTarget }: { checkTarget?: boolean } = {}) => {
    // 旧应用的地址需要处理地址
    const app = await getFinalAppInfo(_app);

    if (!app.path) {
      message.warn('未配置应用地址');
      return;
    }

    // 记录最近使用
    setUserRecentApp(app);

    /**
     * checkTarget 是用户从应用中心和搜索应用的入口打开的应用才是 true
     * 有些非全屏又打开新页签的应用会存在 tab 展示
     * 再点击 tab 时是不需要打开新页签的
     */
    if (checkTarget) {
      // 智慧录播: 录播管理
      if (deployConfigStore.isMediaApp(app.code)) {
        const _path = await deployConfigStore.getMediaAppPath(app.path);
        if (_path) {
          openNewWindow(_path);
          return;
        }
      }

      if (app.target === ApplicationTarget.blank) {
        onOpenNewTab(app);
        return;
      }
    }

    // 主导航应用/应用中心 直接跳转
    if (
      unref(navigationConfigStore.navigationCodes).includes(_app.code) ||
      _app.code === APPLICATIONS_CODE
    ) {
      _routerPush(app);
      return;
    }

    const _currentTabs = unref(applicationTabsStore.data);

    // 不在 tab 的应用，需要添加到 tab
    if (!_currentTabs.find((i) => i.code === _app.code)) {
      if (_currentTabs.length >= MAX_APPS_COUNT) {
        message.warn(`最多只能打开 ${MAX_APPS_COUNT} 个应用。`);
        return;
      }

      applicationTabsStore.add(app);
    }

    _routerPush(app);
  };

  return { push, setUserRecentApp, onOpenNewTab, getFinalAppInfo };
};

export default useApplicationAction;
