import { unref, watch, computed, onBeforeUnmount } from 'vue';
import {
  useUserInfoStore,
  useAccessToken,
  useIsBureau,
  useIsParentOrStudent,
} from '@lexikos/doraemon-business';

export default function useIMPT800() {
  const accessToken = useAccessToken();
  const userInfoStore = useUserInfoStore();
  const userInfoData = computed(() => unref(userInfoStore.data));
  const isBureau = useIsBureau();
  const isParentOrStudent = useIsParentOrStudent();

  watch(
    () => accessToken.value && userInfoData.value,
    async (newBool) => {
      if (!newBool || !window.lds) {
        return;
      }

      try {
        window.isBureau = isBureau.value;
        window.isParentOrStudent = isParentOrStudent.value;
        window.user__info = userInfoData.value;
        const { initSignedInIoCScope } = await import('ImpPlatform/t800');
        await initSignedInIoCScope(window.lds.I);
      } catch (error) {
        console.warn('>>>>>>> t800加载失败，影响旧应用功能的使用!!!', error);
      }
    },
  );

  onBeforeUnmount(() => {
    ['isParentOrStudent', 'isBureau', 'user__info'].forEach((key) => {
      delete window[key];
    });
  });
}
