import { onBeforeMount, ref } from 'vue';
import { Http } from '@lexikos/doraemon-network';
import dayjs from 'dayjs';

export const EarlyCloseNoticeBarTime = 'earlyCloseNoticeBarTime';

function useNoticeBar() {
  const visible = ref(false);
  const noticeContent = ref('');
  const noticeUpdateTime = ref<number>();
  const earlyCloseNoticeBarTime = localStorage.getItem(EarlyCloseNoticeBarTime);
  console.log('>>LL>>> ~ useNoticeBar ~ earlyCloseNoticeBarTime:', earlyCloseNoticeBarTime);

  onBeforeMount(async () => {
    const data = await Http.getInstance().get('/api/auth/anon/publishInfo');

    if (data) {
      const { status, webScope, content, updateTime } = data;
      const isDocNormal = status === 1 && webScope === 1;

      console.log('>>LL>>> ~ 信息状态:', isDocNormal);

      const isGtEarlyDate =
        !earlyCloseNoticeBarTime || dayjs(updateTime).isAfter(dayjs(+earlyCloseNoticeBarTime));

      console.log(
        '>>LL>>> ~ 大于最近关闭时间:',
        isGtEarlyDate,
        dayjs(updateTime).format('YYYY-MM-DD HH:mm:ss'),
      );

      const isUpdateTime = !!updateTime;

      noticeContent.value = content as string;
      noticeUpdateTime.value = updateTime as number;
      if (isDocNormal && isGtEarlyDate && isUpdateTime) {
        visible.value = true;
      }
    }
  });

  return [visible, noticeContent, noticeUpdateTime] as const;
}

export default useNoticeBar;
