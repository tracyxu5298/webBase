import { createRouter, createWebHistory } from 'vue-router';
import routes from './routes';
import { setupRouterGuard } from '@/router/guard';
import { qiankunWindow } from 'vite-plugin-qiankun/dist/helper';

const basename =
  qiankunWindow.__POWERED_BY_QIANKUN__ || window.SOURCE__BASE === 'boss'
    ? `/micro-${import.meta.env.VITE_APP_NAME}`
    : import.meta.env.BASE_URL;

const router = createRouter({
  history: createWebHistory(basename),
  routes,
  scrollBehavior: () => ({ left: 0, top: 0 }),
});

setupRouterGuard(router);

export default router;
