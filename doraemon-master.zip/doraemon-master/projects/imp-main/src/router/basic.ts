// import type { RouteRecordRaw } from 'vue-router';
// import { concat } from 'lodash-es';

// /* 免登应用路由集 */
// export const PAGE_FREE_LOGIN_ROUTE: RouteRecordRaw = {
//   name: 'freeLogin',
//   path: '/free-login/:anyPath(.*)*',
//   meta: { requiresAuth: false },
//   component: () => import('@/views/FreeLogin/index.vue'),
// };

// /* 异常页面集 */
// export const PAGES_EXCEPTION_ROUTE: RouteRecordRaw[] = [
//   {
//     /* 前端微服务、页面没有存在404 */
//     name: '404',
//     path: '/404',
//     meta: { requiresAuth: false },
//     component: () => import('@doraemon-business/components/Exception/Page404.vue'),
//   },
//   {
//     /* 前端微服务没有权限 403 */
//     name: '403',
//     path: '/403',
//     meta: { requiresAuth: false },
//     component: () => import('@doraemon-business/components/Exception/Page403.vue'),
//   },
//   {
//     /* 前端微服务没有发布 500 */
//     name: '500',
//     path: '/500',
//     meta: { requiresAuth: false },
//     component: () => import('@doraemon-business/components/Exception/Page500.vue'),
//   },
// ];

// /* 微应用页集 */
// export const PAGES_MICRO_APP_ROUTE: RouteRecordRaw = {
//   /* 所有微应用按这个配置进去, 默认进入的应用路由见useMicroAppCols下setDefaultMountApp */
//   path: ':microApp(.*)*',
//   name: 'MicroApp',
//   component: () => import('@doraemon-business/components/MicroApp/MicroAppPlaceholder.vue'),
// };

// /** 智慧录播业务页面集 */
// export const PAGES_INTELLIGENT_RECORDING_ROUTE: RouteRecordRaw = {
//   name: 'intelligent-recording-transfer',
//   path: '/intelligent-recording/transfer',
//   component: () => import('@/views/IntelligentRecording/transfer.vue'),
// };

// /* 基础路由集 */
// export const basicRoutes = concat(PAGE_FREE_LOGIN_ROUTE as any, PAGES_EXCEPTION_ROUTE);
