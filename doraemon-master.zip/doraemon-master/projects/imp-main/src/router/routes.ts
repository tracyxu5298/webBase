const routes = [
  {
    name: 'freeLogin',
    path: '/free-login/:anyPath(.*)*',
    meta: { requiresAuth: false },
    component: () => import('@/views/FreeLogin/index.vue'),
  },
  {
    name: 'ThirdLogin',
    path: '/ThirdLogin',
    meta: { requiresAuth: false },
    component: () => import('@/views/ThirdLogin.vue'),
  },
  {
    path: '/Login',
    name: 'loginLayout',
    meta: { requiresAuth: false },
    component: () => import('@doraemon-business/components/login/LoginTheme.vue'),
    children: [
      {
        path: '',
        name: 'Login',
        meta: { requiresAuth: false },
        props: {
          agreementDomain: '',
          envMode: import.meta.env.MODE,
          appVersion: import.meta.env.ROOT_VERSION,
        },
        component: () => import('@doraemon-business/components/login/LoginView.vue'),
      },
      {
        path: 'Forget',
        meta: { requiresAuth: false },
        props: {
          envMode: import.meta.env.MODE,
          appVersion: import.meta.env.ROOT_VERSION,
        },
        component: () => import('@doraemon-business/components/login/LoginForgetView.vue'),
      },
      {
        path: 'Third/:type',
        meta: { requiresAuth: false },
        props: {
          envMode: import.meta.env.MODE,
          appVersion: import.meta.env.ROOT_VERSION,
        },
        component: () => import('@doraemon-business/components/login/LoginThirdScanView.vue'),
      },
    ],
  },
  {
    path: '/About',
    meta: { requiresAuth: false },
    component: () => import('@/views/AboutView.vue'),
  },
  {
    path: '/403',
    meta: { requiresAuth: false },
    component: () => import('@doraemon-business/components/Exception/Page403.vue'),
  },
  {
    path: '/DataCenter/DataScreenGroups/Player/:id',
    component: () => import('@/views/DataCenter/DataScreenGroupsPlayerView.vue'),
  },
  {
    path: '/',
    component: () => import('@/views/HomeView.vue'),
    children: [
      {
        path: '/Applications',
        meta: {
          keepalive: true,
        },
        component: () => import('../views/ApplicationCenter/index.vue'),
      },
      {
        path: '/LowcodeApps',
        component: () => import('../views/Lowcode/LowcodeAppsView.vue'),
        children: [
          {
            path: ':appCode',
            component: () => import('../views/Lowcode/LowcodeAppView.vue'),
            children: [
              {
                path: 'LowcodePage/:moduleId*',
                component: () => import('@doraemon-business/components/lowcode/LowcodeView.vue'),
              },
              {
                path: 'IframePage',
                component: () => import('@doraemon-business/components/IframeView/index.vue'),
              },
            ],
          },
        ],
      },
      {
        path: '/ThirdApps',
        component: () => import('../views/ThirdAppsView.vue'),
        children: [
          {
            path: ':appCode',
            component: () => import('@doraemon-business/components/IframeView/index.vue'),
          },
        ],
      },
      {
        path: '/AccountSettings',
        redirect: '/AccountSettings/BasicInformation',
        component: () => import('@/views/AccountSettings/index.vue'),
        children: [
          {
            path: 'BasicInformation',
            name: 'BasicInformation',
            component: () => import('@/views/AccountSettings/BasicInformation.vue'),
          },
          {
            path: 'AvatarSettings',
            name: 'AvatarSettings',
            component: () => import('@/views/AccountSettings/AvatarSettings.vue'),
          },
          {
            path: 'ChangePassword',
            name: 'ChangePassword',
            component: () => import('@/views/AccountSettings/ChangePassword.vue'),
          },
          {
            path: 'ChangePhoneNumber',
            name: 'ChangePhoneNumber',
            component: () => import('@/views/AccountSettings/ChangePhoneNumber.vue'),
          },
          {
            path: 'AccountBinding',
            name: 'AccountBinding',
            component: () => import('@/views/AccountSettings/AccountBinding.vue'),
          },
        ],
      },
      {
        path: '/SystemSettings',
        component: () => import('@/views/SystemSettings/SystemSettingsView.vue'),
        children: [
          {
            path: 'NavigationSettings',
            component: () => import('@/views/SystemSettings/NavigationSettings/List.vue'),
          },
          {
            path: 'NavigationSettings/:id',
            component: () => import('@/views/SystemSettings/NavigationSettings/Detail.vue'),
          },
          {
            path: 'ThemeSettings',
            component: () => import('@/views/SystemSettings/ThemeSettingsView.vue'),
          },
          {
            path: 'ApplicationManagement',
            component: () => import('@/views/SystemSettings/ApplicationManagement/index.vue'),
          },
          {
            path: 'SystemParameter',
            component: () => import('@/views/SystemSettings/SystemParameter/index.vue'),
          },
          {
            path: 'LogCenter',
            component: () => import('@/views/SystemSettings/LogCenter/LogCenter.vue'),
          },
          {
            path: 'ThirdPartyIntegration',
            component: () => import('@/views/SystemSettings/ThirdPartyIntegration/index.vue'),
          },
          {
            path: 'ReportSubscription',
            component: () => import('@/views/SystemSettings/ReportSubscription/index.vue'),
          },
          {
            path: 'EHRSynchronizationData',
            component: () => import('@/views/SystemSettings/EHRSynchronizationData/index.vue'),
          },
          {
            path: 'WorkbenchSettings',
            props: { userType: 'admin' },
            component: () => import('@/views/Workbench/WorkbenchSettingsView.vue'),
          },
          {
            path: 'MobileHomeLayout',
            props: { userType: 'admin' },
            component: () => import('@/views/Workbench/MobileHomeLayout.vue'),
          },
          {
            path: 'MobileSettings',
            props: { userType: 'admin' },
            component: () => import('@/views/Workbench/MobileSettingsView.vue'),
          },
          {
            path: 'DesignerWorkbench',
            component: () => import('@/views/SystemSettings/DesignerWorkbench/index.vue'),
          },
        ],
      },
      {
        path: '/Workbench',
        component: () => import('@/views/Workbench/components/BasicLayout.vue'),
        children: [
          {
            path: '',
            component: () => import('@/views/Workbench/WorkbenchHomeView.vue'),
          },
          {
            path: 'Design/:userType/:workbenchId?',
            name: 'WorkbenchDesign',
            component: () => import('@/views/Workbench/WorkbenchDesignView.vue'),
            props: true,
          },
          {
            path: 'Boss',
            props: { userType: 'boss' },
            component: () => import('@/views/Workbench/WorkbenchSettingsView.vue'),
          },
        ],
      },
      {
        path: '/DataCenter',
        component: () => import('@/views/DataCenter/DataCenterView.vue'),
        children: [
          {
            path: 'DataScreenManageBoss',
            component: () => import('@/views/DataCenter/DataScreenBossManageView.vue'),
          },
          {
            path: 'DataScreenManage',
            component: () => import('@/views/DataCenter/DataScreenImpManageView.vue'),
          },
          {
            path: 'DataScreenGroups',
            component: () => import('@/views/DataCenter/DataScreenGroupsView.vue'),
          },
        ],
      },

      {
        path: '/OrganizationCenter',
        component: () => import('@/views/OrganizationCenter/OrganizationCenterView.vue'),
        children: [
          {
            path: 'Users',
            component: () => import('../views/OrganizationCenter/UserManagement/index.vue'),
          },
          {
            path: 'Users/:personId',
            component: () => import('../views/OrganizationCenter/UserManagement/UserAddEdit.vue'),
          },
          {
            path: 'BureauOrganization',
            component: () =>
              import('../views/OrganizationCenter/OrganizationManagement/OrganizationView.vue'),
          },
          {
            path: 'Group',
            component: () =>
              import('../views/OrganizationCenter/UserGroupManagement/UserGroupView.vue'),
          },
          {
            path: 'Position',
            component: () => import('../views/OrganizationCenter/PositionManagement/index.vue'),
          },
          {
            path: 'Roles',
            component: () => import('../views/OrganizationCenter/RoleManagement/index.vue'),
          },
          {
            path: 'Roles/:roleId',
            component: () => import('../views/OrganizationCenter/RoleManagement/addOrDetail.vue'),
          },
          {
            path: 'OutsideUsers',
            component: () => import('../views/OrganizationCenter/OutsideUsers/index.vue'),
          },
          {
            path: 'BatchAddition',
            component: () => import('../views/OrganizationCenter/UserManagement/BatchAddition.vue'),
          },
          {
            path: 'Users/Certificate/:personId/:personName',
            component: () => import('../views/OrganizationCenter/UserManagement/Certificate.vue'),
          },
          {
            path: 'VoucherManagement',
            component: () => import('../views/OrganizationCenter/VoucherManagement/index.vue'),
            children: [
              {
                path: '',
                component: () =>
                  import('../views/OrganizationCenter/VoucherManagement/Fingerprint.vue'),
              },
              {
                path: 'ICCard',
                component: () => import('../views/OrganizationCenter/VoucherManagement/ICCard.vue'),
              },
            ],
          },
        ],
      },
      {
        path: '/NoticeCenter',
        component: () => import('@/views/NoticeCenter/NoticeCenterView.vue'),
        children: [
          {
            path: '',
            component: () => import('@/views/NoticeCenter/NoticeCenterHomeView.vue'),
          },
        ],
      },
      {
        /* 前端微服务、页面没有存在404 */
        name: '404',
        path: '/404',
        meta: { requiresAuth: false },
        component: () => import('@doraemon-business/components/Exception/Page404.vue'),
      },
      {
        /* 前端微服务没有权限 403 */
        name: '403',
        path: '/403',
        meta: { requiresAuth: false },
        component: () => import('@doraemon-business/components/Exception/Page403.vue'),
      },
      {
        /* 前端微服务没有发布 500 */
        name: '500',
        path: '/500',
        meta: { requiresAuth: false },
        component: () => import('@doraemon-business/components/Exception/Page500.vue'),
      },
      {
        /* 所有微应用按这个配置进去, 默认进入的应用路由见useMicroAppCols下setDefaultMountApp */
        path: ':microApp(.*)*',
        name: 'MicroApp',
        component: () => import('@doraemon-business/components/MicroApp/MicroAppPlaceholder.vue'),
      },
      {
        name: 'intelligent-recording-transfer',
        path: '/intelligent-recording/transfer',
        component: () => import('@/views/IntelligentRecording/transfer.vue'),
      },
    ],
  },
];

export default routes;
