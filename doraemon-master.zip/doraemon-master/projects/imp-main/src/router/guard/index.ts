import type { Router } from 'vue-router';
// import createFixQiankun2Guard from '@/router/guard/qiankunNav2Guard';
// import createAuthorityGuard from '@/router/guard/authorityGuard';
import createLoginGuard from '@/router/guard/loginGuard';
import createReportGuard from './reportGuard';
// import createErrorGuard from '@/router/guard/errorGuard';

export function setupRouterGuard(router: Router) {
  // createFixQiankun2Guard(router);
  // createErrorGuard(router);
  // createAuthorityGuard(router);
  createLoginGuard(router);
  createReportGuard(router);
}
