import type { RouteLocationNormalized, Router } from 'vue-router';
import { useAutoLogin, useAuthStore } from '@lexikos/doraemon-business';

export default function createLoginGuard(router: Router) {
  router.beforeEach(async (to: RouteLocationNormalized, _form: RouteLocationNormalized) => {
    // 1. 第三方访问, code 换 token, 自动登录
    if (to.query.code && to.path.startsWith('/third')) {
      return {
        name: 'ThirdLogin',
        query: { path: to.path.replace('/third', ''), code: to.query.code },
      };
    }
    // 2. 检测是否携带`_t_`(token)和`_tk_`(tokenKey), 自动登录
    const _to = useAutoLogin({ to });
    if (_to) {
      return _to;
    }
    // 3. 路由配置表
    if (to.meta.requiresAuth !== false) {
      const isAuthenticated = useAuthStore().token;
      const loginAuthGuard = !isAuthenticated && !to.path.includes('free-login');
      if (loginAuthGuard) {
        const dedicatedWebsite = localStorage.getItem('dedicatedWebsite');
        const query: Record<string, string> = {};
        if (dedicatedWebsite) {
          query.n = dedicatedWebsite;
        }
        if (!to.query.logout && to.path !== '/' && !to.path.toLowerCase().startsWith('/login')) {
          query.from = encodeURIComponent(to.fullPath);
        }
        return { name: 'Login', query };
      }
    }
  });
}
