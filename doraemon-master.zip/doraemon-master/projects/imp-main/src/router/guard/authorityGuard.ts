import { ApplicationType, type Application } from '@lexikos/doraemon-business'; //
import { useApplicationsStore } from '@/stores/applications';
import { filter, includes, isEmpty, join, map, replace, some, split, uniqBy } from 'lodash-es';
import { unref } from 'vue';
import type { Router } from 'vue-router';

let warning = true;

/** 校验路由权限403 */
function authorityRouter403(apps: Application[], href: string) {
  // 在path后拼接'/',防止路径前缀相同，后面不同的情况
  const noAuthority = !some(apps, (app) => {
    const { path, type } = app;
    const latestPath = replace(path, /\?.*/, '');
    const newHref = join([href, ''], '/');
    const newLatestPath = join([latestPath, ''], '/');

    if (type === ApplicationType.new) {
      return includes(newHref, newLatestPath);
    }

    if (type === ApplicationType.old) {
      if (includes(newLatestPath, 'notice-center')) {
        return includes(newHref, newLatestPath);
      }

      if (filter(split(newLatestPath, '/'), Boolean).length <= 1) {
        if (warning) {
          warning = false;
          //   console.warn(`>> 旧应用微服务路径配置有问题，正确方式如：/config/xx应用 \n
          //   出问题应用路径：${newLatestPath} \n
          //   出问题应用名称：${app.name} \n
          //   请联系管理员
          // `);
        }

        return false;
      }

      // 处理带有大类的路径 如：/config/xxx/yyy
      return includes(newHref, replace(newLatestPath, /\/?\w+-?\w*/, ''));
    }

    return true;
  });

  const to403Router = {
    name: '403',
    replace: true,
  };

  console.log('>>LL>>访问的路径是无权限的，重定向至403', noAuthority);

  return [noAuthority, to403Router];
}

export default function createAuthorityGuard(router: Router) {
  const paths = map(
    uniqBy(
      filter(router.getRoutes(), (r) => /^\/\w+$/.test(r.path)),
      'path',
    ),
    (rr) => rr.path,
  );

  router.beforeEach(async (to, _from) => {
    const applicationsStore = useApplicationsStore();
    const isMetaRequiresAuthFalse = to.meta.requiresAuth !== false;
    const isAuthenticated = localStorage.getItem('token');
    const applications = unref(applicationsStore.data);

    if (isEmpty(applications) && isAuthenticated) {
      await applicationsStore.fetch();
    }

    const apps = filter(
      unref(applicationsStore.data),
      (d) => !!d.path && d.type !== ApplicationType.third,
    );

    const href = to.path;

    /* 403 */
    if (
      isAuthenticated &&
      href !== '/' &&
      isMetaRequiresAuthFalse &&
      apps.length &&
      /* 当imp-main当做子应用被集成至老boss, 不做403权限拦截 */
      window.SOURCE__BASE !== 'boss'
    ) {
      const [no403Authority, goto403] = authorityRouter403(apps, href);
      const isExistBaseApp = some(paths, (p) => includes(href, p));
      if (no403Authority && !isExistBaseApp) {
        return goto403;
      }
    }

    /* 404 */
    // 基座无法配置404,因为微应用是动态的，导致403和404场景存在冲突

    /* 500 */
    // 异常页由router.onError监控后重定向500
  });
}
