import type { Router } from 'vue-router';

// 允许关闭历史事件的监听器，修复vue-router4.x 下qiankun导致navigation 2次的问题
export default function createFixQiankun2Guard(router: Router) {
  router.listening = false;
  router.beforeEach((to, from) => {
    if (to.fullPath === from.fullPath && to.fullPath !== '/') {
      return false;
    }
  });
}
