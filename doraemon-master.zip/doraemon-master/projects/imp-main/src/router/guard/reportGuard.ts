import type { RouteLocationNormalized, Router } from 'vue-router';
import { Report } from '@lexikos/doraemon-business';

export default function createReportGuard(router: Router) {
  let url = '';
  router.afterEach(async (to: RouteLocationNormalized, _form: RouteLocationNormalized) => {
    if (url === to.fullPath) {
      return; // todo: 2024-06-18, 后续处理, 因为`router.afterEach`会执行两次
    }
    const instance = Report.getInstance();
    if (instance) {
      const event = instance.buildEvent({ code: 'pageview', url: to.fullPath });
      instance.send(event);
      url = to.fullPath;
    }
  });
}
