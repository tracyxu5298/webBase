import '@/assets/styles/main.scss';
import { createApp, type App as VueApp } from 'vue';
import { createPinia } from 'pinia';
import { type QiankunProps } from 'vite-plugin-qiankun/dist/helper';
import { httpPlugin, reportPlugin } from '@lexikos/doraemon-business';
import App from '@/App.vue';
import router from '@/router';

let app: VueApp;

function vueRender(props: QiankunProps = {}) {
  const { container } = props;
  const pinia = createPinia();
  app = createApp(App);

  app.use(pinia as any);
  app.use(router);
  app.use(httpPlugin); // { version: import.meta.env.ROOT_VERSION }
  app.use(reportPlugin);

  if (!container && !document.querySelector('#main')) {
    window.addEventListener('DOMContentLoaded', () => {
      app?.mount(container ? (container as Element).querySelector('#main') : '#main');
    });
  } else {
    app.mount(container ? (container as Element).querySelector('#main') : '#main');
  }
}

export function render(props: QiankunProps) {
  vueRender(props);
}

export function destroy() {
  app.unmount();
}
