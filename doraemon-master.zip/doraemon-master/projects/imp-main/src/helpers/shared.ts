/**
 * @description 基座的shared
 * -------------单例=>专门管理微前端的全局状态管理 -------------
 * 1. 预设子应用切换状态 设置、获取;
 * 2. 其它状态管理，通过插件形式（prototype）加入这个Shared类中，已达到其它文件独立的管理
 * 3. 同时也支持装饰器语法规则;
 */
class Shared {
  private static singleton: Shared;
  microAppStore: any;

  constructor(store?: any) {
    if (store) {
      this.microAppStore = store;
    }
  }

  /**
   * @description 设置 全局loading
   */
  setLoading(_loading: boolean) {
    // this.microAppStore.setMicroAppLoading(loading);
  }
  /**
   * @description 获取 全局loading
   */
  getLoading(): boolean {
    return false; // this.microAppStore.microAppLoading;
  }

  /**
   * @description 获取卸载子应用标志
   */
  getUnmounting(): boolean {
    return true; // this.microAppStore.microAppUnmounting;
  }
  /**
   * @description 设置卸载子应用标志
   */
  setUnmounting(_unmounting: boolean) {
    // this.microAppStore.setMicroAppUnmounting(unmounting);
  }
}

export default Shared;
