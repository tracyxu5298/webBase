import { ApplicationType, type Application } from '@lexikos/doraemon-business';
import { split } from 'lodash-es';

/**
 * @param _app: 来源应用中心的application对象
 * @returns 处理过后的应用对象
 */
export function getFinalMicroAppPath(
  _app: Application & { appPath?: string },
  pathKey: 'appPath' | 'path' = 'path',
) {
  const appPath = _app[pathKey] || '';
  if (appPath && _app.type === ApplicationType.old && appPath.startsWith('/')) {
    let _path = appPath;
    let _search = '';

    // 带参数的 url 需要拆开处理
    const _searchStartIndex = appPath.indexOf('?');
    if (_searchStartIndex >= 0) {
      _search = appPath.substring(_searchStartIndex) || '';
      _path = appPath.substring(0, _searchStartIndex);
    }

    const paths = split(_path, '/');
    const path = paths[paths.length - 1];
    const application = { ..._app, path: `/${path}${_search}` };
    return application;
  }
  return _app as Application;
}

/**
 *
 * @param app 应用信息
 * @returns 去除 query 参数的小写应用路由
 */
export const getAppPathToLower = (app: Application): string => {
  if (!app) {
    return '';
  }
  const _path = getFinalMicroAppPath(app).path;
  return _path ? split(_path, '?')[0].toLowerCase() : '';
};

// 小驼峰--下划连字符互转
export const transHumpUnderline = (str: string, mode: 'toHump' | 'toLine'): string => {
  let result: string = str;
  if (mode === 'toLine' && /([A-Z])/g.test(str)) {
    result = str.replace(/([A-Z])/g, '_$1').toLowerCase();
  } else if (mode === 'toHump' && str.includes('_')) {
    result = str.replace(/_([a-z])/g, (_, p1) => p1.toUpperCase());
  }
  return result;
};

/** 下拉数据转换 */
export const formatterOptions = (
  data: Record<string, string | number>[],
  key?: string,
  name?: string,
) => {
  const value = key || 'value';
  const label = name || 'label';
  const options = data.map((item) => ({ ...item, value: item?.[value], label: item?.[label] }));
  return options;
};

/** 是否为空 */
export const isEmpty = (val: string | null | undefined) => {
  return !![null, undefined, ''].includes(val);
};

// 请求参数过滤null,undefined,空字符串
export const filterParams = (params = {}) => {
  const _p: any = { ...params };
  Object.keys(_p).forEach((one) => {
    if (_p[one] === null || _p[one] === undefined || _p[one] === '') {
      delete _p[one];
    }
  });
  return _p;
};

export const genderMap: any = {
  1: '男',
  2: '女',
};
