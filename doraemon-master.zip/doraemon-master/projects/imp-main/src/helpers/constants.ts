export const APPLICATIONS_CODE = 'ApplicationCenter';
export const APPLICATIONS_PATH = '/Applications';
export interface IMembersItem {
  id: string;
  name: string;
  gender: number;
  tel: string;
  jobNo: string;
  departmentId: string;
  departmentName: string;
  positionNames: any[];
}

interface IMembersSearchParams {
  condition: string | null;
}

export type IMembersTableParams = IMembersSearchParams & {
  pageNum: number;
  pageSize: number;
};
