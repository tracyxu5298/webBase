<script setup lang="ts">
const appName = import.meta.env.VITE_APP_NAME;
const appVersion = import.meta.env.ROOT_VERSION;
const builderNumber = import.meta.env.BUILDER_NUMBER;
</script>

<template>
  <h3>项目名: {{ appName }}</h3>
  <h3>版本号: {{ appVersion }}</h3>
  <h3>构建号: {{ builderNumber }}</h3>
</template>
