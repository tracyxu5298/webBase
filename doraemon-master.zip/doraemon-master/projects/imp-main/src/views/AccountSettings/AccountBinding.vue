<script lang="ts" setup></script>

<template>
  <div>账号绑定</div>
</template>

<style lang="scss" scoped>
//
</style>
