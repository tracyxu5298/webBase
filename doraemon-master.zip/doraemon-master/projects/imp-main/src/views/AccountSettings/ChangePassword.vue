<script lang="ts" setup>
import { computed, reactive, ref } from 'vue';
import { MailOutlined, LockOutlined } from '@ant-design/icons-vue';
import { useHttp, useCountDown, useUserPhone } from '@lexikos/doraemon-business';
import { message } from 'ant-design-vue';
import type { FormInstance } from 'ant-design-vue';
import { MD5Encrypt, RSAEncrypt, onLogout, regExpPassword } from '@lexikos/doraemon-business';
import type { Rule } from 'ant-design-vue/es/form';

const userPhone = useUserPhone();
// const oldPassword = ref('');
const formState = reactive({
  phoneNumber: userPhone.value,
  phoneVerificationCode: '',
  password: '',
  newPassword: '',
});
const hiddenPhoneNumber = computed(() => {
  return userPhone.value?.replace(/(\d{3})\d{4}(\d{4})/, '$1****$2');
});
const validatePassword = async (_rule: Rule, value: string) => {
  if (!value) {
    return Promise.reject('请输入密码');
  }

  if (value.length > 20 || value.length < 8) {
    return Promise.reject('请输入8-20位密码');
  }

  if (!value.match(regExpPassword)) {
    return Promise.reject('您设置的密码安全等级较低，请重新输入');
  }

  if (formState.newPassword && formState.password !== formState.newPassword) {
    return Promise.reject('两次密码不一致!');
  }
  return Promise.resolve();
};

const validateNewPassword = async (_rule: Rule, value: string) => {
  if (!value) {
    return Promise.reject('请输入密码');
  }

  if (value.length > 20 || value.length < 8) {
    return Promise.reject('请输入8-20位密码');
  }

  if (!value.match(regExpPassword)) {
    return Promise.reject('您设置的密码安全等级较低，请重新输入');
  }

  if (formState.password && formState.password !== formState.newPassword) {
    return Promise.reject('两次密码不一致!');
  }
  return Promise.resolve();
};
const rulesRef = reactive({
  phoneVerificationCode: [{ required: true, message: '请输入验证码' }],
  password: [{ validator: validatePassword, trigger: 'blur' }],
  newPassword: [{ validator: validateNewPassword, trigger: 'blur' }],
});
const http = useHttp();
const { time, handleStart } = useCountDown(59);
const formRef = ref<FormInstance>();
const current = ref(0);
const code = ref(); // 手机短信验码验证成功后, 服务端返回的授权码
const disabledNext = computed(() => {
  return !(formState.phoneNumber && formState.phoneVerificationCode);
});

const onSendCode = async () => {
  try {
    const res = await http.get('/api/building/v1/vcode/sendVerificationCode', {
      debugSwitchStatus: import.meta.env.MODE !== 'prod' ? 1 : 0, // 调试开关状态（0：关闭 1：打开）
      phoneNumber: RSAEncrypt(formState.phoneNumber),
    });
    const { verificationCode } = res || {};
    formState.phoneVerificationCode = verificationCode;
    handleStart();
  } catch (error: any) {
    message.error(error?.desc || '获取验证码失败');
  }
};

const nextLoading = ref<boolean>(false);
const next = async () => {
  nextLoading.value = true;
  try {
    const data = await http.post('/api/building/v1/vcode/checkVerificationCode', {
      phoneVerificationCode: formState.phoneVerificationCode,
      phoneNumber: RSAEncrypt(formState.phoneNumber),
    });
    current.value = 1;
    code.value = data;
  } catch (error: any) {
    message.error(error?.desc || '短信验证码无效！');
  } finally {
    nextLoading.value = false;
  }
};
const saveLoading = ref<boolean>(false);
const onSubmit = async () => {
  saveLoading.value = true;
  try {
    await formRef?.value?.validate();
    await http.post('/api/auth/v1/password/changePassword', {
      phoneNumber: RSAEncrypt(formState.phoneNumber),
      newPassword: RSAEncrypt(MD5Encrypt(formState.password)),
      code: code.value,
    });
    message.success('密码重置成功!', 2).then(() => {
      onLogout(); // 退出登录
    });
  } catch (error: any) {
    message.error(error?.desc || '密码重置失败！');
  } finally {
    saveLoading.value = false;
  }
};
</script>

<template>
  <div class="change-password-wrap">
    <a-steps
      style="width: 440px; margin-bottom: 20px"
      :current="current"
      :items="[
        {
          title: '安全验证',
        },
        {
          title: '设置新密码',
        },
      ]"
    ></a-steps>

    <a-form
      v-if="userPhone"
      style="width: 376px"
      name="loginPhoneForm"
      ref="formRef"
      :model="formState"
      autocomplete="off"
      :rules="rulesRef"
    >
      <a-form-item v-if="current === 0">
        <div style="color: #00000073">
          给手机号 {{ hiddenPhoneNumber }} 发送验证码，进行身份验证
        </div>
      </a-form-item>
      <a-form-item v-if="current === 0" name="phoneVerificationCode">
        <a-input
          class="login-input"
          v-model:value="formState.phoneVerificationCode"
          :maxlength="6"
          placeholder="请输入验证码"
        >
          <template #prefix>
            <MailOutlined class="login-input-icon" />
          </template>
          <template #suffix>
            <a class="send-code-button" v-if="!time" @click="onSendCode">获取验证码</a>
            <span class="send-code-time" v-else>{{ time }}s</span>
          </template>
        </a-input>
      </a-form-item>
      <a-form-item v-if="current === 0">
        <a-button
          class="login-form-button"
          :disabled="disabledNext"
          block
          :loading="nextLoading"
          type="primary"
          size="large"
          @click="next"
          >下一步</a-button
        >
      </a-form-item>
      <a-form-item name="password" v-if="current === 1">
        <a-input-password
          v-model:value="formState.password"
          autoComplete="reset-password"
          placeholder="请设置8-20位字母/数字/特殊符号至少3种组合"
          class="login-input"
        >
          <template #prefix>
            <LockOutlined class="login-input-icon" />
          </template>
        </a-input-password>
      </a-form-item>
      <a-form-item name="newPassword" v-if="current === 1">
        <a-input-password
          v-model:value="formState.newPassword"
          autoComplete="reset-password"
          placeholder="请再次输入新的登录密码"
          class="login-input"
        >
          <template #prefix>
            <LockOutlined class="login-input-icon" />
          </template>
        </a-input-password>
      </a-form-item>
      <a-form-item v-if="current === 1">
        <a-button
          class="login-password-form-button"
          :disabled="!formState.newPassword || !formState.password"
          block
          size="large"
          type="primary"
          :loading="saveLoading"
          @click="onSubmit"
        >
          确定
        </a-button>
      </a-form-item>
    </a-form>

    <div v-else>
      <p>未提供手机号，不支持修改密码！</p>
    </div>
  </div>
</template>

<style lang="scss" scoped>
.change-password-wrap {
  display: flex;
  align-items: center;
  padding: 40px var(--components-token-notification-line-height-lg, 0);
  border-radius: var(--components-token-notification-line-height-lg, 0);
  flex-direction: column;
  gap: 20px;
  flex: 1 0 0;
}
.login-input {
  padding: 7px 11px 9px;
}
</style>
