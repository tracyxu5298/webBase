<script setup lang="ts">
import { ref, h, watch } from 'vue';

import type { MenuProps } from 'ant-design-vue';
import { useRoute, RouterLink } from 'vue-router';

import { IdcardOutlined, SmileOutlined, UnlockOutlined } from '@ant-design/icons-vue';

// UserOutlined,

const route = useRoute();
const items = ref<MenuProps['items']>([
  // {
  //   key: '0',
  //   icon: () => h(UserOutlined),
  //   label: h(RouterLink, { to: '/AccountSettings/BasicInformation' }, '用户中心'),
  //   title: '用户中心',
  //   path: '/AccountSettings/BasicInformation',
  // },
  {
    key: '/AccountSettings/BasicInformation',
    icon: () => h(IdcardOutlined),
    label: h(
      RouterLink,
      { to: '/AccountSettings/BasicInformation' },
      { default: () => '基本信息' },
    ),
    title: '基本信息',
  },
  {
    key: '/AccountSettings/AvatarSettings',
    icon: () => h(SmileOutlined),
    label: h(RouterLink, { to: '/AccountSettings/AvatarSettings' }, { default: () => '头像设置' }),
    title: '头像设置',
  },
  {
    key: '/AccountSettings/ChangePassword',
    icon: () => h(UnlockOutlined),
    label: h(RouterLink, { to: '/AccountSettings/ChangePassword' }, { default: () => '修改密码' }),
    title: '修改密码',
  },
  // {
  //   key: '4',
  //   icon: () => h(DesktopOutlined),
  //   label: h(RouterLink, { to: '/AccountSettings/ChangePhoneNumber' }, '修改手机号'),
  //   title: '修改手机号',
  //   path: '/AccountSettings/ChangePhoneNumber',
  // },
  // {
  //   key: '5',
  //   icon: () => h(DesktopOutlined),
  //   label: h(RouterLink, { to: '/AccountSettings/AccountBinding' }, '账号绑定'),
  //   title: '账号绑定',
  //   path: '/AccountSettings/AccountBinding',
  // },
]);

const selectedKeys = ref<string[] | undefined>();
const onClick = (e: any) => {
  selectedKeys.value = [e.key];
};
watch(
  () => route.fullPath,
  () => {
    items.value?.forEach((item: any) => {
      if (item.key === route.fullPath) {
        selectedKeys.value = [item.key];
      }
    });
  },
  {
    immediate: true,
  },
);
</script>

<template>
  <a-layout class="layout">
    <a-layout-sider :width="220" theme="light" class="layout-sider">
      <a-menu
        v-model:selectedKeys="selectedKeys"
        @click="onClick"
        theme="light"
        mode="inline"
        :items="items"
        class="menu"
      ></a-menu>
    </a-layout-sider>
    <a-layout-content class="layout-content">
      <slot>
        <RouterView></RouterView>
      </slot>
    </a-layout-content>
  </a-layout>
</template>

<style lang="scss" scoped>
.layout {
  width: 100%;
  height: 100%;
}
.menu {
  overflow-x: hidden;
  overflow-y: auto;
  height: 100%;
  padding: 16px;
  li a {
    color: inherit;
  }
}
.layout-content {
  display: flex;
  overflow-y: auto;
  height: 100%;
  background: #fff;
  flex: 1;
  flex-direction: column;
}
</style>
