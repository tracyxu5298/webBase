<script lang="ts" setup>
import { reactive, ref, onBeforeMount, computed } from 'vue';
import { message } from 'ant-design-vue';
import type { Rule } from 'ant-design-vue/es/form';
import { useHttp, useUserInfoStore } from '@lexikos/doraemon-business';
import { GenAuthCode } from './components';

interface FormState {
  accountName: string;
  tel: string;
  name: string | null;
  userIdentity: number;
  workUnit: string | null;
}
const http = useHttp();
const formRef = ref();
const formState = reactive<FormState>({
  accountName: '',
  tel: '',
  name: null,
  userIdentity: 0, //0教职工OR教育局人员 1 学生 2 家长 3 其他 4 外部人员   为0的时候禁止修改工作单位
  workUnit: null,
});

const userInfoStore = useUserInfoStore();
const validateName = async (_rule: Rule, value: string) => {
  if (value === '') {
    return Promise.reject('姓名不可为空!');
  }
  return Promise.resolve();
};
const validateWorkUnit = async (_rule: Rule, value: string) => {
  if (value && !/^.{2,30}$/.test(value)) {
    return Promise.reject('请输入2-30个任意字符!');
  }
  return Promise.resolve();
};

const rules: Record<string, Rule[]> = {
  name: [{ required: true, validator: validateName, trigger: 'blur' }],
  workUnit: [{ validator: validateWorkUnit, trigger: 'blur' }],
};
const layout = {
  labelCol: { span: 4 },
  wrapperCol: { span: 14 },
};
const loading = ref<boolean>(false);
const getPersonal = async () => {
  loading.value = true;
  try {
    const res = await http.get('/api/building/personalCenter');
    if (res) {
      formState.accountName = res.accountName;
      formState.tel = res.tel;
      formState.name = res.name;
      formState.userIdentity = res.userIdentity;
      formState.workUnit = res.workUnit;
    }
  } catch (error: any) {
    message.error(error?.desc || '获取数据失败！');
  }
  loading.value = false;
};

const btnLoading = ref<boolean>(false);
const putPersonal = async () => {
  try {
    await http.put('/api/building/personalCenter', {
      name: formState.name,
      workUnit: formState.workUnit,
    });
    message.success('成功！');
    getPersonal();
    userInfoStore.getUserInfoByRemote();
  } catch (error: any) {
    message.error(error?.desc || '修改失败！');
  }
};
const onSubmit = async () => {
  btnLoading.value = true;
  try {
    await formRef.value.validate();
    putPersonal();
  } catch (error: any) {
    message.error(error?.desc || '修改失败！');
  } finally {
    btnLoading.value = false;
  }
};
onBeforeMount(() => {
  getPersonal();
});
const hiddenPhoneNumber = computed(() => {
  return formState.tel.replace(/(\d{3})\d{4}(\d{4})/, '$1****$2');
});
const hiddeAccountName = computed(() => {
  const length = formState.accountName?.length;
  if (length === 0) return;
  const hiddenLength = Math.ceil(length / 3);
  const frontLength = Math.floor((length - hiddenLength) / 2);
  let star = '';
  for (let i = 0; i < hiddenLength; i++) {
    star += '*';
  }
  return formState.accountName?.replace(
    formState.accountName.substring(frontLength, frontLength + hiddenLength),
    star,
  );
});
</script>

<template>
  <div class="basic-wrap">
    <a-spin :spinning="loading">
      <a-form
        style="width: 800px; margin: auto"
        ref="formRef"
        name="custom-validation"
        :model="formState"
        :rules="rules"
        v-bind="layout"
      >
        <a-form-item label="账号" name="accountName">
          <a-input disabled v-model:value="hiddeAccountName" />
        </a-form-item>
        <a-form-item label="手机号" name="tel">
          <a-input disabled v-model:value="hiddenPhoneNumber" autocomplete="off" />
        </a-form-item>
        <a-form-item label="姓名" name="name">
          <a-input
            :disabled="formState.userIdentity === 1"
            v-model:value="formState.name"
            placeholder="请输入您的姓名"
            :maxlength="30"
          />
        </a-form-item>
        <a-form-item
          label="工作单位"
          name="workUnit"
          v-if="formState.userIdentity !== 0 && formState.userIdentity !== 1"
        >
          <a-input v-model:value="formState.workUnit" placeholder="请输入您的工作单位" />
        </a-form-item>
        <a-form-item v-if="formState.userIdentity !== 1" :wrapper-col="{ span: 14, offset: 4 }">
          <a-button :loading="btnLoading" type="primary" @click="onSubmit">保存</a-button>
        </a-form-item>
      </a-form>
      <GenAuthCode />
    </a-spin>
  </div>
</template>
<style scoped>
.basic-wrap {
  padding: 40px 0;
}
</style>
