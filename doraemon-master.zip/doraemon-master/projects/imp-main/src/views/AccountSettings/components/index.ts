export { default as GenAuthCode } from './GenAuthCode/index.vue';
