<script setup lang="ts">
import { useUserInfoStore } from '@lexikos/doraemon-business';
import { computed, unref, ref, watchEffect, watch, onBeforeUnmount } from 'vue';
import { QuestionCircleOutlined } from '@ant-design/icons-vue';
import { Http } from '@lexikos/doraemon-network';
import { get, join } from 'lodash-es';

let timer: NodeJS.Timer | any;
const times = 60;
const adminDisabled = ref(false);
const open = ref(false);
const second = ref(times);
const password = ref('');

const userInfoStore = useUserInfoStore();

const userIdentity = computed(() => {
  const v = unref(userInfoStore.data);
  return (
    [0, '0'].includes(get(v, 'userIdentity', 99999)) &&
    ![1, '1'].includes(get(v, 'adminStatus', 99999))
  );
});
const account = computed(() => {
  const info = unref(userInfoStore.data);
  return (info as any)?.accountName || info?.tel || '/';
});
const personId = computed(() => unref(userInfoStore.data)?.personId!);

function showModal() {
  open.value = true;
}

function handleGenCode() {
  adminDisabled.value = true;
  Http.getInstance()
    .get('/api/building/getTempAuthCode', {
      sceneType: 'imp',
      businessId: unref(personId),
    })
    .then(({ authCode }) => {
      password.value = authCode;
    })
    .catch((e) => {
      console.log(e);
      adminDisabled.value = false;
    });
}

const cleanEffect = watchEffect(() => {
  if (!adminDisabled.value || second.value < 1) {
    clearInterval(timer);
    adminDisabled.value = false;
    second.value = times;
    return;
  }

  if (second.value === times) {
    timer = setInterval(() => {
      second.value -= 1;
    }, 1000);
  }
});

watch(open, () => {
  if (!open.value) {
    password.value = '';
  }
});

onBeforeUnmount(cleanEffect);
</script>

<template>
  <a-affix :style="{ position: 'absolute', top: '-6px', right: '30px' }" v-if="userIdentity">
    <a-space>
      <a-button type="primary" @click="showModal"> 临时授权密码 </a-button>
      <a-tooltip placement="right">
        <template #title> 可生成该账号的临时授权密码，有效期24小时 </template>
        <QuestionCircleOutlined />
      </a-tooltip>
    </a-space>
  </a-affix>

  <a-modal v-model:open="open" title="临时授权密码" centered>
    <template #footer>
      <a-button key="back" @click="handleGenCode" :disabled="adminDisabled">
        生成{{ join(adminDisabled ? ['(', second, 's)'] : [], '') }}
      </a-button>
    </template>
    <p>生成一个{{ account }}的密码</p>
    <p v-show="!!password">
      <a-typography-paragraph :copyable="{ tooltip: false, text: password }">
        {{ password }}
      </a-typography-paragraph>
    </p>
  </a-modal>
</template>
