<script lang="ts" setup>
import { ref, onBeforeMount } from 'vue';
import { useHttp, useUserInfoStore } from '@lexikos/doraemon-business';
import { Modal, message, theme } from 'ant-design-vue';
import { PlusOutlined, CameraOutlined } from '@ant-design/icons-vue';
import AvatarCropper from './AvatarCropper.vue';

const { token } = theme.useToken();
const http = useHttp();
const imgList = ref<any[]>([]);
const imgSpinning = ref<boolean>(false);
const getHeadImageList = async () => {
  imgSpinning.value = true;
  const res = await http.get('/api/auth/systemConfigs/actions/getHeadImageList');
  imgList.value = res;
  imgSpinning.value = false;
};

const userInfoStore = useUserInfoStore();
const headLoading = ref<boolean>(false);
const headImg = ref('');
const isDefault = ref(false);
const activeId = ref<string>('');
const getHeadImage = async () => {
  headLoading.value = true;
  const res = await http.get('/api/building/personalCenter/actions/getHeadImage');
  if (res) {
    headImg.value = res.headImageUrl;
    isDefault.value = imgList.value.some((item) => item.fileId === res.headImageId);
    if (isDefault.value) {
      activeId.value = res.headImageId;
    } else {
      activeId.value = '';
    }
  }
  headLoading.value = false;
};
onBeforeMount(async () => {
  await getHeadImageList();
  await getHeadImage();
});
const headSelect = async (fileId: string) => {
  if (headImg.value && !isDefault.value) {
    Modal.confirm({
      title: '提示',
      content: '已上传自定义头像，确定覆盖吗？',
      okText: '确认',
      cancelText: '取消',
      centered: true,
      async onOk() {
        try {
          await http.put('/api/building/personalCenter/actions/updateHeadImage', {
            headImageId: fileId,
          });
          getHeadImage();
          userInfoStore.getUserInfoByRemote();
          message.success('成功！');
        } catch (e: any) {
          message.error(e?.desc || '失败！');
        }
      },
    });
  } else {
    try {
      await http.put('/api/building/personalCenter/actions/updateHeadImage', {
        headImageId: fileId,
      });
      getHeadImage();
      userInfoStore.getUserInfoByRemote();
      message.success('成功！');
    } catch (e: any) {
      message.error(e?.desc || '失败！');
    }
  }
};
// 定义interface类型
interface IClipper {
  type: string; // 上传类型
  allowTypeList: string[]; // 接收允许上传的图片类型
  limitSize: number; // 限制大小
  fixedNumber: number[]; // 截图框的宽高比例
  fixedNumberAider?: number[]; // 侧边栏收起截图框的宽高比例
  previewWidth: number; // 预览宽度
  previewWidthAider?: number; // 侧边栏收起预览宽度
}

const clipperData = ref<IClipper>({
  type: '',
  allowTypeList: [],
  limitSize: 1,
  fixedNumber: [],
  previewWidth: 0,
});

// 裁剪组件Ref
const clipperRef: any = ref({});
const browserUpload = (): void => {
  clipperData.value = {
    type: 'browserLogo', // 该参数可根据实际要求修改类型
    allowTypeList: ['png', 'jpg', 'PNG', 'JPG'], // 允许上传的图片格式
    limitSize: 1, // 限制的大小
    fixedNumber: [1, 1], // 截图比例，可根据实际情况进行修改
    previewWidth: 100, // 预览宽度
  };
  // 打开裁剪组件
  clipperRef.value.uploadFile();
};

/* 保存logo自定义事件, 实际业务在此编写 */
const onConfirm = (): void => {
  getHeadImage();
  // 更新导航栏头像
  userInfoStore.getUserInfoByRemote();
};
</script>

<template>
  <div class="avatar-wrap">
    <a-spin :spinning="headLoading">
      <div class="avatar-left">
        <div class="head-img" v-if="headImg && !isDefault">
          <img :src="headImg" alt="" />
          <div class="modal-box">
            <CameraOutlined
              style="font-size: 50px; color: #fff; cursor: pointer"
              @click="browserUpload"
            />
          </div>
        </div>
        <template v-else>
          <div class="default-head">
            <img src="@/assets/images/avatar.png" />
          </div>
          <div class="upload-box">
            <a-button class="upload-btn" type="primary" @click="browserUpload">
              <PlusOutlined style="margin-right: 2px" />选择头像</a-button
            >
          </div></template
        >
        <div class="tip">支持2M以内png、jpg格式图片， 建议尺寸300*300像素</div>
      </div>
    </a-spin>
    <a-divider type="vertical" style="height: 300px" />
    <div class="avatar-right">
      <div class="title">您也可以选择您喜欢的经典头像：</div>
      <a-spin :spinning="imgSpinning">
        <div class="img-wrap">
          <div
            @click="headSelect(item.fileId)"
            :class="['img-box', activeId === item.fileId ? 'active' : '']"
            v-for="item in imgList"
            :key="item.fileId"
          >
            <img :src="item.filePath" />
            <a-checkbox class="select" v-if="activeId === item.fileId" :checked="true" />
          </div>
        </div>
      </a-spin>
    </div>
    <AvatarCropper
      ref="clipperRef"
      :type="clipperData.type"
      :allow-type-list="clipperData.allowTypeList"
      :limit-size="clipperData.limitSize"
      :fixed-number="clipperData.fixedNumber"
      :fixed-number-aider="clipperData.fixedNumberAider"
      :preview-width="clipperData.previewWidth"
      @confirm="onConfirm"
    ></AvatarCropper>
  </div>
</template>

<style lang="scss" scoped>
.avatar-wrap {
  display: flex;
  align-items: center;
  width: 100%;
  padding: 40px;
  border-radius: var(--components-token-notification-line-height-lg, 0);
  gap: 80px;
  .avatar-left {
    display: flex;
    align-items: center;
    width: 365px;
    padding: var(--components-token-notification-line-height-lg, 0);
    border-radius: var(--components-token-notification-line-height-lg, 0);
    flex-direction: column;
    gap: 32px;
  }
  .avatar-right {
    display: flex;
    align-items: center;
    padding: var(--components-token-notification-line-height-lg, 0);
    border-radius: var(--components-token-notification-line-height-lg, 0);
    flex-direction: column;
    gap: 12px;
    .title {
      font-size: 14px;
      color: #00000073;
      font-style: normal;
      font-weight: 400;
      line-height: 22px;
    }
  }
}
.head-img {
  position: relative;
  width: 300px;
  height: 300px;
  margin-top: 60px;

  .modal-box {
    position: absolute;
    top: 0;
    left: 0;
    z-index: -1;
    display: flex;
    justify-content: center;
    align-items: center;
    width: 100%;
    height: 100%;
    background-color: rgb(0 0 0 / 50%);
  }
  &:hover {
    .modal-box {
      z-index: 999;
    }
  }
  img {
    width: 100%;
    height: 100%;
  }
}
.default-head {
  display: flex;
  justify-content: center;
  align-items: center;
  width: 120px;
  height: 130px;
  padding: var(--components-token-notification-line-height-lg, 40px)
    var(--components-token-notification-line-height-lg, 36px)
    var(--components-token-notification-line-height-lg, 42px)
    var(--components-token-notification-line-height-lg, 36px);
  background: var(--global-basic-color-fill-tertiary, #0000000a);
  border-radius: 8px;
  flex-direction: column;
  gap: var(--components-token-notification-line-height-lg, 0);
  img {
    width: 40px;
    height: 40px;
  }
}
.img-wrap {
  display: flex;
  align-items: flex-start;
  width: 273px;
  height: 272px;
  padding: var(--components-token-notification-line-height-lg, 0);
  border-radius: var(--components-token-notification-line-height-lg, 0);
  align-content: flex-start;
  gap: 16px;
  flex-wrap: wrap;
  .active {
    border-color: v-bind('token.colorPrimary');
  }
}
.img-box {
  position: relative;
  display: flex;
  align-items: flex-start;
  width: 56px;
  height: 56px;
  padding: 8px;
  border: 1px solid var(--global-basic-color-border-secondary, #00000014);
  border-radius: 8px;
  img {
    width: 40px;
    height: 40px;
  }
  .select {
    position: absolute;
    top: 0;
    right: 0;
    z-index: 999;
    width: 17px;
    height: 17px;
  }
}
.upload-box {
  display: flex;
  align-items: center;
  padding: var(--components-token-notification-line-height-lg, 0);
  border-radius: var(--components-token-notification-line-height-lg, 0);
  flex-direction: column;
  gap: 12px;
  .upload-btn {
    width: 112px;
  }
}
.tip {
  width: 220px;
  font-size: 14px;
  text-align: center;
  color: #00000073;
  font-style: normal;
  font-weight: 400;
  line-height: 22px;
}
</style>
