<script lang="ts" setup>
import { ref, watch, reactive } from 'vue';
import { message } from 'ant-design-vue';
import { uniq } from 'lodash-es';
import 'vue-cropper/dist/index.css';
import { VueCropper } from 'vue-cropper';
import { useHttp } from '@lexikos/doraemon-business';
import { useUploadServer } from '@lexikos/doraemon-business';

import {
  ZoomInOutlined,
  ZoomOutOutlined,
  RotateLeftOutlined,
  RotateRightOutlined,
} from '@ant-design/icons-vue';

/* 父组件传参 */
const props = withDefaults(defineProps<IProps>(), {
  open: false,
  type: 'systemLogo',
  allowTypeList: () => ['jpg', 'png', 'jpeg'],
  limitSize: 1,
  fixedNumber: () => [1, 1],
  fixedNumberAider: () => [1, 1],
  previewWidth: 228,
  title: 'LOGO裁剪',
});
const emit = defineEmits<{
  (e: 'confirm'): void;
}>();
const http = useHttp();
const { uploadFile2Server } = useUploadServer();
const modalOpen = ref<boolean>(false);

// 裁剪组件需要使用到的参数
interface Options {
  img: string | ArrayBuffer | null; // 裁剪图片的地址
  info: true; // 裁剪框的大小信息
  outputSize: number; // 裁剪生成图片的质量 [1至0.1]
  outputType: string; // 裁剪生成图片的格式
  canScale: boolean; // 图片是否允许滚轮缩放
  autoCrop: boolean; // 是否默认生成截图框
  autoCropWidth: number; // 默认生成截图框宽度
  autoCropHeight: number; // 默认生成截图框高度
  fixedBox: boolean; // 固定截图框大小 不允许改变
  fixed: boolean; // 是否开启截图框宽高固定比例
  fixedNumber: Array<number>; // 截图框的宽高比例  需要配合centerBox一起使用才能生效
  full: boolean; // 是否输出原图比例的截图
  canMove: boolean;
  canMoveBox: boolean; // 截图框能否拖动
  original: boolean; // 上传图片按照原始比例渲染
  centerBox: boolean; // 截图框是否被限制在图片里面
  infoTrue: boolean; // true 为展示真实输出图片宽高 false 展示看到的截图框宽高
  accept: string; // 上传允许的格式
}

// 父组件传参props
interface IProps {
  open: boolean;
  type: string; // 上传类型, 企业logo / 浏览器logo
  allowTypeList: string[]; // 接收允许上传的图片类型
  limitSize: number; // 限制大小
  fixedNumber: number[]; // 截图框的宽高比例
  fixedNumberAider?: number[]; // 侧边栏收起截图框的宽高比例
  previewWidth: number; // 预览宽度
  title?: string; // 裁剪标题
}

// 预览样式
interface IStyle {
  width: number | string;
  height: number | string;
}

// 裁剪组件需要使用到的参数
const options = reactive<Options>({
  img: '', // 需要剪裁的图片
  autoCrop: true, // 是否默认生成截图框
  autoCropWidth: 150, // 默认生成截图框的宽度
  autoCropHeight: 150, // 默认生成截图框的长度
  fixedBox: false, // 是否固定截图框的大小 不允许改变
  info: true, // 裁剪框的大小信息
  outputSize: 1, // 裁剪生成图片的质量 [1至0.1]
  outputType: 'png', // 裁剪生成图片的格式
  canScale: true, // 图片是否允许滚轮缩放
  fixed: true, // 是否开启截图框宽高固定比例
  fixedNumber: [1, 1], // 截图框的宽高比例 需要配合centerBox一起使用才能生效 1比1
  full: true, // 是否输出原图比例的截图
  canMove: true,
  canMoveBox: true, // 截图框能否拖动
  original: false, // 上传图片按照原始比例渲染
  centerBox: true, // 截图框是否被限制在图片里面
  infoTrue: false, // true 为展示真实输出图片宽高 false 展示看到的截图框宽高
  accept: 'image/jpeg,image/jpg,image/png,image/gif,image/x-icon',
});

const getStyle = ref<IStyle>({
  width: '',
  height: '',
});

/* 允许上传的类型 */
const acceptType = ref<string[]>([]);

// 裁剪后的预览样式信息
const previews: any = ref({});
const previewFileStyle = ref({});

// 裁剪组件Ref
const cropperRef: any = ref({});
// input组件Ref
const reuploadInput = ref<HTMLElement | null | undefined>();

// 回显图片使用的方法
const onChange = (e: any) => {
  const file = e.target.files[0];
  const URL = window.URL || window.webkitURL;
  // 上传图片前置钩子，用于判断限制类型用
  if (beforeUploadEvent(file)) {
    options.img = URL.createObjectURL(file);
    modalOpen.value = true;
  }
};

/* 上传图片前置拦截函数 */
const beforeUploadEvent = (file: File) => {
  const type = file.name.substring(file.name.lastIndexOf('.') + 1); // 获得图片上传后缀
  // 判断是否符合上传类型
  const isAllowTye = props.allowTypeList.some((item) => {
    return item === type;
  });
  if (!isAllowTye) {
    message.error(`仅支持${acceptType.value.join('、')}格式的图片`);
    return false;
  }
  return true;
};

/* 重置裁剪组件 */
const refreshCrop = () => {
  // cropperRef裁剪组件自带很多方法，可以打印看看
  cropperRef.value.refresh();
};
/* 右旋转图片 */
const rotateLeft = () => {
  cropperRef.value.rotateLeft();
};

/* 右旋转图片 */
const rotateRight = () => {
  cropperRef.value.rotateRight();
};

/* 放大缩小图片比例 */
const changeScale = (num: number) => {
  const scale = num || 1;
  cropperRef.value.changeScale(scale);
};

// 缩放的格式
const tempScale = ref<number>(0);

// 点击上传
const uploadFile = (type: string): void => {
  /* 打开新的上传文件无需生成新的input元素 */
  if (type === 'reupload') {
    reuploadInput.value?.click();
    return;
  }
  let input: HTMLInputElement | null = document.createElement('input');
  input.type = 'file';
  input.accept = options.accept;
  input.onchange = onChange;
  input.click();
  input = null;
};

/* 上传成功方法 */
const cropperSuccess = async (dataFile: File) => {
  try {
    const res = await uploadFile2Server({
      file: dataFile as unknown as File,
    });
    return res;
  } catch (error: any) {
    message.error(error?.desc || '头像上传失败！');
  }
};

// base64转图片文件
const dataURLtoFile = (dataUrl: string, filename: string) => {
  const arr: any = dataUrl.split(',');
  const mime = arr[0]?.match(/:(.*?);/)[1];
  const bstr = atob(arr[1]);
  let len = bstr.length;
  const u8arr = new Uint8Array(len);
  while (len--) {
    u8arr[len] = bstr.charCodeAt(len);
  }
  return new File([u8arr], filename, { type: mime });
};

const loading = ref<boolean>(false);
// 上传图片（点击保存按钮）
const onConfirm = () => {
  loading.value = true;
  try {
    cropperRef.value.getCropData(async (data: string) => {
      const dataFile: File = dataURLtoFile(data, 'images.png');
      if (dataFile.size > 1024 * 1024) {
        return message.error('图片大小超出限制！请重新裁剪合适大小的图片！');
      }
      const res: any = await cropperSuccess(dataFile);
      await http.put('/api/building/personalCenter/actions/updateHeadImage', {
        headImageId: res.fileId,
      });
      // 触发自定义事件
      emit('confirm');
      modalOpen.value = false;
      return res;
    });
  } catch (error: any) {
    message.error(error?.desc || '头像设置失败！');
  } finally {
    loading.value = false;
  }
};

// 裁剪之后的数据
const previewHandle = (data: any) => {
  previews.value = data; // 预览img图片
  tempScale.value = props.previewWidth / data.w;
  previewFileStyle.value = {
    width: data.w + 'px',
    height: data.h + 'px',
    margin: 0,
    overflow: 'hidden',
    zoom: tempScale.value,
    position: 'relative',
    border: '1px solid #e8e8e8',
    'border-radius': '2px',
  };
};

watch(
  () => props,
  () => {
    /* 预览样式 */
    getStyle.value = {
      width: props.previewWidth + 'px', // 预览宽度
      height: props.previewWidth / props.fixedNumber[0] + 'px', // 预览高度
    };
    // 上传格式tips信息
    acceptType.value = [];
    for (let i = 0; i < props.allowTypeList.length; i++) {
      acceptType.value.push(props.allowTypeList[i].toLowerCase());
    }
    // 数组去重
    acceptType.value = uniq(acceptType.value);
  },
  {
    deep: true,
  },
);

/* 向父组件抛出上传事件 */
defineExpose({
  uploadFile,
});
</script>

<template>
  <div>
    <input
      ref="reuploadInput"
      type="file"
      accept="image/*"
      @change="onChange"
      id="fileBtn"
      style="display: none"
    />
    <!-- @close="open = false" -->
    <a-modal :width="620" v-model:open="modalOpen" title="图片裁剪">
      <!-- // 核心内容 -->
      <div class="cropper">
        <!-- // 裁剪左侧内容 -->
        <div class="cropper-left">
          <VueCropper
            :style="{ width: '400px' }"
            ref="cropperRef"
            :img="options.img"
            :info="true"
            :info-true="options.infoTrue"
            :auto-crop="options.autoCrop"
            :fixed-box="options.fixedBox"
            :can-move="options.canMove"
            :can-move-box="options.canMoveBox"
            :can-scale="options.canScale"
            :fixed-number="fixedNumber"
            :fixed="options.fixed"
            :full="options.full"
            :center-box="options.centerBox"
            @real-time="previewHandle"
          />
          <div class="reupload-box">
            <a-button type="link" @click="uploadFile('reload')">重新上传</a-button>
            <div class="action-box">
              <ZoomInOutlined @click="changeScale(1)" />
              <ZoomOutOutlined @click="changeScale(-1)" />
              <RotateLeftOutlined @click="rotateLeft" />
              <RotateRightOutlined @click="rotateRight" />
            </div>
          </div>
        </div>

        <div class="cropper-right">
          <div class="preview-text">预览</div>
          <div :style="getStyle" class="previewImg">
            <div :style="previewFileStyle">
              <img :style="previews.img" :src="previews.url" alt="" />
            </div>
          </div>
        </div>
      </div>

      <template #footer>
        <span class="dialog-footer">
          <a-button @click="modalOpen = false">取消</a-button>
          <a-button @click="refreshCrop">重置</a-button>
          <a-button :loading="loading" type="primary" @click="onConfirm"> 确认 </a-button>
        </span>
      </template>
    </a-modal>
  </div>
</template>
<style lang="scss" scoped>
.cropper {
  display: flex;
  overflow: hidden;
  width: 100%;
  height: 50vh;
  .cropper-left {
    display: flex;
    flex-direction: column;
    .reupload-box {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-top: 10px;
      .reupload-text {
        color: var(--primary-color);
        cursor: pointer;
      }
      .rotate-right {
        margin-left: 16px;
        cursor: pointer;
      }
      .action-box {
        display: flex;
        justify-content: space-between;
        align-items: center;
        width: 120px;
        font-size: 18px;
        color: rgb(0 0 0 / 45.1%);
      }
    }
  }
  .cropper-right {
    flex: 1;
    margin-left: 44px;
    .preview-text {
      margin-bottom: 12px;
    }
  }
}
</style>
