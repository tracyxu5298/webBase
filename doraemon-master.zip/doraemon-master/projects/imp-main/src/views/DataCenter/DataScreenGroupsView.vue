<script setup lang="ts">
import { ref } from 'vue';
import { message, theme } from 'ant-design-vue';
import { deleteDataScreenGroup, getDataScreenGroupDetail, getDataScreenGroups } from './service';
import { useLocationId, usePermission } from '@lexikos/doraemon-business';
import { ArrowLeftOutlined } from '@ant-design/icons-vue';
import { useRouter } from 'vue-router';
import { PlusOutlined } from '@ant-design/icons-vue';
import type { DataScreenGroup } from './utils/types';
import { confirm } from './utils/helper';
import GroupEditModal from './components/GroupEditModal.vue';

const router = useRouter();
const { token } = theme.useToken();
const locationId = useLocationId();

const groupList = ref<DataScreenGroup[]>([]);
const groupListLoading = ref(false);

const addPermission = usePermission('DataCenter', 'btn_add');
const editPermission = usePermission('DataCenter', 'btn_edit');
const deletePermission = usePermission('DataCenter', 'btn_delete');

const currentEditingGroup = ref<Partial<DataScreenGroup>>();
const editGroup = (group: Partial<DataScreenGroup>) => {
  currentEditingGroup.value = group;
};
const closeModal = async (reload = false) => {
  currentEditingGroup.value = undefined;
  if (reload) {
    await getGroupList();
  }
};

const pageBack = () => {
  router.replace('/DataCenter/DataScreenManage');
};

const getGroupList = async () => {
  groupListLoading.value = true;
  const res = await getDataScreenGroups(locationId.value!).finally(
    () => (groupListLoading.value = false),
  );
  groupList.value = res;
};

const getNames = (group: DataScreenGroup) => {
  return group.screenTopics.map((s) => s.title).join('、');
};

const deleteHandle = async (group: DataScreenGroup) => {
  if (!(await confirm({ content: '确定删除当前组合吗？' }))) {
    return;
  }
  groupListLoading.value = true;
  await deleteDataScreenGroup(group.id).catch((e) => {
    groupListLoading.value = false;
    return Promise.reject(e);
  });
  await getGroupList();
};

const playDataScreenGroup = (group: DataScreenGroup) => {
  message.info(`播放大屏组合"${group.name}"`);
  window.open(
    `/DataCenter/DataScreenGroups/Player/${group.id}?fullPath=/DataCenter/DataScreenGroups/Player`,
  );
  getDataScreenGroupDetail(group.id).then((res: any) => {
    console.log('...... > getDataScreenGroupDetail > res:', res);
  });
};

const init = () => {
  getGroupList();
};

init();
</script>

<template>
  <div class="page">
    <header class="header">
      <span class="link" @click="pageBack">
        <a class="icon"><ArrowLeftOutlined /></a>
        <span class="title">返回</span>
      </span>
    </header>
    <div class="body">
      <a-spin :spinning="groupListLoading">
        <a-row :gutter="[20, 20]">
          <a-col
            :xs="8"
            :sm="8"
            :md="8"
            :lg="8"
            :xl="8"
            :xxl="6"
            v-for="(group, index) in groupList"
            :key="index"
          >
            <a-card
              hoverable
              class="card"
              :bodyStyle="{ padding: '20px', borderRadius: '6px' }"
              @click="playDataScreenGroup(group)"
            >
              <div class="title" :title="group.name">{{ group.name }}</div>
              <div class="desc" :title="getNames(group)">{{ getNames(group) }}</div>
              <div class="actions" v-if="editPermission || deletePermission">
                <a v-if="editPermission" class="link" @click.stop="editGroup(group)">编辑</a>
                <a v-if="deletePermission" class="link" @click.stop="deleteHandle(group)">删除</a>
              </div>
            </a-card>
          </a-col>
          <a-col :xs="8" :sm="8" :md="8" :lg="8" :xl="8" :xxl="6" v-if="addPermission">
            <a-card
              hoverable
              class="card create-card"
              :bodyStyle="{ padding: '20px', borderRadius: '6px', height: '100%' }"
              @click="editGroup({})"
            >
              <div class="body">
                <PlusOutlined />
                <span class="text">新建组合播放</span>
              </div>
            </a-card>
          </a-col>
        </a-row>
      </a-spin>
    </div>
  </div>
  <GroupEditModal
    :record="currentEditingGroup"
    @cancel="closeModal(false)"
    @submit="closeModal(true)"
  ></GroupEditModal>
</template>

<style scoped lang="scss">
.page {
  padding: 0;
  background-color: #fff;
  height: 100%;
  display: flex;
  flex-direction: column;
  .header {
    height: 52px;
    padding: 0 16px;
    display: flex;
    align-items: center;
    flex: none;
    border-bottom: 1px solid v-bind('token.colorBorderSecondary');
    .link {
      cursor: pointer;
      &:hover {
        .icon,
        .title {
          color: v-bind('token.colorPrimary');
        }
      }
    }
    .icon {
      color: v-bind('token.colorTextSecondary');
      cursor: pointer;
      margin-right: 8px;
    }
    .title {
      font-size: v-bind('token.fontSize');
      font-weight: bold;
    }
  }

  .body {
    flex: auto;
    overflow: auto;
    padding: 20px;
    position: relative;
    .spin-wrap {
      display: flex;
      justify-content: center;
      position: absolute;
      top: 0;
      left: 0;
      height: 100%;
      width: 100%;
      padding-top: 200px;
      z-index: 1;
    }
    .list-wrap {
      display: flex;
      margin: -10px;
    }
    .card-wrap {
      padding: 10px;
      width: 25%;
    }
    .card {
      height: 148px;
      &.create-card {
        .body {
          height: 100%;
          display: flex;
          align-items: center;
          justify-content: center;
          color: v-bind('token.colorTextSecondary');
          .text {
            margin-left: 8px;
          }
        }
      }
      .title {
        font-size: v-bind('token.fontSize');
        font-weight: bold;
        line-height: 24px;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
      }
      .desc {
        font-size: 12px;
        color: v-bind('token.colorTextSecondary');
        line-height: 20px;
        margin-top: 4px;
        height: 40px;
        overflow: hidden;
        display: -webkit-box;
        -webkit-box-orient: vertical;
        -webkit-line-clamp: 2;
        text-overflow: ellipsis;
      }
      .actions {
        margin-top: 16px;
        .link {
          line-height: 20px;
          color: v-bind('token.colorPrimary');
          margin-right: 20px;
          &:hover {
            color: v-bind('token.colorPrimaryTextHover');
          }
        }
      }
    }
  }
}
</style>
