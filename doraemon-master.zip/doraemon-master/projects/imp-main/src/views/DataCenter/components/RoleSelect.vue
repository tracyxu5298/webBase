<script setup lang="ts">
import { differenceBy, filter } from 'lodash-es';
import { type PropType } from 'vue';
import { ALL_VALUE } from '../utils/helper';

const props = defineProps({
  value: {
    type: Array as PropType<any[] | null | undefined>,
    default: () => [],
  },
  options: {
    type: Array as PropType<any[]>,
    default: () => [],
  },
});
const emit = defineEmits<{
  (e: 'update:value', value: any[]): void;
}>();
const changeHandle = (value: any[]) => {
  const [diff] = differenceBy(value, props.value || [], (item) => item.value);
  if (diff?.value === ALL_VALUE) {
    emit(
      'update:value',
      filter(value, (v) => v?.value === ALL_VALUE),
    );
  } else if (diff?.value !== ALL_VALUE) {
    emit(
      'update:value',
      filter(value, (v) => v?.value !== ALL_VALUE),
    );
  } else {
    emit('update:value', value);
  }
};
</script>
<template>
  <a-select
    :value="value"
    :options="options"
    placeholder="请选择适用角色"
    label-in-value
    mode="multiple"
    allow-clear
    show-arrow
    @update:value="changeHandle"
    :show-search="false"
  ></a-select>
</template>
