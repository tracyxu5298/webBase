<script lang="ts" setup>
import { reactive, type PropType, ref } from 'vue';
import type { DataScreenItem } from '../utils/types';
import { message, type FormInstance } from 'ant-design-vue';
import { republishDataScreen } from '../service';

const props = defineProps({
  record: {
    type: Object as PropType<DataScreenItem | null>,
    default: () => null,
  },
});
const emit = defineEmits<{
  (event: 'cancel'): void;
}>();

const formRef = ref<FormInstance>();
const loading = ref(false);

const formData = reactive({
  organizations: [] as any[],
});

type FormDataType = typeof formData;

const HandleAfterClose = () => {
  formData.organizations = [];
  loading.value = false;
};

const submitHandle = async () => {
  const values: FormDataType = (await formRef.value?.validateFields())! as FormDataType;
  if (!values) {
    return Promise.reject();
  }
  loading.value = true;
  await republishDataScreen({
    locationIds: values.organizations,
    visualId: props.record!.id,
  }).finally(() => (loading.value = false));
  message.success('发布成功');
  emit('cancel');
};
</script>
<template>
  <a-modal
    centered
    :open="!!record"
    title="重新发布"
    @cancel="$emit('cancel')"
    :afterClose="HandleAfterClose"
  >
    <template #footer>
      <a-button key="back" @click="$emit('cancel')">取消</a-button>
      <a-button key="submit" type="primary" :loading="loading" @click="submitHandle">确定</a-button>
    </template>

    <a-form ref="formRef" :model="formData" layout="vertical">
      <a-form-item
        label=""
        name="organizations"
        :rules="[{ required: true, message: '请选择组织' }]"
      >
        <a-select
          v-model:value="formData.organizations"
          mode="multiple"
          placeholder="请选择组织"
          :options="record?.organizations"
          :fieldNames="{ label: 'name', value: 'id' }"
        ></a-select>
      </a-form-item>
    </a-form>
  </a-modal>
</template>
<style lang="scss" scoped></style>
