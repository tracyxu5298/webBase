<script setup lang="ts">
import { reactive, type PropType, ref, watch, computed } from 'vue';
import { type FormInstance, message } from 'ant-design-vue';
import { compact, map } from 'lodash-es';
import { addOrEditDataScreenGroup, getDataScreenCategoriesGroup } from '../service';
import { arrayMaxLengthRule } from '../utils/helper';
import { useLocationId } from '@lexikos/doraemon-business';
import type { SelectProps } from 'ant-design-vue';
import type { DataScreenGroup } from '../utils/types';
import DraggableSelect from './DraggableSelect.vue';

const props = defineProps({
  record: {
    type: Object as PropType<Partial<DataScreenGroup>>,
    default: null,
  },
});

const emit = defineEmits<{
  (e: 'cancel'): void;
  (e: 'submit'): void;
}>();

type FormData = Pick<DataScreenGroup, 'name' | 'rotationTime'> & {
  screenTopics: {
    label: string;
    value: string;
  }[];
};

const locationId = useLocationId();

const initialFormData: FormData = {
  name: null,
  rotationTime: null,
  screenTopics: [],
} as any;

const formData = reactive(initialFormData);

const formRef = ref<FormInstance>();

const screenTopicsRef = ref();

const loading = ref(false);

const title = computed(() => (props.record?.id ? '编辑' : '新增') + '组合播放');

const screenTopicsOptions = ref<SelectProps['options']>([]);

const rotationTimeOptions = [
  { label: '手动切换', value: 0 },
  { label: '5S自动切换', value: 5 },
  { label: '10S自动切换', value: 10 },
  { label: '15S自动切换', value: 15 },
  { label: '20S自动切换', value: 20 },
  { label: '30S自动切换', value: 30 },
  { label: '45S自动切换', value: 45 },
  { label: '60S自动切换', value: 60 },
];

const handleAfterClose = () => {
  loading.value = false;
  formData.name = null as any;
  formData.rotationTime = null as any;
  formData.screenTopics = [];
};

watch(
  () => props.record,
  (val) => {
    if (!val) {
      return;
    }
    if (!screenTopicsOptions.value?.length) {
      getDataScreenCategoriesGroup().then((res) => {
        screenTopicsOptions.value = compact(
          map(res, (g: any) => {
            if (!g.visualEntities?.length) {
              return null;
            }
            return {
              label: g.categoryName,
              options: map(g.visualEntities, (s) => {
                return {
                  label: s.title,
                  value: s.id,
                };
              }),
            };
          }),
        );
      });
    }
    formData.name = val.name!;
    formData.rotationTime = val.rotationTime!;
    formData.screenTopics = map(val.screenTopics, (s) => ({
      label: s.title,
      value: s.bladeVisualId,
    }));
  },
);

const submitHandle = async () => {
  const values: FormData = (await formRef.value?.validateFields()) as any;
  if (!values) {
    return Promise.reject();
  }
  loading.value = true;
  const data: Partial<DataScreenGroup> = {
    ...values,
    screenTopics: map(values.screenTopics, (s) => ({
      bladeVisualId: s.value,
      title: s.label,
    })),
  };
  if (props.record?.id) {
    data.id = props.record.id;
    data.locationId = props.record.locationId;
  } else {
    data.locationId = locationId.value as string;
  }
  await addOrEditDataScreenGroup(data).finally(() => (loading.value = false));
  message.success('操作成功');
  emit('submit');
};
</script>
<template>
  <a-modal
    centered
    destroyOnClose
    :maskClosable="false"
    :open="!!record"
    @cancel="$emit('cancel')"
    :title="title"
    :afterClose="handleAfterClose"
    :width="600"
  >
    <template #footer>
      <a-button key="back" @click="$emit('cancel')">取消</a-button>
      <a-button key="submit" type="primary" :loading="loading" @click="submitHandle">确定</a-button>
    </template>
    <div class="form-wrap">
      <a-form ref="formRef" :model="formData">
        <a-form-item
          label="组合名称"
          name="name"
          :rules="[{ required: true, message: '请输入大屏名称' }]"
        >
          <a-input v-model:value="formData.name" :maxlength="30" autocomplete="off"></a-input>
        </a-form-item>
        <a-form-item
          label="选择主题"
          name="screenTopics"
          :rules="[
            { required: true, message: '请选择主题' },
            arrayMaxLengthRule(15, (n) => `大屏组合已超出${n}个限制。`),
          ]"
          class="form-item-topics"
          ref="screenTopicsRef"
        >
          <DraggableSelect
            v-model:value="formData.screenTopics"
            :options="screenTopicsOptions"
            max-tag-count="responsive"
            allowClear
            @change="
              () => {
                screenTopicsRef?.onFieldChange();
              }
            "
          ></DraggableSelect>
        </a-form-item>
        <a-form-item
          label="轮播时间"
          name="rotationTime"
          :rules="[{ required: true, message: '请选择轮播时间' }]"
        >
          <a-select
            v-model:value="formData.rotationTime"
            :options="rotationTimeOptions"
            allowClear
          ></a-select>
        </a-form-item>
      </a-form>
    </div>
  </a-modal>
</template>
<style scoped lang="scss">
.form-wrap {
  max-height: calc(100vh - 200px);
  overflow: auto;
  margin-top: 20px;
  .form-item-topics {
    margin-bottom: 0;
    :deep([role='alert']) {
      position: absolute;
      top: 32px;
    }
  }
}
</style>
