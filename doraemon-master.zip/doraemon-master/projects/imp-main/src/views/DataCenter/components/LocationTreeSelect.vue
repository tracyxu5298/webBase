<script setup lang="ts">
import { type PropType } from 'vue';
import { TreeSelect } from 'ant-design-vue';

defineProps({
  value: {
    type: Array as PropType<any[] | null | undefined>,
    default: () => [],
  },
  treeData: {
    type: Array as PropType<any[]>,
    default: () => [],
  },
});
defineEmits<{
  (e: 'update:value', value: any[]): void;
}>();
</script>
<template>
  <a-tree-select
    tree-default-expand-all
    :value="value"
    @update:value="$emit('update:value', $event)"
    :tree-data="treeData"
    tree-checkable
    show-arrow
    allow-clear
    placeholder="请选择定向组织"
    tree-node-filter-prop="name"
    treeCheckStrictly
    :showCheckedStrategy="TreeSelect.SHOW_ALL"
    virtual
    :fieldNames="{ children: 'childs', label: 'name', value: 'id' }"
  ></a-tree-select>
</template>
