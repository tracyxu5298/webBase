<script setup lang="ts">
import { reactive, type PropType, ref, watch } from 'vue';
import { type FormInstance, message } from 'ant-design-vue';
import { map } from 'lodash-es';
import { YesOrNo, type DataScreenItem, type LabelValue } from '../utils/types';
import { getLocationRoles, updateImpDataScreen } from '../service';
import { ALL_VALUE, arrayMaxLengthRule } from '../utils/helper';
import RoleSelect from './RoleSelect.vue';

const props = defineProps({
  record: {
    type: Object as PropType<DataScreenItem | null>,
    default: null,
  },
});

const emit = defineEmits<{
  (e: 'cancel'): void;
  (e: 'submit'): void;
}>();

const formData = reactive({
  name: '',
  roles: [],
  // users: [],
} as Partial<
  Pick<DataScreenItem, 'name'> & {
    roles: LabelValue[];
    // users: NameId[];
  }
>);

type FormDataType = typeof formData;

const formRef = ref<FormInstance>();

const loading = ref(false);

const roleList = ref<any[]>([]);

watch(
  () => props.record,
  (val) => {
    if (!val) {
      formData.name = '';
      formData.roles = [];
      return;
    }
    formData.name = val.name;
    formData.roles = val.allVisible
      ? [{ label: '全员', value: ALL_VALUE }]
      : map(val.roles, (o) => ({ label: o.name, value: o.id }));
    if (!roleList.value?.length) {
      getLocationRoles().then((res) => (roleList.value = res));
    }
  },
);

const submitHandle = async () => {
  const values: FormDataType = (await formRef.value?.validateFields())!;
  if (!values) {
    return Promise.reject();
  }
  loading.value = true;
  const isAll = values.roles?.[0].value === ALL_VALUE;
  const params: Partial<DataScreenItem> = {
    name: values.name,
    roles: isAll
      ? []
      : map(values.roles, (o) => ({
          name: o.label,
          id: o.value,
        })),
    allVisible: isAll ? YesOrNo.Yes : YesOrNo.No,
  };
  await updateImpDataScreen(props.record!.id, params).finally(() => (loading.value = false));
  message.success('操作成功');
  emit('submit');
};
</script>
<template>
  <a-modal
    centered
    destroyOnClose
    :maskClosable="false"
    :open="!!record"
    @cancel="$emit('cancel')"
    title="配置"
  >
    <template #footer>
      <a-button key="back" @click="$emit('cancel')">取消</a-button>
      <a-button key="submit" type="primary" :loading="loading" @click="submitHandle">确定</a-button>
    </template>

    <a-form ref="formRef" :model="formData" class="form-wrap">
      <a-form-item
        label="大屏名称"
        name="name"
        :rules="[{ required: true, message: '请输入大屏名称' }]"
      >
        <a-input v-model:value="formData.name" :maxlength="20"></a-input>
      </a-form-item>
      <a-form-item
        label="适用角色"
        name="roles"
        :rules="[{ required: true, message: '请至少选择1个角色' }, arrayMaxLengthRule(50)]"
      >
        <RoleSelect v-model:value="formData.roles" :options="roleList"></RoleSelect>
      </a-form-item>
    </a-form>
  </a-modal>
</template>
<style scoped lang="scss">
.form-wrap {
  margin-top: 20px;
}
</style>
