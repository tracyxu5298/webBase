<script setup lang="ts">
import { reactive, type PropType, ref, watch, computed } from 'vue';
import { type FormInstance, message, theme } from 'ant-design-vue';
import { map } from 'lodash-es';
import { CfgType, DataScreenStatus, YesOrNo } from '../utils/types';
import type { DataScreenItem, NameId, LabelValue, NameCode } from '../utils/types';
import {
  getDataScreenCategories,
  updateDataScreen,
  getLocationTree,
  getRoles,
  addManualDataScreen,
} from '../service';
import { ALL_VALUE, STATUS_OPTIONS, arrayMaxLengthRule } from '../utils/helper';
import LocationTreeSelect from './LocationTreeSelect.vue';
import RoleSelect from './RoleSelect.vue';
import { Upload } from '@lexikos/doraemon-business';

const props = defineProps({
  record: {
    type: Object as PropType<DataScreenItem | null>,
    default: null,
  },
});

const emit = defineEmits<{
  (e: 'cancel'): void;
  (e: 'submit'): void;
}>();

const { token } = theme.useToken();

const formData = reactive({
  name: '',
  bizCode: '',
  category: null,
  status: DataScreenStatus.Inactive,
  roles: [],
  organizationIds: [],
} as Partial<
  Pick<DataScreenItem, 'name' | 'status' | 'viewUrl' | 'thumbnailId' | 'bizCode'> & {
    roles: LabelValue[];
    organizations: LabelValue[] | null;
    category: LabelValue | null;
  }
>);

type FormDataType = typeof formData;

const formRef = ref<FormInstance>();

const loading = ref(false);

const categoryList = ref<NameCode[]>([]);
const locationTree = ref<NameId[]>([]);
const roleList = ref<any[]>([]);

const isManual = computed(() => props.record?.cfgType === CfgType.Manual);
const isAdd = computed(() => !props.record?.id);
const title = computed(() => (isAdd.value ? '新建' : '配置') + (isManual.value ? '手工大屏' : ''));

const fileList = ref<any[]>([]);

const onAfterUpload = (data: any) => {
  formData.thumbnailId = data.fileId;
  formRef.value?.validateFields('thumbnailId');
};

const onCustomRemove = () => {
  formData.thumbnailId = '';
  formRef.value?.validateFields('thumbnailId');
  return true;
};

watch(
  () => props.record,
  (val) => {
    if (!val) {
      formData.name = '';
      formData.category = null;
      formData.bizCode = '';
      formData.status = DataScreenStatus.Inactive;
      formData.roles = [];
      formData.organizations = [];
      formData.thumbnailId = '';
      formData.viewUrl = '';
      fileList.value = [];
      return;
    }
    formData.name = val.name;
    formData.bizCode = val.bizCode;
    formData.category = { value: val.categoryCode, label: val.categoryName };
    formData.status = val.status;
    formData.thumbnailId = val.thumbnailId;
    formData.viewUrl = val.viewUrl;
    formData.roles = val.allVisible
      ? [{ label: '全员', value: ALL_VALUE }]
      : map(val.roles, (o) => ({ label: o.name, value: o.id }));

    formData.organizations = map(val.organizations, (r) => ({ label: r.name, value: r.id }));
    if (!categoryList.value?.length) {
      getDataScreenCategories().then((res) => (categoryList.value = res));
    }
    if (!locationTree.value?.length) {
      getLocationTree().then((res) => (locationTree.value = res));
    }
    if (!roleList.value?.length) {
      getRoles().then((res) => {
        roleList.value = res;
      });
    }
    if (val.thumbnail) {
      fileList.value = [val.thumbnail];
    }
  },
);

const submitHandle = async () => {
  const values: FormDataType = (await formRef.value?.validateFields())!;
  if (!values) {
    return Promise.reject();
  }
  loading.value = true;
  const isAll = values.roles?.[0].value === ALL_VALUE;
  const params: Partial<DataScreenItem> = {
    name: values.name,
    bizCode: values.bizCode,
    categoryCode: values.category?.value,
    categoryName: values.category?.label,
    status: values.status,
    organizations: map(values.organizations, (r) => ({
      name: r.label,
      id: r.value,
    })),
    roles: isAll
      ? []
      : map(values.roles, (o) => ({
          name: o.label,
          id: o.value,
        })),
    allVisible: isAll ? YesOrNo.Yes : YesOrNo.No,
  };
  if (isManual.value) {
    params.viewUrl = values.viewUrl;
    params.thumbnailId = values.thumbnailId;
  }
  if (isAdd.value && isManual.value) {
    await addManualDataScreen(params).finally(() => (loading.value = false));
  } else {
    await updateDataScreen(props.record!.id, params!).finally(() => (loading.value = false));
  }
  message.success('操作成功');
  emit('submit');
};
</script>
<template>
  <a-modal
    centered
    destroyOnClose
    :maskClosable="false"
    :open="!!record"
    @cancel="$emit('cancel')"
    :title="title"
  >
    <template #footer>
      <a-button key="back" @click="$emit('cancel')">取消</a-button>
      <a-button key="submit" type="primary" :loading="loading" @click="submitHandle">确定</a-button>
    </template>
    <div class="form-wrap">
      <a-form ref="formRef" :model="formData">
        <a-form-item
          label="大屏名称"
          name="name"
          :rules="[{ required: true, message: '请输入大屏名称' }]"
        >
          <a-input v-model:value="formData.name" :maxlength="20"></a-input>
        </a-form-item>
        <a-form-item
          label="大屏编码"
          name="bizCode"
          :rules="[
            { required: true, message: '请输入大屏编码' },
            {
              pattern: /^[a-zA-Z0-9_]*$/,
              message: '只允许输入大小写字母、数字、下划线',
            },
          ]"
        >
          <a-input
            :disabled="!(isAdd && isManual)"
            v-model:value="formData.bizCode"
            :maxlength="30"
          ></a-input>
        </a-form-item>
        <a-form-item
          v-if="isManual"
          label="大屏地址"
          name="viewUrl"
          :rules="[{ required: true, message: '请输入大屏地址' }]"
        >
          <a-input v-model:value="formData.viewUrl" :maxlength="80"></a-input>
        </a-form-item>
        <a-form-item
          v-if="isManual"
          label="大屏缩略图"
          name="thumbnailId"
          :rules="[{ required: true, message: '请选择大屏缩略图' }]"
        >
          <Upload
            accept=".jpg, .png, .svg"
            :fileList="fileList"
            :maxCount="1"
            listType="picture-card"
            :maxSize="2048"
            :onCustomRemove="onCustomRemove"
            @onAfterUpload="onAfterUpload"
          />
          <div class="tip">只支持jpg、png、svg，缩略图像素为400*220，文件大小不超过2M</div>
        </a-form-item>
        <a-form-item
          label="大屏分类"
          name="category"
          :rules="[{ required: true, message: '请选择大屏分类' }]"
        >
          <a-select
            v-model:value="formData.category as any"
            :options="categoryList"
            label-in-value
            :field-names="{ label: 'name', value: 'code' }"
            allow-clear
          ></a-select>
        </a-form-item>
        <a-form-item
          label="适用角色"
          name="roles"
          :rules="[{ required: true, message: '请至少选择1个角色' }, arrayMaxLengthRule(50)]"
        >
          <RoleSelect v-model:value="formData.roles" :options="roleList"></RoleSelect>
        </a-form-item>
        <a-form-item label="定向组织" name="organizations" :rules="[arrayMaxLengthRule(50)]">
          <LocationTreeSelect
            v-model:value="formData.organizations"
            :tree-data="locationTree"
          ></LocationTreeSelect>
        </a-form-item>
        <a-form-item
          label="状态"
          name="status"
          :rules="[{ required: true, message: '请选择状态' }]"
        >
          <a-radio-group v-model:value="formData.status" :options="STATUS_OPTIONS" />
        </a-form-item>
      </a-form>
    </div>
  </a-modal>
</template>
<style scoped lang="scss">
.form-wrap {
  max-height: calc(100vh - 200px);
  overflow: auto;
  margin-top: 20px;
}
.tip {
  color: v-bind('token.colorTextSecondary');
}
</style>
