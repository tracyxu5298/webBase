<script lang="ts" setup>
import { nextTick, ref, watch, type PropType } from 'vue';
import type { DataScreenItem } from '../utils/types';
import { useTimer } from '../hooks/useTimer';
import { debounce, findIndex, map, sum } from 'lodash-es';
import { onBeforeUnmount } from 'vue';

const props = defineProps({
  list: {
    type: Array as PropType<DataScreenItem[]>,
    default: () => [],
  },
  currentKey: {
    type: String,
    default: '',
  },
  intervalMs: {
    type: Number,
    default: 0,
  },
});

const emit = defineEmits<{
  (e: 'change', key: string): void;
}>();

const open = ref(false);
const toggle = () => {
  open.value = !open.value;
  if (open.value) {
    stop();
  } else {
    start();
  }
};

const startIfClosed = () => {
  if (!open.value) {
    start();
  } else {
    stop();
  }
};

const setCurrentKey = (key: string) => {
  emit('change', key);
  startIfClosed();
};

const next = () => {
  let nextIndex = findIndex(props.list, (item) => item.id === props.currentKey) + 1;
  if (nextIndex > props.list.length - 1) {
    nextIndex = 0;
  }
  setCurrentKey(props.list[nextIndex]?.id || '');
};

const prev = () => {
  let nextIndex = findIndex(props.list, (item) => item.id === props.currentKey) - 1;
  if (nextIndex < 0) {
    nextIndex = props.list.length - 1;
  }
  setCurrentKey(props.list[nextIndex]?.id || '');
};

const { start, stop, setIntervalMs } = useTimer(next);

const needScroll = ref(false);
const wrapRef = ref<HTMLDivElement>();
const listRef = ref<HTMLDivElement>();
const itemRef = ref<HTMLDivElement[]>();
const offset = ref(0);
const updateWidth = () => {
  const wrapWidth = wrapRef.value?.clientWidth || 0;
  const listWidth = sum(map(itemRef.value, (el) => el.clientWidth + 16)) - 16;
  if (wrapWidth && listWidth && listWidth > wrapWidth - 40) {
    needScroll.value = true;
    setOffset(offset.value);
  } else {
    setOffset(0);
    needScroll.value = false;
  }
};
const debouncedUpdateWidth = debounce(updateWidth, 500);
const setOffset = (val: number) => {
  if (val <= 0) {
    offset.value = 0;
    return;
  }
  const wrapWidth = listRef.value?.clientWidth || 0;
  const listWidth = sum(map(itemRef.value, (el) => el.clientWidth + 16)) - 16;
  if (val > listWidth - wrapWidth) {
    offset.value = listWidth - wrapWidth;
  } else {
    offset.value = val;
  }
};
const scrollRight = () => {
  if (!listRef.value) {
    return;
  }
  setOffset(offset.value + 100);
};
const scrollLeft = () => {
  if (!listRef.value) {
    return;
  }
  setOffset(offset.value - 100);
};

watch(
  () => props.intervalMs,
  () => {
    setIntervalMs(props.intervalMs);
    startIfClosed();
  },
);

watch(
  () => props.list,
  async () => {
    await nextTick();
    updateWidth();
  },
);

window.addEventListener('resize', debouncedUpdateWidth);

onBeforeUnmount(() => {
  window.removeEventListener('resize', debouncedUpdateWidth);
});

defineExpose({
  next: () => {
    next();
    if (!open.value) {
      start();
    }
  },
  prev: () => {
    prev();
    if (!open.value) {
      start();
    }
  },
});
</script>
<template>
  <div ref="wrapRef" :class="[['tab-wrap'], { open, needScroll }]">
    <div class="btn btn-left" v-if="needScroll" @click="scrollLeft"></div>
    <div ref="listRef" class="nav-wrap">
      <div class="nav-list" :style="{ transform: `translateX(${-offset}px)` }">
        <div
          v-for="item in list"
          :key="item.id"
          :class="['nav-item', { active: item.id === currentKey }]"
          @click="setCurrentKey(item.id)"
          ref="itemRef"
        >
          <span class="placeholder">{{ item.name }}</span>
          <div class="title">
            <span>{{ item.name }}</span>
          </div>
        </div>
      </div>
    </div>
    <div class="btn btn-right" v-if="needScroll" @click="scrollRight"></div>
    <div class="toggle" @click="toggle()"></div>
  </div>
</template>
<style lang="scss" scoped>
.tab-wrap {
  height: 66px;
  background-color: #0e151f;
  position: fixed;
  bottom: -66px;
  left: 0;
  width: 100vw;
  display: flex;
  align-items: center;
  user-select: none;
  transform: translateY(0);
  transition: transform 0.3s ease-out;
  &.open {
    transform: translateY(-66px);
  }
  &::before {
    content: ' ';
    display: block;
    width: 100%;
    height: 1px;
    position: absolute;
    top: 0;
    left: 0;
    background: linear-gradient(
      to right,
      #0295ff00 5%,
      #0295ff 40%,
      #88caff 50%,
      #0295ff 60%,
      #0295ff00 95%
    );
  }
}
.nav-wrap {
  display: flex;
  justify-content: center;
  overflow: hidden;
  flex: auto;
  width: 1px;
  .nav-list {
    display: flex;
    align-items: center;
    transition: all 0.3s ease-out;
  }
}
.nav-item {
  height: 40px;
  display: flex;
  align-items: center;
  padding: 0 4px;
  flex: none;
  font-size: 16px;
  font-weight: bold;
  margin-right: 16px;
  cursor: pointer;
  background: url(../../../assets/images/DataCenter/nav_bg.svg) no-repeat bottom;
  transition: all 0.1s ease-out;
  position: relative;
  .placeholder {
    visibility: hidden;
  }
  &.active {
    background-image: url(../../../assets/images/DataCenter/nav_bg_active.svg);
    font-size: 16px;
    font-weight: bold;
    color: #fff;
    .title {
      font-size: 16px;
    }
  }
  &:last-child {
    margin-right: 0;
  }
  .title {
    transition: all 0.1s ease-out;
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 14px;
  }
}
.toggle {
  width: 68px;
  height: 24px;
  position: absolute;
  top: -24px;
  left: 50%;
  margin-left: -34px;
  cursor: pointer;
  background: url(../../../assets/images/DataCenter/toggle_up.svg);
  opacity: 0.8;
  transition: opacity 0.1s ease-out;
  &:hover {
    opacity: 1;
  }
  .open & {
    background: url(../../../assets/images/DataCenter/toggle_down.svg);
  }
}
.btn {
  width: 40px;
  height: 40px;
  background-color: #88caff;
  flex: none;
  cursor: pointer;
  opacity: 0.8;
  transition: opacity 0.1s ease-out;
  &:hover {
    opacity: 1;
  }
  &-left {
    margin-left: 24px;
    margin-right: 10px;
    background: url(../../../assets/images/DataCenter/btn_left.svg);
  }
  &-right {
    margin-right: 24px;
    margin-left: 10px;
    background: url(../../../assets/images/DataCenter/btn_right.svg);
  }
}
</style>
