<script setup lang="ts">
import type { SelectProps } from 'ant-design-vue';
import { theme } from 'ant-design-vue';
import { ref, type PropType } from 'vue';
import Draggable from 'vuedraggable';
import { DragOutlined, CloseCircleFilled } from '@ant-design/icons-vue';
import { filter } from 'lodash-es';

const props = defineProps({
  options: {
    type: Array as PropType<SelectProps['options']>,
    default: () => [],
  },
  value: {
    type: Array as PropType<any[]>,
    default: () => [],
  },
  allowClear: {
    type: Boolean,
    default: false,
  },
  maxTagCount: {
    type: [Number, String],
  },
});

const emit = defineEmits<{
  (e: 'update:value', value: any): void;
  (e: 'change', value: any): void;
}>();

const { token } = theme.useToken();

const dragOptions = ref({
  animation: 300,
  group: 'description',
  disabled: false,
  ghostClass: 'ghost',
  chosenClass: 'chosen',
});

const deleteHandle = (element: any) => {
  const val = filter(props.value, (item) => item?.value !== element?.value);
  emit('update:value', val);
  emit('change', val);
};
</script>
<template>
  <div class="wrap">
    <a-select
      v-bind="props"
      mode="multiple"
      labelInValue
      @update:value="$emit('update:value', $event)"
    ></a-select>
    <Draggable
      class="drag-list"
      :modelValue="value"
      @update:modelValue="$emit('update:value', $event)"
      v-bind="dragOptions"
      item-key="value"
    >
      <template #item="{ element }">
        <div class="drag-item">
          <DragOutlined class="drag-handle" />
          <span class="label" :title="element.label">{{ element.label }}</span>
          <div
            class="close-icon"
            @click.stop="deleteHandle(element)"
            @dragstart.stop.prevent
            @mousedown.stop.prevent
          >
            <CloseCircleFilled />
          </div>
        </div>
      </template>
    </Draggable>
  </div>
</template>
<style scoped lang="scss">
.drag-list {
  margin-top: 4px;
  margin-bottom: 24px;
}
.drag-handle {
  margin-right: 4px;
  flex: none;
}
.drag-item {
  display: flex;
  align-items: center;
  padding: 2px;
  cursor: move;
  border-radius: 6px;
  &:hover {
    background-color: #f7f7fa;
  }
  .label {
    flex: auto;
    width: 1px;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }
  .close-icon {
    flex: none;
    color: v-bind('token.colorTextQuaternary');
    cursor: pointer;
    height: 20px;
    width: 20px;
    &:hover {
      color: v-bind('token.colorTextSecondary');
    }
  }
}
.form-wrap {
  max-height: calc(100vh - 200px);
  overflow: auto;
}
.flip-list-move {
  transition: transform 0.5s;
}
.no-move {
  transition: transform 0s;
}
.ghost {
  opacity: 0;
}
.wrap {
  :deep {
    .antv-select.antv-select-status-error + .drag-list {
      margin-top: 24px;
    }
  }
}
</style>
