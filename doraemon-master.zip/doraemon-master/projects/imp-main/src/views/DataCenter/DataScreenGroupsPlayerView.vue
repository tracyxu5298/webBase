<script setup lang="ts">
import { ref, watch, unref, computed } from 'vue';
import { useRoute } from 'vue-router';
import { split, includes, merge, filter } from 'lodash-es';
import { useOldUrl, useConfigStore } from '@lexikos/doraemon-business';
import { getDataScreenGroupDetail } from './service';
import type { DataScreenItem } from './utils/types';
import PlayerTabs from './components/PlayerTabs.vue';
import { getDataScreenPageSrc } from './utils/helper';
// import { RightOutlined, LeftOutlined } from '@ant-design/icons-vue';
import Right from '@/assets/images/DataCenter/right.svg';

const oldAppPrefixValues = [
  'access-management',
  'ai-monitor',
  'ai-monitor-bureau',
  'ai-prevent-bullying',
  'analysis-of-learning-situation',
  'approval-center-bureau',
  'archives',
  'asset-management',
  'basic-school-management',
  'behavior-security-large-screen',
  'boss',
  'broadcasting-management',
  'canteen-management',
  'civilized-clazz',
  'class-appraisal',
  'class-tour-evaluation',
  'class-tour-evaluation-bureau',
  'classroom-on-cloud',
  'classroom-on-cloud-bureau',
  'configuration-center',
  'consumable-management',
  'consumption-management',
  'contingency-manage',
  'corner-analysis',
  'daily-health',
  'data-overview-new',
  'digital-sport',
  'disease-management',
  'disinfection-management',
  'disinfection-serilization-management',
  'dormitory-attendance',
  'electrical-safety',
  'electronic-file',
  'electronic-student-identity-card',
  'employee-attendance',
  'energy-consumption-screen',
  'energy-management',
  'environmental-monitoring',
  'excellent-resources',
  'eye-exercises',
  'fire-safety',
  'free-login',
  'growth-evaluation',
  'growth-portfolio',
  'health-collect-bureau',
  'health-vision',
  'hidden-danger-check',
  'home-school-notice',
  'information-delivery',
  'instrument-management',
  'intelligent-inspection',
  'intelligent-retrieval',
  'intelligent-retrieval-bureau',
  'iot-cockpit-screen',
  'iot-management',
  'lead-the-cockpit',
  'load-forecasting',
  'low-carbon-energy-saving',
  'medication-regist',
  'mental-health',
  'observation-record',
  'office-document-management',
  'office-document-management-bureau',
  'overview-health',
  'patrol-management',
  'physical-examination',
  'physique-health',
  'physique-health-bureau',
  'platform',
  'practical-management-screen',
  'preprimary-education-board',
  'recording-broadcasting',
  'repair-order-center',
  'resource-management',
  'return-process',
  'safety-board',
  'safety-education',
  'safety-education-bureau',
  'safety-task',
  'safety-task-bureau',
  'school-bus-travel',
  'school-over-transfer',
  'security-administration',
  'security-log',
  'security-steward',
  'site-reservation',
  'smart-class',
  'smart-digital',
  'smart-sport',
  'smart-sports',
  'student-attendance',
  'student-evaluation',
  'student-for-leave',
  'study-platform',
  'teaching-research-online',
  'teaching-research-online-bureau',
  'time-collection',
  'training-management',
  'vehicle-control',
  'venue',
  'venue-bureau',
  'video-monitoring',
  'video-monitoring-bureau',
  'vision-screening',
  'vision-training',
  'visitor-appointment',
  'visitor-appointment-bureau',
  'weekly-plan',
  'wisdom-recorded',
  'work-rest-management',
  'workforce-management',
];

const oldClassify2AppCode: Record<string, string> = {
  platform: 'platform',
  'configuration-center': 'config',
  'smart-digital': 'digital',
  'iot-management': 'digital',
  'intelligent-inspection': 'digital',
  archives: 'digital',
  'data-overview-new': 'digital',
  'energy-consumption-screen': 'digital',
  'iot-cockpit-screen': 'digital',
  'smart-class': 'digital',
  'lead-the-cockpit': 'digital',
  'repair-order-center': 'digital',
  'approval-center-bureau': 'digital',
  'home-school-notice': 'digital',
  'growth-evaluation': 'digital',
  'canteen-management': 'digital',
  'work-rest-management': 'digital',
  'instrument-management': 'digital',
  'office-document-management-bureau': 'digital',
  'office-document-management': 'digital',
  'workforce-management': 'digital',
  'broadcasting-management': 'digital',
  'student-evaluation': 'digital',
  'asset-management': 'digital',
  'consumable-management': 'digital',
  'practical-management-screen': 'digital',
  'preprimary-education-board': 'digital',
  'safety-board': 'sas',
  'intelligent-retrieval': 'sas',
  'intelligent-retrieval-bureau': 'sas',
  'safety-education-bureau': 'sas',
  'visitor-appointment-bureau': 'sas',
  'ai-monitor': 'sas',
  'ai-monitor-bureau': 'sas',
  'ai-prevent-bullying': 'sas',
  'access-management': 'sas',
  'hidden-danger-check': 'sas',
  'vehicle-control': 'sas',
  'return-process': 'sas',
  'fire-safety': 'sas',
  'behavior-security-large-screen': 'sas',
  venue: 'sas',
  'venue-bureau': 'sas',
  'dormitory-attendance': 'sas',
  'video-monitoring': 'sas',
  'video-monitoring-bureau': 'sas',
  'student-for-leave': 'sas',
  'consumption-management': 'sas',
  'safety-task': 'sas',
  'safety-task-bureau': 'sas',
  'site-reservation': 'sas',
  'school-bus-travel': 'sas',
  'electrical-safety': 'energy',
  'patrol-management': 'sas',
  'disinfection-serilization-management': 'sas',
  'disinfection-management': 'digital',
  'wisdom-recorded': 'sas',
  'student-attendance': 'sas',
  'security-log': 'sas',
  'employee-attendance': 'sas',
  'electronic-student-identity-card': 'sas',
  'visitor-appointment': 'sas',
  'contingency-manage': 'sas',
  'safety-education': 'sas',
  'school-over-transfer': 'sas',
  'security-administration': 'sas',
  'energy-management': 'energy',
  'low-carbon-energy-saving': 'energy',
  'load-forecasting': 'energy',
  'overview-health': 'health',
  'electronic-file': 'health',
  'environmental-monitoring': 'health',
};
const route = useRoute();
const partUrl = useOldUrl(import.meta.env);
const list = ref<DataScreenItem[]>([]);
const intervalMs = ref(0);
const currentKey = ref('');
const playerTabsRef = ref();

const configStore = useConfigStore();

const lowcode = computed(() => {
  return unref(configStore.data)?.lowcode;
});

const prev = () => {
  playerTabsRef.value?.prev();
};

const next = () => {
  playerTabsRef.value?.next();
};

const getDataScreenPageURL = (record: DataScreenItem) => {
  let url = record.viewUrl || '';
  const [firstPathPrefix] = filter(split(url, '/'), Boolean);
  if (includes(oldAppPrefixValues, firstPathPrefix) && firstPathPrefix) {
    url = `${partUrl.value}/${oldClassify2AppCode[firstPathPrefix]}/${firstPathPrefix}/?token={TOKEN}`;
  }
  const iframeUrl = getDataScreenPageSrc(lowcode.value!, merge(record, { viewUrl: url }));
  return iframeUrl;
};

watch(
  () => route.params.id,
  (val: any) => {
    getDataScreenGroupDetail(val).then((res) => {
      list.value = res.screenConcretes;
      currentKey.value = list.value[0]?.id;
      intervalMs.value = (res.rotationTime || 0) * 1000;
    });
  },
  {
    immediate: true,
  },
);
</script>

<template>
  <div class="page-wrap">
    <div class="iframe-wrap" v-if="lowcode">
      <iframe
        :class="[
          'iframe',
          {
            active: currentKey === item.id,
          },
        ]"
        v-for="item in list"
        :key="item.id"
        :src="getDataScreenPageURL(item)"
      ></iframe>
    </div>
    <template v-if="list.length > 1">
      <div class="btn btn-prev" @click="prev">
        <Right class="icon-left"></Right>
      </div>
      <div class="btn btn-next" @click="next">
        <Right></Right>
      </div>
    </template>
    <PlayerTabs
      ref="playerTabsRef"
      :list="list"
      :interval-ms="intervalMs"
      :current-key="currentKey"
      @change="currentKey = $event"
    ></PlayerTabs>
  </div>
</template>

<style scoped lang="scss">
.page-wrap {
  width: 100vw;
  height: 100vh;
  background-color: #0e151f;
  color: #bcd2f4;
  overflow: hidden;
}
.iframe-wrap {
  width: 100%;
  height: 100%;
  position: relative;
  .iframe {
    width: 100%;
    height: 100%;
    position: absolute;
    border: 0;
    top: 0;
    left: 0;
    // display: none;
    opacity: 0;
    pointer-events: none;
    transition: opacity 0.3s;
    &.active {
      // display: block;
      opacity: 1;
      pointer-events: all;
    }
  }
}
.btn {
  width: 40px;
  height: 40px;
  border-radius: 50%;
  background: #0000003d;
  position: fixed;
  top: 50%;
  margin-top: -20px;
  cursor: pointer;
  font-size: 14px;
  color: #fff;
  display: flex;
  align-items: center;
  justify-content: center;
  opacity: 0.5;
  transition: opacity 0.1s ease-out;

  &:hover {
    opacity: 1;
  }
  &.btn-prev {
    left: 12px;
  }
  &.btn-next {
    right: 12px;
  }
  .icon-left {
    transform: rotate(180deg);
  }
}
</style>
