<script setup lang="ts">
import { h, reactive, ref } from 'vue';
import { PlusOutlined, EllipsisOutlined, ExclamationCircleOutlined } from '@ant-design/icons-vue';
import { theme, message } from 'ant-design-vue';
import { debounce, map, merge, pick } from 'lodash-es';
import { CfgType, DataScreenStatus, YesOrNo } from './utils/types';
import type { DataScreenItem, PageData } from './utils/types';
import { deleteDataScreen, getDataScreenList, updateDataScreen } from './service';
import ConfigModal from './components/ConfigModal.vue';
import RepublishModal from './components/RepublishModal.vue';
import { confirm } from './utils/helper';
import { openNewWindow, useConfigStore } from '@lexikos/doraemon-business';
import { unref } from 'vue';

const { token } = theme.useToken();
const loading = ref<boolean>(false);
const list = ref<DataScreenItem[]>([]);
const previewImageUrl = ref<string>('');
const statusChanging = ref<string | null>(null);
const configRecord = ref<DataScreenItem | null>(null);
const republishRecord = ref<DataScreenItem | null>(null);
const configStore = useConfigStore();

const pageData = reactive<PageData>({
  pageNum: 1,
  pageSize: 16,
  total: 0,
});

/** 查询参数 */
const searchParams = reactive({
  keyword: '',
});

/** 拼接角色名称 */
const getRoleNames = (record: DataScreenItem) => {
  if (record.allVisible === YesOrNo.Yes) {
    return '全员';
  }
  return (record.roles || []).map((i) => i.name).join('，') || '/';
};

/** 拼接组织名称 */
const getOrganizationNames = (record: DataScreenItem) => {
  return (record.organizations || []).map((i) => i.name).join('，') || '/';
};

const searchId = ref(0);

/** 执行查询 */
const search = debounce(
  async (pageNum?: number) => {
    const currentSearchId = ++searchId.value;
    loading.value = true;
    const res = await getDataScreenList(searchParams, {
      ...pageData,
      pageNum: pageNum ?? pageData.pageNum,
    }).finally(() => {
      if (currentSearchId === searchId.value) {
        loading.value = false;
      }
    });
    if (currentSearchId !== searchId.value) {
      return;
    }
    merge(pageData, {
      total: res.total,
      pageNum: res.pageNum,
    });
    list.value = res.result;
  },
  500,
  {
    leading: true,
  },
);

/** 更新页码数据并执行查询 */
const updatePagination = async (changes: Partial<PageData>) => {
  merge(pageData, changes);
  await search();
};

/** 导航到大屏页面，带上token */
const navigateToDataScreenPage = (path: string, params: Record<string, any> = {}) => {
  let url = `${unref(configStore.data)?.lowcode}/data-screen${path}`;
  const connector = url.includes('?') ? '&' : '?';
  const paramsStr = map(
    { ...params, token: localStorage.getItem('token') },
    (value, key) => `${key}=${value}`,
  ).join('&');
  url += `${connector}${paramsStr}`;
  openNewWindow(url);
};

/** 新建大屏 */
const handleCreate = () => {
  navigateToDataScreenPage('/create');
};

/** 新建手工大屏 */
const handleCreateManual = () => {
  configRecord.value = {
    id: '',
    name: '',
    thumbnail: '',
    thumbnailId: '',
    roles: [],
    organizations: [],
    users: [],
    status: DataScreenStatus.Inactive,
    allVisible: YesOrNo.No,
    categoryCode: '',
    categoryName: '',
    cfgType: CfgType.Manual,
  };
};

/** 预览缩略图 */
const handlePreviewImg = (record: DataScreenItem) => {
  if (record.thumbnail) {
    previewImageUrl.value = record.thumbnail;
  }
};

/** 启用/停用 */
const handleStatusChange = async (status: DataScreenStatus, item: DataScreenItem) => {
  if (
    status === DataScreenStatus.Inactive &&
    !(await confirm({ content: '确定停用当前大屏吗？' }))
  ) {
    return;
  }
  statusChanging.value = item.id;
  await updateDataScreen(item.id, {
    ...pick(item, ['name', 'roles', 'allVisible']),
    status,
  }).finally(() => (statusChanging.value = null));
  message.success('操作成功');
  search();
};

/** 配置，弹窗表单编辑 */
const handleConfig = (item: DataScreenItem) => {
  configRecord.value = item;
};

const closeConfigModal = (reload = false) => {
  configRecord.value = null;
  if (reload) {
    search();
  }
};

const handleRepublish = (item: DataScreenItem) => {
  republishRecord.value = item;
};

const closeRepublishModal = () => {
  republishRecord.value = null;
};

/** 编辑，跳转到大屏编辑页面 */
const handleEdit = (item: DataScreenItem) => {
  navigateToDataScreenPage(`/build/${item.id}`);
};
/** 预览，跳转到大屏预览页面 */
const handlePreview = (item: DataScreenItem) => {
  navigateToDataScreenPage(`/view/${item.id}`);
};
/** 删除操作 */
const handleDelete = async (item: DataScreenItem) => {
  if (
    await confirm({
      content: '确定删除当前大屏吗？',
      onOk: async () => await deleteDataScreen(item.id),
    })
  ) {
    message.success('删除成功');
    search();
  }
};

const handleMenuClick = (key: string, item: DataScreenItem) => {
  switch (key) {
    case 'preview':
      handlePreview(item);
      break;
    case 'delete':
      handleDelete(item);
      break;
    case 'republish':
      handleRepublish(item);
      break;
    default:
      break;
  }
};

search();
</script>

<template>
  <a-layout class="page">
    <a-page-header class="header">
      <div class="header-content">
        <div :style="{ width: '300px' }">
          <a-input-search
            v-model:value="searchParams.keyword"
            placeholder="请输入名称"
            enter-button="查询"
            @search="search(1)"
          />
        </div>
        <a-space>
          <a-button class="button" :icon="h(PlusOutlined)" @click="handleCreateManual">
            新建手工大屏
          </a-button>
          <a-button class="button" type="primary" :icon="h(PlusOutlined)" @click="handleCreate">
            新建低码大屏
          </a-button>
        </a-space>
      </div>
      <a-space>
        <div class="warn-icon">
          <ExclamationCircleOutlined />
        </div>
        <div>
          <div>
            <a-typography-text> 请确保已为需要数据大屏的组织开通数据中心应用。 </a-typography-text>
          </div>
          <div>
            <a-typography-text>
              请勿直接删除大屏设计器中对应的数据大屏，以免影响正常使用。
            </a-typography-text>
          </div>
        </div>
      </a-space>
    </a-page-header>
    <a-layout-content class="content">
      <a-spin :spinning="loading">
        <div>
          <a-row
            v-if="list.length > 0"
            :gutter="[
              { xs: 16, sm: 16, xxl: 16 },
              { xs: 16, sm: 16, xxl: 16 },
            ]"
          >
            <template v-for="item in list" :key="item.id">
              <a-col :xs="6" :sm="6" :xxl="4">
                <a-card class="card" hoverable :bodyStyle="{ padding: 0 }">
                  <div
                    class="cover"
                    @click="handlePreviewImg(item)"
                    :style="{
                      'background-image': `url(${item.thumbnail})`,
                    }"
                  />
                  <a-card-meta>
                    <template #title>
                      <span :title="item.name">{{ item.name }}</span>
                    </template>
                    <template #description>
                      <div class="roles-wrap">
                        <a-typography-text type="secondary"> 适配角色：</a-typography-text>
                        <a-typography-text
                          :content="getRoleNames(item)"
                          :title="getRoleNames(item)"
                        />
                      </div>
                      <div class="roles-wrap" type="secondary">
                        <a-typography-text type="secondary"> 定向组织：</a-typography-text>
                        <a-typography-text
                          :content="getOrganizationNames(item)"
                          :title="getOrganizationNames(item)"
                        />
                      </div>
                    </template>
                  </a-card-meta>
                  <div class="footer">
                    <a-space size="middle" v-if="item.cfgType === CfgType.Manual">
                      <a-typography-link @click="handleConfig(item)">配置</a-typography-link>
                      <a-typography-link
                        :disabled="item.status === DataScreenStatus.Active"
                        type="danger"
                        @click="handleDelete(item)"
                        >删除</a-typography-link
                      >
                    </a-space>
                    <a-space size="middle" v-else>
                      <a-typography-link @click="handleConfig(item)">配置</a-typography-link>
                      <a-typography-link @click="handleEdit(item)">编辑</a-typography-link>
                      <a-dropdown :getPopupContainer="(node: any) => node.parentNode">
                        <a-typography-link
                          ><EllipsisOutlined class="action action-more"
                        /></a-typography-link>
                        <template #overlay>
                          <a-menu style="width: 100px" @click="handleMenuClick($event?.key, item)">
                            <a-menu-item key="preview">
                              <a-typography-text type="link" class="primary-text"
                                >预览</a-typography-text
                              >
                            </a-menu-item>
                            <a-menu-item key="republish" :disabled="!item.organizations?.length">
                              <a-typography-text
                                type="link"
                                :class="{
                                  'disabled-text': !item.organizations?.length,
                                }"
                                class="primary-text"
                                >重新发布</a-typography-text
                              >
                            </a-menu-item>
                            <a-menu-item
                              key="delete"
                              :disabled="item.status === DataScreenStatus.Active"
                            >
                              <a-typography-text
                                :class="{
                                  'disabled-text': item.status === DataScreenStatus.Active,
                                }"
                                :type="item.status === DataScreenStatus.Active ? '' : 'danger'"
                                >删除</a-typography-text
                              >
                            </a-menu-item>
                          </a-menu>
                        </template>
                      </a-dropdown>
                    </a-space>
                    <a-switch
                      :checkedValue="DataScreenStatus.Active"
                      :unCheckedValue="DataScreenStatus.Inactive"
                      :loading="statusChanging === item.id"
                      :checked="item.status"
                      @update:checked="
                        (checked: DataScreenStatus) => handleStatusChange(checked, item)
                      "
                    />
                  </div>
                </a-card>
              </a-col>
            </template>
          </a-row>

          <a-result v-if="!loading && list.length === 0" subTitle="暂无数据">
            <template #icon>
              <img alt="empty" src="@/assets/images/workbench_empty.png" width="73" height="73" />
            </template>
          </a-result>

          <div
            class="pagination-wrap"
            v-if="!(pageData.pageNum === 1 && pageData.total <= pageData.pageSize)"
          >
            <a-pagination
              :current="pageData.pageNum"
              @update:current="updatePagination({ pageNum: $event })"
              :page-size="pageData.pageSize"
              @update:page-size="updatePagination({ pageSize: $event, pageNum: 1 })"
              :total="pageData.total"
              :show-total="(total: number) => `共${total}条`"
            />
          </div>
        </div>
      </a-spin>
    </a-layout-content>
  </a-layout>
  <a-image
    :width="200"
    :style="{ display: 'none' }"
    :preview="{
      visible: !!previewImageUrl,
      onVisibleChange: () => (previewImageUrl = ''),
      getContainer: false,
    }"
    :src="previewImageUrl"
  />
  <ConfigModal
    @cancel="closeConfigModal()"
    @submit="closeConfigModal(true)"
    :record="configRecord"
  ></ConfigModal>
  <RepublishModal :record="republishRecord" @cancel="closeRepublishModal"></RepublishModal>
</template>

<style scoped lang="scss">
.page {
  padding: 0;
  background-color: #fff;
}

.warn-icon {
  font-size: 24px;
  color: v-bind('token.colorWarningText');
}

.primary-text {
  color: v-bind('token.colorPrimary');
}

.disabled-text {
  color: v-bind('token.colorTextDisabled');
}

.header {
  height: auto;
  padding: 12px 24px 0;
  line-height: 24px;
}
.header-content {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 16px;
}
.content {
  overflow-y: auto;
  padding: 16px 24px 24px;
}
.card {
  width: 100%;
  padding: 16px;
  border-color: rgb(0 0 0 / 15%);
  cursor: default;
  &:hover {
    border-color: transparent;
  }
}
.cover {
  width: 100%;
  height: 0;
  padding-bottom: 58%;
  margin-bottom: 16px;
  background-position: center;
  background-repeat: no-repeat;
  background-size: contain;
  cursor: pointer;
  &[disabled='true'] {
    cursor: default;
  }
}

.roles-wrap {
  // display: flex;
  // justify-content: flex-start;
  // align-items: center;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}
.roles {
  color: rgb(0 0 0 / 88%);
}
.footer {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-top: 20px;
}

.pagination-wrap {
  margin-top: 8px;
  text-align: right;
}
</style>
