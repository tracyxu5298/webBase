import { Modal, type ModalFuncProps } from 'ant-design-vue';
import { CfgType, DataScreenStatus, type DataScreenItem } from './types';
import { map } from 'lodash-es';

export const confirm = (options: ModalFuncProps) => {
  return new Promise<boolean>((resolve) => {
    Modal.confirm({
      ...options,
      onOk: async () => {
        await options?.onOk?.();
        resolve(true);
      },
      onCancel: async () => {
        await options?.onCancel?.();
        resolve(false);
      },
    });
  });
};

export const ALL_VALUE = '__ALL__';

export const STATUS_OPTIONS = [
  { label: '启用', value: DataScreenStatus.Active },
  { label: '停用', value: DataScreenStatus.Inactive },
];

export const arrayMaxLengthRule = (max: number, message?: (n: number) => string) => ({
  validator: (_rule: any, value: any[]) => {
    if (value?.length > max) {
      return Promise.reject(message?.(max) ?? `最多支持${max}个`);
      return;
    }
    return Promise.resolve();
  },
});

export const getDataScreenPageSrc = (lowcodeUrl: string, record: DataScreenItem) => {
  if (record.cfgType === CfgType.Manual) {
    return (record.viewUrl || '').replace('{TOKEN}', localStorage.getItem('token') || '');
  } else {
    let url = `${lowcodeUrl}/data-screen/view/${record.id}`;
    const connector = url.includes('?') ? '&' : '?';
    const paramsStr = map(
      { token: localStorage.getItem('token') },
      (value, key) => `${key}=${value}`,
    ).join('&');
    url += `${connector}${paramsStr}`;
    return url;
  }
};
