import { map } from 'lodash-es';
import { Http } from '@lexikos/doraemon-network';
import { message } from 'ant-design-vue';
import type {
  DataScreenItem,
  PageData,
  SearchParams,
  NameId,
  NameCode,
  DataScreenGroup,
} from '../utils/types';
import { ALL_VALUE } from '../utils/helper';

const http = Http.getInstance();
const prefix = '/api/lowcode/dataCenter';

const toastErrorMsg = <T = any>(p: Promise<T>): Promise<T> => {
  return p.catch((reason) => {
    message.error(reason.msg || '请求错误');
    return Promise.reject(reason);
  });
};

/** 获取大屏列表分页 */
export const getDataScreenList = async (params: SearchParams, pageData: Partial<PageData>) => {
  return toastErrorMsg(
    http.get(`${prefix}/boss/dataScreens`, {
      ...params,
      pageNum: pageData.pageNum,
      pageSize: pageData.pageSize,
    }),
  );
};

/** 获取大屏详情 */
export const getDataScreenDetail = async (id: string) => {
  return toastErrorMsg(http.get<DataScreenItem>(`${prefix}/boss/dataScreens/${id}`));
};

/** 删除大屏 */
export const deleteDataScreen = async (id: string) => {
  return toastErrorMsg(http.delete(`${prefix}/boss/dataScreens/${id}`));
};

/** 更新大屏 */
export const updateDataScreen = async (id: string, data: Partial<DataScreenItem>) => {
  return toastErrorMsg(http.patch(`${prefix}/boss/dataScreens/${id}`, data));
};

/** 新增手工大屏 */
export const addManualDataScreen = async (data: Partial<DataScreenItem>) => {
  return toastErrorMsg(http.post(`${prefix}/boss/dataScreens/addCustomScreen`, data));
};

/** 重新发布大屏 */
export const republishDataScreen = async (data: { locationIds: string[]; visualId: string }) => {
  return toastErrorMsg(http.post(`/api/lowcode/blade-visual/visual/republish`, data));
};

/** 获取大屏分类列表 */
export const getDataScreenCategories = async () => {
  return toastErrorMsg(http.get<NameCode[]>(`${prefix}/dataScreenCategories`));
};

/** 获取大屏类别分组列表 */
export const getDataScreenCategoriesGroup = async () => {
  return toastErrorMsg(http.get<NameCode[]>(`${prefix}/dataScreenCategories/categoriesGroup`));
};

/** 获取大屏列表IMP */
export const getImpDataScreenList = async (params: SearchParams, pageData: Partial<PageData>) => {
  return toastErrorMsg(
    http.get(`${prefix}/imp/dataScreens`, {
      ...params,
      pageNum: pageData.pageNum,
      pageSize: pageData.pageSize,
    }),
  );
};

/** 更新大屏 */
export const updateImpDataScreen = async (id: string, data: Partial<DataScreenItem>) => {
  return toastErrorMsg(http.patch(`${prefix}/imp/dataScreens/${id}`, data));
};

/** 获取组织树 */
export const getLocationTree = async () => {
  return toastErrorMsg(http.get<NameId[]>(`/api/boss/v2/boss/org/getLocationTree`));
};

/**
 * 获取角色
 * api/auth/defaultRoles/frontend/choice/{locationLevel}
 * locationLevel =1  执行单位  locationLevel=0 管理单位
 */
export const getRoles = async () => {
  const url = 'api/auth/defaultRoles/frontend/choice';
  const res = await toastErrorMsg(Promise.all([http.get(`${url}/0`), http.get(`${url}/1`)]));
  return [
    { label: '全员', value: ALL_VALUE },
    {
      label: '管理单位',
      options: map(res[0], (r) => ({ value: r.id, label: r.name })),
    },
    {
      label: '执行单位',
      options: map(res[1], (r) => ({ value: r.id, label: r.name })),
    },
  ];
};

export const getLocationRoles = async () => {
  const res = await toastErrorMsg(http.get<any[]>('/api/auth/v1/roles/actions/findByLocation'));
  return [
    { label: '全员', value: ALL_VALUE },
    ...map(res, (r) => ({ value: r.id, label: r.roleName })),
  ];
};

/**
 * 获取组合大屏列表
 */
export const getDataScreenGroups = async (locationId?: string) => {
  return await toastErrorMsg(
    http.get<DataScreenGroup[]>(`${prefix}/screenCombination/getScreenCombinations/${locationId}`),
  );
};

/** 新增、编辑组合大屏 */
export const addOrEditDataScreenGroup = async (data: Partial<DataScreenGroup>) => {
  return await toastErrorMsg(
    http.post(`${prefix}/screenCombination/addOrEditScreenCombination`, data),
  );
};

/** 删除组合大屏 */
export const deleteDataScreenGroup = async (id?: string) => {
  return await toastErrorMsg(
    http.delete(`${prefix}/screenCombination/deleteScreenCombination/${id}`),
  );
};

/** 获取大屏组合详情 */
export const getDataScreenGroupDetail = async (id?: string) => {
  return await toastErrorMsg(
    http.get<
      DataScreenGroup & {
        screenConcretes: DataScreenItem[];
      }
    >(`${prefix}/screenCombination/getDetail/${id}`),
  );
};
