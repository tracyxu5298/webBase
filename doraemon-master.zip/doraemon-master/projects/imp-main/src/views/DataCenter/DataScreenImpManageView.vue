<script setup lang="ts">
import { reactive, ref, computed } from 'vue';
import { debounce, merge } from 'lodash-es';
import { Empty, theme } from 'ant-design-vue';
import { type DataScreenItem, type NameCode, type PageData } from './utils/types';
import { getDataScreenCategories, getImpDataScreenList } from './service';
import ConfigModal from './components/ImpConfigModal.vue';
import { usePermission, useConfigStore } from '@lexikos/doraemon-business';
import { useRouter } from 'vue-router';
import { getDataScreenPageSrc } from './utils/helper';
import { unref } from 'vue';

const router = useRouter();
const { token } = theme.useToken();
const configStore = useConfigStore();

const loading = ref<boolean>(false);
const list = ref<DataScreenItem[]>([]);
const configRecord = ref<DataScreenItem | null>(null);

const lowcode = computed(() => {
  return unref(configStore.data)?.lowcode;
});

const pageData = reactive<PageData>({
  pageNum: 1,
  pageSize: 16,
  total: 0,
});

/** 查询参数 */
const searchParams = reactive({
  keyword: '',
  categoryCode: '',
});

const searchId = ref(0);

/** 执行查询 */
const search = debounce(
  async () => {
    const currentSearchId = ++searchId.value;
    loading.value = true;
    const res = await getImpDataScreenList(searchParams, pageData).finally(() => {
      if (currentSearchId === searchId.value) {
        loading.value = false;
      }
    });
    if (currentSearchId !== searchId.value) {
      return;
    }
    merge(pageData, {
      total: res.total,
      pageNum: res.pageNum,
    });
    list.value = res.result;
  },
  500,
  {
    leading: true,
  },
);

/** 更新页码数据并执行查询 */
const updatePagination = async (changes: Partial<PageData>) => {
  merge(pageData, changes);
  await search();
};

/** 配置，弹窗表单编辑 */
const handleConfig = (item: DataScreenItem) => {
  configRecord.value = item;
};

const closeConfigModal = (reload = false) => {
  configRecord.value = null;
  if (reload) {
    search();
  }
};

/** 预览，跳转到大屏预览页面 */
const handlePreview = (item: DataScreenItem) => {
  window.open(getDataScreenPageSrc(lowcode.value!, item));
};

const categoryList = ref<NameCode[]>([{ name: '全部', code: '' }]);

const updateCategoryCodeHandle = (key: string) => {
  searchParams.categoryCode = key;
  search();
};

const init = () => {
  search();
  getDataScreenCategories().then((res) => (categoryList.value = [...categoryList.value, ...res]));
};

init();
</script>

<template>
  <a-layout class="page">
    <a-page-header class="header">
      <div class="header-content">
        <div :style="{ width: '238px' }">
          <a-input-search
            v-model:value="searchParams.keyword"
            placeholder="请输入名称"
            @search="search"
          />
        </div>
        <div>
          <a-button
            v-if="usePermission('DataCenter', 'groups').value"
            type="primary"
            @click="router.push('/DataCenter/DataScreenGroups')"
            >组合播放</a-button
          >
        </div>
      </div>
      <div class="header-tabs">
        <a-tabs
          :activeKey="searchParams.categoryCode"
          @update:activeKey="updateCategoryCodeHandle as any"
        >
          <a-tab-pane
            v-for="category in categoryList"
            :key="category.code"
            :tab="category.name"
          ></a-tab-pane>
        </a-tabs>
      </div>
    </a-page-header>
    <a-layout-content class="content">
      <a-spin :spinning="loading">
        <div style="min-height: 200px">
          <a-row
            v-if="list.length > 0"
            :gutter="[
              { xs: 16, sm: 16, xxl: 16 },
              { xs: 16, sm: 16, xxl: 16 },
            ]"
          >
            <template v-for="item in list" :key="item.id">
              <a-col :xs="6" :sm="6" :xxl="4">
                <a-card class="card" hoverable :bodyStyle="{ padding: 0 }">
                  <div
                    class="cover"
                    @click="handlePreview(item)"
                    :style="{
                      'background-image': `url(${item.thumbnail})`,
                    }"
                  />
                  <a-card-meta>
                    <template #title>
                      <span :title="item.name">{{ item.name }}</span>
                    </template>
                  </a-card-meta>
                  <div class="footer" v-if="usePermission('DataCenter', 'btn_edit').value">
                    <a-space size="middle">
                      <a class="link" @click="handleConfig(item)">配置</a>
                    </a-space>
                  </div>
                </a-card>
              </a-col>
            </template>
          </a-row>

          <a-empty
            v-if="!loading && list.length === 0"
            style="margin-top: 80px"
            :image="Empty.PRESENTED_IMAGE_SIMPLE"
          />

          <div
            class="pagination-wrap"
            v-if="!(pageData.pageNum === 1 && pageData.total <= pageData.pageSize)"
          >
            <a-pagination
              :current="pageData.pageNum"
              @update:current="updatePagination({ pageNum: $event })"
              :page-size="pageData.pageSize"
              @update:page-size="updatePagination({ pageSize: $event, pageNum: 1 })"
              :total="pageData.total"
              :show-total="(total: number) => `共${total}条`"
            />
          </div>
        </div>
      </a-spin>
    </a-layout-content>
  </a-layout>
  <ConfigModal
    @cancel="closeConfigModal()"
    @submit="closeConfigModal(true)"
    :record="configRecord"
  ></ConfigModal>
</template>

<style scoped lang="scss">
.page {
  padding: 0;
  background-color: #fff;
  height: 100%;
}

.header {
  height: auto;
  padding: 8px 20px 0;
  line-height: 24px;
}

.header-content {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 8px;
}

.header-tabs {
  :deep(.antv-main-tabs-nav) {
    margin-bottom: 0;
  }
}

.content {
  overflow-y: auto;
  padding: 0 20px 20px;
}
.card {
  width: 100%;
  padding: 16px;
  border-color: rgb(0 0 0 / 15%);
  cursor: default;
  &:hover {
    border-color: transparent;
  }
}
.cover {
  width: 100%;
  height: 0;
  padding-bottom: 56.2%;
  margin-bottom: 16px;
  background-position: center;
  background-repeat: no-repeat;
  background-size: contain;
  border: 1px solid v-bind('token.colorBorderSecondary');
  border-radius: v-bind('token.borderRadius') px;
  cursor: pointer;
  border-radius: 6px;
  &[disabled='true'] {
    cursor: default;
  }
}

.footer {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-top: 16px;
  .link {
    line-height: 20px;
    color: v-bind('token.colorPrimary');
    &:hover {
      color: v-bind('token.colorPrimaryTextHover');
    }
  }
}

.pagination-wrap {
  margin-top: 8px;
  text-align: right;
}
</style>
