<script lang="ts" setup>
import { ApplicationLayoutView } from '@lexikos/doraemon-business';
</script>

<template>
  <ApplicationLayoutView hide-menu appCode="DataCenter" />
</template>
