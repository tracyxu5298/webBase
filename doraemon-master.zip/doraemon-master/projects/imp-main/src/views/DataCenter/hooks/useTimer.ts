import { onBeforeUnmount, ref } from 'vue';

export const useTimer = (callback: () => void) => {
  const intervalMs = ref(0);
  const timer = ref();

  const stop = () => {
    clearTimeout(timer.value);
  };

  const start = () => {
    stop();
    if (intervalMs.value) {
      timer.value = setTimeout(() => {
        callback();
      }, intervalMs.value);
    }
  };

  const setIntervalMs = (interval: number) => {
    intervalMs.value = interval;
  };

  onBeforeUnmount(stop);

  return {
    start,
    stop,
    setIntervalMs,
  };
};
