<script setup lang="ts">
import { ref, onActivated } from 'vue';
import { onBeforeRouteLeave } from 'vue-router';
import { Empty, message, theme } from 'ant-design-vue';
import { StarFilled, StarOutlined } from '@ant-design/icons-vue';
import { useHttp, ApplicationPosition, ApplicationIcon } from '@lexikos/doraemon-business';
import type { Application } from '@lexikos/doraemon-business';
import { useApplicationsFavoriteStore } from '@/stores/applicationsFavorite';
import useApplicationAction from '@/hooks/useApplicationAction';
import ListFavorite from './ListFavorite.vue';
import useListData from './useListData';
import ListCategory from './ListCategory.vue';

const simpleImage = Empty.PRESENTED_IMAGE_SIMPLE;

const applicationsFavoriteStore = useApplicationsFavoriteStore();

const { token } = theme.useToken();
const http = useHttp();
const { dataByCategory, categories, loading } = useListData();

const scrollY = ref(0);
const applicationScrollWrap = ref();
const applicationAction = useApplicationAction();

onActivated(() => {
  if (scrollY.value && applicationScrollWrap.value) {
    applicationScrollWrap.value.scrollTop = scrollY.value;
  }
});

onBeforeRouteLeave(() => {
  scrollY.value = applicationScrollWrap.value?.scrollTop || 0;
});

const handleClickApp = (item: Application) => {
  applicationAction.push(item, { checkTarget: true });
};

const handleFavorite = async (item: Application) => {
  if (item.position === ApplicationPosition.navigation) {
    message.error('收藏失败，此应用已被设置为主导航菜单');
    return;
  }

  // 0 取消收藏, 1 添加收藏
  const enabled = item.position === ApplicationPosition.default ? 1 : 0;

  try {
    await http.put(`/api/auth//favoriteApplications/${item.id}`, {
      enabled,
      clientType: 1,
    });
    if (enabled) {
      applicationsFavoriteStore.add({ ...item, position: enabled });
      message.success('已收藏');
    } else {
      applicationsFavoriteStore.remove({ ...item, position: enabled });
      message.success('已取消收藏');
    }
  } catch (error: any) {
    message.error(error?.msg || '操作失败');
  }
};
</script>

<template>
  <a-spin class="application-content-loading" v-if="loading"></a-spin>
  <div class="application-content" v-else-if="categories.length">
    <ListCategory :categories="categories" />
    <div class="application-scroll-wrap" id="application-scroll-wrap" ref="applicationScrollWrap">
      <ListFavorite @clickApp="handleClickApp" @favorite="handleFavorite" />
      <div
        class="application-group"
        v-for="item in dataByCategory"
        :id="`${item.categoryId}`"
        :key="item.categoryId"
      >
        <p class="application-group-name">
          {{ item.categoryName }}
        </p>
        <div class="application-list">
          <div
            class="application-item"
            v-for="app in item.applications"
            :key="app.id"
            @click="handleClickApp(app)"
          >
            <ApplicationIcon :icon="app.icon" :size="40" />
            <p class="application-name" :title="app.name?.length > 6 ? app.name : ''">
              {{ app.name }}
            </p>
            <div
              :class="[
                'application-favorite-icon',
                app.position === ApplicationPosition.favorite
                  ? 'favorite-icon-show'
                  : 'favorite-icon-hide',
              ]"
              @click.stop="handleFavorite(app)"
            >
              <StarFilled v-if="app.position === ApplicationPosition.favorite" />
              <StarOutlined v-else />
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <a-empty v-else :image="simpleImage" />
</template>

<style lang="scss">
.application-content {
  display: flex;
  overflow: hidden;
  height: 100%;
}

.application-content-loading {
  margin-top: 100px;
}

.application-group {
  padding-bottom: 16px;
  &-name {
    padding-top: 16px;
    margin-bottom: 12px;
    font-style: normal;
    line-height: 22px;
    font-weight: v-bind('token.fontWeightStrong');
    color: v-bind('token.colorTextHeading');
  }
}

.application-list {
  display: grid;
  // justify-content: space-between;
  padding: 0;
  margin: 0;
  list-style: none;
  gap: 16px;
  grid-template-columns: repeat(auto-fill, 172px);
  .application-item {
    position: relative;
    display: flex;
    align-items: center;
    width: 174px;
    padding: 11px;
    background-color: v-bind('token.colorBgContainer');
    border: 1px solid v-bind('token.colorSplit');
    border-radius: 8px;
    cursor: pointer;
    // &:hover {
    //   background-color: v-bind('token.colorFillTertiary');
    //   border-color: v-bind('token.colorPrimaryBorderHover');
    //   .favorite-icon-hide {
    //     opacity: 1;
    //   }
    // }

    .favorite-icon-hide {
      opacity: 0;
    }
  }
  .application-icon {
    margin-right: 12px;
  }
  .application-name {
    margin: 0;
    flex: 1;
    width: 84px;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
  }
  .application-favorite-icon {
    position: absolute;
    top: 0;
    right: 0;
    display: flex;
    justify-content: center;
    align-items: center;
    width: 24px;
    height: 24px;
    font-size: 14px;
    color: v-bind('token.orange');
    background: v-bind('token.colorFillTertiary');
    border-radius: 0 7px 0 8px;
  }
}

.application-scroll-wrap {
  overflow-x: hidden;
  overflow-y: auto;
  height: 100%;
  padding: 0 24px 12px;
  flex: 1;
}

@media (pointer: fine) {
  .application-list .application-item:hover {
    background-color: v-bind('token.colorFillTertiary');
    border-color: v-bind('token.colorPrimaryBorderHover');
    .favorite-icon-hide {
      opacity: 1;
    }
  }
}
</style>
