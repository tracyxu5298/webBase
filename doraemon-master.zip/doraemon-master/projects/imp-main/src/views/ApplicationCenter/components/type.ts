export interface CategoryItem {
  key: string;
  href: string;
  title: string;
}
