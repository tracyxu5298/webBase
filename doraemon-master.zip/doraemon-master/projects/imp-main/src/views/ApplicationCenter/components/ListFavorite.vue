<script setup lang="ts">
import { computed, watch, onUnmounted, ref, watchEffect, unref } from 'vue';
import draggable from 'vuedraggable';
import { useHttp } from '@lexikos/doraemon-business';
import { StarFilled } from '@ant-design/icons-vue';
import { message, theme } from 'ant-design-vue';
import { cloneDeep } from 'lodash-es';
import { ApplicationIcon } from '@lexikos/doraemon-business';
import { ApplicationPosition, type Application } from '@lexikos/doraemon-business';
import { FAVORITE_CATEGORY } from './useListData';
import { useApplicationsFavoriteStore } from '@/stores/applicationsFavorite';

const emit = defineEmits<{
  (event: 'clickApp', value: Application): void;
  (event: 'favorite', value: Application): void;
}>();

let timer: any;

const http = useHttp();

const { token } = theme.useToken();

const dragging = ref(false);
const dragOptions = ref({
  animation: 300,
  group: 'description',
  disabled: false,
  ghostClass: 'ghost',
  chosenClass: 'chosen',
});

const applicationsFavoriteStore = useApplicationsFavoriteStore();

const data = computed(() => unref(applicationsFavoriteStore.data));

const prevSortIds = ref('');
const newSortIds = computed(() => data.value.map((i: Application) => i.id));

watch(newSortIds, (newValue, oldValue) => {
  // 收藏数量发生变化也去更新上一次的顺序
  if (newValue.length !== oldValue?.length) {
    prevSortIds.value = newValue.toString();
  }
});

watchEffect(() => {
  // 设置初始值
  if (!prevSortIds.value && newSortIds.value.length) {
    prevSortIds.value = newSortIds.value.toString();
  }
});

const handleFavorite = (value: Application) => {
  emit('favorite', { ...value, position: ApplicationPosition.favorite });
};

const handleClick = (value: Application) => {
  emit('clickApp', { ...value, position: ApplicationPosition.favorite });
};

const onEnd = async () => {
  const _newSortIds = newSortIds.value.toString();
  if (prevSortIds.value !== _newSortIds) {
    try {
      await http.post('/api/auth/favoriteApplications/sort', {
        clientType: 1,
        codes: data.value.map((i) => i.code),
      });
      prevSortIds.value = _newSortIds;
    } catch (error: any) {
      console.log('favoriteApplications sort error', error);
      const _new = cloneDeep(data.value);
      const _sort = prevSortIds.value.split(',');
      _new.sort((curr, next) => _sort.indexOf(curr.id) - _sort.indexOf(next.id));
      applicationsFavoriteStore.update(_new);
      message.error(error?.msg || '排序出错，请重试');
    }
  }

  timer = setTimeout(() => {
    dragging.value = false;
  }, 100);
};

onUnmounted(() => {
  timer && clearTimeout(timer);
});
</script>

<template>
  <div
    class="application-group application-favorite-group"
    v-if="data.length"
    :id="`${FAVORITE_CATEGORY.categoryId}`"
  >
    <p class="application-group-name">{{ FAVORITE_CATEGORY.categoryName }}</p>
    <draggable
      v-model="applicationsFavoriteStore.data"
      v-bind="dragOptions"
      item-key="id"
      :class="['application-list', dragging ? 'application-list-dragging' : '']"
      @start="dragging = true"
      @end="onEnd"
    >
      <template #item="{ element }">
        <div class="application-item" @click.stop="handleClick(element)">
          <ApplicationIcon :icon="element.icon" :size="40" />
          <p class="application-name" :title="element.name?.length > 6 ? element.name : ''">
            {{ element.name }}
          </p>
          <div
            class="application-favorite-icon favorite-icon-hide"
            @click.stop="handleFavorite(element)"
          >
            <StarFilled />
          </div>
        </div>
      </template>
    </draggable>
  </div>
</template>

<style lang="scss" scoped>
.flip-list-move {
  transition: transform 0.5s;
}

.no-move {
  transition: transform 0s;
}
.chosen {
  background: v-bind('token.colorFillAlter');
}
.ghost {
  opacity: 0;
}

.application-list.application-list-dragging {
  .application-item:hover {
    border-color: v-bind('token.colorSplit');
    .favorite-icon-hide {
      opacity: 0;
    }
  }
}
</style>
