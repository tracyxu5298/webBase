<script setup lang="ts">
import { theme } from 'ant-design-vue';
import type { AnchorProps } from 'ant-design-vue';
import type { CategoryItem } from './type';

defineProps<{
  categories: CategoryItem[];
}>();

const { token } = theme.useToken();

const handleClick: AnchorProps['onClick'] = (e, link) => {
  e.preventDefault();
  if (link.href) {
    // 找到锚点对应得的节点 跳滚动到锚点顶部
    let element = document.getElementById(link.href);
    element && element.scrollIntoView({ block: 'start', behavior: 'smooth' });
  }
};

const getContainer = () => {
  return document.getElementById(`application-scroll-wrap`);
};
</script>

<template>
  <div class="application-category">
    <a-anchor
      :affix="true"
      :getContainer="getContainer"
      :items="categories"
      :wrapperStyle="{
        maxHeight: 'calc(100vh - 180px)',
      }"
      class="application-category-anchor"
      @click="handleClick"
    ></a-anchor>
  </div>
</template>

<style lang="scss" scoped>
.application-category {
  width: 150px;
  height: 100%;
  padding-left: 16px;
  border-right: 1px solid v-bind('token.colorSplit');
}
.application-category-anchor {
  :deep(.#{$ant-prefix}-anchor::before) {
    opacity: 0;
  }
  :deep(.#{$ant-prefix}-anchor .#{$ant-prefix}-anchor-link) {
    padding: 0 8px;
    margin: 0 0 12px;
  }
  :deep(.#{$ant-prefix}-anchor .#{$ant-prefix}-anchor-link .#{$ant-prefix}-anchor-link-title) {
    padding: 8px 0;
    line-height: 22px;
  }
  :deep(.#{$ant-prefix}-anchor .#{$ant-prefix}-anchor-ink) {
    right: 0;
    left: auto;
  }
  :deep(.#{$ant-prefix}-anchor-wrapper) {
    overflow-y: auto;
    padding: 12px 0;
    margin: 0;
  }
}
</style>
