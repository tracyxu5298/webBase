import { storeToRefs } from 'pinia';
import { computed, onBeforeMount, unref } from 'vue';
import { concat, groupBy, filter, map, toLower } from 'lodash-es';
import {
  ApplicationPosition,
  ApplicationBelong,
  type Application,
} from '@lexikos/doraemon-business';
import { useApplicationsStore } from '@/stores/applications';
import { useNavigationConfigStore } from '@/stores/navigationConfig';
import { useApplicationsFavoriteStore } from '@/stores/applicationsFavorite';

export const FAVORITE_CATEGORY = {
  categoryName: '收藏',
  categoryId: 'FAVORITE_CATEGORY_ID',
};

const useListData = (): any => {
  // 主导航数据
  const navigationConfigStore = useNavigationConfigStore();

  // 收藏应用列表
  const applicationsFavoriteStore = useApplicationsFavoriteStore();
  const { loading: loadingFavorite } = storeToRefs(applicationsFavoriteStore);

  // 应用列表
  const applicationsStore = useApplicationsStore();
  const { loading: loadingApplications } = storeToRefs(applicationsStore);

  const dataByCategory = computed(() => {
    const _list = map(
      filter(
        unref(applicationsStore.data),
        (i) =>
          i.belong !== ApplicationBelong.system && toLower(i.code) !== 'basic:school:management',
      ),
      (i) => {
        let position = ApplicationPosition.default;
        if (unref(navigationConfigStore.navigationCodes).includes(i.code)) {
          position = ApplicationPosition.navigation;
        } else if (unref(applicationsFavoriteStore.applicationFavoriteIds).includes(i.id)) {
          position = ApplicationPosition.favorite;
        }

        return {
          ...i,
          position,
        } as Application;
      },
    );

    return Object.entries(groupBy(_list, 'categoryId'))
      .map(([key, values]) => {
        return {
          categoryId: key,
          categoryName: values[0].categoryName,
          typeSort: values[0].typeSort,
          applications: values,
        };
      })
      .sort((a, b) => a.typeSort! - b.typeSort!);
  });

  const categories = computed(() =>
    concat(
      unref(applicationsFavoriteStore.data).length
        ? [
            {
              key: FAVORITE_CATEGORY.categoryId,
              href: `#${FAVORITE_CATEGORY.categoryId}`,
              title: FAVORITE_CATEGORY.categoryName,
            },
          ]
        : [],
      dataByCategory.value.map((i) => ({
        key: i.categoryId,
        href: `#${i.categoryId}`,
        title: i.categoryName,
      })),
    ),
  );

  const loading = computed(() => {
    return (
      (loadingApplications.value && !unref(applicationsStore.data).length) ||
      (loadingFavorite.value && !unref(applicationsFavoriteStore.data).length)
    );
  });

  onBeforeMount(() => {
    applicationsFavoriteStore.fetch();
  });

  return { dataByCategory, categories, loading };
};

export default useListData;
