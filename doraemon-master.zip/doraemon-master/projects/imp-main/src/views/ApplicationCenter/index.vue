<script setup lang="ts">
import { theme } from 'ant-design-vue';

import ApplicationList from './components/List.vue';

const { token } = theme.useToken();
</script>

<template>
  <div class="application-view">
    <h2 class="application-view-header">我的应用</h2>
    <ApplicationList />
  </div>
</template>

<style lang="scss" scoped>
.application-view {
  display: flex;
  height: 100%;
  flex-direction: column;
  background-color: v-bind('token.colorBgContainer');
  &-header {
    padding: 12px 24px;
    margin: 0;
    font-size: 16px;
    color: v-bind('token.colorText');
    line-height: 32px;
    border-bottom: 1px solid v-bind('token.colorSplit');
    font-weight: v-bind('token.fontWeightStrong');
  }
}
</style>
