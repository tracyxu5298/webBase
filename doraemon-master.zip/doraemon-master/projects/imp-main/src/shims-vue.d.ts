export {};
declare module 'veaury/*';
declare global {
  interface Window {
    qiankunStarted: boolean;
  }
}
