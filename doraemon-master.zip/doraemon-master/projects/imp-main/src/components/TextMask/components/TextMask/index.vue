<script lang="ts" setup>
import { toRefs } from 'vue';
import { computed, type PropType } from 'vue';

export type TextMaskProps = {
  /** 需要打码的文本 */
  text: string;
  /** 打码范围 [start, end], 从 start（包含） 到 end（不包含） */
  maskRange: [number, number];
  /** 是否启用打码显示，默认为 true */
  masked?: boolean;
  /** 打码符号 */
  maskChar?: string;
};
/**
 * 文字打码组件
 */

const props = defineProps({
  text: {
    type: String,
    default: '',
  },
  maskRange: {
    type: Array as PropType<number[]>,
    default: () => [0, Infinity],
  },
  masked: {
    type: Boolean,
    default: true,
  },
  maskChar: {
    type: String,
    default: '*',
  },
});

const { text, maskRange, masked, maskChar } = toRefs(props);
const [start, end] = maskRange.value;

const displayText = computed(() => {
  if (!masked.value) {
    return text.value;
  }

  return text.value
    ?.split('')
    .map((char, i) => {
      if (i >= start && i < end) {
        return maskChar.value;
      }
      return char;
    })
    .join('');
});
</script>

<template>
  <span>{{ displayText }}</span>
</template>
