<script lang="ts" setup>
import { theme } from 'ant-design-vue';
import eyeClose from '../../assets/eye-close-2.svg';
import eyeOpen from '../../assets/eye-open.svg';

export type ToggleIconsProps = {
  /** SvgIcon 图标名称，对应 value 为 false 和 true 两个状态 */
  icons?: [string, string];
  /** 组件值, false / true */
  value?: boolean;
  /** 点击图标时的回调方法 */
  onChange?: (value: boolean) => void;
  /** 图标前缀文本 */
  prefixText?: string;
  /** 图标后缀文本 */
  suffixText?: string;
  /** 是否显示链接状态（显示为蓝色） */
  isLink?: boolean;
};

/**
 * 开关切换图标组件
 */
const props = defineProps<ToggleIconsProps>();

const { value = false, onChange, prefixText, suffixText, isLink } = props;

const { token } = theme.useToken();

const clickHandle = () => {
  if (!onChange) {
    return;
  }
  onChange(!value);
};
</script>

<template>
  <a :class="['wrap', { 'is-link': isLink }]" @click="clickHandle">
    <span v-if="prefixText">{{ prefixText }}</span>
    <span>
      <eye-open class="button-icon" v-if="props.value" />
      <eye-close class="button-icon" v-else />
    </span>
    <span v-if="suffixText">{{ suffixText }}</span>
  </a>
</template>

<style lang="scss" scoped>
.wrap {
  color: inherit;
  user-select: none;
  display: flex;

  .button-icon {
    width: 20px;
    height: 20px;
    color: v-bind('token.colorPrimary');
    margin-left: 2px;
  }

  &.is-link {
    color: inherit;
  }
  .prefix-text {
    color: inherit;
  }
  .suffix-text {
    color: inherit;
  }
}
</style>
