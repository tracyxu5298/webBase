import type { TextMaskProps } from './TextMask/index.vue';

export type RangedTextMaskProps = Pick<TextMaskProps, 'text' | 'masked' | 'maskChar'>;
