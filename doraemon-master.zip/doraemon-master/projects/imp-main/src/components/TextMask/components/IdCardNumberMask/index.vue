<script lang="ts" setup>
import { computed } from 'vue';
import type { TextMaskProps } from '../TextMask/index.vue';
import TextMask from '../TextMask/index.vue';
import type { RangedTextMaskProps } from '../base';

/**
 * 身份证号打码组件
 * 打码规则：保留身份证号前 3 位与后 3 位
 */
const props = defineProps<RangedTextMaskProps>();

const maskRange = computed<TextMaskProps['maskRange']>(() => {
  const { length } = props.text ?? '';
  return [3, length - 3];
});
</script>

<template>
  <TextMask v-bind="props" :maskRange="maskRange" />
</template>
