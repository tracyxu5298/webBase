<script lang="ts" setup>
import { computed } from 'vue';
import TextMask, { type TextMaskProps } from '../TextMask/index.vue';
import type { RangedTextMaskProps } from '../base';

/**
 * 学生证号打码组件
 * 打码规则：隐藏手机号的第 4 位至第 7 位
 */
const props = defineProps<RangedTextMaskProps>();

const maskRange = computed<TextMaskProps['maskRange']>(() => {
  const { length } = props.text ?? '';
  return [3, length - 4];
});
</script>

<template>
  <TextMask v-bind="props" :maskRange="maskRange" />
</template>
