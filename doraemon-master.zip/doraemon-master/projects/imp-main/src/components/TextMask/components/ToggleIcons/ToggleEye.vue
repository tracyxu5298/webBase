<script lang="ts" setup>
import type { ToggleIconsProps } from './ToggleIcons.vue';
import ToggleIcons from './ToggleIcons.vue';

export type ToggleEyesProps = ToggleIconsProps;
const props = defineProps<ToggleIconsProps>();
</script>

<template>
  <ToggleIcons v-bind="props" />
</template>
