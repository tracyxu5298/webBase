<script lang="ts" setup>
import { ref } from 'vue';
import { hideStr } from '../../util';

type Props = {
  string: string;
  from: number;
  end: number;
};
const { string, from, end } = defineProps<Props>();
const privacy = ref(true);

function setPrivacy(bol: boolean) {
  privacy.value = bol;
}
</script>

<template>
  {{ privacy ? hideStr(string, from, end) : string }}
  &nbsp;&nbsp;
  <Icon :type="privacy ? 'eye-invisible' : 'eye'" class="eye" @click="setPrivacy(!privacy)" />
</template>
