<script lang="ts" setup>
import TextMask from '../TextMask/index.vue';
import type { RangedTextMaskProps } from '../base';

/**
 * 手机号打码组件
 * 打码规则：隐藏手机号的第 4 位至第 7 位
 */
const props = defineProps<RangedTextMaskProps>();

const maskRange = [3, 7];
</script>

<template>
  <TextMask v-bind="props" :maskRange="maskRange" />
</template>
