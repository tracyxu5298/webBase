<script lang="ts" setup>
import type { RangedTextMaskProps } from '../base';
import IdCardNumberMask from '../IdCardNumberMask/index.vue';

/**
 * 护照、通行证打码组件
 * 打码规则：和身份证一样
 */
const props = defineProps<RangedTextMaskProps>();
</script>

<template>
  <IdCardNumberMask v-bind="props" />
</template>
