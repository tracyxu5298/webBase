import { type DefineComponent, defineComponent, useAttrs, h } from 'vue';

type HocProps<P> = Omit<P, 'text'> & { value: string };

/** 将组件包装一层，接收的 text 属性 */
export function WithAttr<P>(WrapperComponent: DefineComponent<HocProps<P>>) {
  return defineComponent({
    setup() {
      const attrs = useAttrs() as HocProps<P>;

      return () =>
        h(WrapperComponent, {
          ...attrs,
        });
    },
  });
}

export const hideStr = (str: string = '', from: number = 0, end: number = 0) => {
  if (str.length <= from + end) return str;
  const len = str.length - from - end;
  let star = '';
  for (let i = 0; i < len; i++) {
    star += '*';
  }
  return str.substr(0, from) + star + str.substr(str.length - end);
};
