import PhoneNumberMask from './components/PhoneNumberMask/index.vue';
import StudentNumberMask from './components/StudentNumberMask/index.vue';
import type { RangedTextMaskProps } from './components/base';
import IdCardNumberMask from './components/IdCardNumberMask/index.vue';
import PassportNumberMask from './components/PassportNumberMask/index.vue';
import Privacy from './components/Privacy/index.vue';
import type { Component } from 'vue';

export { default as TextMask, type TextMaskProps } from './components/TextMask/index.vue';
export type { RangedTextMaskProps } from './components/base';
export * from './util';
export { IdCardNumberMask, PassportNumberMask, StudentNumberMask, PhoneNumberMask, Privacy };
export * from './components/ToggleIcons';

export const CertificateComponents: Record<string, Component<RangedTextMaskProps>> = {
  0: IdCardNumberMask, // 身份证
  1: PassportNumberMask, // 军官证
  2: PassportNumberMask, // 护照
  3: PassportNumberMask, // 通行证
  4: PassportNumberMask, // 香港特区护照/身份证明
  5: PassportNumberMask, // 澳门特区护照/身份证明
  6: PassportNumberMask, // 台湾居民往来大陆通行证
  7: PassportNumberMask, // 境外永久居住证明
  8: IdCardNumberMask, // 其他
};
