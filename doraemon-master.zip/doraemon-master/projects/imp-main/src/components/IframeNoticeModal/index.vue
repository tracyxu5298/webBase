<script lang="ts" setup>
import { useIframeNoticeModal, useOldUrl } from '@lexikos/doraemon-business';
import { onMounted, onBeforeUnmount, ref } from 'vue';
import { theme } from 'ant-design-vue';

const { token } = theme.useToken();

const iframeNoticeModalStore = useIframeNoticeModal();

const noticeModalIframeRef = ref<HTMLIFrameElement>();

const handleMessage = (e: any) => {
  switch (e?.data?.type) {
    case 'noticeModalReady':
      console.log('消息中心弹窗准备就绪.');
      iframeNoticeModalStore.setReady(true);
      break;
    case 'closeNoticeModal':
      iframeNoticeModalStore.setVisible(false);
      break;
    default:
      break;
  }
};

onMounted(() => {
  window.addEventListener('message', handleMessage, false);
});

onBeforeUnmount(() => {
  iframeNoticeModalStore.setReady(false);
  iframeNoticeModalStore.setVisible(false);
  window.removeEventListener('message', handleMessage, false);
});

const partUrl = useOldUrl(import.meta.env);

const src = `${partUrl.value}/platform/notice-modal?token=${localStorage.getItem('token')}`;

defineExpose({
  noticeModalIframeRef,
});
</script>
<template>
  <iframe
    :ref="(el) => iframeNoticeModalStore.setIframeRef(el as HTMLIFrameElement)"
    v-show="iframeNoticeModalStore.visible"
    class="notice-modal-iframe"
    :src="src"
  >
  </iframe>
</template>
<style lang="scss" scoped>
.notice-modal-iframe {
  position: fixed;
  top: 0;
  left: 0;
  width: 100vw;
  height: 100vh;
  border: 0;
  z-index: v-bind('token.zIndexPopupBase + 1');
}
</style>
