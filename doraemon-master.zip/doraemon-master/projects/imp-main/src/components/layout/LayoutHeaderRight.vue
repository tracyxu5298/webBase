<script lang="ts" setup>
import { useRoute, useRouter } from 'vue-router';
import { Modal, message, theme } from 'ant-design-vue';
import { onLogout, TaskCenterDrawer, useUserAvatar, useUserName } from '@lexikos/doraemon-business';
import { computed, unref, h, createVNode, ref } from 'vue';
import {
  SettingOutlined,
  BellOutlined,
  ExclamationCircleOutlined,
  CarryOutOutlined,
  FormOutlined,
  DownOutlined,
} from '@ant-design/icons-vue';
import LayoutHeaderSearchInput from './LayoutHeaderSearchInput.vue';
import { useApplicationsStore } from '@/stores/applications';
import { useNotificationStore } from '@/stores/useNotification';
import defaultAvatar from '@/assets/images/avatar.png';
import { Http } from '@lexikos/doraemon-network';
import IframeNoticeModal from '@/components/IframeNoticeModal/index.vue';
import MqttNotification from '@/components/MqttNotification/index.vue';
import { InfoCircleFilled } from '@ant-design/icons-vue';
import { onBeforeUnmount } from 'vue';
import { ChangeType } from '@doraemon-business/enums/TaskCenter';
import { watch } from 'vue';
import Feedback from '@/components/Feedback/index.vue';

const { token } = theme.useToken();
const route = useRoute();
const router = useRouter();
const notificationStore = useNotificationStore();
const applicationsStore = useApplicationsStore();
const userName = useUserName();
const userAvatar = useUserAvatar();
const importMetaEnv = import.meta.env;

const applicationsStoreData = computed(() => {
  return unref(applicationsStore.data);
});
const isSystemSettings = computed(
  () => applicationsStoreData.value?.findIndex((i) => i.code === 'SystemSettings') >= 0,
);
const isNoticeCenter = computed(
  () => applicationsStoreData.value?.findIndex((i) => i.code === 'NoticeCenter') >= 0,
);
const isTaskCenter = computed(
  () => applicationsStoreData.value?.findIndex((i) => i.code === 'TaskCenter') >= 0,
);
const teacherArchives = computed(() =>
  applicationsStoreData.value?.find((i) => i.code === 'TeacherArchives' || i.code === 'ArchiveEdu'),
);

const taskVisible = ref(false);
function showTaskDrawer() {
  Http.getInstance().get('/api/lowcode/workflow/Engine/FlowTask/todoNums', { type: 'task-iframe' });
  taskVisible.value = !taskVisible.value;
}
const taskPopoverOpen = ref(false);
let taskPopoverTimer: any = null;
const openTaskPopover = () => {
  clearTimeout(taskPopoverTimer);
  taskPopoverOpen.value = true;
  taskPopoverTimer = setTimeout(() => {
    taskPopoverOpen.value = false;
  }, 3000);
};
watch(
  () => notificationStore.taskCenterMessage,
  (val: any) => {
    if (val.changeType === ChangeType.Complete) {
      openTaskPopover();
    }
  },
);

function handleLogout() {
  Modal.confirm({
    title: '退出',
    icon: createVNode(ExclamationCircleOutlined),
    content: '是否确认退出登录？',
    centered: true,
    onOk: async () => {
      try {
        await Http.getInstance().get('/api/building/v3/logout');
        onLogout();
      } catch (e: any) {
        message.error(e?.desc || '退出失败！');
      }
    },
  });
}

function clickToLink(targetPath: string) {
  if (route.path.includes(targetPath)) {
    return; // 防止重复点击
  }
  router.push(targetPath);
}

onBeforeUnmount(() => {
  clearTimeout(taskPopoverTimer);
});
</script>

<template>
  <ul class="header-right">
    <li class="item"><LayoutHeaderSearchInput /></li>
    <li v-if="isSystemSettings" class="item">
      <a-tooltip placement="bottom">
        <template #title>
          <span>系统设置</span>
        </template>
        <a-button
          class="header-right-button"
          :icon="h(SettingOutlined)"
          :type="route.path.includes('/SystemSettings') ? 'default' : 'primary'"
          @click="clickToLink('/SystemSettings')"
        />
      </a-tooltip>
    </li>
    <li v-if="isNoticeCenter" class="item">
      <a-tooltip placement="bottom">
        <template #title>
          <span>消息中心</span>
        </template>
        <a-button
          class="header-right-button"
          :icon="h(BellOutlined)"
          :type="route.path.includes('/NoticeCenter') ? 'default' : 'primary'"
          @click="clickToLink('/NoticeCenter')"
        />
      </a-tooltip>
      <a-badge :count="notificationStore.unReadNum" :class="['badge']" />
    </li>
    <li v-if="isTaskCenter" class="item">
      <a-popover placement="bottomRight" :open="taskPopoverOpen">
        <template #content>
          <div class="task-popup-content">
            <a-space
              ><InfoCircleFilled class="task-popup-icon" :style="{ color: token.colorPrimary }" />
              <span class="task-popup-text">任务处理完成</span></a-space
            >
          </div>
        </template>
        <a-tooltip placement="bottom">
          <template #title>
            <span>任务中心</span>
          </template>
          <a-button
            id="taskCenterBtn"
            class="header-right-button"
            :icon="h(CarryOutOutlined)"
            type="primary"
            @click="showTaskDrawer"
          />
        </a-tooltip>
      </a-popover>
      <a-badge :dot="!!notificationStore.taskCenterRedDotShow" class="dot" />
    </li>
    <li class="item">
      <Feedback>
        <template #trigger="{ show }">
          <a-tooltip placement="bottom">
            <template #title>
              <span>意见反馈</span>
            </template>
            <a-button
              class="header-right-button"
              :icon="h(FormOutlined)"
              type="primary"
              @click="show"
            />
          </a-tooltip>
        </template>
      </Feedback>
    </li>
    <li class="item">
      <a-dropdown
        :trigger="['click']"
        placement="bottom"
        :getPopupContainer="(triggerNode: any) => triggerNode?.parentNode"
      >
        <span class="avatar-content">
          <div class="avatar">
            <img
              :src="userAvatar || defaultAvatar"
              :onerror="`javascript:this.src='${defaultAvatar}';this.onerror=null;`"
            />
          </div>
          <div :title="userName!" class="name">
            {{ userName }}
          </div>
          <DownOutlined class="header-icon" />
        </span>
        <template #overlay>
          <a-menu class="item-user-menu">
            <!-- <a-menu-item disabled>
              <div class="user-info">
                <div class="avatar">
                  <img
                    :src="userAvatar || defaultAvatar"
                    :onerror="`javascript:this.src='${defaultAvatar}';this.onerror=null;`"
                  />
                </div>
                <div>
                  <a-typography-paragraph ellipsis class="name" :content="userName" />
                  <a-typography-paragraph
                    ellipsis
                    class="user-type"
                    :content="userName || ''"
                  />
                </div>
              </div>
            </a-menu-item>
            <a-menu-divider />
            <a-menu-item class="item-link">
              <a href="javascript:;">个人中心</a>
            </a-menu-item>
            <a-menu-divider />
            <a-menu-item class="item-link">
              <a href="javascript:;">账号设置</a>
            </a-menu-item>
            <a-menu-divider />
            <a-menu-item @click="handleLogout" class="item-logout">
              <a-button block>退出登录</a-button>
            </a-menu-item> -->
            <a-menu-item class="item-link" @click="router.push('/AccountSettings')">
              <i class="icon-ym icon-ym-header-userInfo"></i>
              <a href="javascript:;">账号设置</a>
            </a-menu-item>
            <a-menu-divider />
            <template v-if="teacherArchives">
              <a-menu-item class="item-link" @click="router.push(teacherArchives.path)">
                <i class="icon-ym icon-ym-customForm"></i>
                <a href="javascript:;">我的档案</a>
              </a-menu-item>
              <a-menu-divider />
            </template>
            <a-menu-item class="item-link" @click="handleLogout">
              <i class="icon-ym icon-ym-header-loginOut"></i>
              <a href="javascript:;">退出登录</a>
            </a-menu-item>
          </a-menu>
        </template>
      </a-dropdown>
    </li>
    <TaskCenterDrawer
      :open="taskVisible"
      @close="taskVisible = false"
      :import-meta-env="importMetaEnv"
    />
    <IframeNoticeModal />
    <MqttNotification />
  </ul>
</template>

<style lang="scss" scoped>
.dot {
  top: -4px;
  right: 14px;
}
.badge {
  position: absolute;
  top: 0;
  left: 28px;
  z-index: 1;
  :deep(sup) {
    min-width: 16px;
    height: 16px;
    line-height: 16px;
    font-family: helvetica;
  }
  :deep(.#{$ant-prefix}-badge-multiple-words) {
    padding: 0 6px;
  }
}
.header-right {
  display: flex;
  justify-content: center;
  align-items: center;
  padding: 0;
  margin: 0 0 0 18px;
  .item {
    display: flex;
    align-items: center;
    padding-left: 12px;
    list-style: none;
    position: relative;
  }
  &-button {
    box-shadow: none;
    border: none;
  }
  .header-right-button:deep(.#{$ant-prefix}-btn-default) {
    color: v-bind('token.colorPrimaryActive');
  }
}

.avatar {
  display: flex;
  justify-content: center;
  align-items: center;
  overflow: hidden;
  border-radius: 50%;
  img {
    width: 100%;
  }
}

.avatar-content {
  display: flex;
  align-items: center;
  height: 32px;
  margin-left: 12px;
  cursor: pointer;
  .avatar {
    width: 28px;
    height: 28px;
  }
  .header-icon {
    margin-left: 4px;
    font-size: 14px;
    color: rgb(255 255 255 / 65%);
  }
}

.name {
  max-width: 100px;
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
  margin: 0 0 0 8px;
}

.user-info {
  display: flex;
  align-items: center;
  margin-bottom: 16px;
  .name {
    font-size: 16px;
    font-weight: 600;
    line-height: 24px;
  }
  .avatar {
    width: 40px;
    height: 40px;
  }
}

.user-type {
  margin: 0 0 0 8px;
  line-height: 22px;
  margin-top: 4px;
  color: rgb(0 0 0 / 65%);
}

.item-user-menu {
  :deep(.#{$ant-prefix}-dropdown-menu-item) {
    padding: 0;
  }
  :deep(.item-link) {
    min-width: 102px;
    display: flex;
    align-items: center;
    flex-wrap: nowrap;
    padding: 8px 12px;
    a {
      margin-left: 5px;
    }
  }
  :deep(.item-logout) {
    margin-top: 16px;
  }
}

.task-popup {
  &-content {
    padding: 8px;
  }
  &-icon {
    font-size: 16px;
  }
}

iframe {
  display: block;
  width: 100%;
  height: 100%;
  border: none;
}
</style>
