<script lang="ts" setup>
import { computed, unref } from 'vue';
import { find, cloneDeep } from 'lodash-es';
import { message, theme } from 'ant-design-vue';
import { useRoute, useRouter } from 'vue-router';
import type { Application } from '@lexikos/doraemon-business';
import {
  ApplicationTarget,
  ApplicationIcon,
  useDeployConfigStore,
  openNewWindow,
} from '@lexikos/doraemon-business';
import { useApplicationTabsStore } from '@/stores/applicationTabs';
import { useNavigationConfigStore } from '@/stores/navigationConfig';
import useApplicationTab from '@/hooks/useApplicationTab';
import { getAppPathToLower } from '@/helpers/util';
import { APPLICATIONS_CODE } from '@/helpers/constants';
import useApplicationAction from '@/hooks/useApplicationAction';

withDefaults(defineProps<Props>(), {
  mode: 'side',
});

const router = useRouter();
const route = useRoute();
const { token } = theme.useToken();
const { showTab } = useApplicationTab();
const applicationTabsStore = useApplicationTabsStore();
const navigationConfigStore = useNavigationConfigStore();
const applicationAction = useApplicationAction();
const deployConfigStore = useDeployConfigStore();

interface Props {
  mode?: string;
}

const navigation = computed(() => unref(navigationConfigStore.data));

const activeKey = computed(() => {
  if (showTab.value) {
    return APPLICATIONS_CODE;
  }

  const _route = route.path.toLowerCase();

  const _active = find(navigation.value, (item) => {
    if (!item.path) {
      return false;
    }

    const _path = getAppPathToLower(item);
    // startsWith 需要加上斜杠否则 /dataCenter 会匹配到 /data
    return _path === _route || (_path !== '/' && `${_route}/`.startsWith(`${_path}/`));
  });
  return _active?.code || '';
});

const onClickNav = async (app: Application) => {
  // 点击同一个应用时
  if (unref(activeKey) === app.code) {
    /** 在应用中心其他应用时，点击应用中心回到应用中心 tab */
    if (app.code === APPLICATIONS_CODE && route.path.toLowerCase() !== app.path?.toLowerCase()) {
      router.push(app.path);
    }
    return;
  }

  const application = await applicationAction.getFinalAppInfo(app);
  const { path, code, target } = application;

  if (!path) {
    message.warn('未配置应用地址');
    return;
  }

  // 记录最近使用
  applicationAction.setUserRecentApp(application);

  // 智慧录播
  if (deployConfigStore.isMediaApp(app.code)) {
    const _path = await deployConfigStore.getMediaAppPath(app.path);
    if (_path) {
      openNewWindow(_path);
      return;
    }
  }
  // 打开新页签
  if (target === ApplicationTarget.blank) {
    applicationAction.onOpenNewTab(application);
    return;
  }

  // 点击应用中心
  if (code === APPLICATIONS_CODE) {
    // 查找本地最新访问的应用中心的应用地址
    const _recentRoute = applicationTabsStore.getRecentApp();
    if (_recentRoute) {
      router.push(cloneDeep(_recentRoute));
    } else {
      router.push(path);
    }
    return;
  }

  router.push(path);
};
</script>

<template>
  <a-tabs
    :activeKey="activeKey"
    :tab-position="mode === 'side' ? 'left' : 'top'"
    :tabBarGutter="0"
    :animated="false"
    prefixCls="layout-navigation"
    type="line"
  >
    <a-tab-pane v-for="item in navigation" :key="item.code">
      <template #tab>
        <div :class="['layout-navigation-item']" @click="onClickNav(item)">
          <ApplicationIcon class="layout-navigation-icon" :icon="item.icon" :size="36" />
          <p class="layout-navigation-name" :title="item.name?.length > 6 ? item.name : ''">
            {{ item.name }}
          </p>
        </div>
      </template>
    </a-tab-pane>
  </a-tabs>
</template>

<style lang="scss">
.layout-navigation {
  overflow: hidden;
  height: 100%;
  .layout-navigation-nav .layout-navigation-tab {
    padding: 0;
  }
  .layout-navigation-nav .layout-navigation-ink-bar {
    display: none;
  }
  &.layout-navigation-top {
    margin: 0 10px;
    .layout-navigation-nav {
      height: 100%;
      margin: 0;
    }
    .layout-navigation-nav::before {
      border-bottom: none;
    }
    .layout-navigation-tab-btn,
    .layout-navigation-item {
      height: 38px;
    }

    .layout-navigation-item {
      padding: 0 16px;
      border-radius: 8px;
    }
    .layout-navigation-nav-operations {
      color: v-bind('token.colorTextLightSolid');
    }
    .layout-navigation-name {
      margin: 0;
      font-size: 16px;
      line-height: 22px;
      color: v-bind('token.colorTextLightSolid');
      text-shadow: none;
    }
    .layout-navigation-icon {
      display: none;
    }
    .layout-navigation-tab-active {
      .layout-navigation-item {
        background-color: v-bind('token.colorBgContainer');
      }
      .layout-navigation-name {
        color: v-bind('token.colorPrimary');
      }
    }
  }
  &.layout-navigation-left {
    padding: 8px;
    margin: 0;
    .layout-navigation-content-holder {
      border-left: none;
    }
    .layout-navigation-item {
      width: 74px;
      padding: 12px 0 8px;
      margin-bottom: 8px;
      flex-direction: column;
      border-radius: 8px;
    }
    .layout-navigation-name {
      margin: 4px 4px 0;
      font-size: 12px;
      line-height: 20px;
      color: v-bind('token.colorTextSecondary');
    }
    // .layout-navigation-tab:hover,
    .layout-navigation-tab-active {
      .layout-navigation-item {
        color: v-bind('token.colorPrimary');
        background-color: v-bind('token.controlItemBgActive');
      }
      .layout-navigation-name {
        color: v-bind('token.colorPrimary');
      }
    }
    &.layout-navigation > .layout-navigation-nav .layout-navigation-nav-operations {
      display: none;
    }
    > .layout-navigation-nav
      .layout-navigation-nav-wrap.layout-navigation-nav-wrap-ping-top::before,
    > .layout-navigation-nav
      .layout-navigation-nav-wrap.layout-navigation-nav-wrap-ping-bottom::after {
      opacity: 0;
    }
  }
  .layout-navigation-nav-more {
    cursor: pointer;
  }
  .layout-navigation-name {
    user-select: none;
  }
}

.layout-navigation-item {
  display: flex;
  justify-content: center;
  align-items: center;
  flex: none;
  cursor: pointer;
  user-select: none;
  .layout-navigation-name {
    display: inline-block;
    overflow: hidden;
    width: 100%;
    margin: 0;
    text-align: center;
    text-overflow: ellipsis;
    white-space: nowrap;
  }
}

.layout-navigation-dropdown {
  // .layout-navigation-dropdown-menu-item:hover {
  //   background-color: v-bind('token.controlItemBgActive');
  // }
  .layout-navigation-dropdown-menu-item {
    padding: 10px 12px;
  }
  .layout-navigation-icon {
    width: 16px !important;
    height: 16px !important;
  }
  .layout-navigation-name {
    padding-left: 8px;
    text-align: left;
  }
}

@media (pointer: fine) {
  .layout-navigation.layout-navigation-left .layout-navigation-tab:hover {
    .layout-navigation-item {
      color: v-bind('token.colorPrimary');
      background-color: v-bind('token.controlItemBgActive');
    }
    .layout-navigation-name {
      color: v-bind('token.colorPrimary');
    }
  }
}
</style>
