<script lang="ts" setup>
import { computed, ref, unref } from 'vue';
import { filter } from 'lodash-es';
import { SearchOutlined } from '@ant-design/icons-vue';
import { ApplicationBelong } from '@lexikos/doraemon-business';
import type { Application } from '@lexikos/doraemon-business';
import { theme } from 'ant-design-vue';
import { useApplicationsStore } from '@/stores/applications';
import useApplicationAction from '@/hooks/useApplicationAction';

const { token } = theme.useToken();

const applicationAction = useApplicationAction();

const filterData = ref<Application[]>([]);
const searchValue = ref();
const searchInput = ref();

// 应用列表
const applicationsStore = useApplicationsStore();

const _applications = computed(() =>
  filter(unref(applicationsStore.data), (i) => i.belong !== ApplicationBelong.system),
);

const handleSearch = (val: string) => {
  if (!val || !val.trim()) {
    filterData.value = [];
  } else {
    filterData.value = _applications.value.filter((i) =>
      i.name?.toLowerCase().includes(val.toLowerCase()),
    );
  }
};

const handleClickApp = (val: string, params: any) => {
  searchValue.value = null;
  searchInput.value.blur();
  filterData.value = [];

  if (params?.item) {
    applicationAction.push(params?.item, { checkTarget: true });
  }
};

const inputKeyDown = (e: any) => {
  if (e.keyCode === 13 && filterData.value.length === 1) {
    handleClickApp(filterData.value[0].id, { item: filterData.value[0] });
  }
};
</script>

<template>
  <div class="layout-search-input">
    <span class="layout-search-input-icon">
      <SearchOutlined />
    </span>
    <a-select
      v-model:value="searchValue"
      show-search
      placeholder="搜索"
      :default-active-first-option="false"
      :show-arrow="false"
      :filter-option="false"
      ref="searchInput"
      :listHeight="348"
      @search="handleSearch"
      @change="handleClickApp"
      @inputKeyDown="inputKeyDown"
    >
      <a-select-option v-for="item in filterData" :key="item.id" :value="item.id" :item="item">
        <div class="search-option-app">
          <span class="search-option-app-icon"><img :src="item.icon" /></span>
          {{ item.name }}
        </div>
      </a-select-option>
    </a-select>
  </div>
</template>

<style lang="scss" scoped>
.layout-search-input {
  position: relative;
  display: flex;
  margin-right: 12px;
  :deep(.#{$ant-prefix}-select-selector) {
    width: 180px;
    padding-left: 32px;
    color: v-bind('token.colorTextLightSolid');
    background: v-bind('token.colorFill');
    border-color: transparent;
  }
  :deep(.#{$ant-prefix}-select-selection-search) {
    inset-inline-start: 32px;
  }
  :deep(.#{$ant-prefix}-select-selector .#{$ant-prefix}-select-selection-placeholder) {
    color: rgb(255 255 255 / 65%);
  }
}
.layout-search-input-icon {
  position: absolute;
  top: 0;
  left: 10px;
  z-index: 1;
  font-size: 16px;
  color: rgb(255 255 255 / 65%);
  line-height: 32px;
}
.search-option-app {
  display: flex;
  padding: 8px 0;
  line-height: 20px;
}
.search-option-app-icon {
  width: 20px;
  height: 20px;
  margin-right: 10px;
  img {
    width: 100%;
  }
}
</style>
