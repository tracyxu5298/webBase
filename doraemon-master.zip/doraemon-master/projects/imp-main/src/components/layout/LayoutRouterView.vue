<script lang="ts" setup>
import { theme } from 'ant-design-vue';
import { RouterView, useRoute } from 'vue-router';

import { MicroAppView } from '@lexikos/doraemon-business';
import { find, includes, isEqual, map, omit, startsWith } from 'lodash-es';
import { computed, unref } from 'vue';

import {
  useUserInfoStore,
  LowcodeIframeView,
  useConfigStore,
  type Application,
  type PreferenceLayout,
} from '@lexikos/doraemon-business';
import type { RegistrableApp } from 'qiankun';
import ApplicationCenterTab from '../ApplicationCenterTab/index.vue';
import useApplicationFullPath from '../../hooks/useApplicationFullPath';
import LayoutHeader from './LayoutHeader.vue';
import LayoutNavigation from './LayoutNavigation.vue';
import { useApplicationsStore } from '@/stores/applications';
import { useApplicationTabsStore } from '@/stores/applicationTabs';
import Shared from '@/helpers/shared';
import { qiankunWindow } from 'vite-plugin-qiankun/dist/helper';
import { useWorkbenchBg } from '@/hooks/useWorkbenchBg';
import useNoticeBar, { EarlyCloseNoticeBarTime } from '@/hooks/useNoticeBar';
import NoticeBar from '@/components/NoticeBar/index.vue';

defineProps<{ mode: PreferenceLayout }>();

const configStore = useConfigStore();
const [showNoticeBar, noticeContent, updateTime] = useNoticeBar();
const lowcodeDomain = computed(() => {
  return unref(configStore.data)?.lowcode;
});

// 是否需要厂字头
const appFullPath = useApplicationFullPath();
const route = useRoute();
const { token } = theme.useToken();
const appStore = useApplicationsStore();
const { currentThemeWorkbenchBgImg } = useWorkbenchBg();

// 用户信息
const userInfoStore = useUserInfoStore();

const shared = new Shared();

const loading = computed(() => !userInfoStore.data);

function activeRule(appPath: string, location: Location) {
  const { data: dashboardTabs } = useApplicationTabsStore();

  const isTab = find(unref(dashboardTabs), (tab) =>
    includes(tab.path.toLowerCase(), appPath.toLowerCase()),
  );
  const flag = startsWith(location.pathname, appPath);
  const finalActiveFlag = flag || !!isTab;

  return finalActiveFlag;
}

function handleNoticeClose() {
  localStorage.setItem(EarlyCloseNoticeBarTime, String(updateTime.value ?? ''));
}

const applications = computed(() => {
  const oldApplications = unref(applications) as Application[];
  const newApplications = map(
    unref(appStore.data),
    (app) => omit(app, ['icon', 'name']) as Application,
  );
  return isEqual(newApplications, oldApplications) ? oldApplications : newApplications;
});

const isWorkbench = computed(() => {
  return route.path.toLowerCase() === '/workbench';
});

const isFullWrap = computed(() => {
  return isWorkbench.value;
});

const showWorkbenchBg = computed(() => isWorkbench.value && currentThemeWorkbenchBgImg.value);

const isLayout = computed(() => {
  if (qiankunWindow.__POWERED_BY_QIANKUN__) {
    return false;
  }

  return unref(appFullPath.data).findIndex((i: string) => route.path.includes(i)) === -1;
});

const importMetaEnv = computed(() => import.meta.env);

const qiankunRegisterLifeCycles = {
  // 加载前
  beforeLoad(app: RegistrableApp<any>) {
    console.log(`%c${app?.name} 已挂载`, 'color: green;');
    return Promise.resolve();
  },
  beforeUnmount(app: RegistrableApp<any>) {
    console.log(`%c${app?.name} 已卸载`, 'color: yellow;');
    return Promise.resolve();
  },
} as any;
</script>

<template>
  <a-layout class="main-layout-root" v-if="isLayout">
    <a-layout :class="['main-layout', { 'show-workbench-bg': showWorkbenchBg }]">
      <LayoutHeader>
        <div v-if="mode === 'top'" class="main-layout-side-navigation">
          <LayoutNavigation mode="top" />
        </div>
      </LayoutHeader>
      <div class="notice-bar" v-if="showNoticeBar">
        <NoticeBar
          :list="noticeContent"
          v-model="showNoticeBar"
          @update:model-value="handleNoticeClose"
        />
      </div>
      <a-layout
        class="layout-body"
        :style="{
          backgroundImage: showWorkbenchBg ? `url(${currentThemeWorkbenchBgImg})` : undefined,
        }"
      >
        <a-layout-sider v-if="mode === 'side'" theme="light" width="90" class="main-layout-sider">
          <LayoutNavigation mode="side" />
        </a-layout-sider>
        <a-layout-content class="main-layout-content">
          <div class="full-screen-spin" v-if="loading">
            <a-spin tip="加载中" />
          </div>
          <template v-else>
            <ApplicationCenterTab />
            <div :class="['main-layout-content-wrap', isFullWrap ? 'full-wrap' : '']">
              <MicroAppView
                :applications="applications"
                :active-rule="activeRule"
                :import-meta-env="importMetaEnv"
                :qiankun-register-life-cycles="qiankunRegisterLifeCycles"
                :shared="shared"
              >
                <RouterView v-slot="{ Component }">
                  <KeepAlive>
                    <component :is="Component" v-if="$route.meta.keepalive" />
                  </KeepAlive>
                  <component :is="Component" v-if="!$route.meta.keepalive" />
                </RouterView>
                <LowcodeIframeView :lowcodeDomain="lowcodeDomain!" v-if="lowcodeDomain" />
              </MicroAppView>
            </div>
          </template>
        </a-layout-content>
      </a-layout>
    </a-layout>
  </a-layout>

  <template v-else>
    <div class="full-screen-spin" v-if="loading">
      <a-spin tip="加载中" />
    </div>
    <MicroAppView
      v-else
      :applications="applications"
      :active-rule="activeRule"
      :import-meta-env="importMetaEnv"
      :qiankun-register-life-cycles="qiankunRegisterLifeCycles"
      :shared="shared"
    >
      <RouterView v-slot="{ Component }">
        <KeepAlive>
          <component :is="Component" v-if="$route.meta.keepalive" :key="$route.path" />
        </KeepAlive>
        <component :is="Component" v-if="!$route.meta.keepalive" />
      </RouterView>
      <LowcodeIframeView :lowcodeDomain="lowcodeDomain!" v-if="lowcodeDomain" />
    </MicroAppView>
  </template>
</template>

<style lang="scss" scoped>
.main-layout {
  min-width: 1280px;
  &-root {
    overflow-x: auto;
    overflow-y: hidden;
    height: 100%;
  }
}
.main-layout-side-navigation {
  flex: 1;
  display: flex;
  width: 200px;
}

.main-layout-sider {
  // transition: all 0.3s;
  position: relative;
  background-color: v-bind('token.colorBgContainer');
  border-right: 1px solid v-bind('token.colorSplit');
  .show-workbench-bg & {
    background: linear-gradient(180deg, rgba(255, 255, 255, 0.8) 0%, rgba(255, 255, 255, 0.4) 100%);
    border-right: rgba(255, 255, 255, 0.8);
    box-shadow: 0px 2px 6px 0px #00000014;
  }
}
.main-layout-content {
  display: flex;
  flex-direction: column;
  background-color: transparent;
  &-wrap {
    position: relative;
    overflow-x: hidden;
    overflow-y: auto;
    margin: 16px;
    border-radius: 4px;
    flex: 1;
    &.full-wrap {
      margin: 0;
      border-radius: 0;
    }
  }
}

.layout-body {
  background-color: v-bind('token.colorBgLayout');
  background-repeat: no-repeat;
  background-size: cover;
  transition: all 1s;
}

.notice-bar {
  color: v-bind('token.colorError');
  background: v-bind('token.colorBgContainer');
  border-radius: 4px;
  padding-left: 6px;
}
</style>
