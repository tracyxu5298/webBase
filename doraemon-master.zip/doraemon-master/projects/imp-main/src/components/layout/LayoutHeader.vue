<script lang="ts" setup>
import { ref, onMounted } from 'vue';
import { SwapOutlined } from '@ant-design/icons-vue';
import { useRoute } from 'vue-router';
import {
  LocationSelector,
  useCurrentChildId,
  useLocationLogo,
  useLocationId,
  useLocationName,
  useUserIdentity,
} from '@lexikos/doraemon-business';
import { theme } from 'ant-design-vue';
import LayoutHeaderRight from './LayoutHeaderRight.vue';

const { token } = theme.useToken();
const route = useRoute();
const locationId = useLocationId();
const locationName = useLocationName();
const locationLogo = useLocationLogo();
const userIdentity = useUserIdentity();
const currentChildId = useCurrentChildId();

const spinning = ref(false);
const open = ref(false);
const isMultipleLocation = ref(
  !!(localStorage.getItem('multipleLocation') || route.query.isMultipleLocation),
);

const onLoading = (value: boolean) => {
  spinning.value = value;
};

const onBeforeChanged = () => {
  open.value = false;
};

const onAfterChanged = (_locationItem: any, homePageAddress?: string) => {
  window.location.href = homePageAddress || '/';
};

const onMultiple = (_multiple: boolean) => {
  isMultipleLocation.value = _multiple;
};

onMounted(() => {
  if (route.query.isMultipleLocation) {
    localStorage.setItem('multipleLocation', '1');
  }
});
</script>

<template>
  <a-layout-header class="header">
    <div class="header-left">
      <div class="header-logo" v-if="locationLogo">
        <img :src="locationLogo" alt="" />
      </div>
      <a-dropdown :trigger="['click']" v-model:open="open">
        <a-typography-paragraph class="dropdown-title">
          <a-typography-text>{{ locationName }}</a-typography-text>
          <SwapOutlined v-show="isMultipleLocation" class="dropdown-title-icon" />
        </a-typography-paragraph>
        <template #overlay>
          <div class="dropdown-location-selector" v-show="isMultipleLocation">
            <LocationSelector
              :currentId="locationId!"
              :currentUserType="userIdentity!"
              :currentChildId="currentChildId!"
              @multiple="onMultiple"
              @beforeChanged="onBeforeChanged"
              @afterChanged="onAfterChanged"
              @loading="onLoading"
            />
          </div>
        </template>
      </a-dropdown>
    </div>
    <slot></slot>
    <LayoutHeaderRight v-if="locationId" />
  </a-layout-header>
  <a-spin spinning class="global-loading" v-if="spinning"></a-spin>
</template>

<style lang="scss" scoped>
.header {
  position: relative;
  display: flex;
  justify-content: space-between;
  height: 56px;
  color: v-bind('token.colorTextLightSolid');
  background-color: v-bind('token.colorPrimary');
  padding-inline-start: 24px;
  padding-inline-end: 24px;
  line-height: 56px;
  box-shadow:
    0 8px 26px 8px rgb(0 0 0 / 5%),
    0 3px 6px -4px rgb(0 0 0 / 12%),
    0 4px 14px 0 rgb(0 0 0 / 8%);
}

.header-left {
  display: flex;
  align-items: center;
  padding-inline-end: 22px;
}

.header-logo {
  overflow: hidden;
  padding: 4px;
  margin-right: 8px;
  img {
    float: left;
    min-width: 32px;
    height: 32px;
  }
}

.dropdown-location-selector {
  display: flex;
  flex-direction: column;
  overflow: hidden;
  width: 350px;
  max-height: 408px;
  padding: 16px;
  background: #fff;
  border: 1px solid rgb(0 0 0 / 15%);
  border-radius: 8px;
  box-shadow:
    0 9px 28px 8px rgb(0 0 0 / 5%),
    0 3px 6px -4px rgb(0 0 0 / 12%),
    0 6px 16px 0 rgb(0 0 0 / 8%);
}
.dropdown-title {
  line-height: 32px;
  margin: 0;
  color: v-bind('token.colorTextLightSolid');
  cursor: pointer;
  & :deep(.#{$ant-prefix}-typography) {
    margin: 0 8px 0 0;
    font-size: 16px;
    color: v-bind('token.colorTextLightSolid');
    font-weight: 600;
  }
  .dropdown-title-icon {
    font-size: 16px;
  }
}
.global-loading {
  position: fixed;
  z-index: 9999;
  display: flex;
  justify-content: center;
  align-items: center;
  inset: 0;
  background: rgb(0 0 0 / 10%);
}
</style>
