<script lang="ts" setup>
import { computed, ref, unref, watch } from 'vue';
import { useRoute } from 'vue-router';
import { concat, find, map, filter } from 'lodash-es';
import type { Application } from '@lexikos/doraemon-business';
import { ApplicationBelong } from '@lexikos/doraemon-business';
import { theme } from 'ant-design-vue';
import ApplicationTabItem from './TabItem.vue';
import { useApplicationTabsStore } from '@/stores/applicationTabs';
import useApplicationTab from '@/hooks/useApplicationTab';
import useApplicationAction from '@/hooks/useApplicationAction';
import { useApplicationsStore } from '@/stores/applications';
import { useNavigationConfigStore } from '@/stores/navigationConfig';
import { getAppPathToLower } from '@/helpers/util';
import { APPLICATIONS_CODE } from '@/helpers/constants';

const { token } = theme.useToken();

const applicationsStore = useApplicationsStore();
const applicationAction = useApplicationAction();
const route = useRoute();
const applicationTabsStore = useApplicationTabsStore();
const navigationConfigStore = useNavigationConfigStore();
const { showTab } = useApplicationTab();
const activeTab = ref('');

const panes = computed(() => {
  return concat(
    filter(unref(navigationConfigStore.data), (i) => i.code === APPLICATIONS_CODE),
    unref(applicationTabsStore.data),
  ) as Application[];
});

// 应用中心的需要展示 tab 应用集合
const _apps = computed(() =>
  map(
    filter(
      unref(applicationsStore.data),
      (i) =>
        !!i.path &&
        !(
          unref(navigationConfigStore.navigationCodes).includes(i.code) ||
          i.belong === ApplicationBelong.system
        ),
    ),
    (i) => ({
      ...i,
      path: getAppPathToLower(i),
    }),
  ),
);

const getActiveKey = () => {
  if (!showTab.value) {
    return '';
  }

  const _currentPath = route.path.toLowerCase();

  // startsWith 需要加上斜杠否则 /dataCenter 会匹配到 /data
  // 当前高亮的 tab
  const _active = panes.value.find((item) => {
    let _path = item.path.toLowerCase();
    return `${_currentPath}/`.startsWith(`${_path}/`);
  });

  if (_active) {
    // 当前页面是应用中心的页面时，记住上次的路由，下次点击应用中心时跳转到该页面
    applicationTabsStore.saveRecentApp(_active, {
      // fullPath: route.fullPath,
      path: route.path,
      query: { ...route.query },
    });
    return _active.code;
  }

  // 在当前缓存的 tab 中未找到，需要在应用列表中匹配数据，
  // 一般是直接输入地址进入页面与工作台入口进入
  const _app = find(unref(_apps), (i) => {
    // startsWith 需要加上斜杠否则 /dataCenter 会匹配到 /data
    return `${_currentPath}/`.startsWith(`${i.path}/`);
  });

  if (_app) {
    applicationTabsStore.add(_app);
    applicationTabsStore.saveRecentApp(_app, {
      // fullPath: route.fullPath,
      path: route.path,
      query: { ...route.query },
    });
    return _app.code;
  }

  return '';
};

watch(
  () => route.fullPath,
  () => {
    if (!showTab.value) {
      return;
    }

    const _newKey = getActiveKey();
    if (_newKey !== activeTab.value) {
      activeTab.value = _newKey;
    }
  },
  {
    immediate: true,
  },
);

const remove = (targetKey: string) => {
  let nextTab = null;
  if (activeTab.value === targetKey) {
    panes.value.forEach((pane, i) => {
      if (pane.code === targetKey) {
        nextTab = panes.value[i - 1] || panes.value[0];
      }
    });
  }

  if (nextTab) {
    applicationAction.push(nextTab);
  }

  applicationTabsStore.remove(targetKey);
};

const onEdit = (targetKey: string) => {
  remove(targetKey);
};

const onClickTab = (targetKey: string) => {
  const _app = panes.value.find((i) => i.code === targetKey);
  if (_app) {
    applicationAction.push(_app);
  }
};
</script>

<template>
  <div class="application-tabs-wrap" v-show="showTab">
    <a-tabs
      v-model:activeKey="activeTab"
      hide-add
      :tabBarGutter="8"
      :animated="false"
      prefixCls="application-tabs"
      type="editable-card"
      @edit="onEdit"
      @change="onClickTab"
    >
      <a-tab-pane v-for="pane in panes" :key="pane.code" :closable="pane.code !== panes[0].code">
        <template #tab>
          <ApplicationTabItem :name="pane.name" :icon="pane.icon" />
        </template>
      </a-tab-pane>
    </a-tabs>
  </div>
</template>

<style lang="scss">
.application-tabs-wrap {
  position: relative;
  padding: 0 16px;
  background-color: v-bind('token.colorBgContainer ');
  .application-tabs {
    height: 32px;
    margin-top: 8px;
    background-color: v-bind('token.colorBgContainer ');
    .application-tabs-nav {
      height: 100%;
      margin: 0;
    }
    .application-tabs-nav::before {
      border-bottom: none;
    }
    .application-tabs-nav .application-tabs-tab + .application-tabs-tab,
    .application-tabs-nav .application-tabs-tab {
      padding: 6px 12px;
    }
    .application-tabs-nav .application-tabs-tab,
    .application-tabs-tab + .application-tabs-tab {
      background: transparent;
      border: none;
    }
    .application-tabs-nav .application-tabs-tab-active {
      background: v-bind('token.colorBgLayout');
    }
    .application-tabs-tab-remove {
      display: flex;
      justify-content: center;
      align-items: center;
      padding-right: 4px;
      padding-left: 4px;
      margin-left: 4px;
      font-size: 10px;
    }
  }
}

.application-tabs-dropdown {
  .application-tabs-dropdown-menu-item {
    padding: 6px 12px;
    .application-tabs-dropdown-menu-title-content {
      display: flex;
    }
  }
  .application-tabs-dropdown-menu-item-remove {
    padding: 0 4px;
    margin-left: 4px;
  }
}
</style>
