<script lang="ts" setup>
import { ApplicationIcon } from '@lexikos/doraemon-business';

defineProps(['name', 'icon']);
</script>

<template>
  <div class="application-tab-title">
    <ApplicationIcon :icon="icon" :size="16" />
    <span class="application-tab-label">{{ name }}</span>
  </div>
</template>

<style lang="scss" scoped>
.application-tab-title {
  display: flex;
  justify-content: center;
  align-items: center;
}
.application-tab-label {
  font-size: 12px;
  color: rgb(0 0 0 / 65%);
}
.application-icon {
  margin-right: 8px;
}
</style>
