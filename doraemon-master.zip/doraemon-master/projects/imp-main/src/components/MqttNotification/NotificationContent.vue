<script lang="ts" setup>
import dayjs from 'dayjs';
import { computed, type PropType } from 'vue';
import { theme } from 'ant-design-vue';

const props = defineProps({
  source: {
    type: Object as PropType<{
      title: string;
      content: string;
      notifyTime: string;
      id: string;
      imageFileUrl: string;
      bizSeq: string;
      bizDataJson: string;
    }>,
    default: () => ({}),
  },
});

defineEmits<{
  (event: 'click', item: any): void;
}>();

const { token } = theme.useToken();

const time = computed(() => {
  const { notifyTime } = props.source;
  return notifyTime ? dayjs(notifyTime).format('YYYY/MM/DD HH:mm') : null;
});
</script>
<template>
  <div>
    <div class="content">
      {{ source.content }}
    </div>
    <div class="info">
      <span class="time">{{ time }}</span>
      <a class="link" @click="$emit('click', source)">详情</a>
    </div>
  </div>
</template>
<style lang="scss" scoped>
// .content {
// }
.info {
  display: flex;
  align-items: center;
  justify-content: space-between;
}
.time {
  color: v-bind('token.colorTextDisabled');
}
.link {
  color: v-bind('token.colorPrimary');
  &:hover {
    color: v-bind('token.colorPrimaryHover');
  }
}
</style>
