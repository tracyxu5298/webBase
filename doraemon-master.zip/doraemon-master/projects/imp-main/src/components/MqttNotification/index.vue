<script lang="ts" setup>
import { h } from 'vue';
import { notification } from 'ant-design-vue';
import { MqttObserver } from '@lexikos/doraemon-business';
import NotificationContent from './NotificationContent.vue';
import { ReadStatus, useNoticeDetail, type NoticeItem } from '@lexikos/doraemon-business';

const { handleNoticeDetail } = useNoticeDetail();

notification.config({
  maxCount: 5,
});

const clickHandle = (item: any) => {
  handleNoticeDetail({ ...item, readStatus: ReadStatus.Unread } as unknown as NoticeItem);
  notification.close(item.bizSeq);
};

function onMessage(message: any) {
  console.log('...... > onMessage > message:', message);
  const { title, bizSeq } = message.message;
  notification.open({
    message: title,
    description: h(NotificationContent, {
      source: message.message,
      onClick: clickHandle,
    }),
    duration: null,
    key: bizSeq,
  });
}
</script>
<template>
  <MqttObserver :topics="['notify/systemMessage']" @message="onMessage"></MqttObserver>
</template>
<style lang="scss" scoped></style>
