<script lang="ts" setup>
import {
  onBeforeUnmount,
  computed,
  onMounted,
  ref,
  getCurrentInstance,
  type HTMLAttributes,
  type CSSProperties,
} from 'vue';
import { forEach } from 'lodash-es';
import { SoundFilled, CloseOutlined } from '@ant-design/icons-vue';

interface NoticeBarProps extends /* @vue-ignore */ HTMLAttributes {
  modelValue?: boolean;
  iconStyle?: CSSProperties;
  contentStyle?: CSSProperties;
  height?: number;
  padding?: number;
  showLeftIcon?: boolean;
  showRightIcon?: boolean;
  list: (string | Record<string, any>)[] | string;
  field?: string;
  speed?: number;
}

const props = withDefaults(defineProps<NoticeBarProps>(), {
  padding: 0,
  speed: 150,
  field: 'text',
  list: '',
  height: 30,
  showLeftIcon: true,
  showRightIcon: true,
});
const emits = defineEmits<{
  (e: 'update:modelValue', value: boolean): void;
}>();
const proxy = getCurrentInstance()?.proxy!;
const contentRef = ref<HTMLDivElement>();
const _width = ref<string | number>('100%');
const _duration = ref(0);
const _Left = ref(0);

const _list = computed<string[]>(() => {
  let listData: string[] = [];
  if (typeof props.list === 'string') {
    listData.push(props.list);
  }
  if (typeof props.list === 'object') {
    listData.push((props.list as Record<string, any>)[props.field]);
  }
  if (Array.isArray(props.list)) {
    forEach(props.list, (el) => {
      if (typeof el == 'string') {
        listData.push(el);
      } else if (typeof el == 'object' && props.field) {
        listData.push(el[props.field]);
      }
    });
  }
  return listData;
});

function init() {
  const el = proxy.$el;
  const containerSize = el.getBoundingClientRect();
  _width.value = containerSize.width as number;

  if (props.showRightIcon) {
    _width.value = _width.value - 24;
    _Left.value = Math.ceil(_width.value);
    return;
  }
  _Left.value = _width.value;
}

function setDuration() {
  const oContent = contentRef.value!;
  const size = oContent.getBoundingClientRect();
  const _w = _width.value as number;

  let totalWidth = (size.width + _w) / props.speed;
  _duration.value = Math.ceil(totalWidth);
}

function ready() {
  init();
  setDuration();
}

onMounted(() => {
  ready();
  window.addEventListener('resize', ready);
});

onBeforeUnmount(() => {
  window.removeEventListener('resize', ready);
});
</script>

<template>
  <div
    class="flex flex-row flex-between notice-bar-wrapper relative"
    :style="`padding-right: ${padding}px; height:${height}px; width: 100%`"
    v-if="modelValue"
  >
    <div v-if="showLeftIcon" class="flex flex-row flex-center overflow" style="width: 24px">
      <slot name="showLeftIcon">
        <SoundFilled />
      </slot>
    </div>
    <div class="flex flex-1 flex-row overflow" style="width: 0px">
      <div
        ref="contentRef"
        :style="{
          animationDuration: _duration + 's',
          paddingLeft: _Left + 'px',
        }"
        class="aniRow flex-row flex-start"
      >
        <div
          class="flex-row flex-start"
          v-for="(item, index) in _list"
          :key="index"
          :style="contentStyle"
        >
          <span class="nowrap"> {{ item }} </span>
        </div>
      </div>
    </div>
    <div
      v-if="showRightIcon"
      class="flex flex-row flex-center overflow right-icon"
      @click.stop="emits('update:modelValue', false)"
    >
      <slot name="showRightIcon">
        <CloseOutlined />
      </slot>
    </div>
  </div>
</template>

<style lang="scss" scoped>
.flex {
  display: flex;
}

.relative {
  position: relative;
}

.absolute {
  position: absolute;
}

.flex-row {
  flex-direction: row;
}

.flex-1 {
  flex: 1;
  flex-grow: 1;
}

.flex-between {
  justify-content: space-between;
  align-items: center;
  align-content: center;
}

.flex-start {
  justify-content: flex-start;
  align-items: center;
  align-content: center;
}

.flex-center {
  justify-content: center;
  align-items: center;
  align-content: center;
}

.nowrap {
  white-space: nowrap;
}

.overflow {
  overflow: hidden;
}

.notice-bar-wrapper {
  cursor: default;

  .aniRow {
    animation-name: roll;
    animation-timing-function: linear;
    animation-iteration-count: infinite;
  }

  :not(.right-icon):hover {
    .aniRow {
      animation-play-state: paused;
    }
  }

  .right-icon {
    width: 24px;
    font-size: 12px;
    color: #555;
    height: 100%;

    &:hover {
      cursor: pointer;
      opacity: 0.8;
    }
  }
}

@keyframes roll {
  0% {
    transform: translateX(0);
  }
  100% {
    transform: translateX(-100%);
  }
}
</style>
