<script setup lang="ts">
import { ref, reactive, toRaw, type UnwrapRef } from 'vue';
import {
  theme,
  message,
  Modal,
  Form,
  FormItem,
  Textarea,
  RadioGroup,
  Radio,
  DatePicker,
} from 'ant-design-vue';
import { Upload } from '@lexikos/doraemon-business';
import { Http } from '@lexikos/doraemon-network';
import dayjs from 'dayjs';

interface FeedbackType {
  code: string;
  desc: string;
}

const { token } = theme.useToken();
const useForm = Form.useForm;

const labelCol = { style: { width: '100px' } };
const loading = ref<boolean>();
const open = ref<boolean>(false);
const feedbackType = ref<FeedbackType[]>([]);
const modelRef: UnwrapRef<{
  feedbackType: string;
  content: string;
  imageIds?: string[];
  videoId?: string;
  occurrenceTime: string;
}> = reactive({
  feedbackType: 'exception',
  content: '',
  occurrenceTime: '',
});
const rulesRef = reactive({
  content: [
    { required: true, message: '请输入反馈内容' },
    {
      validator: (_rule: any, value: string) => {
        if (value && !/[^\s]/.test(value)) {
          return Promise.reject(`反馈内容不能全为空白字符`);
        }
        return Promise.resolve();
      },
    },
  ],
});

const { resetFields, validate, validateInfos } = useForm(modelRef, rulesRef, {
  onValidate: (...args) => console.log(...args),
});

const fetchFeedbackType = () => {
  Http.getInstance()
    .get<FeedbackType[]>('/api/data/enum/values?enumName=FeedbackTypeEnum')
    .then((res) => {
      if (res && Array.isArray(res)) {
        feedbackType.value = res;
        modelRef.feedbackType = res[0].code;
      }
    });
};

const handleShowModal = () => {
  if (!feedbackType.value.length) {
    fetchFeedbackType();
  }
  resetFields({
    occurrenceTime: dayjs().format('YYYY-MM-DD HH:mm:ss'),
  });
  open.value = true;
};

const handleImageUploadChange = (files: any[]) => {
  const arrList: string[] = [];
  files.forEach((item) => {
    arrList.push(item.fileId);
  });
  modelRef.imageIds = arrList;
};
const handleVideoUploadChange = (files: any[]) => {
  modelRef.videoId = files && files.length ? files[0].fileId : undefined;
};

const handleOk = () => {
  validate().then(() => {
    const data = toRaw(modelRef);
    loading.value = true;
    Http.getInstance()
      .post('/api/data/feedback', data)
      .then(() => {
        open.value = false;
        message.success('反馈已提交');
      })
      .finally(() => {
        loading.value = false;
      });
  });
};
</script>

<template>
  <slot name="trigger" :show="handleShowModal"></slot>
  <Modal
    v-model:open="open"
    destroy-on-close
    title="意见反馈"
    width="600px"
    :mask-closable="false"
    @ok="handleOk"
  >
    <Form :label-col="labelCol" style="padding: 24px 0">
      <FormItem label="反馈类型">
        <RadioGroup v-model:value="modelRef.feedbackType">
          <Radio v-for="t in feedbackType" :key="t.code" :value="t.code">
            {{ t.desc }}
          </Radio>
        </RadioGroup>
      </FormItem>
      <FormItem label="反馈内容" v-bind="validateInfos.content">
        <Textarea
          v-model:value="modelRef.content"
          :rows="4"
          :maxlength="500"
          placeholder="您可以在这里尽可能详细地描述您的问题（希望达到怎样的效果，解决什么问题），以便于我们更快地处理您的反馈"
        />
        <div
          class="desc"
          :style="{ color: token.colorTextDescription, position: 'absolute', right: '0' }"
        >
          {{ modelRef.content.length || 0 }}/500
        </div>
      </FormItem>
      <FormItem label="上传截图">
        <Upload
          accept=".jpg, .jepg, .png"
          listType="picture-card"
          multiple
          :maxCount="5"
          :maxSize="5120"
          @onChange="handleImageUploadChange"
        />
        <div class="desc" :style="{ color: token.colorTextDescription }">
          支持JPG/PNG格式，最多上传5张，每张大小限制5M
        </div>
      </FormItem>
      <FormItem label="上传视频">
        <Upload
          accept=".mp4"
          listType="picture-card"
          onLineFilePreview
          :maxCount="1"
          :maxSize="51200"
          @onChange="handleVideoUploadChange"
        />
        <div class="desc" :style="{ color: token.colorTextDescription }">
          支持.mp4，视频最大不超过50M
        </div>
      </FormItem>
      <FormItem label="发生时间">
        <DatePicker
          show-time
          v-model:value="modelRef.occurrenceTime"
          value-format="YYYY-MM-DD HH:mm:ss"
          format="YYYY-MM-DD HH:mm"
        />
      </FormItem>
    </Form>
  </Modal>
</template>

<style scoped lang="scss"></style>
