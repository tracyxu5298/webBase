import { renderWithQiankun, qiankunWindow } from 'vite-plugin-qiankun/dist/helper';
import type { QiankunProps } from 'vite-plugin-qiankun/dist/helper';

// localStorage.setItem('version', import.meta.env.BUILDER_NUMBER);

let app: Promise<any> | null;

// 模块联邦
app = import('./bootstrap');

const render = (props?: QiankunProps) => {
  app!.then((res) => res.render(props));
};

if (!qiankunWindow.__POWERED_BY_QIANKUN__) {
  render();
} else {
  renderWithQiankun({
    bootstrap() {
      console.log('[基座] bootstrap lifecycle');
    },
    mount(props: QiankunProps) {
      if (qiankunWindow.__POWERED_BY_QIANKUN__) {
        const { shared } = props;
        shared.setLoading(false);
      }
      console.log('[基座] mount lifecycle, props from main framework', props);
      render(props);
    },
    unmount(props: QiankunProps) {
      const { shared } = props;
      if (shared) {
        const isUnmounting = shared.getUnmounting();
        if (isUnmounting) {
          app!.then((res) => {
            res.destroy();
            app = null;
          });
        }

        const timer = setTimeout(() => {
          shared.setUnmounting(false);
          console.log('[基座] unmount lifecycle, props from main framework', props);
          clearTimeout(timer);
        }, 100);
      }
    },
    update(props: QiankunProps) {
      console.log('[基座] update lifecycle, props from main framework', props);
    },
  });
}
