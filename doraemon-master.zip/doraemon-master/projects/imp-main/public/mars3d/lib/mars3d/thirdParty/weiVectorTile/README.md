# 支持小数据量的geojson、shape文件矢量动态切片，实现贴地

 说明：Cesium VectorTileImageryProvider 支持小数据量的geojson、shape文件矢量动态切片，实现贴地 

 github地址：https://github.com/MikesWei/CesiumVectorTile

 
#####  依赖
* [Cesium](https://github.com/CesiumGS/cesium)
* [turf](https://github.com/Turfjs/turf)
* [shpjs](https://github.com/calvinmetcalf/shapefile-js)
* [proj4js](https://github.com/proj4js/proj4js)
* [text-encoding](https://github.com/inexorabletash/text-encoding)
* [geojson-topojson](https://github.com/JeffPaine/geojson-topojson)
 