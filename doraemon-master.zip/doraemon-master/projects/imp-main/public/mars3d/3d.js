// 第三方类库加载管理js，方便切换lib
/* eslint-disable */
(function () {
  var r = new RegExp('(^|(.*?\\/))(3d.js)(\\?|$)'),
    s = document.getElementsByTagName('script'),
    targetScript;
  for (var i = 0; i < s.length; i++) {
    var src = s[i].getAttribute('src');
    if (src) {
      var m = src.match(r);
      if (m) {
        targetScript = s[i];
        break;
      }
    }
  }

  // cssExpr 用于判断资源是否是css
  var cssExpr = new RegExp('\\.css');

  function inputLibs(list) {
    if (list == null || list.length === 0) {
      return;
    }

    for (var i = 0, len = list.length; i < len; i++) {
      var url = list[i];
      if (cssExpr.test(url)) {
        const css = document.createElement('link');
        css.setAttribute('href', url);
        css.setAttribute('rel', 'stylesheet');
        document.getElementsByTagName('head')[0].appendChild(css);
      } else {
        const script = document.createElement('script');
        script.setAttribute('type', 'text/javascript');
        script.setAttribute('src', url);
        if (url.indexOf('mars3d.js') > -1) {
          var timer = setInterval(() => {
            if (window.Cesium) {
              clearTimeout(timer);
              document.getElementsByTagName('head')[0].appendChild(script);
            }
          }, 200);
          return;
        }
        document.getElementsByTagName('head')[0].appendChild(script);
      }
    }
  }

  //加载类库资源文件
  function load() {
    var arrInclude = (targetScript.getAttribute('include') || '').split(',');
    var libpath = targetScript.getAttribute('libpath') || '';

    //在线lib，开发中请注释下面代码
    // libpath = '//127.0.0.1:4000/lib/';

    var libsConfig = {
      /******************************** Mars3D及其插件 ***************************************/
      mars3d: [
        //三维地球“主库”
        libpath + 'Cesium/Widgets/widgets.css', //cesium
        libpath + 'Cesium/Cesium.js',
        libpath + 'turf/turf.min.js',
        // libpath + 'mars3d/plugins/compatible/cesium-version.js', //cesium版本兼容处理
        libpath + 'mars3d/mars3d.css', //mars3d
        libpath + 'mars3d/mars3d.js',
      ],
      'mars3d-space': [
        //卫星插件
        libpath + 'mars3d/plugins/space/mars3d-space.js',
      ],
      'mars3d-echarts': [
        //echarts支持插件
        libpath + 'echarts/echarts.min.js',
        libpath + 'echarts/echarts-gl/echarts-gl.min.js',
        libpath + 'mars3d/plugins/echarts/mars3d-echarts.js',
      ],
      'mars3d-mapv': [
        //mapv支持插件
        libpath + 'mapV/mapv.min.js',
        libpath + 'mars3d/plugins/mapv/mars3d-mapv.js',
      ],
      'mars3d-heatmap': [
        //heatmap热力图支持插件
        libpath + 'mars3d/plugins/heatmap/heatmap.min.js',
        libpath + 'mars3d/plugins/heatmap/mars3d-heatmap.js',
      ],
      'mars3d-wind': [
        //风场图层插件
        libpath + 'mars3d/plugins/wind/netcdfjs.js', //m10_windLayer解析nc
        libpath + 'mars3d/plugins/wind/mars3d-wind.js',
      ],
      'mars3d-tdt': [
        //天地图三维
        libpath + 'mars3d/plugins/tdt/mars3d-tdt.js',
      ],
      'mars3d-widget': [
        //项目widget模块插件
        libpath + 'mars3d/plugins/widget/mars3d-widget.css',
        libpath + 'mars3d/plugins/widget/mars3d-widget.js',
      ],

      /************************************ cesium相关第3方插件 ***********************************/
      'cesium-pbf': [
        libpath + 'mars3d/thirdParty/pbf/ol.js',
        libpath + 'mars3d/thirdParty/pbf/olms.js',
        libpath + 'mars3d/thirdParty/pbf/mvt.js',
        libpath + 'mars3d/thirdParty/pbf/style/MapboxStreetsV6.js',
      ],
      'cesium-weiVectorTile': [
        // 项目矢量瓦片方式加载GeoJson插件
        'mars3d/thirdParty/weiVectorTile/CesiumVectorTile.min.js',
        'mars3d/thirdParty/weiVectorTile/WeiVectorTileLayer.js',
      ],
      'cesium-meshVisualizer': [
        libpath + 'three/three.js',
        libpath + 'ammo/ammo.js',
        libpath + 'mars3d/thirdParty/meshVisualizer/CesiumMeshVisualizer.js',
      ],
      olcesium: [libpath + 'ol/ol.css', libpath + 'ol/ol.js', libpath + 'ol/ol-cesium/olcesium.js'],

      /********************************  其他库 ********************************/
      haoutil: [libpath + 'hao/haoutil.js'],
      localforage: [libpath + 'localforage/localforage.js'],
    };

    var keys = {};
    for (var i = 0, len = arrInclude.length; i < len; i++) {
      var key = arrInclude[i];

      if (keys[key]) {
        //规避重复引入lib
        continue;
      }
      keys[key] = true;

      inputLibs(libsConfig[key]);
    }
  }

  load();
})();
