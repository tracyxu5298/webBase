#!/bin/sh

hostname
pwd
yarn install

# $1: main|data|organization|platform $2:dev|test|test2|test3|pre|prod 
yarn build:$1 --mode $2