# GitLab NPM Registry

- [Publishing your private npm packages to Gitlab NPM Registry](https://shivamarora.medium.com/publishing-your-private-npm-packages-to-gitlab-npm-registry-39d30a791085)
- Gitlab NPM Registry supports only `scoped packages`.
- For example, if your project url is `https://gitlab.com/my-org/second-group/my-project`, the root namespace is `my-org`. So you must use `my-org` as the scope name for your package. `@my-org/my-package-name`

1.  公共包工程项目，开启 `Package Registry` 配置

    1. 展开配置`Settings > General > Visibility, project features, permissions`
    2. 开启`Repository > Packages`设置（默认已开启）

2.  公共包工程项目，设置 `Package Registry` 授权

    1. 展开配置`Settings > Repository > Deploy Tokens`
    2. 在`Name`选项中，设置唯一名称，比如 `gitlab-deploy-token-linbin`
    3. 在`Scopes`选项中，选择`read_package_registry`和`write_package_registry`权限
    4. 生成`username`，如 `gitlab+deploy-token-8`，保存到本地
    5. 生成`token`，如 `ofePyQzgmfQz-_Ybk1qw`，保存到本地（刷新会不可见）

3.  公共包工程项目，更新`package.json`信息

    ```json
    // Domain: GitLab 公司部署的域名
    // <project-id>: 来自公共包工程项目，`Project overview > Details`, 如 `5581`
    {
      "name": "@lexikos/my-lib",
      "version": "0.1.0",
      "publishConfig": {
        // If using npm or lerna
        "@lexikos:registry": "https://iotgit.leedarson.com/api/v4/projects/5581/packages/npm/",
        // If using yarn or yarn workspaces
        "registry": "http://iotgit.leedarson.com/api/v4/projects/5581/packages/npm/"
      }
    }
    ```

4.  公共包工程项目，创建 `.npmrc` 配置文件

    ```shell
      # Authenticate to the Package Registry


      # Project-level npm endpoint
      # http://iotgit.leedarson.com/help/user/packages/npm_registry/index#project-level-npm-endpoint

      # Set URL for your scoped packages.
      # For example package with name `@foo/bar` will use this URL for download
      # npm config set @foo:registry https://gitlab.example.com/api/v4/projects/<project_id>/packages/npm/
      # @lexikos:registry=http://iotgit.leedarson.com/api/v4/projects/5581/packages/npm/

      # Add the token for the scoped packages URL. Replace <project_id>
      # with the project where your package is located.
      # npm config set '//gitlab.example.com/api/v4/projects/<project_id>/packages/npm/:_authToken' "<project_deploy_token>"
      '//iotgit.leedarson.com/api/v4/projects/5581/packages/npm/:_authToken'="xu74z8Wyos73k2Qt3rZ8"


      # Instance-level npm endpoint
      # http://iotgit.leedarson.com/help/user/packages/npm_registry/index#instance-level-npm-endpoint

      # Set URL for your scoped packages.
      # For example package with name `@foo/bar` will use this URL for download
      # npm config set @foo:registry https://gitlab.example.com/api/v4/packages/npm/
      @lexikos:registry=http://iotgit.leedarson.com/api/v4/packages/npm/

      # Add the token for the scoped packages URL. This will allow you to download
      # `@foo/` packages from private projects.
      # npm config set '//gitlab.example.com/api/v4/packages/npm/:_authToken' "<root_group_deploy_token>"
      '//iotgit.leedarson.com/api/v4/packages/npm/:_authToken'="y56oZMhcYyxaQrgVywqh"


      # 跨仓库下载包, 添加`<root_group_deploy_token>`
      # error Couldn't find package "@lexikos/school-affairs-widgets" on the "npm" registry.
      '//iotgit.leedarson.com/api/v4/projects/:_authToken'="y56oZMhcYyxaQrgVywqh"
    ```

5.  公共包工程项目，构建包 `yarn build`

6.  公共包工程项目，发布包 `npm publish` 或 `yarn publish`

    ```shell
      # 如果固定授权
      npm publish
      # Using npm
      GITLAB_AUTH_TOKEN=$AUTH_TOKEN npm publish
      # Using yarn
      GITLAB_AUTH_TOKEN=$AUTH_TOKEN yarn publish
      # Using yarn workspaces
      GITLAB_AUTH_TOKEN=$AUTH_TOKEN yarn workspace @my-org/my-package publish
      # Using lerna
      GITLAB_AUTH_TOKEN=$AUTH_TOKEN lerna publish
    ```

7.  应用工程使用

    1. Registry setup

       ```shell
         # npm command
         echo @lexikos:registry=http://iotgit.leedarson.com/api/v4/packages/npm/ >> .npmrc
         # yarn command
         echo \"@lexikos:registry\" \"http://iotgit.leedarson.com/api/v4/packages/npm/\" >> .yarnrc
       ```

    2. Installation

       ```shell
         # npm command
         npm i @lexikos/my-lib
         # yarn command
         yarn add @lexikos/my-lib
       ```

8.  错误处理

    1.  发布`Vue`组件包，报`read ECONNRESET`错误

        ```bash
        npm ERR! code ECONNRESET
        npm ERR! syscall read
        npm ERR! errno ECONNRESET
        npm ERR! network request to http://iotgit.leedarson.com/api/v4/projects/5581/packages/npm/@lexikos%2fdoraemon-desktop-components failed, reason: read ECONNRESET
        npm ERR! network This is a problem related to network connectivity.
        npm ERR! network In most cases you are behind a proxy or have bad network settings.
        npm ERR! network
        npm ERR! network If you are behind a proxy, please make sure that the
        npm ERR! network 'proxy' config is set properly.  See: 'npm help config'
        ```

        解答：因为`npm init vite@latest`命令安装的`Vue`工程的`README.md`格式有问题，只需要修改或删除`README.md`文件即可。

    2.  yarn 安装包时，报`404 Not Found`错误

        ```bash
          # error An unexpected error occurred: "http://iotgit.leedarson.com/api/v4/projects/5598/packages/npm/@lexikos/school-affairs-widgets/-/@lexikos/school-affairs-widgets-0.1.0.tgz: Request failed \"404 Not Found\"".
          # info If you think this is a bug, please open a bug report with the information provided in "/Users/linbin/Desktop/work/doraemon/projects/imp-main/yarn-error.log".
          # info Visit https://yarnpkg.com/en/docs/cli/add for documentation about this command.
          # error Command failed.
        ```

        解答：添加`.yarnrc`两个配置，参考官方文档 [Error running Yarn with the Package Registry for npm registry](https://docs.gitlab.com/ee/user/packages/yarn_repository/#error-running-yarn-with-the-package-registry-for-the-npm-registry)

    3.  yarn 安装包时，报`Couldn't find package`错误

        ```bash
          # error Couldn't find package "@lexikos/school-affairs-widgets" on the "npm" registry.
          # info Visit https://yarnpkg.com/en/docs/cli/add for documentation about this command.
          # error Command failed.
        ```

        解答：`.npmrc`添加如下配置

        ```bash
          @lexikos:registry="http://iotgit.leedarson.com/api/v4/packages/npm/"
          '//iotgit.leedarson.com/api/v4/projects/:_authToken'="<root_group_deploy_token>"
          '//iotgit.leedarson.com/api/v4/packages/npm/:_authToken'="<root_group_deploy_token>"
          '//iotgit.leedarson.com/api/v4/projects/<project_id>/packages/npm/:_authToken'="<project_deploy_token>"
        ```

        ```bash
          "@lexikos:registry" "http://iotgit.leedarson.com/api/v4/packages/npm/"
          "//iotgit.leedarson.com/api/v4/projects/<project_id>/packages/npm/:_authToken" "<project_deploy_token>"
          "//iotgit.leedarson.com/api/v4/packages/npm/:_authToken" "<root_group_deploy_token>"
        ```
