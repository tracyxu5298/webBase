# stylelint

1. 安装依赖包

安装相关依赖包，如果你的项目中使用了 less 而不是 scss 则将下面命令中的 scss 全部换为 less

```shell
yarn add stylelint postcss postcss-scss postcss-html stylelint-prettier stylelint-config-recommended-scss stylelint-config-standard stylelint-config-standard-vue stylelint-scss stylelint-order -D -W
```

- stylelint: css 样式 lint 工具, 用户检测样式文件(.css文件)
- postcss: 转换 css 代码工具
- postcss-scss: 识别 scss 语法的插件
- postcss-html: 识别 html/vue 中的 <style></style> 标签中的样式
- stylelint-config-standard: Stylelint的标准可共享配置规则，详细可查看官方文档
- stylelint-prettier: 关闭所有不必要或可能与 Prettier 冲突的规则
- stylelint-config-recommended-scss: scss的推荐可共享配置规则，详细可查看官方文档
- stylelint-config-standard-vue: lint.vue文件的样式配置
- stylelint-scss: stylelint-config-recommended-scss 的依赖，scss 的 stylelint 规则集合
- stylelint-order: 指定样式书写的顺序，在 .stylelintrc.js 中 order/properties-order 指定顺序

2. 添加`.stylelintrc.js`配置文件

3. 在 `package.json` 文件中增加脚本命令

```json
{
  "scripts": {
    "lint:js": "eslint . --ext .js,.jsx,.ts,.tsx,.vue --fix",
    "lint:css": "stylelint \"./**/*.{css,scss,sass,vue,html}\" --fix",
    "lint": "npm run lint:js & npm run lint:css"
  }
}
```

- lint:js 使用 eslint 检测项目中的 vue、js、jsx、ts、tsx 代码。
- lint:js:fix 脚本代码格式化，一般搭配 eslint 命令使用。
- lint:css 使用 stylelint 检测项目中的样式文件和其他样式规则的书写
- lint:css:fix 样式代码格式化，一般搭配 stylelint 命令使用。
- lint 同时检测样式代码和脚本代码(相当于同时执行了eslint和stylelint)。
- lint:fix 代码格式化，一般搭配 lint 命令使用。

5. VSCode 安装 Stylelint 插件
   安装该插件可在我们保存代码时自动执行 stylelint
   `/.vscode/settings.json`配置如下
   ```json
   {
     // 开启自动修复
     "editor.codeActionsOnSave": {
       "source.fixAll.stylelint": true
     },
     // stylelint 校验的文件格式
     "stylelint.validate": ["css", "scss", "vue", "html"]
   }
   ```
