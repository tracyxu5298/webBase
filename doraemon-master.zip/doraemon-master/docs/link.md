# link

```shell
# 公共包，生成`link`链接，需要进入`工程目录`执行命令
yarn link
# 公共包，删除`link`链接，需要进入`工程目录`执行命令
yarn unlink
# 查看`link`列表
ls $HOME/.config/yarn/link
```

```shell
# 应用工程，关联`link`链接
yarn link @lexikos/my-lib
# 不同仓库，本地调试，步骤如下，参考`debugging.md`文档
# 1. 公共包，需要配置`src`模块解析路径
# 2. 应用工程，需要配置`mainFields`模块解析优先级
```

```shell
# 添加`link`仓库，会添加绝对路径，会导致 1. 开发者的路径不同 2. 操作系统 MacOS 和 Windows 路径无法兼容
yarn add link:$HOME/.config/yarn/link/xxx
# `package.json` 依赖配置如下
# "desktop-components": "link:/Users/linbin/.config/yarn/link/xxx"

# 添加`GitHub`仓库, 因为跟 NPM Registry 有挂钩，所以可以添加。但是私有 GitLab 无法添加。
yarn add https://github.com/vuejs/vuex.git
# `package.json` 依赖配置如下
# "vuex": "https://github.com/vuejs/vuex.git"
```
