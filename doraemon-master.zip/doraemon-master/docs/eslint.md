# eslint

[在vue3+ts项目中配置eslint、stylelint和commitlint](https://juejin.cn/post/7147326774903308296#heading-3)
[vue3+ts+vite项目中使用eslint+prettier+stylelint+husky指南](https://juejin.cn/post/7118294114734440455#heading-2)

1. 安装依赖包

```shell
yarn add eslint -D -W
```

2. 初始化配置

```shell
# 生成`.eslintrc.js`配置文件
npm init @eslint/config

# ✔ How would you like to use ESLint? · problems
# ✔ What type of modules does your project use? · esm
# ✔ Which framework does your project use? · vue
# ✔ Does your project use TypeScript? · Yes
# ✔ Where does your code run? · browser
# ✔ What format do you want your config file to be in? · JavaScript
# Local ESLint installation not found.
# The config that you've selected requires the following dependencies:

# @typescript-eslint/eslint-plugin@latest eslint-plugin-vue@latest @typescript-eslint/parser@latest eslint@latest
# ✔ Would you like to install them now? · No
# ✔ Which package manager do you want to use? · yarn
# Installing @typescript-eslint/eslint-plugin@latest, eslint-plugin-vue@latest, @typescript-eslint/parser@latest, eslint@latest
```

- eslint: JavaScript 和 JSX 检查工具
- eslint-plugin-vue: 使用 ESLint 检查 .vue 文件的 `<template>` 和 `<script>`，以及.js文件中的Vue代码

3. 在根目录 `package.json` 中增加脚本命令

```json
{
  "scripts": {
    "lint": "yarn workspaces run lint"
  }
}
```

4. 在子工程 `package.json` 中增加脚本命令

```json
{
  "scripts": {
    // "lint:js": "eslint --ext .vue,.js,.jsx,.cjs,.mjs,.ts,.tsx,.cts,.mts --fix src/"
    "lint:js": "eslint . --ext .vue,.js,.ts,.jsx,.tsx --fix"
  }
}
```

5. 删除子工程配置文件，全部统一采用根目录配置规则

6. VSCode 安装 ESLint 插件
   如果写一行代码就要执行一遍lint命令，这效率就太低了。所以我们可以配合vscode的ESLint插件，实现每次保存代码时，自动执行lint命令来修复代码的错误。
   `/.vscode/settings.json`配置如下
   ```json
   {
     // 开启自动修复
     "editor.codeActionsOnSave": {
       "source.fixAll.eslint": true
     }
   }
   ```
