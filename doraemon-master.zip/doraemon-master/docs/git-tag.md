# Git Tag

1. 创建

```shell
git tag -a v7.0.0 -m 'version 7.0.0'
```

2. 推送

```shell
# 本地全部标签
git push origin --tags
# 推送具体标签
git push origin tag v7.5.0
```

3. 删除

```shell
# delete local tag 'v0.1.0'
git tag -d v0.1.0
```
