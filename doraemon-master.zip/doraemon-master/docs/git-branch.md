# Git Branch

1. 删除本地分支

```shell
git branch -D hotfix/v7.0.8
```

2. 删除远程分支

```shell
git push origin --delete hotfix/v7.0.8
```
