# 创建应用工程

创建应用工程，`Vue`脚手架比`Vite`脚手架好，因为可以把`Router`和`Pinia`等初始化。

```shell
cd projects
npm create vue@latest

# Need to install the following packages:
#   create-vue@3.7.4
# Ok to proceed? (y) y

# Vue.js - The Progressive JavaScript Framework

# ✔ Project name: … xxx
# ✔ Add TypeScript? …  Yes
# ✔ Add JSX Support? … Yes
# ✔ Add Vue Router for Single Page Application development? … Yes
# ✔ Add Pinia for state management? … Yes
# ✔ Add Vitest for Unit Testing? … No
# ✔ Add an End-to-End Testing Solution? › No
# ✔ Add ESLint for code quality? … Yes
# ✔ Add Prettier for code formatting? … Yes
```
