# husky

虽然已经配置好了eslint、prettier与stylelint，但是还是存在以下问题。

1. 对于不使用vscode的，或者没有安装eslint、prettier与stylelint插件的同学来说，就不能实现在保存的时候自动的去修复与和格式化代码。
2. 这样提交到git仓库的代码还是不符合要求的。因此需要引入强制的手段来保证提交到git仓库的代码时符合我们的要求的。

husky是一个用来管理git hook的工具，git hook即在我们使用git提交代码的过程中会触发的钩子。

1. 添加依赖包

```shell
yarn add husky lint-staged -D -W
```

2. 在根目录 `package.json` 中增加脚本命令

可以用此命令添加脚本 `npm pkg set scripts.prepare="husky install"`

```json
{
  "scripts": {
    "prepare": "husky install"
  }
}
```

`prepare`: 在两种情况前运行，一是`npm publish`命令前，二是不带参数的`npm install`命令；它会在`prepublish`之后、`prepublishOnly`之前执行。

该命令会在`yarn install`之后运行，这样其他克隆该项目的同事就在装包的时候就会自动执行该命令来安装`husky`。这里我们就不重新执行`yarn install`了，直接执行`yarn prepare`，这个时候你会发现多了一个.husky目录。

3. 使用 husky 命令添加 Git Hook 钩子

```shell
yarn husky add .husky/commit-msg "node scripts/validate-commit-msg.js"
yarn husky add .husky/pre-commit "yarn lint-staged"
yarn husky add .husky/pre-push "yarn lint"
```

4. 添加`.lintstagedrc.js`配置文件

5. 检查 Git Staged Changes 文件规范

```shell
yarn lint-staged
```
