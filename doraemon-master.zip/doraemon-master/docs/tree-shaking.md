# tree shaking

[深入理解sideEffects配置](https://libin1991.github.io/2019/05/01/%E6%B7%B1%E5%85%A5%E7%90%86%E8%A7%A3sideEffects%E9%85%8D%E7%BD%AE/)

## sideEFfects 作用

```ts
// utils/a.js
export function a() {
  console.log('aaaaaaaaaaaaa');
}

// utils/b.js
console.log('======== b.js =========='); // 1. 具有副作用代码
export function b() {
  console.log('bbbbbbbbbbbbbb');
}

// utils/index.js
export * from './a';
export * from './b';

// app.js
import { a } from './utils';
a();

// output
(function () {
  'use strict';
  console.log('======== b.js =========='); // 2. 包含副作用代码
  console.log('aaaaaaaaaaaaa');
})();

// 3. 修改package.json配置, 新增字段 "sideEffects": false, 该字段表明整个工程是”无副作用”的
// output
(function () {
  'use strict';
  // 3. 无副作用代码
  console.log('aaaaaaaaaaaaa');
})();
```

## sideEffects 配置

sideEffects 除了能设置 boolean 值, 还可以设置为数组, 传递需要保留副作用的代码文件(例如: `./src/polyfill.js`) 或者传递模糊匹配符(例如: `src/**/*.css`)

```ts
// package.json
sideEffects: boolean | string[]
```

## sideEffects 注意事项

实际项目中, 通常并不能简单的设置为 `"sideEffects": false`, 有些副作用是需要保留的, 比如引入样式文件。
`webpack` 会认为所有 `import 'xxx'` 语句是仅引入而未使用, 如果你错误的将其声明成了”无副作用”, 它们就会被 `tree-shaking` 掉, 并且由于 `tree-shaking` 仅在 `production` 模式生效, 本地开发时可能一切仍是正常的, 生产环境并不能及时发现问题.

```json
{
  "sideEffects": ["./src/**/*.css", "./src/**/*.scss"]
}
```

## sideEffects 局限性

sideEffects 配置是以文件为维度的, 只要你配置了文件具备副作用, 即便你只用了该文件中没有副作用的那部分功能, 仍然会将副作用保留。

```ts
Object.defineProperty(Array.prototype, 'sum', {
  value: function () {
    return this.reduce(((sum, num) = sum += num), 0);
  },
});
export function b() {
  console.log([1, 2, 3, 4].sum());
}
export function c() {
  console.log('ccccccccccccccccccc');
}

// 结果: 在 app.js 中仅引入 c 方法, b 方法会被 tree-shaking, 但 sum 方法不会。
```
