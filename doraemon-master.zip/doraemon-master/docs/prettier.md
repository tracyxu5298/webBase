# prettier

1. 添加依赖 `yarn add prettier -D -W`

2. 添加根目录文件 `.prettierrc` + `.prettierignore`

3. 删除子工程文件配置文件，全部统一采用根目录配置规则

4. 在根目录 `package.json` 文件中增加脚本命令

```json
{
  "scripts": {
    "format": "yarn workspaces run format"
  }
}
```

5. 在子工程 `package.json` 文件中增加脚本命令

```json
{
  "scripts": {
    "format": "prettier . --write"
  }
}
```

6. VSCode 安装 Prettier 插件
   安装该插件的目的是，让该插件在我们保存的时候自动完成格式化
   `/.vscode/settings.json`配置如下
   ```json
   {
     // 保存的时候自动格式化
     "editor.formatOnSave": true,
     // 默认格式化工具选择 prettier
     "editor.defaultFormatter": "esbenp.prettier-vscode"
   }
   ```

## 解决 eslint 与 prettier 的冲突

[vue3+ts+vite项目中使用eslint+prettier+stylelint+husky指南](https://juejin.cn/post/7118294114734440455#heading-16)

在理想的状态下，eslint与prettier应该各司其职。eslint负责我们的代码质量，prettier负责我们的代码格式。但是在使用的过程中会发现，由于我们开启了自动化的eslint修复与自动化的根据prettier来格式化代码。所以我们保存代码，会出现屏幕闪一起后又恢复到了报错的状态。
这其中的根本原因就是eslint有部分规则与prettier冲突了，所以保存的时候显示运行了eslint的修复命令，然后再运行prettier格式化，所以就会出现屏幕闪一下然后又恢复到报错的现象。这时候你可以检查一下是否存在冲突的规则。
查阅资料会发现，社区已经为我们提供了一个非常成熟的方案，即eslint-config-prettier + eslint-plugin-prettier。

1. 安装依赖包

```shell
yarn add eslint-config-prettier eslint-plugin-prettier -D -W
```

- eslint-plugin-prettier：基于 prettier 代码风格的 eslint 规则，即 eslint 使用 prettier 规则来格式化代码。
- eslint-config-prettier：禁用所有与格式相关的 eslint 规则，解决 prettier 与 eslint 规则冲突，确保将其放在 extends 队列最后，这样它将覆盖其他配置

2. 在`.eslintrc.js`中`extends`的最后添加一个配置

```json
{
  "extends": [
    // 新增，必须放在最后面
    "plugin:prettier/recommended"
  ]
}
```
