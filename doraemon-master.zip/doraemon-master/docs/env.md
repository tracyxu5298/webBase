# 环境变量

1. 变量之，应用工程版本号（方法一）

   1. [Vite官网 -> 共享选项 -> define](https://cn.vitejs.dev/config/shared-options.html#define)
   2. `vite.config.ts`增加全局变量
      ```ts
      export default defineConfig({
        define: {
          __APP_VERSION__: JSON.stringify(process.env.npm_package_version),
        },
      });
      ```
   3. `env.d.ts`或`vite-env.d.ts`添加类型声明
      ```ts
      declare const __APP_VERSION__: string;
      ```
   4. 应用工程使用
      ```ts
      console.log(__APP_VERSION__);
      ```

2. 变量之，应用工程版本号（方法二）

   1. [Vite官网 -> 环境变量与模式 -> .env文件](https://cn.vitejs.dev/guide/env-and-mode.html#env-files)
   2. 创建`.env`文件，添加配置
      ```shell
      # 为了防止意外地将一些环境变量泄漏到客户端，只有以 `VITE_` 为前缀的变量才会暴露给经过 vite 处理的代码。
      # VITE_SOME_KEY=123
      # DB_PASSWORD=foobar
      # console.log(import.meta.env.VITE_SOME_KEY) // 123
      # console.log(import.meta.env.DB_PASSWORD) // undefined
      VITE_APP_VERSION=$npm_package_version
      ```
   3. `env.d.ts`或`vite-env.d.ts`添加类型声明
      ```ts
      interface ImportMetaEnv {
        readonly VITE_APP_VERSION: string;
      }
      interface ImportMeta {
        readonly env: ImportMetaEnv;
      }
      ```
   4. 应用工程使用
      ```ts
      console.log(import.meta.env.VITE_APP_VERSION);
      ```

3. 常量之，服务端环境（方法一）

   1. [Vite官网 -> 环境变量与模式 -> 环境变量](https://cn.vitejs.dev/guide/env-and-mode.html#env-variables)
   2. 运行脚本时，添加参数
      ```shell
      yarn dev --mode=dev
      ```
   3. 应用工程使用
      ```ts
      console.log(import.meta.env.MODE);
      ```

4. 常量之，服务端环境（方法二）

   1. [Vite官网 -> 环境变量与模式 -> .env文件](https://cn.vitejs.dev/guide/env-and-mode.html#env-files)
   2. 创建`.env.[mode]`文件
      ```
      VITE_SEVER_ENV=dev
      ```
   3. `env.d.ts`或`vite-env.d.ts`添加类型声明
      ```ts
      interface ImportMetaEnv {
        readonly VITE_SEVER_ENV: string;
      }
      interface ImportMeta {
        readonly env: ImportMetaEnv;
      }
      ```
   4. 应用工程使用
      ```ts
      console.log(import.meta.env.VITE_SEVER_ENV);
      ```

## .env 文件说明

- [Vite官网 - 指引 - 环境变量与模式 - .env 文件](https://cn.vitejs.dev/guide/env-and-mode.html#env-files)

1. Vite 使用`dotenv`从你的`环境目录`中的下列文件加载额外的环境变量：

   ```shell
   .env                # 所有情况下都会加载
   .env.local          # 所有情况下都会加载，但会被 git 忽略
   .env.[mode]         # 只在指定模式下加载
   .env.[mode].local   # 只在指定模式下加载，但会被 git 忽略
   ```

2. 环境加载优先级

   1. 一份用于指定模式的文件（例如 `.env.production`或`.env.[mode]`）会比通用形式的优先级更高（例如 `.env`）。
   2. 命令执行时的环境变量有最高的优先级，不会被 `.env` 类文件覆盖。例如当运行 `VITE_SOME_KEY=123 vite build` 的时候。
      `VITE_SERVER_URL=111 yarn dev`
      `VITE_SERVER_URL=222 yarn vite dev`
      `VITE_SERVER_URL=333 yarn build`
      `VITE_SERVER_URL=444 yarn vite build`
      环境变量会通过`import.meta.env.VITE_SERVER_URL`字符串形式暴露给客户端源码。
      需要为`env.d.ts`或`vite-env.d.ts`添加类型声明。
   3. `.env` 类文件会在 Vite 启动一开始时被加载，而改动会在重启服务器后生效。

3. 命名规则，为了防止意外地将一些环境变量泄漏到客户端，只有以 `VITE_` 为前缀的变量才会暴露给经过 vite 处理的代码。

   ```shell
    VITE_SOME_KEY=123
    DB_PASSWORD=foobar
   ```

   ```ts
   console.log(import.meta.env.VITE_SOME_KEY); // 123
   console.log(import.meta.env.DB_PASSWORD); // undefined
   ```

4. Vite 使用 `dotenv-expand` 来直接拓展变量。想要了解更多相关语法，请查看它们的文档。
   请注意，如果想要在环境变量中使用 `$` 符号，则必须使用 `\` 对其进行转义。

   ```shell
    KEY=123
    NEW_KEY1=test$foo   # test
    NEW_KEY2=test\$foo  # test$foo
    NEW_KEY3=test$KEY   # test123
   ```
