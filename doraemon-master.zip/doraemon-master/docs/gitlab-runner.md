# GitLab Runner

[Install GitLab Runner on macOS](https://docs.gitlab.com/runner/install/osx.html)
[Set up a specific runner manually](http://iotgit.leedarson.com/lexikos/frontend/my-lib/-/settings/ci_cd)

1. Download the binary for your system

```shell
sudo curl --output /usr/local/bin/gitlab-runner "https://gitlab-runner-downloads.s3.amazonaws.com/latest/binaries/gitlab-runner-darwin-arm64"
```

2. Give it permissions to execute

```shell
sudo chmod +x /usr/local/bin/gitlab-runner
```

3. As the user who will run the runners

```shell
# The rest of commands execute as the user who will run the Runner
cd ~

gitlab-runner install
# Runtime platform arch=arm64 os=darwin pid=50763 revision=4e724e03 version=16.4.0

gitlab-runner start
# Runtime platform arch=arm64 os=darwin pid=50771 revision=4e724e03 version=16.4.0
```

4. Register Runner

```shell
# Specific runners
sudo gitlab-runner register --url http://iotgit.leedarson.com/ --registration-token 1mryxymSMzb8y9-1hVGw
# Shared runners
sudo gitlab-runner register --url http://iotgit.leedarson.com/ --registration-token ats62FqgU5LgJR7qcus-

# Runtime platform arch=arm64 os=darwin pid=50797 revision=4e724e03 version=16.4.0
# Running in system-mode.

# Created missing unique system ID system_id=s_09717a0775e3
# Enter the GitLab instance URL (for example, https://gitlab.com/):
# [http://iotgit.leedarson.com/]:

# Enter the registration token:
# [1mryxymSMzb8y9-1hVGw]:

# Enter a description for the runner:
# [administratordeMac-mini-2.local]: Mac mini M1 Pack Server

# Enter tags for the runner (comma-separated):
# MacMiniM1PackServer

# Enter optional maintenance note for the runner:
# Frontend CI/CD Runner

# WARNING: Support for registration tokens and runner parameters in the 'register' command has been deprecated in GitLab Runner 15.6 and will # be replaced with support for authentication tokens. For more information, see https://docs.gitlab.com/ee/ci/runners/new_creation_workflow

# Registering runner... succeeded runner=1mryxymS

# Enter an executor: parallels, shell, ssh, virtualbox, docker+machine, instance, custom, docker, docker-windows, docker-autoscaler, # kubernetes:
# shell

# Runner registered successfully. Feel free to start it, but if it's running already the config should be automatically reloaded!

# Configuration (with the authentication token) was saved in "/etc/gitlab-runner/config.toml"
# sudo cat /etc/gitlab-runner/config.toml
# sudo vim /etc/gitlab-runner/config.toml
# concurrent = 10

# The GitLab Runner configuration file (config.toml) is in /Users/<username>/.gitlab-runner/config.toml
```

5. 根目录创建`.gitlab-ci.yml`配置文件

```yml
default:
  tags:
    - MacMiniM1PackServer #  Settings --> CI/CD --> Runners --> Shared runners

build-job:
  stage: build
  script:
    - echo "Hello, $GITLAB_USER_LOGIN!"

test-job1:
  stage: test
  script:
    - echo "This job tests something"

test-job2:
  stage: test
  script:
    - echo "This job tests something, but takes more time than test-job1."
    - echo "After the echo commands complete, it runs the sleep command for 20 seconds"
    - echo "which simulates a test that runs 20 seconds longer than test-job1"
    - sleep 20

deploy-prod:
  stage: deploy
  script:
    - echo "This job deploys something from the $CI_COMMIT_BRANCH branch."
  environment: production
```

## 问题处理

1. 黑色三角感叹号, 提示 "New runner. Has not connected yet."

```shell
sudo gitlab-runner verify
```

2. `CI /CD --> Pipelines` 一直显示 `Pending` 状态

```shell
# 没有`&`，表求前台运行
sudo gitlab-runner run
# 增加`&`，表示后台运行，可以关闭`Terminal`终端
sudo gitlab-runner run &
```
