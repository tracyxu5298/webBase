# 本地调试

## 公共包

1. 公共包`package.json`导出配置

```json
{
  "private": false,
  "version": "0.1.0",
  "type": "module",
  "license": "MIT",
  "main:src": "./src/main.ts", // 本地调试，模块解析路径，需要把`exports`配置去掉，因为此配置优先级更高
  "main": "./dist/desktop-components.umd.js",
  "module": "./dist/desktop-components.es.js",
  "types": "./dist/main.d.ts",
  "peerDependencies": {
    "vue": "3.x"
  }
}
```

2. 公共包`vite.config.ts`打包配置

```ts
import { resolve } from 'path';
import { defineConfig } from 'vite';
import vue from '@vitejs/plugin-vue';
import dts from 'vite-plugin-dts';
import packageJson from './package.json';

export default defineConfig({
  plugins: [vue(), dts()],
  build: {
    lib: {
      entry: resolve(__dirname, 'src/main.ts'),
      name: 'desktopComponents',
      formats: ['es', 'umd'],
      fileName: (format) => `desktop-components.${format}.js`,
    },
    sourcemap: true,
    rollupOptions: {
      external: [...Object.keys(packageJson.peerDependencies)],
    },
  },
});
```

如果上面配置`import packageJson from './package.json';`解析报错，公共包`tsconfig.node.json`修改路径解析配置

```json
{
  "include": ["vite.config.ts", "package.json"]
}
```

## 相同仓库，本地调试

1. 应用工程，添加依赖包

```shell
yarn workspace project1 add @lexikos/desktop-components@0.1.0
```

2. 应用工程，配置模块解析优先级 `vite.config.ts`

```ts
export default defineConfig({
  resolve: {
    mainFields: ['main:src', 'module', 'main'], // 本地调试，模块解析优先级
  },
});
```

## 不同仓库，本地调试

1. 公共包，配置模块解析路径，同上

2. 公共包，生成`link`链接，需要进入根目录执行命令

```shell
yarn link
```

2. 应用工程，配置模块解析优先级，同上

3. 应用工程，关联`link`链接，需要进入根目录执行命令

```shell
yarn link @lexikos/desktop-component
```
