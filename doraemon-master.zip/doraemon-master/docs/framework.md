# 使用说明

## Git 全局设置

```shell
git config --global user.name "linbin"
git config --global user.email "linbin@leedarson.com"
# git config --list
# git config --get user.name
```

## Git 提交代码

```shell
# git add README.md
git add .
git commit -m "Initial commit"
git push -u origin main
```

## Yarn workspaces

```json
{
  "private": true,
  "workspaces": ["packages/*", "projects/*"]
}
```

## 确保依赖版本一样

```shell
yarn workspace desktop-components add typescript -D
yarn workspace mobile-components add typescript -D
yarn workspace project1 add typescript -D
yarn workspace project2 add typescript -D
```

## 添加必要文件

- .editorconfig
- .gitignore
- .yarnrc

## 安装依赖

```shell
yarn install

# yarn config get registry
# yarn config set registry <url-to-your-registry>
# yarn config delete registry
# yarn config list

# npm config get registry
# npm config set registry <url-to-your-registry>
# npm config delete registry
# npm config list
```

## 本地调试

```json
{
  "scripts": {
    "start:project1": "cd ./projects/project1 && yarn dev",
    "start:project2": "cd ./projects/project2 && yarn dev",
    "start:helper": "cd ./packages/helper && yarn start"
  }
}
```

## 发布构建

## commitlint

## vite

1. 在浏览器中暴露 ESLint 问题，会导致无浏览弊端，暂时去掉

```ts
// yarn workspaces project1 add vite-plugin-eslint -D
import { defineConfig } from 'vite';
import eslint from 'vite-plugin-eslint';

export default defineConfig({
  plugins: [eslint()],
});
```
