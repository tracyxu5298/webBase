# 新旧应用融合

> 因`前端技术栈`整体切换`vue技术栈`,以及产品线整体升级，蜕变成一个全新的vue基座(后面统称基座`doraemon-main`)，所以imp原来的微应用（后面统称`imp应用`）需要接入至新基座(`doraemon-main`)；
> 案例以`智慧物联`和`学习平台`接入的，下面的规则也是在这个过程中遇到的问题，并做如下描述：

```ts
                                                                                     proxy rules
                                                               +------------------------------------------------------+
             +----------+                                      |                                                      |
             |          |                                      v                 fetch index.html  +-----------+      |
micro config |   +------v--------+                     +-------+-------+        +----------------+ | digital   |      |
escape strategy  |               |                     |               |        |                  +-----------+      |
             |   | doraemon-main | <-----------------+ |     vite      | <--+---+                                     |
             |   |               |    inject js&cdn    |               |    |   ^                                     |
             |   +------+--------+                     +---------------+    |   |                                     |
             |          |                                                   |   | fetch index.html +-----------+      |
             +----------+                                                   |   +------------------+  energy   |      |
                                                                            |   ^                  +-----------+      |
                                                                            |   |                                +----+
             +----------+                                                   |   |                                     |
             |          |                                                   |   | fetch index.html +-----------+      |
             |   +------v--------+                     +---------------+    |   +------------------+  health   |      |
             |   |               |                     |               |    |   ^                  +-----------+      |
      same top   |    imp-web    | <-----------------+ |   webpack     | <--+   |                                     |
             |   |               |    inject js&cdn    |               |        |                                     |
             |   +------+--------+                     +-------+-------+        | fetch index.html +-----------+      |
             |          |                                      ^                +------------------+  sas      |      |
             +----------+                                      |                                   +-----------+      |
                                                               |                                                      |
                                                               +------------------------------------------------------+
                                                                                     proxy rules

```

## doraemon-main：新基座改造

1. 将`imp基座`原有关键授权引入至`packages/desktop-components/lib/perssion`, 将cdn链接迁移至`vite.config.ts`【托管给vite】, 以及转发vite下的静态资源;

> cdn的目录在`public`下的`thirdjs`目录【copy至imp仓库下public】.

![perssion](images/image.png)

![cdn & index.html配置](images/image-1.png)

![vite代理本地静态资源（.env.development）](images/image-2.png)

2. 新应用和imp应用集合注册在`projects/imp-main/src/views/MicroAppView.vue`并在`mouted`钩子中调用**qiankun**提供的`start`完成应用表注册(**临时？**), 注册微应用相关配置统一在
   `projects/imp-main/src/helpers/micro.ts`下；

   > 另外：apps、router此列表，可以通过接口权限返回微应用列表后进行*异步批量*注册。

![微应用配置相关](images/image-3.png)

![apps](images/image-4.png)

![router](images/image-5.png)

## imp应用改造

> imp应用分3种形式：iframe, microApp(vue, react)，_菜单须支持iframe,微应用模式_;

- _react的imp应用_，之前按8个大类目录配置并关联`src/index.ts`作为入口，其余的应用入口都是自动读取这些大类下的`bootstrap.ts`和`index.ts`；所以集成到
  新基座`doraemon-main`下，仅针对性更改各大类下，涉及的上面2个ts文件即可，具体参看[此链接](http://iotgit.leedarson.com/lexikos/frontend/BMS-WEB/-/commit/3598ee9cfcdbeae277ef2687cedb9d9ebed5ea5e);

- _vue的imp应用_(实训管理，学习平台，实力筛查)，只要在`doraemon-main`上调试即可，基本零改造，仅须本地调试通过即可；

- iframe，业务端针对性的在`doraemon`创建一个具有iframe并动态修改src能力的容器即可(`此容器可以中台提供`);

## **react的imp应用**集成至`doraemon-main`改造点的相关注解

> [参看链接](http://iotgit.leedarson.com/lexikos/frontend/BMS-WEB/-/commit/3598ee9cfcdbeae277ef2687cedb9d9ebed5ea5e)

![改造点的重点注解](images/image-6.png)
