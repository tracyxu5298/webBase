# 创建公共包

1. 创建工具函数包

```shell
cd packages
npm init vite@latest

# ✔ Project name: … helper
# ✔ Select a framework: › Others
# ✔ Select a variant: › create-vite-extra ↗
# ✔ Select a template: › library
# ✔ Select a variant: › TypeScript
```

2. 创建 Vue 组件包

```shell
cd packages
npm init vite@latest

# ✔ Project name: … desktop-components
# ✔ Select a framework: › Vue
# ✔ Select a variant: › TypeScript
```
